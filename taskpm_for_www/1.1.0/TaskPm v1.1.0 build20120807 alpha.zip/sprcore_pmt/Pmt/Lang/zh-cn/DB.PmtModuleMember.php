<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='pmt_module_member'
//common.php:
$lanArray = array_merge($lanArray,include("DB.pmt_module_member.php"));
*/
return array(
'pmt_module_member'=>'模块成员',

'pmt_module_member.id'=>'ID',
'pmt_module_member.module_id'=>'项目',
'pmt_module_member.user_id'=>'成员',
'pmt_module_member.adv_begin_date'=>'预计开始时间',
'pmt_module_member.adv_end_date'=>'预计截至时间',
'pmt_module_member.user_rate'=>'使用率',);

?>