<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='pmt_version_project'
//common.php:
$lanArray = array_merge($lanArray,include("DB.pmt_version_project.php"));
*/
return array(
'pmt_version_project'=>'项目基线',

'pmt_version_project.project_id'=>'项目',
'pmt_version_project.name'=>'基线名称',
'pmt_version_project.memo'=>'基线描述',
'pmt_version_project.create_time'=>'创建时间',
'pmt_version_project.belong_user_id'=>'所属人',);

?>