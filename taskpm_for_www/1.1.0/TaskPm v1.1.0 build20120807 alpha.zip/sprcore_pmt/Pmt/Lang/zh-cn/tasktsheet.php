<?php
return array(
	'queryTaskTsheet.title'=>'查询工时填报',
	'saveTaskTsheetPage.title'=>'新增工时填报',
	'editTaskTsheetPage.title'=>'修改工时填报',
	'managerTaskTsheetPage.title'=>'修改工时填报',
	'viewTaskTsheetPage.title'=>'查看工时填报',
);

?>