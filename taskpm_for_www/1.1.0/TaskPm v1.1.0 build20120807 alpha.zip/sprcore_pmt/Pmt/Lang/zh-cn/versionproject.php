<?php
return array(
	'queryVersionProject.title'=>'查询项目基线',
	'saveVersionProjectPage.title'=>'新增项目基线',
	'editVersionProjectPage.title'=>'修改项目基线',
	'managerVersionProjectPage.title'=>'修改项目基线',
	'viewVersionProjectPage.title'=>'查看项目基线',
	
	'page.button.compareModule'=>'模块基线比较',
	'page.button.compareTask'=>'任务基线比较',
);

?>