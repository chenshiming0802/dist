<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='pmt_task_favorite'
//common.php:
$lanArray = array_merge($lanArray,include("DB.pmt_task_favorite.php"));
*/
return array(
'pmt_task_favorite'=>'任务收藏夹',

'pmt_task_favorite.id'=>'ID',
'pmt_task_favorite.task_id'=>'任务',
'pmt_task_favorite.type'=>'收藏类型',);

?>