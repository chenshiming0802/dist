<?php
return array(
	'queryModuleMs.title'=>'查询模块(里程碑)',
	'saveModuleMsPage.title'=>'新增模块(里程碑)',
	'editModuleMsPage.title'=>'修改模块(里程碑)',
	'managerModuleMsPage.title'=>'修改模块(里程碑)',
	'viewModuleMsPage.title'=>'查看模块(里程碑)',
);

?>