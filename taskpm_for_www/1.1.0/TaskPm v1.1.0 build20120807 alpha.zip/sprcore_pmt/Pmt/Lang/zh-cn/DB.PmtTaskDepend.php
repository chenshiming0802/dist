<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='pmt_task_depend'
//common.php:
$lanArray = array_merge($lanArray,include("DB.pmt_task_depend.php"));
*/
return array(
'pmt_task_depend'=>'前置任务',

'pmt_task_depend.id'=>'ID',
'pmt_task_depend.task_id'=>'项目',
'pmt_task_depend.depend_task_id'=>'前置任务',
'pmt_task_depend.depend_type'=>'前置关系',
'pmt_task_depend.delay_day'=>'延迟天数',);

?>