<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='pmt_message_re'
//common.php:
$lanArray = array_merge($lanArray,include("DB.pmt_message_re.php"));
*/
return array(
'pmt_message_re'=>'消息回复',

'pmt_message_re.table_id'=>'任务',
'pmt_message_re.table_name'=>'名称',
'pmt_message_re.title'=>'标题',
'pmt_message_re.content'=>'内容',);

?>