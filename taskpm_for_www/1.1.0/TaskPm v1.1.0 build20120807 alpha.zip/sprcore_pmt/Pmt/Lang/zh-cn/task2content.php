<?php
return array(
	'queryTask2Content.title'=>'查询任务信息_内容',
	'saveTask2ContentPage.title'=>'新增任务信息_内容',
	'editTask2ContentPage.title'=>'修改任务信息_内容',
	'managerTask2ContentPage.title'=>'修改任务信息_内容',
	'viewTask2ContentPage.title'=>'查看任务信息_内容',
);

?>