<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='pmt_module'
//common.php:
$lanArray = array_merge($lanArray,include("DB.pmt_module.php"));
*/
return array(
'pmt_module'=>'模块',

'pmt_module.id'=>'ID',
'pmt_module.project_id'=>'项目',
'pmt_module.module_type_id'=>'模块类型',
'pmt_module.code'=>'模块代码',
'pmt_module.status'=>'模块状态',
'pmt_module.name'=>'模块名称',
'pmt_module.proirity'=>'优先级',
'pmt_module.manager_id'=>'模块负责人',
'pmt_module.adv_person_day'=>'预计人日',
'pmt_module.adv_begin_date'=>'预计开始',
'pmt_module.adv_end_date'=>'预计结束',
'pmt_module.url'=>'链接地址',
'pmt_module.depend_module_id'=>'依赖模块',
'pmt_module.content'=>'描述',
'pmt_module.adv_progress'=>'计划进度',
'pmt_module.tsh_progress'=>'工时进度',
'pmt_module.act_progress'=>'实际进度',);

?>