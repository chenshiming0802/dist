<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='sys_tool_table_field2'
//common.php:
$lanArray = array_merge($lanArray,include("DB.sys_tool_table_field2.php"));
*/
return array(
'sys_tool_table_field2'=>'生成器配置子表',

'sys_tool_table_field2.id'=>'ID',
'sys_tool_table_field2.table_id'=>'表名',
'sys_tool_table_field2.field_name'=>'字段名',
'sys_tool_table_field2.field_desc'=>'描述',
'sys_tool_table_field2.field_type'=>'字段类型',
'sys_tool_table_field2.field_type_value'=>'字段类型值（代码）',
'sys_tool_table_field2.field_type_desc_value'=>'字段类型值（非代码）',
'sys_tool_table_field2.field_class'=>'值限制',
'sys_tool_table_field2.size_display'=>'显示长度',
'sys_tool_table_field2.size_max'=>'最大长度',
'sys_tool_table_field2.item_line_class'=>'ITEM CLS',
'sys_tool_table_field2.item_control_class'=>'CRL CLS',
'sys_tool_table_field2.has_query_clause'=>'是否查询条件',
'sys_tool_table_field2.has_query_result'=>'是否查询结果',
'sys_tool_table_field2.field_no'=>'字段顺序',
'sys_tool_table_field2.item_control_param'=>'控件参数',
'sys_tool_table_field2.item_info'=>'INFO',);

?>