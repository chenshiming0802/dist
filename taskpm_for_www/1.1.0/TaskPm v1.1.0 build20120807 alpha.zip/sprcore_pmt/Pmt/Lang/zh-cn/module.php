<?php
return array(
	'queryModule.title'=>'查询模块',
	'saveModulePage.title'=>'新增模块',
	'editModulePage.title'=>'修改模块',
	'managerModulePage.title'=>'修改模块',
	'viewModulePage.title'=>'查看模块',
);

?>