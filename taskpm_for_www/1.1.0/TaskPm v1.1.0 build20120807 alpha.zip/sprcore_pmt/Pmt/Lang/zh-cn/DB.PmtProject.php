<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='pmt_project'
//common.php:
$lanArray = array_merge($lanArray,include("DB.pmt_project.php"));
*/
return array(
'pmt_project'=>'项目信息_内容',

'pmt_project.manager_id'=>'项目经理',
'pmt_project.adv_begin_date'=>'预计开始时间',
'pmt_project.adv_end_date'=>'预计结束时间',
'pmt_project.status'=>'状态',
'pmt_project.id'=>'ID',
'pmt_project.code'=>'项目编码',
'pmt_project.name'=>'项目名称',
'pmt_project.customer_name'=>'项目客户',
'pmt_project.project_level'=>'项目级别',
'pmt_project.content'=>'项目描述',
'pmt_project.url'=>'链接地址',
'pmt_project.config_user_id'=>'配置管理员',
'pmt_project.security_type'=>'安全级别',


);

?>