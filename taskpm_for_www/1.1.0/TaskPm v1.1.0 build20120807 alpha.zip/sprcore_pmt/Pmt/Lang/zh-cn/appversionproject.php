<?php
return array(
 	'page.button.task'=>'任务',
 	'compareModule.title'=>'模块基线比较',
 	'compareTask.title'=>'任务基线比较',
);

?>