<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='pmt_employee_assign'
//common.php:
$lanArray = array_merge($lanArray,include("DB.pmt_employee_assign.php"));
*/
return array(
'pmt_employee_assign'=>'资源分配单',

'pmt_employee_assign.id'=>'ID',
'pmt_employee_assign.status'=>'状态',
'pmt_employee_assign.employee_id'=>'职员',
'pmt_employee_assign.project_id'=>'项目',
'pmt_employee_assign.project_joblevel_id'=>'项目成员属性',
'pmt_employee_assign.joblevel_id'=>'岗位',
'pmt_employee_assign.company_id'=>'所属公司',
'pmt_employee_assign.memo'=>'备注',
'pmt_employee_assign.year'=>'年份',
'pmt_employee_assign.m1'=>'1月',
'pmt_employee_assign.m2'=>'2月',
'pmt_employee_assign.m3'=>'3月',
'pmt_employee_assign.m4'=>'4月',
'pmt_employee_assign.m5'=>'5月',
'pmt_employee_assign.m6'=>'6月',
'pmt_employee_assign.m7'=>'7月',
'pmt_employee_assign.m8'=>'8月',
'pmt_employee_assign.m9'=>'9月',
'pmt_employee_assign.m10'=>'10月',
'pmt_employee_assign.m11'=>'11月',
'pmt_employee_assign.m12'=>'12月',);

?>