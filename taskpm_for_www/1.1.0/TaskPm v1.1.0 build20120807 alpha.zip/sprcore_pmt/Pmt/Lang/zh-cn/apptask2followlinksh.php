<?php
return array(
	'viewTask2FollowLinkPage.title'=>'查看任务信息_上线任务清单'
 
);

?>