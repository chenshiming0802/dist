<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='sys_version'
//common.php:
$lanArray = array_merge($lanArray,include("DB.sys_version.php"));
*/
return array(
'sys_version'=>'基线版本',

'sys_version.table_name'=>'数据表',
'sys_version.table_id'=>'数据ID',
'sys_version.name'=>'基线名称',
'sys_version.memo'=>'基线描述',
'sys_version.create_time'=>'创建时间',);

?>