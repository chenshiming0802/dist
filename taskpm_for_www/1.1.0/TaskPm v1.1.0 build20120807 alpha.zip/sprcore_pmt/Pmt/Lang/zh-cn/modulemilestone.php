<?php
return array(
	'queryModuleMilestone.title'=>'查询模块里程碑',
	'saveModuleMilestonePage.title'=>'新增模块里程碑',
	'editModuleMilestonePage.title'=>'修改模块里程碑',
	'managerModuleMilestonePage.title'=>'修改模块里程碑',
	'viewModuleMilestonePage.title'=>'查看模块里程碑',
);

?>