<?php
return array(
	'queryTaskTsheet.title'=>'查询工时填报',
	'getSheetInfoFromProjectModuleTask.title'=>'查看任务信息_时间进度',
	'fillQucikTsheetPage.title'=>'工时填写',

	'pmt_task_tsheet.belong_user_id'=>'员工',
	'pmt_task_tsheet.tsheet_hours_020'=>'待审',
	'pmt_task_tsheet.tsheet_hours_030'=>'驳回',
	'pmt_task_tsheet.tsheet_hours_100'=>'已审',


	'baosight.1'=>'工号',
	'baosight.2'=>'员工姓名',
	'baosight.3'=>'周末日',
	'baosight.4'=>'工作日',
	'baosight.5'=>'项目编号',
	'baosight.6'=>'项目名称',
	'baosight.7'=>'任务描述',
	'baosight.8'=>'工作模块',
	'baosight.9'=>'正常',
	'baosight.10'=>'加班',
	'baosight.11'=>'运维电话数',
	'baosight.12'=>'工作技能',
	'baosight.13'=>'工作态度',
	'baosight.14'=>'工作负荷',
	'baosight.15'=>'工作质量',
	'baosight.16'=>'人员去向',
	'baosight.17'=>'人员类型',
);

?>