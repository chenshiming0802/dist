<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='sys_tool_table2'
//common.php:
$lanArray = array_merge($lanArray,include("DB.sys_tool_table2.php"));
*/
return array(
'sys_tool_table2'=>'生成器配置表',

'sys_tool_table2.id'=>'ID',
'sys_tool_table2.table_name'=>'表名',
'sys_tool_table2.table_desc'=>'描述',
'sys_tool_table2.code_module'=>'代码模块名',
'sys_tool_table2.code_module_method'=>'代码方法名',
'sys_tool_table2.table_has_status'=>'是否有状态',
'sys_tool_table2.table_status_field'=>'主表状态字段',
'sys_tool_table2.table_status_save'=>'主表草稿状态',
'sys_tool_table2.table_status_submit'=>'主表提交状态',
'sys_tool_table2.child_type'=>'子项新增类型',
'sys_tool_table2.child_type_value'=>'子项新增类型值',
'sys_tool_table2.is_tree'=>'是否树形',
'sys_tool_table2.tree_parent_field'=>'树形父结点字段',
'sys_tool_table2.table_info'=>'相关属性',
'sys_tool_table2.query_sql_method'=>'查询SQL方法',
'sys_tool_table2.before_query_method'=>'Action查询前的方法',
'sys_tool_table2.before_update_page_method'=>'Action修改页前的方法',
'sys_tool_table2.before_add_method'=>'Action新增前的方法',
'sys_tool_table2.before_update_method'=>'Action修改前的方法',
'sys_tool_table2.before_delete_method'=>'Action删除前的方法',
'sys_tool_table2.before_get_method'=>'ActionGet前的方法',
'sys_tool_table2.after_query_method'=>'Action查询后的方法',
'sys_tool_table2.after_update_page_method'=>'Action修改页后的方法',
'sys_tool_table2.after_update_method'=>'Action修改后的方法',
'sys_tool_table2.after_delete_method'=>'Action删除后的方法',
'sys_tool_table2.after_get_method'=>'ActionGet后的方法',
'sys_tool_table2.after_db_query_method'=>'Query后的方法',
'sys_tool_table2.after_db_add_method'=>'新增后的方法',
'sys_tool_table2.after_db_update_method'=>'修改后的方法',
'sys_tool_table2.after_db_au_method'=>'增改后的方法',
'sys_tool_table2.after_db_delete_method'=>'删除后的方法',
'sys_tool_table2.after_db_get_method'=>'Get后的方法',
'sys_tool_table2.before_db_add_method'=>'修改前的方法',
'sys_tool_table2.before_db_update_method'=>'修改前的方法',
'sys_tool_table2.before_db_au_method'=>'增改前的方法',
'sys_tool_table2.before_db_delete_method'=>'删除前的方法',
'sys_tool_table2.before_db_get_method'=>'Get前的方法',
'sys_tool_table2.after_view_query_method'=>'VIEW查询后',
'sys_tool_table2.after_view_add_method'=>'VIEW新增后',
'sys_tool_table2.after_view_update_method'=>'VIEW修改后',
'sys_tool_table2.after_view_get_method'=>'VIEW查看后',
'sys_tool_table2.add_default_value_method'=>'创建时加默认',);

?>