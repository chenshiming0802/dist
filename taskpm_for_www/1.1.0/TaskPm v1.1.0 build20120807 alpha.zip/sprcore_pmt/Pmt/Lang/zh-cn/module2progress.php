<?php
return array(
	'queryModule2Progress.title'=>'查询模块_时间进度',
	'saveModule2ProgressPage.title'=>'新增模块_时间进度',
	'editModule2ProgressPage.title'=>'修改模块_时间进度',
	'managerModule2ProgressPage.title'=>'修改模块_时间进度',
	'viewModule2ProgressPage.title'=>'查看模块_时间进度',
	
'pmt_module.table_id'=>'项目',
'pmt_module.table_name'=>'名称',
'pmt_module.adv_begin_date'=>'预计开始时间',
'pmt_module.adv_end_date'=>'预计结束时间',
'pmt_module.adv_work_day'=>'预计工期',
'pmt_module.adv_person_day'=>'预计人日',
'pmt_module.adv_progress'=>'计划进度',
'pmt_module.act_begin_date'=>'实际开始时间[废除]',
'pmt_module.act_end_date'=>'实际结束时间[废除]',
'pmt_module.act_work_day'=>'实际工期',
'pmt_module.act_person_day'=>'实际耗时',
'pmt_module.act_progress'=>'实际进度',
'pmt_module.tsh_begin_date'=>'工时开始时间',
'pmt_module.tsh_end_date'=>'工时结束时间',
'pmt_module.tsh_work_day'=>'工时工期',
'pmt_module.tsh_person_day'=>'实际工时',
'pmt_module.tsh_person_normal_day'=>'正常工时(H)',
'pmt_module.tsh_person_over_day'=>'加班工时(H)',
'pmt_module.tsh_progress'=>'实际工时进度',		
);

?>