<?php
return array(
	'pmt_task.emergency_degree'=>'紧急程度',
	'viewEmployeeTask.title'=>'成员任务',
	'queryTaskList.title'=>'任务查询',
	'queryDocuments.title'=>'查看任务信息_任务附件',

);

?>