<?php
$lanArray = array(
);
$lanArray = array_merge(include(SPR_INDEX_PATH."/lang/".LANG_SET."/common.php"),$lanArray);
//数据库语言包
$lanArray = array_merge($lanArray,include("DB.PmtProject.php"));
$lanArray = array_merge($lanArray,include("DB.PmtProjectMember.php"));
$lanArray = array_merge($lanArray,include("DB.PmtModule.php"));
$lanArray = array_merge($lanArray,include("DB.PmtModuleMember.php"));
$lanArray = array_merge($lanArray,include("DB.PmtModuleMilestone.php"));
$lanArray = array_merge($lanArray,include("DB.PmtTask.php"));
$lanArray = array_merge($lanArray,include("DB.PmtTaskMember.php"));
$lanArray = array_merge($lanArray,include("DB.PmtTaskTsheet.php"));
$lanArray = array_merge($lanArray,include("DB.PmtTaskDepend.php"));
$lanArray = array_merge($lanArray,include("DB.PmtProgress.php"));
$lanArray = array_merge($lanArray,include("DB.SysVersion.php"));
$lanArray = array_merge($lanArray,include("DB.PmtVersionProject.php"));
$lanArray = array_merge($lanArray,include("DB.PmtDocument.php"));
$lanArray = array_merge($lanArray,include("DB.PmtTaskFollow.php"));
$lanArray = array_merge($lanArray,include("DB.PmtEmployee.php"));
$lanArray = array_merge($lanArray,include("DB.PmtEmployeeAssign.php"));


$lanArray = array_merge($lanArray,array(
	"page.button.plan"=>"计划",
	"page.button.cycle"=>"生命周期",
	"page.button.filltimesheet"=>"填写工时",
	"page.button.taskprocess"=>"处理任务",
	"page.button.fillprogress"=>"汇报进度",
	"page.button.moveprogress"=>"移动任务",
	"pmt_task.act_progress"=>"实际进度",
	"pmt_task.act_progress_desc"=>"当前进度描述",
	"page.button.finish.task"=>"完成任务",
	"page.button.close.task"=>"关闭任务",
	"page.button.unfinish.task"=>"激活任务",
 	'label.grid_display_milestone'=>'显示里程碑',
 	'page.button.viewTimeSheetWeek'=>'任务周视图',

 	'page.button.active.module'=>'激活模块',
 	'page.button.stop.module'=>'暂停模块',
 	'page.button.finish.module'=>'完成模块',
 	'page.button.close.module'=>'关闭模块',
 	'page.button.fillQucikTsheet'=>'快速填写工时',
 	'page.button.convert.directory'=>'转为任务目录',
 	'page.button.convert.page'=>'转为任务叶子',
 	'page.button.list.task'=>'查看任务清单',
 	'page.button.list.module'=>'查看模块清单',

 	'message.exception.task.nofollow'=>'任务没有对应的后续任务#{0}',
 	'message.exception.task.alreadyfollow'=>'任务已经有对应的后续任务#{0}',

));


return $lanArray;

?>