<?php
return array(
	'queryproject2Content.title'=>'查询项目信息_内容',
	'saveproject2ContentPage.title'=>'新增项目信息_内容',
	'editproject2ContentPage.title'=>'修改项目信息_内容',
	'managerproject2ContentPage.title'=>'修改项目信息_内容',
	'viewproject2ContentPage.title'=>'查看项目信息_内容',
);

?>