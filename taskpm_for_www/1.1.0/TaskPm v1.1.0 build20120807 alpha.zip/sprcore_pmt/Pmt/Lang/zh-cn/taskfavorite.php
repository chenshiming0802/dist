<?php
return array(
	'queryTaskFavorite.title'=>'查询任务收藏夹',
	'saveTaskFavoritePage.title'=>'新增任务收藏夹',
	'editTaskFavoritePage.title'=>'修改任务收藏夹',
	'managerTaskFavoritePage.title'=>'修改任务收藏夹',
	'viewTaskFavoritePage.title'=>'查看任务收藏夹',
);

?>