<?php
return array(
'WEB_MAX_OBJECT'=>array('uup_user'=>20),
'PRIVATE_SN'=>'c339b6ad1fa5ccae85c62dd06a36ce49',
);
?>
