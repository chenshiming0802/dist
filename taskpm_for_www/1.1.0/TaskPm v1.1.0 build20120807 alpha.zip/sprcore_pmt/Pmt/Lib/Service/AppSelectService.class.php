<?php
class AppSelectService extends SrService
{
 	public function queryUnFollowTask($spModel){
		$srModel = array();
		$sql = "select t1.* from pmt_task t1,pmt_task_follow t2  where t1.id=t2.task_id and (t2.follow_task_id is null or t2.follow_task_id='0') /*w[t1,t2]*/";
		$sql .= self::getCauseIfNotNull("t1.code like '%{0}%'",$spModel["query_code"]);
		$sql .= self::getCauseIfNotNull("t1.name like '%{0}%'",$spModel["query_name"]);
		$sql .= self::getCauseIfNotNull("t1.type like '%{0}%'",$spModel["query_type"]);
		$sql .= self::getCauseIfNotNull("t1.project_id = '{0}'",$spModel["query_project_id"]);
		$sql .= self::getCauseIfNotNull("t1.status = '{0}'",$spModel["query_status"]);

		$sql .= self::getCauseIfNotNull("t.id not in ({0})",$spModel["no_in_ids"]);
		$sql .= " order by t2.id desc";
 		$srModel = self::queryPageBySql($sql);
 		
		foreach($srModel['list'] as $k=>$model){
			$srModel2 = self::invokeBusiness("AppCommonBusiness","progress_getRow",array('table_id'=>$model["id"],'table_name'=>'pmt_task'),'@');
			$model = Sr::sys_copyProperties($model,$srModel2);
			$srModel['list'][$k] = $model;			
		} 		
		self::addInfoResults($srModel,null);
		return $srModel;
	}

 	public function queryEmployeeAssignInfo($spModel){
 		//dump($spModel);
		$srModel = array();
		$where = "";
		$where .= self::getCauseIfNotNull("t1.emp_no like '%{0}%'",$spModel["query_emp_no"]);
		$where .= self::getCauseIfNotNull("t1.name like '%{0}%'",$spModel["query_name"]);
		$where .= self::getCauseIfNotNull("t1.joblevel_id = '{0}'",$spModel["query_joblevel_id"]);
		$where .= self::getCauseIfNotNull("t1.company_id = '{0}'",$spModel["query_company_id"]);
		$where .= self::getCauseIfNotNull("t1.status = '{0}'",$spModel["query_status"]);
		$where .= self::getCauseIfNotNull("t1.belong_org_id = '{0}'",SrUser::getOrgId());
		
		if(array_key_exists("query_month",$spModel)){
			foreach($spModel['query_month'] as $k=>$v){
				$where .= self::getCauseIfNotNull("t2.m{$v} < 100",$v);
			}
		}

		$where .= self::getCauseIfNotNull("t1.id not in ({0})",str_replace("|",",",$spModel["no_in_ids"]));
		$sql = "SELECT
  t1.id             employee_id,
  t1.emp_no,
  t1.name,
  t1.joblevel_id,
  t1.company_id,
  t1.status,
  ifnull(SUM(t2.m1),0)        m1,
  ifnull(SUM(t2.m2),0)        m2,
  ifnull(SUM(t2.m3),0)        m3,
  ifnull(SUM(t2.m4),0)        m4,
  ifnull(SUM(t2.m5),0)        m5,
  ifnull(SUM(t2.m6),0)        m6,
  ifnull(SUM(t2.m7),0)        m7,
  ifnull(SUM(t2.m8),0)        m8,
  ifnull(SUM(t2.m9),0)        m9,
  ifnull(SUM(t2.m10),0)       m10,
  ifnull(SUM(t2.m11),0)       m11,
  ifnull(SUM(t2.m12),0)       m12
FROM pmt_employee t1
  LEFT JOIN pmt_employee_assign t2
    ON t1.id = t2.employee_id
      AND t2.status = '020'/*w[t2]*/
WHERE 1 = 1
 /*w[t1]*/ {$where}
GROUP BY t1.id,t1.emp_no,t1.name,t1.joblevel_id,t1.company_id,t1.status ";
		$sql .= " order by t1.id desc";
 		$srModel = self::queryPageBySql($sql);	
		self::addInfoResults($srModel,null);
		return $srModel;
	} 
	
 	public function queryUupUser($spModel){
		$srModel = array();
		
		$sql = "select t.*,t.id user_id from uup_user t where t.org_id=".SrUser::getOrgId()." /*w[t]*/";
		$sql .= self::getCauseIfNotNull("t.code like '%{0}%'",$spModel["query_code"]);
		$sql .= self::getCauseIfNotNull("t.name like '%{0}%'",$spModel["query_name"]);

		$sql .= self::getCauseIfNotNull("t.id not in ({0})",$spModel["no_in_ids"]);
		$sql .= " order by t.id desc";
 		$srModel = self::queryPageBySql($sql);
 		
 	
		self::addInfoResults($srModel,null);
		return $srModel;
	}	

}//end class

?>