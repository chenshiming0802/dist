<?php
class AppVersionProjectService extends SrService{	
	public function displayVersionCompare($spModel){
		$project_id = $spModel['project_id'];
		$srModel = array();
		
		self::addInfoResults($srModel,null);
		return $srModel;		
	}
	
	public function compareModule($spModel){
		$project_id = $spModel['query_project_id'];
		$version_id_1 = $spModel['version_id_1'];
		$version_id_2 = $spModel['version_id_2'];
		$srModel = array();
		
		if($project_id!=null && $version_id_1!=null && $version_id_2!=null){
			$sql = "select t.*,concat(t.status,'@PMT03@DICT') _gridGroupSort_ from pmt_module t where t.project_id={0} /*w[t]*/";
			$list = self::queryBySql($sql,array($project_id));
			$list1 = array();
			$list2 = array();
			//获取数据List
			foreach($list as $k=>$model){
				$mid = $model['id'];
				$data1 = self::getModuleVersion($model,$version_id_1);
				$data2 = self::getModuleVersion($model,$version_id_2);
				$list1[] = $data1;
				$list2[] = $data2;
			}
			//转换成比较过的基线数据
			$srModel2 = SrRowVersion::fillCompareRow(array(
				'list1'=>$list1,
				'list2'=>$list2,
				'keyField'=>'id',
				'fields'=>array(
					'adv_begin_date',
					'adv_end_date',
					'adv_work_day',
					'adv_person_day',
					'adv_progress',
					//'act_begin_date',
					//'act_end_date',
					//'act_work_day',
					//'act_person_day',
					'act_progress',
					'act_progress_desc',
					'tsh_begin_date',
					'tsh_end_date',
					'tsh_work_day',
					'tsh_person_day',
					'tsh_person_normal_day',
					'tsh_person_over_day',
					'tsh_progress',
					'table_status_desc'),
			));
			$srModel['list'] = $srModel2['list'];			
		}
			
		self::addInfoResults($srModel,null);
		return $srModel;		
	}
	private function getModuleVersion($model,$versionId){
		if($versionId=='-1'){
			$srModel2 = self::invokeBusiness("AppCommonBusiness","progress_getRow",array('table_id'=>$model["id"],'table_name'=>'pmt_module'),'@');
			$model = Sr::sys_copyProperties($model,$srModel2);
			$model = self::getValue_invokeBusiness("AppCommonBusiness","module_calcProgress",$model,'@','spModel');	
			$model['table_status'] = $model['status'];
			$model['table_status_desc'] = SrDict::getValueName('PMT03',$model['table_status']);
		}else{
			$srModel2 = self::invokeBusiness("AppCommonBusiness","progress_version_getRow",array('table_id'=>$model["id"],'table_name'=>'pmt_module','spr_version_id'=>$versionId),'@');
			$model = Sr::sys_copyProperties($model,$srModel2);
			$model = self::getValue_invokeBusiness("AppCommonBusiness","module_calcProgress",$model,'@','spModel');	
			$model['table_status_desc'] = SrDict::getValueName('PMT03',$model['table_status']);			
		}
		return $model;
	}
	
	
	public function compareTask($spModel){
		$project_id = $spModel['query_project_id'];
		$module_id = $spModel['query_module_id'];
		$version_id_1 = $spModel['version_id_1'];
		$version_id_2 = $spModel['version_id_2'];
		$srModel = array();
		
		if($project_id!=null && $version_id_1!=null && $version_id_2!=null){
			$where = '';
			$where .= self::getCauseIfNotNull("t.project_id = '{0}'",$spModel["query_project_id"]);		
			$where .= self::getCauseIfNotNull("t.module_id = '{0}'",$spModel["query_module_id"]);					
			$sql = "SELECT t.*,t.id _childCode_,t.parent_task_id _parentCode_,t.no _childSortNo_   FROM pmt_task t ,pmt_progress t1  WHERE t.is_deleted='0' AND t.id=t1.table_id AND t1.table_name='pmt_task' {$where} order by t.id desc"; 
 			$list = self::queryTreeViewBySql2($sql,array(),'name');			
			
			$list1 = array();
			$list2 = array();
			//获取数据List
			foreach($list as $k=>$model){
				$mid = $model['id'];
				$data1 = self::getTaskVersion($model,$version_id_1);
				$data2 = self::getTaskVersion($model,$version_id_2);
				$list1[] = $data1;
				$list2[] = $data2;
			}
			//转换成比较过的基线数据
			$srModel2 = SrRowVersion::fillCompareRow(array(
				'list1'=>$list1,
				'list2'=>$list2,
				'keyField'=>'id',
				'fields'=>array(
					'adv_begin_date',
					'adv_end_date',
					'adv_work_day',
					'adv_person_day',
					'adv_progress',
					//'act_begin_date',
					//'act_end_date',
					//'act_work_day',
					//'act_person_day',
					'act_progress',
					'act_progress_desc',
					'tsh_begin_date',
					'tsh_end_date',
					'tsh_work_day',
					'tsh_person_day',
					'tsh_person_normal_day',
					'tsh_person_over_day',
					'tsh_progress',
					'table_status_desc'),
			));
			$srModel['list'] = $srModel2['list'];			
		}
			
		self::addInfoResults($srModel,null);
		return $srModel;			
	}	
	
	private function getTaskVersion($model,$versionId){
		if($versionId=='-1'){
			$srModel2 = self::invokeBusiness("AppCommonBusiness","progress_getRow",array('table_id'=>$model["id"],'table_name'=>'pmt_task'),'@');
			$model = Sr::sys_copyProperties($model,$srModel2);
			$model = self::getValue_invokeBusiness("AppCommonBusiness","task_calcProgress",$model,'@','spModel');
			$model['table_status'] = $model['status'];
			$model['table_status_desc'] = SrDict::getValueName('PMT04',$model['table_status']);	

		}else{
			$srModel2 = self::invokeBusiness("AppCommonBusiness","progress_version_getRow",array('table_id'=>$model["id"],'table_name'=>'pmt_task','spr_version_id'=>$versionId),'@');
			$model = Sr::sys_copyProperties($model,$srModel2);
			$model = self::getValue_invokeBusiness("AppCommonBusiness","module_calcProgress",$model,'@','spModel');	
			$model['table_status_desc'] = SrDict::getValueName('PMT04',$model['table_status']);		
			//dump($model);halt();
		}
		return $model;
	}		
}
?>
