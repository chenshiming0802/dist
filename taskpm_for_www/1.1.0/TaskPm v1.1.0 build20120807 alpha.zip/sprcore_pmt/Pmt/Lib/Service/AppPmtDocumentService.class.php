<?php
class AppPmtDocumentService extends SrService{
	public function queryDocuments($spModel) {
		$srModel = array ();
		$table_id = $spModel["table_id"];
		$table_name = $spModel["table_name"];
		$table_ids = $spModel["table_ids"];
		$where = '';

		$sql = "
SELECT t.* FROM pmt_document t,pmt_document_link t1
WHERE t.id=t1.document_id
AND t1.table_name='{0}' and t.status<>'000' and t.is_current_version='1'
AND t1.table_id in ({1})
{$where} /*w[t,t1]*/
		";
		$srModel['list'] = self :: queryBySql($sql,array($table_name,$table_id));
		$srModel['other_list'] = self :: queryBySql($sql,array($table_name,$table_ids));

		self :: addInfoResults($srModel, null);
		return $srModel;
	}
	public function queryDocumentsByCurrentVersionId($spModel) {
		$srModel = array ();
		$current_version_id = $spModel["current_version_id"];


		$sql = "
SELECT t.* FROM pmt_document t,pmt_document_link t1
WHERE t.id=t1.document_id
AND  t.status<>'000'
 /*w[t,t1]*/ and t.current_version_id='{0}' order by t.current_version_id asc
		";
		$srModel['list'] = self :: queryBySql($sql,array($current_version_id));

		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function uploadDocumentFilePage($spModel) {

		$srModel = array ();
		$table_id = $spModel["table_id"];
		$table_name = $spModel["table_name"];
		$table_ids = $spModel["table_ids"];
		$old_document_id = $spModel["old_document_id"];
		$srModel['old_document'] = self::queryById2($old_document_id,'pmt_document');


		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function uploadDocumentFile($spModel) {
		if(SrUser::isVisitor()===true){
			throw_exception(Sr::sys_l("message.exception.result.dueto.vistor",array()));
		}
		$srModel = array ();
		$path_id = $spModel["path_id"];
		$table_id = $spModel["table_id"];
		$table_name = $spModel["table_name"];
		$old_document_id = $spModel["old_document_id"];


		if ($_FILES["file"]["error"] > 0){
	    	echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
	    }else{
	    	$fileName = $_FILES["file"]["name"];
	    	$ostream = $_FILES["file"]["type"];
	    	$size = $_FILES["file"]["size"];
	    	$ext = end(explode('.',$_FILES["file"]["name"]));
	    	if(in_array($ext,c('UPLOADFILE_EXCEPTION_EXTS'))){
	    		throw_exception(Sr::sys_l("message.exception.upload.dueto.extinvalid",array()));
	    	}

	 		$tmp_name = $_FILES["file"]["tmp_name"];

			//上传文件
 			$newFileName = time().'.'.$ext;
 			$rootPath = c('FILE_BASE_ROOT');
 			//halt($rootPath);
 			$path = date('Y/m/');
 			$newPath = $rootPath.$path;
 			Sr::sys_createFolder($newPath);
	   		move_uploaded_file($_FILES["file"]["tmp_name"],$newPath . $newFileName);
	   		$docuemnt = array();
	   		$docuemnt['document_type'] = '010';
	   		$docuemnt['title'] = $fileName;
	   		$docuemnt['status'] = '000';
	   		$docuemnt['document_version'] = '0';
			$docuemnt = self::insert2($docuemnt,'pmt_document');



			$tfile = array();
			$tfile['document_id'] = $docuemnt['id'];
			$tfile['original_document_name'] = $fileName;
			$tfile['download_document_name'] = $newFileName;
			$tfile['path'] = $path;
			$tfile['file_ext'] = $ext;
			$tfile['file_ostream'] = $ostream;
			$tfile['file_size'] = $size;
			$tfile = self::insert2($tfile,'pmt_document_tfile');
 			$document_id = $docuemnt['id'];



			//如果是升级,则计算版本值
			$document_version = 1;
			$current_version_id = $document_id;
			if($old_document_id!=null&&$old_document_id!=''){
				$old_document = self::queryById2($old_document_id,"pmt_document");
				$document_version = (int)$old_document['document_version'] + 1;
				$current_version_id = $old_document['current_version_id'];
				$old_document['is_current_version'] = '0';
				self::update2($old_document_id,$old_document,'pmt_document');

			}

		   	//设置关联
	   		$link = array();
	   		$link['table_id'] = $table_id;
	   		$link['table_name'] = $table_name;
	   		$link['document_id'] = $document_id;
	   		$link['path_id'] = $path_id;
			$link = self::insert2($link,'pmt_document_link');
			$docuemnt['status'] = '100';
			$docuemnt['is_current_version'] = '1';
			$docuemnt['current_version_id'] = $current_version_id;
			$docuemnt['document_version'] = $document_version;
			self::update2($docuemnt['id'],$docuemnt,'pmt_document');
	   	}


		self :: addInfoResults($srModel, null);
		return $srModel;
	}
	/**
	 * 自动匹配同名文件
	 *
	 */
//	public function uploadDocumentFile($spModel) {
//		if(SrUser::isVisitor()===true){
//			throw_exception(Sr::sys_l("message.exception.result.dueto.vistor",array()));
//		}
//		$srModel = array ();
//		$path_id = $spModel["path_id"];
//		$table_id = $spModel["table_id"];
//		$table_name = $spModel["table_name"];
////		$table_ids = $spModel["table_ids"];
//
//		if ($_FILES["file"]["error"] > 0){
//	    	echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
//	    }else{
//	    	$fileName = $_FILES["file"]["name"];
//	    	$ostream = $_FILES["file"]["type"];
//	    	$size = $_FILES["file"]["size"];
//	    	$ext = end(explode('.',$_FILES["file"]["name"]));
//	    	if(in_array($ext,c('UPLOADFILE_EXCEPTION_EXTS'))){
//	    		throw_exception(Sr::sys_l("message.exception.upload.dueto.extinvalid",array()));
//	    	}
//
//	 		$tmp_name = $_FILES["file"]["tmp_name"];
//
//			//上传文件
// 			$newFileName = time().'.'.$ext;
// 			$rootPath = c('FILE_BASE_ROOT');
// 			//halt($rootPath);
// 			$path = date('Y/m/');
// 			$newPath = $rootPath.$path;
// 			Sr::sys_createFolder($newPath);
//	   		move_uploaded_file($_FILES["file"]["tmp_name"],$newPath . $newFileName);
//	   		$docuemnt = array();
//	   		$docuemnt['document_type'] = '010';
//	   		$docuemnt['title'] = $fileName;
//	   		$docuemnt['status'] = '000';
//	   		$docuemnt['document_version'] = '0';
//			$docuemnt = self::insert2($docuemnt,'pmt_document');
//			$tfile = array();
//			$tfile['document_id'] = $docuemnt['id'];
//			$tfile['original_document_name'] = $fileName;
//			$tfile['download_document_name'] = $newFileName;
//			$tfile['path'] = $path;
//			$tfile['file_ext'] = $ext;
//			$tfile['file_ostream'] = $ostream;
//			$tfile['file_size'] = $size;
//			$tfile = self::insert2($tfile,'pmt_document_tfile');
// 			$document_id = $docuemnt['id'];
//
// 			//处理文件关系
// 			$sql = "SELECT t.* FROM  pmt_document t   WHERE t.title='{0}' and t.status<>'000' and t.is_current_version='1' /*w[t]*/";
// 			$dup_list = self::queryBySql($sql,array($fileName));
// 			if(count($dup_list)>0){
// 				//查找文件是否已经存在
// 				$srModel['dup_list'] = $dup_list;
// 				$srModel['document_id'] = $document_id;
// 			}else{
//		   		//设置关联
//	   			$link = array();
//	   			$link['table_id'] = $table_id;
//	   			$link['table_name'] = $table_name;
//	   			$link['document_id'] = $document_id;
//	   			$link['path_id'] = $path_id;
//				$link = self::insert2($link,'pmt_document_link');
//
//				$docuemnt['status'] = '100';
//				$docuemnt['is_current_version'] = '1';
//				$docuemnt['current_version_id'] = $document_id;
//				$docuemnt['document_version'] = '1';
//				self::update2($docuemnt['id'],$docuemnt,'pmt_document');
// 			}
//	   	}
//
//
//		self :: addInfoResults($srModel, null);
//		return $srModel;
//	}

	public function uploadDocumentUrl($spModel) {
		$srModel = array ();
		$path_id = $spModel["path_id"];
		$table_id = $spModel["table_id"];
		$table_name = $spModel["table_name"];
		$old_document_id = $spModel["old_document_id"];

//		$table_ids = $spModel["table_ids"];
 		$original_document_name = $spModel['original_document_name'];
		$path = $spModel['path'];
		//dump($spModel);halt();
	   	$docuemnt = array();
	   	$docuemnt['document_type'] = '020';
	   	$docuemnt['title'] = $original_document_name;
	   	$docuemnt['status'] = '010';
	   	$docuemnt['document_version'] = '0';
		$docuemnt = self::insert2($docuemnt,'pmt_document');

		$tfile = array();
		$tfile['document_id'] = $docuemnt['id'];
		$tfile['original_document_name'] = $original_document_name;
		$tfile['path'] = $path;
		$tfile = self::insert2($tfile,'pmt_document_turl');
 		$document_id = $docuemnt['id'];


 		//设置关联
	   	$link = array();
	   	$link['table_id'] = $table_id;
	   	$link['table_name'] = $table_name;
	   	$link['document_id'] = $document_id;
	   	$link['path_id'] = $path_id;
		$link = self::insert2($link,'pmt_document_link');

		//如果是升级,则计算版本值
		$document_version = 1;
		$current_version_id = $document_id;
		if($old_document_id!=null&&$old_document_id!=''){
			$old_document = self::queryById2($old_document_id,"pmt_document");
			$document_version = (int)$old_document['document_version'] + 1;
			$current_version_id = $old_document['current_version_id'];
			$old_document['is_current_version'] = '0';
			self::update2($old_document_id,$old_document,'pmt_document');
		}
//		dump($old_document);halt();
		$docuemnt['status'] = '100';
		$docuemnt['is_current_version'] = '1';
		$docuemnt['current_version_id'] = $current_version_id;
		$docuemnt['document_version'] = $document_version;
		self::update2($docuemnt['id'],$docuemnt,'pmt_document');




		self :: addInfoResults($srModel, null);
		return $srModel;
	}

//	//升级文件版本/新文件上传
//	public function uploadDocumentFileDup($spModel) {
//		$srModel = array ();
//		$path_id = $spModel['path_id'];
//		$document_id = $spModel["document_id"];
//		$table_id = $spModel["table_id"];
//		$table_name = $spModel["table_name"];
////		$table_ids = $spModel["table_ids"];
//		$action = $spModel["action"];
//
//		switch($action){
//			case 'upload_file':
//		   		//设置关联
//	   			$link = array();
//	   			$link['table_id'] = $table_id;
//	   			$link['table_name'] = $table_name;
//	   			$link['document_id'] = $document_id;
//	   			$link['path_id'] = $path_id;
//				$link = self::insert2($link,'pmt_document_link');
//
//				$docuemnt['status'] = '100';
//				$docuemnt['is_current_version'] = '1';
//				$docuemnt['current_version_id'] = $document_id;
//				$docuemnt['document_version'] = '1';
//				self::update2($document_id,$docuemnt,'pmt_document');
//
//				break;
//			case 'update_version':
//				$docuemnt['status'] = '100';
//				$docuemnt['is_current_version'] = '1';
//				$docuemnt['current_version_id'] = $document_id;
////				$docuemnt['document_version'] = '1';
//				self::update2($document_id,$docuemnt,'pmt_document');
//
//				$oldDocumentIds = $spModel["oldDocumentIds"];
//				if(count($oldDocumentIds)==0){
//					self :: addFailResults($srModel, null);
//					return $srModel;
//				}
//
//				foreach($oldDocumentIds as $k=>$oid){
//					$sql = "SELECT t.* FROM  pmt_document t   WHERE t.status<>'000' and (t.id={0} or t.current_version_id='{1}') /*w[t]*/";
//					$tlist = self::queryBySql($sql,array($oid,$oid));
//
//					$index = 1;
//					foreach($tlist as $kk=>$vv){
//						$vv_id = $vv['id'];
//						//文件版本升级
//						$docuemnt['is_current_version'] = '0';
//						$docuemnt['current_version_id'] = $document_id;
//						self::update2($vv_id,$docuemnt,'pmt_document');
//						$index++;
//
//						//更新关联
//						$sql = "select * from pmt_document_link t where t.document_id='{0}' /*w[t]*/";
//						$t2list = self::queryBySql($sql,array($vv_id,$vv_id));
//						foreach($t2list as $kkd=>$vvv){
//							$vvv_id = $vvv['id'];
//							$vvv['document_id'] = $document_id;
//							self::update2($vvv_id,$vvv,'pmt_document_link');
//
//						}
//					}
//					$vd = array();
//					$vd['document_version'] = $index;
//					self::update2($document_id,$vd,'pmt_document');
//
//					//如果是页面上传,可能出现当前table_id下没有关联;如果是vbs上传,则不会出现这样的情况,都是更新不会新增新文件
//					if($table_id!=null && $table_id!=''){
//				   		//如果当前记录没有关联,升级时需要设置关联
//				   		$sql = "select * from pmt_document_link t where t.table_id='{0}' and t.table_name='{1}' and t.document_id='{2}' /*w[t]*/";
//				   		$cnt = self::getCountBySql($sql,array($table_id,$table_name,$document_id));
//				   		if($cnt==0){
//				   			$link = array();
//				   			$link['table_id'] = $table_id;
//				   			$link['table_name'] = $table_name;
//				   			$link['document_id'] = $document_id;
//				   			$link['path_id'] = $path_id;
//							$link = self::insert2($link,'pmt_document_link');
//				   		}
//					}
//
//				}
//				break;
//		}
//		//halt();
//
//		self :: addInfoResults($srModel, null);
//		return $srModel;
//	}

	public function getDocument($spModel) {
		$srModel = array ();
		$document_id = $spModel["document_id"];
 		$srModel['document'] = self::queryById2($document_id,'pmt_document');
 		switch($srModel['document']['document_type']){
 			case '010':
  				$sql = "select * from pmt_document_tfile t where t.document_id='{0}' /*w[t]*/";
 				$srModel['document_tfile'] = self::getRowBySql($sql,array($document_id));
 				break;
 			case '020':
   				$sql = "select * from pmt_document_turl t where t.document_id='{0}' /*w[t]*/";
 				$srModel['document_turl'] = self::getRowBySql($sql,array($document_id));
 				break;
 		}

		self :: addInfoResults($srModel, null);
		return $srModel;
	}


	public function listTableDocuments($spModel) {
		$srModel = array ();
		$table_id = $spModel["table_id"];
		$table_name = $spModel["table_name"];
		$path_id = $spModel["path_id"];
		$where = '';
		$where .= self::getCauseIfNotNull("t1.path_id={0}",$path_id);

		$sql = "
SELECT t.*,t1.belong_user_id link_belong_user_id FROM pmt_document t,pmt_document_link t1
WHERE t.id=t1.document_id
AND t1.table_name='{0}' and t.status<>'000' and t.is_current_version='1'
AND t1.table_id = {1}
{$where} /*w[t,t1]*/
		";
		$srModel['list'] = self :: queryBySql($sql,array($table_name,$table_id));
		$srModel['list_count'] = count($srModel['list']);

		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	//删除文档
	public function deleteDocument($spModel) {
		$srModel = array();
		$document_id = $spModel['document_id'];
		$table_id = $spModel['table_id'];
		$table_name = $spModel['table_name'];
 		self::invokeBusiness("AppPmtDocumentBusiness","deleteDocument",array(
 			"document_id"=>$document_id,
 			"table_id"=>$table_id,
 			"table_name"=>$table_name
 		));
		self :: addInfoResults($srModel, null);
		return $srModel;
	}
}
?>
