<?php

class Task2DependService extends SrService
{



 	public function getTask2Depend($spModel){
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$srModel = array();
		$srModel = self::queryById2($spModel["id"],"pmt_task");
		if($srModel!=null){
			$srModel["details"] = self::queryBySql("select t.* from pmt_task_depend t where t.task_id={0} and t.is_deleted='0'",array($spModel["id"]));



		}else{

		}

		if($detail_add_count_flag=="1"){
			$i = (int)$detail_add_count;
			while($i>0){
				$i--;
				$srModel["details"][] = null;
			}
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}



	public function managerTask2Depend($spModel){
		//main id
		$id = $spModel["id"];


		//detail info
		$detail_id = $spModel["detail_id"];

		$detail_id = $spModel["detail_id"];
		$detail_task_id = $spModel["detail_task_id"];
		$detail_depend_task_id = $spModel["detail_depend_task_id"];
		$detail_depend_type = $spModel["detail_depend_type"];
		$detail_delay_day = $spModel["detail_delay_day"];
		//del detail_id
		$detail_del_id = $spModel["detail_del_id"];
		$detail_add_id = explode(",",$spModel["detail_add_id"]);

		$srModel = array();
		if($id==null){

			$srModel = self::insert2($spModel,"pmt_task");

			$id = $srModel["id"];
		}else{

			$srModel = self::update2($id,$spModel,"pmt_task");

		}
		//add detail
		foreach($detail_id as $key=>$value){
			$dModel = array();
			$dModel["id"] = $detail_id[$key];

			$dModel["id"] = $detail_id[$key];
			$dModel["task_id"] = $detail_task_id[$key];
			$dModel["depend_task_id"] = $detail_depend_task_id[$key];
			$dModel["depend_type"] = $detail_depend_type[$key];
			$dModel["delay_day"] = $detail_delay_day[$key];
			$dModel["task_id"] = $id;
			if($value!=null && $value!=''){
				self::update2($dModel["id"],$dModel,"pmt_task_depend");
			}else{
				self::insert2($dModel,"pmt_task_depend");
			}
		}
		//delete detail
		if($detail_del_id!=null && $detail_del_id!=''){
			$model = array();
			$model["task_id"] = $id;
			$model["id"] = $detail_del_id;
			$model["is_deleted"] = "1";
			self::update2($model["id"],$model,"pmt_task_depend");
		}
		//add detail
		foreach($detail_add_id as $key=>$value){
			if($value==0 || $value==null){
				continue;
			}
			$dModel = array();
			$dModel["task_id"] = $id;
			$cnt = self::getCountBySql("select t.* from pmt_task_depend t where t.is_deleted='0' and t.task_id={0} ",
				array($id));
			if($cnt==0){
				self::insert2($dModel,"pmt_task_depend");
			}else{
				self::update2($dModel["id"],$dModel,"pmt_task_depend");
			}
		}


		self::addInfoResults($srModel,'message.success.update',array($spModel["name"]));
		$srModel["sflow_method_business_id"] = $spModel["id"];//for sflow
		return $srModel;
	}

public function editTask2Depend($spModel){
		$id = $spModel["id"];

		$srModel = array();
		if($id!=null&&$id!=''){

			$srModel = self::update2($id,$spModel,"pmt_task");

		}else{

			$srModel = self::insert2($spModel,"pmt_task");

		}



		self::addInfoResults($srModel,'message.success.update',array($srModel["name"]));
		return $srModel;
	}




}//end class



?>