<?php

class TaskService extends SrService
{

public function queryTask($spModel){
		$srModel = array();

		$where = '';

		$where .= self::getCauseIfNotNull("t.id like '%{0}%'",$spModel["query_id"]);
		$where .= self::getCauseIfNotNull("t.project_id = '{0}'",$spModel["query_project_id"]);
		$where .= self::getCauseIfNotNull("t.module_id = '{0}'",$spModel["query_module_id"]);
		$where .= self::getCauseIfNotNull("t.code like '%{0}%'",$spModel["query_code"]);
		$where .= self::getCauseIfNotNull("t.parent_task_id like '%{0}%'",$spModel["query_parent_task_id"]);
		$where .= self::getCauseIfNotNull("t.name like '%{0}%'",$spModel["query_name"]);
		$where .= self::getCauseIfNotNull("t.proirity = '{0}'",$spModel["query_proirity"]);
		$where .= self::getCauseIfNotNull("t.module_type_task_id like '%{0}%'",$spModel["query_module_type_task_id"]);
		$where .= self::getCauseIfNotNull("t.manager_id = '{0}'",$spModel["query_manager_id"]);
		$where .= self::getCauseIfNotNull("EXISTS(SELECT a.* FROM pmt_task_member a WHERE 1=1 /*w[a]*/ and a.task_id = t.id AND a.user_id IN({0}))",$spModel["query_array_task_member"]);
		$where .= self::getCauseIfNotNull("t.adv_begin_date like '%{0}%'",$spModel["query_adv_begin_date"]);
		$where .= self::getCauseIfNotNull("t.adv_end_date like '%{0}%'",$spModel["query_adv_end_date"]);
		$where .= self::getCauseIfNotNull("t.adv_person_day like '%{0}%'",$spModel["query_adv_person_day"]);
		$where .= self::getCauseIfNotNull("t.constraint_type = '{0}'",$spModel["query_constraint_type"]);
		$where .= self::getCauseIfNotNull("t.constraint_time like '%{0}%'",$spModel["query_constraint_time"]);
		$where .= self::getCauseIfNotNull("t.content like '%{0}%'",$spModel["query_content"]);
		$where .= self::getCauseIfNotNull("t.url like '%{0}%'",$spModel["query_url"]);
		$where .= self::getCauseIfNotNull("t.ticket_type like '%{0}%'",$spModel["query_ticket_type"]);
		$where .= self::getCauseIfNotNull("t.status like '%{0}%'",$spModel["query_status"]);
		$where .= self::getCauseIfNotNull("t.no like '%{0}%'",$spModel["query_no"]);
		$where .= self::getCauseIfNotNull("t.type_ms_id like '%{0}%'",$spModel["query_type_ms_id"]);
		$where .= self::getCauseIfNotNull("t.adv_progress like '%{0}%'",$spModel["query_adv_progress"]);
		$where .= self::getCauseIfNotNull("t.tsh_progress like '%{0}%'",$spModel["query_tsh_progress"]);
		$where .= self::getCauseIfNotNull("t.act_progress like '%{0}%'",$spModel["query_act_progress"]);
		$where .= self::getCauseIfNotNull("t.work_calc_type = '{0}'",$spModel["query_work_calc_type"]);
		$where .= self::getCauseIfNotNull("t.module_follow_id like '%{0}%'",$spModel["query_module_follow_id"]);
		$where .= self::getCauseIfNotNull("t.belong_org_id = {0}",$spModel["query_belong_org_id"]);
		$where .= self::getCauseIfNotNull("t.belong_user_id = {0}",$spModel["query_belong_user_id"]);

		//$sql = "SELECT t.*,t.id _childCode_,t.parent_task_id _parentCode_,t.no _childSortNo_,t1. adv_begin_date,t1. adv_end_date,t1.adv_work_day,t1.adv_person_day,t1.adv_progress,t1.act_begin_date,t1.act_end_date,t1.act_work_day,t1.act_person_day,t1.act_progress,t1.tsh_begin_date,t1.tsh_end_date,t1.tsh_work_day,t1.tsh_person_day,t1.tsh_person_normal_day,t1.tsh_person_over_day,t1.tsh_progress  FROM pmt_task t ,pmt_progress t1  WHERE t.is_deleted='0' AND t.id=t1.table_id AND t1.table_name='pmt_task' {$where} order by t.id desc";
		//T000497
		$sql = "SELECT DISTINCT
  d2.id,d2.name,d2.code,d2.status,d2.manager_id,d2.proirity,
  d2.id                       _childCode_,
  d2.parent_task_id           _parentCode_,
  d2.no                       _childSortNo_,
  t1. adv_begin_date,
  t1. adv_end_date,
  t1.adv_work_day,
  t1.adv_person_day,
  t1.adv_progress,
  t1.act_begin_date,
  t1.act_end_date,
  t1.act_work_day,
  t1.act_person_day,
  t1.act_progress,
  t1.tsh_begin_date,
  t1.tsh_end_date,
  t1.tsh_work_day,
  t1.tsh_person_day,
  t1.tsh_person_normal_day,
  t1.tsh_person_over_day,
  t1.tsh_progress
FROM pmt_task t,
  pmt_progress t1,
  sys_help_tree_detail d1,
  pmt_task d2
WHERE 1=1 /*w[t,t1,d1,d2]*/
    AND d1.help_tree_id = '15' AND d1.node_value = t.id AND d1.parent_field_value = d2.id
    AND d2.id = t1.table_id
    AND t1.table_name = 'pmt_task'
    {$where}
ORDER BY t.id desc";

 		$list = self::queryTreeViewBySql2($sql,array(),'name');
		$srModel['list'] = $list;
		$srModel['page'] = "";

//		foreach($srModel['list'] as $k=>$model){
//			$srModel2 = self::queryBySql("select t.user_id from pmt_task_member t where t.task_id={0} /*w[t]*/",array($model["id"]));
//			$srModel['list'][$k]['array_task_member'] = Sr::sys_listToPostparam($srModel2,'user_id');
//		}
		foreach($srModel['list'] as $k=>$model){
			$model = self::getValue_invokeBusiness("AppCommonBusiness","task_calcProgress",$model,'@','spModel');
			$srModel['list'][$k] = $model;
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}

 	public function getTask($spModel){
		$id = $spModel["id"];
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$srModel = array();
		$srModel = self::queryById2($id,"pmt_task");
		if($srModel!=null){


			$srModel2 = self::queryBySql("select t.user_id from pmt_task_member t where t.task_id={0} /*w[t]*/",array($id));
			$srModel['array_task_member'] = Sr::sys_listToPostparam($srModel2,'user_id');
			//dump($srModel['array_task_member']);

		}else{
			$srModel2 = self::getRowBySql("select * from pmt_task t where 1=1 /*w[t]*/ and t.id='".$spModel["parent_task_id"]."'");
			$srModel["project_id"] = $srModel2["project_id"];
			$srModel["module_id"] = $srModel2["module_id"];
			$srModel["proirity"] = $srModel2["proirity"];
			$srModel["module_type_task_id"] = $srModel2["module_type_task_id"];
//			$srModel["manager_id"] = $srModel2["manager_id"];

		}
		$srModel['source_config'] = self::queryBySql("select t.* from pmt_task_source_config t where t.belong_org_id={0}  /*w[t]*/",array(SrUser::getOrgId()));
		$srModel['source_config'][] = array('id'=>'mail','name'=>'E-Mail');//(仅支持163邮箱)


$srModel2 = self::invokeBusiness("AppCommonBusiness","progress_getRow",array('table_id'=>$spModel["id"],'table_name'=>'pmt_task'),'@');
$srModel = Sr::sys_copyProperties($srModel,$srModel2);
$srModel2 = self::invokeBusiness("AppTaskBusiness","getTaskInfo",$spModel,'@');
$srModel = Sr::sys_copyProperties($srModel,$srModel2);
		self::addInfoResults($srModel,null);
		return $srModel;
	}




public function editTask($spModel){
		$id = $spModel["id"];
		$oldStatus = null;

		$srModel = array();
		if($id!=null&&$id!=''){
			$task = self::queryById2($id,'pmt_task');
			$oldStatus = $task['status'];

			$srModel = self::update2($id,$spModel,"pmt_task");

		}else{
		   $spModel['code'] = self::getValue_invokeBusiness("AppCommonBusiness","task_genNo",array(array()),'@','code');

			$srModel = self::insert2($spModel,"pmt_task");
			SrTree::addRow(array('table_name'=>'pmt_task','node_value'=>$srModel['id']));
			$spModel['id'] = $srModel['id'];
		}


		$spModel2 = array();
		$spModel2['table_name'] = 'pmt_task_member';

		$spModel2['values'] = Sr::sys_postparamToList($spModel['array_task_member'],'user_id');

		$spModel2['param'] = array(
			'is_deleted'=>'0',
			'task_id'=>$srModel['id'],
		);
		self::batch_managerCompleteTableList($spModel2);
		self::invokeBusiness("AppCommonBusiness","progress_fillTask",$spModel);
		self::invokeBusiness("AppTaskBusiness","fillTaskInfo",$spModel);
		self::invokeBusiness("AppCommonBusiness","task_updateParentTask",array("id"=>$srModel['id']));

//		$parentModel = self::queryById2($srModel['parent_task_id'],"pmt_task");
//		if($parentModel!=null){
//			//halt($spModel["spr_tree_type"]);
//			if($spModel["spr_tree_type"]!=null&&$spModel["spr_tree_type"]!=''){
//				$parentModel["spr_tree_type"] = $spModel["spr_tree_type"];
//			}else{
//				$parentModel["spr_tree_type"] = "010"; //module
//			}
//			self::update2($srModel['parent_task_id'],$parentModel,"pmt_task");
//		}
		if($spModel['status']=='020'){
			self::invokeBusiness("AppTaskBusiness","sendTaskMail",array("task_id"=>$srModel['id']));
		}

		self::addInfoResults($srModel,'message.success.update',array($srModel["name"]));
		return $srModel;
	}


public function deleteTask($spModel){
		$id = $spModel["id"];
		$srModel = array();
		$spModel["is_deleted"] = "1";

		$srModel = self::update2($id,$spModel,"pmt_task");
		SrTree::deleteRow(array('table_name'=>'pmt_task','node_value'=>$srModel['id']));

		self::addInfoResults($srModel,'message.success.delete',array($srModel["name"]));
		return $srModel;
	}

	//T000506	       任务添加从其他系统读取任务详情功能
	public function getTaskSourceInfo($spModel){

		$source_id = self::assertNotBlank($spModel,"source_id");
		//$source_value = self::assertNotBlank($spModel,"source_value");
		$source_value = $spModel["source_value"];

		$data = array();
		switch($source_id){
			case 'mail':
				$srModel2 = self::getTaskSourceFromMail($spModel);
				$data = $srModel2['content'];
				break;
			default:
				$model = self::queryById2($source_id,'pmt_task_source_config');
				$url = $model['get_url'].$source_value;

				$url .= "&md5=".md5(md5($source_value));
		//		Sr::info("URL:{$url}");
				$srModel = array();
				$handle = fopen ($url, "r");
				$content = fgets($handle, 5000);
		//		Sr::info('getTaskSourceInfo:1');
		//		Sr::info($content);
		//		Sr::info(json_decode($content,true));
		//		Sr::info('getTaskSourceInfo:2');
				fclose($handle);
				$data = json_decode($content,true);
				break;
		}
		//T000524 任务从外部获取的json数据接口同时至此和spr的action json格式
		if($data['status']=='info'){
			$srModel['content'] = json_decode($data['data'],true);
		}else{
			$srModel['content'] = $data;
		}


		self::addInfoResults($srModel,null);
		return $srModel;
	}

	//T000386	       支持邮件模块任务项目绑定
	//for test: http://127.0.0.1/sprcore_all/Pmt/index.php/Task/getTaskSourceInfo?source_id=mail&source_value=1111111111111111
	public function getTaskSourceFromMail($spModel){

		$mailTitle = $spModel['source_value'];
		$srModel = array();
//		$user = SrUser::getUserSummary()->userMap;
//		dump($mailTitle);
//		dump($user['mail']);
//		dump($user['mail_psd']);
////		halt();
//		var_dump($user);
//		//$obj= new SrImap('sprcore_server@163.com','abc123','sprcore_server@163.com','pop.163.com','pop3','110',false);
//		$obj= new SrImap($user['mail'],$user['mail_psd'],$user['mail'],'pop.163.com','pop3','110',false);
//		$obj->connect();
//		//$tot=$obj->getTotalMails();
//		$date = date ( "d M Y", strToTime ( "-7 days" ) );
//		dump( ' SINCE "'.$date.'" SUBJECT "'.$mailTitle.'"');
//		//$some   = imap_search($obj->marubox, ' SINCE "'.$date.'" SUBJECT "'.$mailTitle.'"', SE_UID);
//		dump( ' SUBJECT "'.$mailTitle.'"');
//		$some   = imap_search($obj->marubox, ' SUBJECT "'.$mailTitle.'"', SE_UID);
//		$data = array();
//		dump($some);
//		foreach($some as $index){
//			$head=$obj->getHeaders($index);
//			$data['name'] = $obj->get_mime_header_decode($head['subject']);
//			$data['content'] =  $obj->get_utf8_body($index);
//			$data['adv_begin_date'] = date("Y-m-d");
//			$data['adv_end_date'] = date("Y-m-d");
//			$data['business_person_name'] = $obj->get_mime_header_decode($head['fromName']);
//			break;
//		}
//		//echo $data['content'];
//		$obj->close_mailbox();
//		$srModel['content'] = $data;
		//var_dump(json_encode($data));

		$user = SrUser::getUserSummary()->userMap;
		$spModel2 = array();
		$spModel2['subject'] = $mailTitle;
		$spModel2['from'] = $user['mail'];
		$srModel2 = self::invokeBusiness("SprMailBusiness","getMailBySubject",$spModel2,"SprPage");
		$model = $srModel2['model'];

		$data = array();
		$data['name'] = $model['subject'];
		$data['adv_begin_date'] = date("Y-m-d");
		$data['adv_end_date'] = date("Y-m-d");
		$data['business_person_name'] = $model['fromName'];
		$data['url'] = "/".SPR_ROOT_APATH."/SprPage/index.php/sprMail/viewMailPage?id=".$model['id'];
		$srModel['content'] = $data;

		self::addInfoResults($srModel,null);
		return $srModel;
	}

}//end class



?>