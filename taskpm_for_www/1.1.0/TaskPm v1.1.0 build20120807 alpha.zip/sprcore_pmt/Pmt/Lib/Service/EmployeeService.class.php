<?php
 
class EmployeeService extends SrService
{
 
public function queryEmployee($spModel){
		$srModel = array();

		$where = '';
		
		$where .= self::getCauseIfNotNull("t.id like '%{0}%'",$spModel["query_id"]);		
		$where .= self::getCauseIfNotNull("t.user_id = '{0}'",$spModel["query_user_id"]);		
		$where .= self::getCauseIfNotNull("t.emp_no like '%{0}%'",$spModel["query_emp_no"]);		
		$where .= self::getCauseIfNotNull("t.name like '%{0}%'",$spModel["query_name"]);		
		$where .= self::getCauseIfNotNull("t.joblevel_id = '{0}'",$spModel["query_joblevel_id"]);		
		$where .= self::getCauseIfNotNull("t.depart_id = '{0}'",$spModel["query_depart_id"]);		
		$where .= self::getCauseIfNotNull("t.company_id = '{0}'",$spModel["query_company_id"]);		
		$where .= self::getCauseIfNotNull("t.status = '{0}'",$spModel["query_status"]);		
		$where .= self::getCauseIfNotNull("t.memo like '%{0}%'",$spModel["query_memo"]);
		$where .= self::getCauseIfNotNull("t.belong_org_id = {0}",$spModel["query_belong_org_id"]);
		$where .= self::getCauseIfNotNull("t.belong_user_id = {0}",$spModel["query_belong_user_id"]);

 
		$sql = "select t.* from pmt_employee t  where 1=1 /*w[t]*/ {$where}  order by id desc";
 

 		$srModel = self::queryPageBySql($sql);


		self::addInfoResults($srModel,null);
		return $srModel;
	}
	
 	public function getEmployee($spModel){
		$id = $spModel["id"];
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$user_id = $spModel['user_id'];
		if($user_id!=null && $user_id!=''){
			$id = self::getValue_getRowBySql("select t.id from pmt_employee t where t.user_id='{0}' /*w[t]*/",array($user_id),'id');			
		}
		$srModel = array();
		$srModel = self::queryById2($id,"pmt_employee");
		if($srModel!=null){		



		}else{
	
		}

		self::addInfoResults($srModel,null);
		return $srModel;
	}




public function editEmployee($spModel){
		$id = $spModel["id"];
		
		$srModel = array();
		if($id!=null&&$id!=''){
			
			$srModel = self::update2($id,$spModel,"pmt_employee");		
			
		}else{
			
			$srModel = self::insert2($spModel,"pmt_employee");	

			$spModel['id'] = $srModel['id'];
			
		}

		

		self::addInfoResults($srModel,'message.success.update',array($srModel["name"]));
		return $srModel;
	}	

	
public function deleteEmployee($spModel){
		$id = $spModel["id"];
		$srModel = array();
		$spModel["is_deleted"] = "1";
		
		$srModel = self::update2($id,$spModel,"pmt_employee");

		
		self::addInfoResults($srModel,'message.success.delete',array($srModel["name"]));
		return $srModel;
	}	

}//end class



?>