<?php
class AppTaskTsheetService extends SrService {
	public function queryUserShTimes($spModel){
		$srModel = array();
		$begin_date = self::assertNotBlank($spModel,'begin_date');
		$total_day = self::assertNotBlank($spModel,'total_day');
//		$total_day = 7;
//
//		$to_day = Sr::sys_date();
		$tarTime = time() - 86400 * ($total_day-1);
		$tarDate = Sr::sys_date(array('time'=>$tarTime));
		$timeDims = array();
		for($i=0;$i<$total_day;$i++){
			$vv = Sr::sys_date(array('time'=>time()-86400*$i));
			$timeDims[$vv] = $vv;
		}
		$srModel['timeDims'] = $timeDims;

		$where = '';
		$where .= self :: getCauseIfNotNull("t3.id={0}", $spModel['query_project_id']);
		$where .= self :: getCauseIfNotNull("t1.occure_date<='{0}'", $begin_date.' 23:59:59');
		$where .= self :: getCauseIfNotNull("t1.occure_date>='{0}'", $tarDate.' 00:00:00');


		$sql = "SELECT
  t1.occure_date tsheet_occure_date,
  (SELECT SUM(a1.hours+a1.ext_hours) FROM pmt_task_tsheet a1 WHERE a1.occure_date=t1.occure_date AND a1.belong_user_id=t1.belong_user_id AND a1.status='020') tsheet_hours_020,
  (SELECT SUM(a1.hours+a1.ext_hours) FROM pmt_task_tsheet a1 WHERE a1.occure_date=t1.occure_date AND a1.belong_user_id=t1.belong_user_id AND a1.status='100') tsheet_hours_100,
  t1.belong_user_id belong_user_id
FROM pmt_task_tsheet t1,
  pmt_task t2,
  pmt_project t3
WHERE t1.task_id = t2.id
    AND t2.project_id = t3.id /*w[t1,t2,t3]*/ {$where}
    /*AND t2.belong_org_id=1*/ GROUP BY t1.occure_date,t1.belong_user_id order by t1.occure_date desc";
    	$srModel['details'] = self :: queryBySql($sql);
    	//dump($srModel['list']);
		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function getSheetInfoFromProjectModuleTask($spModel) {
		$task_id = $spModel['task_id'];
		$module_id = $spModel['module_id'];
		$project_id = $spModel['project_id'];
		$status = $spModel['status'];
		$srModel = array ();

		$where = '';
		$ss = "exists(
	SELECT *
	FROM sys_help_tree a1,sys_help_tree_detail a2
	where a1.is_deleted='0' and a2.is_deleted='0'
	and a1.id=a2.help_tree_id
	and a2.node_value=t1.task_id and a2.parent_field_value={0}
 )";
		$where .= self :: getCauseIfNotNull($ss, $task_id);
		$where .= self :: getCauseIfNotNull("t2.module_id = '{0}'", $module_id);
		$where .= self :: getCauseIfNotNull("t2.project_id = '{0}'", $project_id);
		$where .= self :: getCauseIfNotNull("t1.status = '{0}'", $status);

		$sql = "SELECT t2.project_id,t2.module_id,t3.name user_name, t1.* FROM pmt_task_tsheet t1,pmt_task t2,uup_user t3
		WHERE t1.task_id=t2.id AND t1.belong_user_id=t3.id
		/*w[t1,t2,t3]*/
		{$where}
		ORDER BY t1.occure_date asc";

		$srModel['details'] = self :: queryBySql($sql);

		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function exportBaosightSheet($spModel) {
		$begin_occure_day = $spModel['begin_occure_day'];
		$end_occure_day = $spModel['end_occure_day'];

		$srModel = array ();
		$list = array();

		//计算日期
		$sep = Sr::sys_getSepDateByDbString($end_occure_day,$begin_occure_day);
		$begin_occure_time = strtotime($begin_occure_day);
		$days = array();
		for($i=0;$i<=$sep;$i++){
			$tt = $begin_occure_time+60*60*24*($i);
			$tar_day = Sr::sys_date(array('time'=>$tt));
			$days[] = $tar_day;
		}

		$sql = "select t1.* from uup_user t1,uup_org t2 where t1.org_id=t2.id and t2.code='{0}' /*w[t1,t2]*/ AND LENGTH(t1.memo)=6";
		$users = self::queryBySql($sql,array('C20001'));
		foreach($users as $k=>$user){
			foreach($days as $kk=>$day){
				$model = array();
				$model['work_day'] = $day;//工作日
				//任务描述
				$model['module_names'] = "";
				$sql = "SELECT distinct t1.* FROM pmt_module t1,pmt_task t2,pmt_task_member t3,pmt_progress t4
WHERE t1.id=t2.module_id and t2.id=t3.task_id and t4.table_name='pmt_task' and t4.table_id=t2.id
and t4.adv_begin_date<='{0}' and t4.adv_end_date>='{0}'
AND (t2.manager_id='{1}' OR t3.user_id='{1}') /*w[t1,t2,t3,t4]*/";
				$modules = self::queryBySql($sql,array($day,$user['id']));
				foreach($modules as $kkk=>$module){
					$model['module_names'] .= $module['name'].'/';
				}
				//正常
				$ww = date('w',strtotime($day));

				if($ww==0 || $ww==6){
					$model['work_perday'] = '0';	//周末上班时间为0
					$model['work_day'] = "<font color='red'>".$model['work_day']."</font>";
					$model['extwork_perday'] = '0';
					$model['module_names'] = '';
				}else{
					$model['work_perday'] = '8';
				}
				$ww = ($ww==0)?7:$ww;
				$tt = 60*60*24*(7-$ww) + strtotime($day);
				$model['work_day_nextsun'] = Sr::sys_date(array('time'=>$tt));
				//加班
				$sql = "select SUM(t.ext_hours) hours from pmt_task_tsheet t where t.occure_date='{0}' and t.belong_user_id='{1}' and t.status in('020','030','100') /*w[t]*/";
				$cc = self::getValue_getRowBySql($sql,array($day,$user['id']),'hours');
				if($cc==null){
					$cc = 0;
				}else{
					$cc = $cc+1;
				}
				$model['extwork_perday'] = $cc;

				$model['baosight.1'] = $user['memo'];
				$model['baosight.2'] = $user['name'];
				$model['baosight.3'] = $model['work_day_nextsun'];
				$model['baosight.4'] = $model['work_day'];
				$model['baosight.5'] = "XTK10059";
				$model['baosight.6'] = "东方钢铁会员服务平台二期";
				$model['baosight.7'] = "系统实现";
				$model['baosight.8'] = $model['module_names'];
				$model['baosight.9'] = $model['work_perday'];
				$model['baosight.10'] = $model['extwork_perday'];
				$model['baosight.11'] = "";
				//$model['baosight.12'] = "B";
				//$model['baosight.13'] = "B";
				//$model['baosight.14'] = "B";
				//$model['baosight.15'] = "B";
				$model['baosight.16'] = "";
				$model['baosight.17'] = "";

				$list[] = $model;
			}
		}
		$list[] = array();
		$srModel['list'] = $list;
//		dump($list);halt();
		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function updateTouchTask($spModel) {
		$task_id = $spModel['task_id'];
		$to_day = Sr::sys_date();
		$user_id = SrUser::getUserId();

		$srModel = array();

		$sql = "select * from pmt_task_tsheet t where t.occure_date='{0}' and t.belong_user_id={1} and t.task_id={2} /*w[t]*/";
		$cnt = self::getCountBySql($sql,array($to_day,$user_id,$task_id));

		if($cnt==0){
			$model = array();
			$model['task_id'] = $task_id;
			$model['occure_date'] = $to_day;
			$model['status'] = '010';
			self::insert2($model,'pmt_task_tsheet');

		}

		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function fillQucikTsheetPage($spModel) {
		$occure_date = $spModel['query_occure_date'];
		$add_task_id = $spModel['add_task_id'];//如果是有值,则先置为处理中
		if($add_task_id!=null&&$add_task_id!=''){
			self::invokeService('AppTaskFavoriteService','doProcess', array('task_id'=>$add_task_id) );
		}

		if($occure_date==null || $occure_date==''){
			$occure_date = Sr::sys_date();//如果没有传输,则查询当天
		}

		$user_id = SrUser::getUserId();
		$srModel = array();

		$sql = "select t.* ,t2.id project_id,t3.id module_id  from pmt_task_tsheet t ,pmt_task t1 ,pmt_project t2 ,pmt_module t3 where t.task_id=t1.id and t1.project_id=t2.id and t1.module_id=t3.id and t.occure_date='{0}' and t.belong_user_id={1} /*w[t,t1,t2,t3]*/";
		$list = self::queryBySql($sql,array($occure_date,$user_id));

		$srModel['list'] = $list;

		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function fillQucikTsheet($spModel) {
//		dump($spModel);halt();
	 	$ids = $spModel['id'];
	 	$status = $spModel['status'];
	 	$statuses = $spModel['statuses'];

	 	$hours = $spModel['hours'];
	 	$ext_hours = $spModel['ext_hours'];
		$srModel = array();
		foreach($ids as $k=>$id){
			$model = self::queryById2($id,'pmt_task_tsheet');
			if($model['status']!=$status[$k]){
				self :: addFailResults($srModel);
			}
			if($model['status']=='010' ||$model['status']=='020' ||$model['status']=='030' || $model['status']==null){
				$model['hours'] = $hours[$k];
				$model['ext_hours'] = $ext_hours[$k];
				$model['status'] = $statuses;
				self::update2($id,$model,'pmt_task_tsheet');
			}
		}

		self :: addInfoResults($srModel, null);
		return $srModel;
	}
	public function deleteQucikTsheet($spModel) {
	 	$id = $spModel['id'];
		$srModel = array();
		$model = self::queryById2($id,'pmt_task_tsheet');
		$model['is_deleted'] = '1';
		self::update2($id,$model,'pmt_task_tsheet');

		self :: addInfoResults($srModel, null);
		return $srModel;
	}
}
?>
