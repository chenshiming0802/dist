<?php
class IndexService extends SrService{
	public function queryWelcome($spModel){
		$srModel = array();

		//新闻清单
		$srModel2 = SrUup::getPublicNewList(array('query_belong_org_id'=>SrUser::getOrgId()));
		$srModel["news_list"] = $srModel2['list'];
		$srModel["news_more_url"] = $srModel2['more_url'];
		//dump($srModel);

		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function queryProject($spModel){
		$srModel = array();



		self :: addInfoResults($srModel, null);
		return $srModel;
	}
}
?>
