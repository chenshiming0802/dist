<?php
 
class Project2ContentService extends SrService
{
 

	
 	public function getProject2Content($spModel){
		$id = $spModel["id"];
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$srModel = array();
		$srModel = self::queryById2($id,"pmt_project");
		if($srModel!=null){		



		}else{
	
		}

		self::addInfoResults($srModel,null);
		return $srModel;
	}




public function editProject2Content($spModel){
		$id = $spModel["id"];
		
		$srModel = array();
		if($id!=null&&$id!=''){
			
			$srModel = self::update2($id,$spModel,"pmt_project");		
			
		}else{
			
			$srModel = self::insert2($spModel,"pmt_project");	

			$spModel['id'] = $srModel['id'];
			
		}

		

		self::addInfoResults($srModel,'message.success.update',array($srModel["name"]));
		return $srModel;
	}	

	
	

}//end class



?>