<?php
 
class Task2ProgressService extends SrService
{
 

	
 	public function getTask2Progress($spModel){
		$id = $spModel["id"];
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$srModel = array();
		$srModel = self::queryById2($id,"pmt_task");
		if($srModel!=null){		



		}else{
	
		}
$srModel2 = self::invokeBusiness("AppCommonBusiness","progress_getRow",array('table_id'=>$spModel["id"],'table_name'=>'pmt_task'),'@');
$srModel = Sr::sys_copyProperties($srModel,$srModel2);
$srModel = self::getValue_invokeBusiness("AppCommonBusiness","task_calcProgress",$srModel,'@','spModel');
		self::addInfoResults($srModel,null);
		return $srModel;
	}




	

	
	

}//end class



?>