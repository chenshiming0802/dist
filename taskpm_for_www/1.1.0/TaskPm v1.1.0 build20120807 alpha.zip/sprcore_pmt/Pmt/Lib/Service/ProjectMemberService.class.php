<?php
 
class ProjectMemberService extends SrService
{
 
public function queryProjectMember($spModel){
		$srModel = array();

		$where = '';
		
		$where .= self::getCauseIfNotNull("t.id like '%{0}%'",$spModel["query_id"]);		
		$where .= self::getCauseIfNotNull("t.project_id like '%{0}%'",$spModel["query_project_id"]);		
		$where .= self::getCauseIfNotNull("t.user_id = '{0}'",$spModel["query_user_id"]);		
		$where .= self::getCauseIfNotNull("t.adv_begin_date like '%{0}%'",$spModel["query_adv_begin_date"]);		
		$where .= self::getCauseIfNotNull("t.adv_end_date like '%{0}%'",$spModel["query_adv_end_date"]);		
		$where .= self::getCauseIfNotNull("t.user_rate like '%{0}%'",$spModel["query_user_rate"]);
		$where .= self::getCauseIfNotNull("t.belong_org_id = {0}",$spModel["query_belong_org_id"]);
		$where .= self::getCauseIfNotNull("t.belong_user_id = {0}",$spModel["query_belong_user_id"]);

 
		$sql = "select t.* from pmt_project_member t  where 1=1 /*w[t]*/ {$where}  order by id desc";
 

 		$srModel = self::queryPageBySql($sql);


		self::addInfoResults($srModel,null);
		return $srModel;
	}
	
 	public function getProjectMember($spModel){
		$id = $spModel["id"];
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$srModel = array();
		$srModel = self::queryById2($id,"pmt_project_member");
		if($srModel!=null){		



		}else{
	
		}

		self::addInfoResults($srModel,null);
		return $srModel;
	}




public function editProjectMember($spModel){
		$id = $spModel["id"];
		
		$srModel = array();
		if($id!=null&&$id!=''){
			
			$srModel = self::update2($id,$spModel,"pmt_project_member");		
			
		}else{
			
			$srModel = self::insert2($spModel,"pmt_project_member");	

			$spModel['id'] = $srModel['id'];
			
		}

		

		self::addInfoResults($srModel,'message.success.update',array($srModel["name"]));
		return $srModel;
	}	

	
public function deleteProjectMember($spModel){
		$id = $spModel["id"];
		$srModel = array();
		$spModel["is_deleted"] = "1";
		
		$srModel = self::update2($id,$spModel,"pmt_project_member");

		
		self::addInfoResults($srModel,'message.success.delete',array($srModel["name"]));
		return $srModel;
	}	

}//end class



?>