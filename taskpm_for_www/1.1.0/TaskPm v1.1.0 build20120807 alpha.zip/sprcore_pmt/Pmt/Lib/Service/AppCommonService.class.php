<?php
class AppCommonService extends SrService {
 	public function batchUpdateTaskActProcess($spModel){
 		$sql = "select * from pmt_task t where 1=1 /*w[t]*/";
		$list = self::queryBySql($sql,array());
		foreach($list as &$model){
			self::invokeBusiness("AppCommonBusiness","task_updateParentTask",array("id"=>$model['id']),'Pmt');
		}
		$srModel = array();
		self::addInfoResults($srModel,null);
		return $srModel;
	}

	public function queryPersonDayStatus($spModel){
		$srModel = array ();
		$begin_occure_day = $spModel['begin_occure_day'];
		$end_occure_day = $spModel['end_occure_day'];
		if(($begin_occure_day==null&&$begin_occure_day!='')||($end_occure_day==null&&$end_occure_day=='')){
			self :: addInfoResults($srModel, null);
			return $srModel;
		}

		$where = self::getCauseIfNotNull(" t1.spr_tree_type='020' and t1.project_id = '{0}'",$spModel["query_project_id"]);

		//开始的任务
		$sql = " SELECT  'begin' person_day_type,t2.adv_begin_date occure_date, SUM(t2.adv_person_day) person_day FROM pmt_task t1,pmt_progress t2,pmt_module t3
WHERE t1.id=t2.table_id AND t2.table_name='pmt_task' AND t2.adv_person_day IS NOT NULL and t1.module_id=t3.id {$where} /*w[t1,t2,t3]*/ and t3.status in ('020','050')
and t2.adv_begin_date>='{0}' and t2.adv_begin_date<='{1}'
GROUP BY t2.adv_begin_date order by t2.adv_begin_date asc";
		$begins = self::queryBySql($sql,array($begin_occure_day,$end_occure_day));
		//关闭的任务
//		$sql = "SELECT  'end' person_day_type,date_format(t3.create_time,'%Y-%m-%d') occure_date, SUM(t2.adv_person_day) person_day FROM pmt_task t1,pmt_progress t2,sys_sflow_log t3
//WHERE t1.id=t2.table_id AND t2.table_name='pmt_task' AND t2.adv_person_day IS NOT NULL {$where} /*w[t1,t2,t3]*/
//AND t1.status='100' AND t1.id = t3.business_id AND t1.id=t3.business_id AND t3.flow_d_id = 42
//AND t3.create_time>='{0}' AND t3.create_time<='{1}'
//GROUP BY t2.create_time order by t2.create_time asc ";
//		$ends = self::queryBySql($sql,array($begin_occure_day,$end_occure_day));
		$sql = " SELECT  'end' person_day_type,t2.close_time occure_date, SUM(t2.adv_person_day) person_day FROM pmt_task t1,pmt_progress t2,pmt_module t3
WHERE t1.id=t2.table_id AND t2.table_name='pmt_task' AND t2.adv_person_day IS NOT NULL and t1.module_id=t3.id {$where} /*w[t1,t2,t3]*/ and t3.status in ('020','050')
and t2.close_time>='{0}' and t2.close_time<='{1}'
GROUP BY t2.close_time order by t2.close_time asc";
		$ends = self::queryBySql($sql,array($begin_occure_day,$end_occure_day));
		//dump($ends);halt();

		//计算日期
		$sep = Sr::sys_getSepDateByDbString($end_occure_day,$begin_occure_day);
		$begin_occure_time = strtotime($begin_occure_day);

		$days = array();
		for($i=0;$i<=$sep;$i++){
			$tt = $begin_occure_time+60*60*24*($i);
			$tar_day = Sr::sys_date(array('time'=>$tt));
			$days[] = $tar_day;
		}
		$srModel['days'] = $days;
		$todos = array();
		foreach($days as $dk=>$dv){
//			$sql = "SELECT    SUM(t2.adv_person_day) person_day FROM pmt_task t1,pmt_progress t2
//WHERE t1.id=t2.table_id AND t2.table_name='pmt_task' AND t2.adv_person_day IS NOT NULL {$where} /*w[t1,t2]*/
//";
//			$total_person = self::getValue_getRowBySql($sql,array(),"total_person_day");
//			$sql = "SELECT  SUM(t2.adv_person_day) person_day FROM pmt_task t1,pmt_progress t2,sys_sflow_log t3
//WHERE t1.id=t2.table_id AND t2.table_name='pmt_task' AND t2.adv_person_day IS NOT NULL {$where} /*w[t1,t2,t3]*/
//AND t1.status='100' AND t1.id = t3.business_id AND t1.id=t3.business_id AND t3.flow_d_id = 42
//AND t2.adv_begin_date>='{0}'  AND t2.adv_begin_date<='{1}'
//GROUP BY t2.create_time ";
			$sql = "SELECT  SUM(t2.adv_person_day/(DATEDIFF(t2.adv_end_date,t2.adv_begin_date)+1)) person_day FROM pmt_task t1,pmt_progress t2 ,pmt_module t3
WHERE t1.id=t2.table_id AND t2.table_name='pmt_task' AND t2.adv_person_day IS NOT NULL and t1.module_id=t3.id {$where} /*w[t1,t2,t3]*/
AND t1.status in ('020','050','100') and t3.status in ('020','050')
AND t2.adv_begin_date<='{0}' and t2.adv_end_date>='{0}' and (t2.close_time>'{0}' or t2.close_time is null)
";
			$close_person = round(self::getValue_getRowBySql($sql,array($dv.' 00:00:00',$dv.' 23:59:59'),"person_day"),2);

			$sql = "SELECT  SUM(t2.adv_person_day) person_day FROM pmt_task t1,pmt_progress t2 ,pmt_module t3
WHERE t1.id=t2.table_id AND t2.table_name='pmt_task' AND t2.adv_person_day IS NOT NULL and t1.module_id=t3.id {$where} /*w[t1,t2,t3]*/
AND t1.status in ('020','050','100') and t3.status in ('020','050')
AND  t2.adv_end_date<'{0}' and (t2.close_time>'{0}' or t2.close_time is null)
";
			$expired_person = round(self::getValue_getRowBySql($sql,array($dv.' 00:00:00',$dv.' 23:59:59'),"person_day"),2);
			$todos[] = array('person_day_type'=>'todo','occure_date'=>$dv,'person_day'=>$close_person);
			$expired[] = array('person_day_type'=>'expired','occure_date'=>$dv,'person_day'=>$expired_person);
		}
		$srModel['details'] = array_merge($begins,$ends,$todos,$expired);

		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function getLeftMenuPage($spModel) {
		$srModel = array ();
 		$userId = SrUser::getUserId();
 		$to_day = Sr::sys_date();

 		//总填写工时
 		$sql = "SELECT (CASE WHEN SUM(t.hours) IS NULL THEN '0' ELSE SUM(t.hours) END)  sheetHousrs FROM pmt_task_tsheet t WHERE t.belong_user_id='{0}' /*w[t]*/ and t.occure_date='{1}'";
 		$srModel['sheetHousrs'] = self::getValue_getRowBySql($sql,array($userId,$to_day),"sheetHousrs");
 		//总填写工时
 		$sql = "SELECT (CASE WHEN SUM(t.hours) IS NULL THEN '0' ELSE SUM(t.hours) END)  sheetHousrs FROM pmt_task_tsheet t WHERE t.belong_user_id='{0}' /*w[t]*/ and t.occure_date='{1}' and t.status='010'";
 		$srModel['sheetHousrs_010'] = self::getValue_getRowBySql($sql,array($userId,$to_day),"sheetHousrs");

 		//待处理任务信息
 		$tarDate = $to_day;
 		$sql1 = "
				SELECT distinct t1.id task_id,t1.code task_code, t1.name task_name ,t2.name module_name,t3.name manager_user_name,
t0. adv_begin_date,t0. adv_end_date,t0.adv_work_day,t0.adv_person_day,t0.adv_progress,t0.act_begin_date,t0.act_end_date,t0.act_work_day,t0.act_person_day,t0.act_progress,t0.tsh_begin_date,t0.tsh_end_date,t0.tsh_work_day,t0.tsh_person_day,t0.tsh_person_normal_day,t0.tsh_person_over_day,t0.tsh_progress
				FROM pmt_task t1,pmt_module t2,uup_user t3,pmt_progress t0
				WHERE t1.module_id=t2.id and t0.table_id=t1.id and t0.table_name='pmt_task'
				AND t1.spr_tree_type='020'  and t1.manager_id=t3.id
				/*w[t1,t2,t0]*/
				{$sql2}
				{$sql3}
			";
 		$sql2 = self::getCauseIfNotNull("t1.manager_id={0} OR EXISTS (SELECT a1.* FROM pmt_task_member a1 WHERE a1.user_id={0} AND a1.task_id=t1.id /*w[a1]*/)",$userId);
 		$sql3 = "and t1.status='020' and t2.status='020'  AND t0.adv_begin_date<='{$tarDate} 23:59:00'";
		$srModel['taskNum_020'] = self::getCountBySql($sql1.$sql2.$sql3,array());//总填写工时
		//过期任务信息
 		$sql3 = "and t1.status='020' and t2.status='020'  AND t0.adv_end_date<'{$tarDate} 00:00:00'";
 		$srModel['taskNum_020_delay'] = self::getCountBySql($sql1.$sql2.$sql3,array());//总填写工时
		//今天过期任务信息
 		$sql3 = "and t1.status='020' and t2.status='020'  AND t0.adv_end_date<='{$tarDate} 23:59:59' and t0.adv_end_date>='{$tarDate} 00:00:00'";
		$srModel['taskNum_020_today_delay'] = self::getCountBySql($sql1.$sql2.$sql3,array());//总填写工时
		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function queryUserTask($spModel) {

		$action_count = $spModel['action_count'];//1:做统计操作
		$task_list_type = Sr::sys_get($spModel['task_list_type'],'1');
		$srModel = array ();
		$srModel['list'] = array();
		$b1 = time();
		$to_day = Sr::sys_datetime();
		//当前的任务清单
		$totolDay = 7;

		for ($i = 0; $i < $totolDay; $i++) {
			$tarTime = time() + 60 * 60 * 24 * $i;
			$tarDateOrinal = Sr::sys_date(array('time'=>$tarTime));
			$tarDate = Sr::sys_date(array('time'=>$tarTime));


			$sql3 = '';
			if($task_list_type=='2'){
				//2：创建的任务清单
				$tarTime = time() - 60*60*24*($totolDay-1) + 86400 * $i;
				$tarDate = Sr::sys_date(array('time'=>$tarTime));
				$sql3 = " AND t0.create_time<='{$tarDate} 23:59:00' and t0.create_time>='{$tarDate} 00:00:00'";
				$tarDateOrinal = $tarDate;
			}else if($task_list_type=='3'){
				//3:完成的任务清单
				$tarTime = time() - 60*60*24*($totolDay-1) + 86400 * $i;
				$tarDate = Sr::sys_date(array('time'=>$tarTime));
				$sql3 = " and t1.status='050' and t1.id in (select a1.business_id from sys_sflow_log a1 where t1.id=a1.business_id and a1.flow_d_id = 28 and a1.create_time<='{$tarDate} 23:59:00' and a1.create_time>='{$tarDate} 00:00:00'  /*w[a1]*/) ";
				$tarDateOrinal = $tarDate;
				$totolDay = 20;//统计20天
			}else if($task_list_type=='4'){
				//3:关闭的任务清单
				$tarTime = time() - 60*60*24*($totolDay-1) + 86400 * $i;
				$tarDate = Sr::sys_date(array('time'=>$tarTime));
				$sql3 = " and t1.status='100'and t1.id in (select a1.business_id from sys_sflow_log a1 where t1.id=a1.business_id and a1.flow_d_id = 42 and a1.create_time<='{$tarDate} 23:59:00' and a1.create_time>='{$tarDate} 00:00:00'  /*w[a1]*/) ";
				$tarDateOrinal = $tarDate;
			}else if($task_list_type=='5'){
				//5:未指派任务
				$tarTime = time() - 60*60*24*($totolDay-1) + 86400 * $i;
				$tarDate = Sr::sys_date(array('time'=>$tarTime));
				$sql3 = " and t1.status='020' and (t1.manager_id is null or t1.manager_id='0') ";
				$totolDay = 1;//仅统计一天
			}else{
				//default 1:待处理的任务清单
				$tarDate = Sr::sys_date(array('time'=>($tarTime+86400*30)));
				$sql3 = "and t1.status='020' and t2.status='020' and t0.adv_begin_date is not null ";	//AND t0.adv_begin_date<='{$tarDate} 23:59:00'
				$totolDay = 1;//仅统计一天
			}


			$sql2 = '';
			$sql2 .= self::getCauseIfNotNull("t1.manager_id={0} OR EXISTS (SELECT a1.* FROM pmt_task_member a1 WHERE a1.user_id={0} AND a1.task_id=t1.id /*w[a1]*/)",$spModel["query_user_id"]);
			$sql2 .= self::getCauseIfNotNull("t1.project_id={0}",$spModel["query_project_id"]);

			$sql = "
					SELECT distinct t1.*,t1.id task_id,t1.code task_code, t1.name task_name ,t2.name module_name,t3.name manager_user_name
 					FROM pmt_task t1 left join uup_user t3 on t1.manager_id=t3.id,pmt_module t2,pmt_progress t0
					WHERE t1.module_id=t2.id and t0.table_id=t1.id and t0.table_name='pmt_task'
					AND t1.spr_tree_type='020'
					/*w[t1,t2,t0]*/
					{$sql2}
					{$sql3}
					ORDER BY t2.id ASC,  ISNULL(t0.adv_end_date), t0.adv_end_date asc , t0.adv_begin_date asc
				";
			//echo $tarDate;
			//dump($sql);
			if($action_count=='1'){
				$cnt = self::getCountBySql($sql);
				$srModel['list_count'] = $cnt;
				self :: addInfoResults($srModel, null);
				return $srModel;
			}
			$list = self :: queryBySql($sql);
			foreach ($list as $k => $model) {
				$model['forcalc_info_base_day'] = $tarDateOrinal;
				$srModel2 = self::invokeBusiness("AppCommonBusiness","progress_getRow",array('table_id'=>$model["task_id"],'table_name'=>'pmt_task'),'@');
				$model = Sr::sys_copyProperties($model,$srModel2);

				$model = self::getValue_invokeBusiness("AppCommonBusiness","task_calcProgress",$model,'@','spModel');
				$model = self::getValue_invokeBusiness("AppCommonBusiness","task_addTodayTimeSheet",$model,'@','spModel');

				$srModel2 = self::invokeBusiness("AppTaskBusiness","getTaskInfo",array('id'=>$model['task_id'],'need_tsheet'=>'1'),'@');
				$model = Sr::sys_copyProperties($model,$srModel2);

				$srModel2 = self::queryBySql("select distinct t.user_id from pmt_task_member t where t.task_id={0} /*w[t]*/",array($model["task_id"]));
				foreach($srModel2 as $kk=>$item){
					$model['array_task_member_bar'] .= Sr::sys_dictTableById('uup_user',$item['user_id'],'name').' ';
				}
				//dump($model['array_task_member']);
				$list[$k] = $model;
			}
			$srModel['list'][$tarDateOrinal] = Sr::sys_groupArray($list,"module_name");
		}
		if($task_list_type=='2'){
			krsort($srModel['list']);
		}else if($task_list_type=='3'){
			krsort($srModel['list']);
		}else if($task_list_type=='4'){
			krsort($srModel['list']);
		}else{
		}


//		$sql = "SELECT t2.id user_id,t2.name user_name
//FROM pmt_project_member t1, uup_user t2
//WHERE 1=1 /*w[t1]*/
//AND t1.user_id=t2.id";
//		$sql .= self::getCauseIfNotNull("t1.project_id = {0}",$spModel["query_project_id"]);
//		$list = self :: queryBySql($sql);
//
//
//		$srModel['project_user'] = $list;
		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function queryTask($spModel) {
		$srModel = array ();

		$where = '';

		$where .= self::getCauseIfNotNull("t.id like '%{0}%'",$spModel["query_id"]);
		$where .= self::getCauseIfNotNull("t.project_id = '{0}'",$spModel["query_project_id"]);
		$where .= self::getCauseIfNotNull("t.module_id = '{0}'",$spModel["query_module_id"]);
		$where .= self::getCauseIfNotNull("t.code like '%{0}%'",$spModel["query_code"]);
		$where .= self::getCauseIfNotNull("t.parent_task_id like '%{0}%'",$spModel["query_parent_task_id"]);
		$where .= self::getCauseIfNotNull("t.name like '%{0}%'",$spModel["query_name"]);
		$where .= self::getCauseIfNotNull("t.proirity = '{0}'",$spModel["query_proirity"]);
		$where .= self::getCauseIfNotNull("t.module_type_task_id like '%{0}%'",$spModel["query_module_type_task_id"]);
		$where .= self::getCauseIfNotNull("t.manager_id = '{0}'",$spModel["query_manager_id"]);
		$where .= self::getCauseIfNotNull("EXISTS(SELECT a.* FROM pmt_task_member a WHERE 1=1 /*w[a]*/ and a.task_id = t.id AND a.user_id IN({0}))",$spModel["query_array_task_member"]);
		$where .= self::getCauseIfNotNull("t.adv_begin_date like '%{0}%'",$spModel["query_adv_begin_date"]);
		$where .= self::getCauseIfNotNull("t.adv_end_date like '%{0}%'",$spModel["query_adv_end_date"]);
		$where .= self::getCauseIfNotNull("t.adv_person_day like '%{0}%'",$spModel["query_adv_person_day"]);
		$where .= self::getCauseIfNotNull("t.constraint_type = '{0}'",$spModel["query_constraint_type"]);
		$where .= self::getCauseIfNotNull("t.constraint_time like '%{0}%'",$spModel["query_constraint_time"]);
		$where .= self::getCauseIfNotNull("t.content like '%{0}%'",$spModel["query_content"]);
		$where .= self::getCauseIfNotNull("t.url like '%{0}%'",$spModel["query_url"]);
		$where .= self::getCauseIfNotNull("t.ticket_type like '%{0}%'",$spModel["query_ticket_type"]);
		$where .= self::getCauseIfNotNull("t.status like '%{0}%'",$spModel["query_status"]);
		$where .= self::getCauseIfNotNull("t.adv_progress like '%{0}%'",$spModel["query_adv_progress"]);
		$where .= self::getCauseIfNotNull("t.no like '%{0}%'",$spModel["query_no"]);
		$where .= self::getCauseIfNotNull("t.type_ms_id like '%{0}%'",$spModel["query_type_ms_id"]);
		$where .= self::getCauseIfNotNull("t.act_begin_date like '%{0}%'",$spModel["query_act_begin_date"]);
		$where .= self::getCauseIfNotNull("t.act_end_date like '%{0}%'",$spModel["query_act_end_date"]);
		$where .= self::getCauseIfNotNull("t.act_person_day like '%{0}%'",$spModel["query_act_person_day"]);
		$where .= self::getCauseIfNotNull("t.act_person_normal_day like '%{0}%'",$spModel["query_act_person_normal_day"]);
		$where .= self::getCauseIfNotNull("t.act_person_over_day like '%{0}%'",$spModel["query_act_person_over_day"]);
		$where .= self::getCauseIfNotNull("t.act_progress like '%{0}%'",$spModel["query_act_progress"]);
		$where .= self::getCauseIfNotNull("t.belong_org_id = {0}",$spModel["query_belong_org_id"]);
		$where .= self::getCauseIfNotNull("t.belong_user_id = {0}",$spModel["query_belong_user_id"]);

		$sql = "SELECT t.*,t.id _childCode_,t.parent_task_id _parentCode_,t.no _childSortNo_,t1. adv_begin_date,t1. adv_end_date,t1.adv_work_day,t1.adv_person_day,t1.adv_progress,t1.act_begin_date,t1.act_end_date,t1.act_work_day,t1.act_person_day,t1.act_progress,t1.tsh_begin_date,t1.tsh_end_date,t1.tsh_work_day,t1.tsh_person_day,t1.tsh_person_normal_day,t1.tsh_person_over_day,t1.tsh_progress  FROM pmt_task t ,pmt_progress t1  WHERE 1=1 /*w[t,t1]*/ AND t.id=t1.table_id AND t1.table_name='pmt_task' {$where} order by t.id desc";
		$list = self :: queryTreeViewBySql2($sql, array (), 'name');
		$srModel['list'] = $list;
		$srModel['page'] = "";

		foreach ($srModel['list'] as $k => $model) {
			$srModel2 = self :: queryBySql("select t.user_id,t1.name from pmt_task_member t,uup_user t1 where t.task_id={0} and t.is_deleted='0' and t.user_id=t1.id", array (
				$model["id"]
			));
			$model['array_task_member'] = Sr :: sys_listToPostparam($srModel2, 'user_id');
			$model['array_task_member_name'] = Sr :: sys_listToPostparam($srModel2, 'name');

			$model = self::getValue_invokeBusiness("AppCommonBusiness","task_calcProgress",$model,'@','spModel');
			$srModel['list'][$k] = $model;
		}
		self :: addInfoResults($srModel, null);
		return $srModel;
	}

} //end class
?>