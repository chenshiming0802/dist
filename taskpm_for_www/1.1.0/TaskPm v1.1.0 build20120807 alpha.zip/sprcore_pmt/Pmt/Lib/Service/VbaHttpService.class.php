<?php
class VbaHttpService extends SrService {
 	public function uploadDocumentFile($spModel) {

		$srModel = array ();
 
		$document_id = $spModel["document_id"];
		$path_id = $spModel["path_id"];
		$table_id = $spModel["table_id"];
		$table_name = $spModel["table_name"];
		$file_size = $spModel["file_size"];
 		$file = $_FILES['file'];
 
 		$model = self::queryById2($document_id,'pmt_document');
 		
 		if($model==null){
			//文件不存在
			self :: addFailResults($srModel, "message.fail.upload.filename.notfound",array());
			return $srModel;
		}		
		if($model['is_current_version']!='1'){
			//版本不是最新的
			self :: addFailResults($srModel,'message.fail.upload.filename.notcurrentversion',array());
			return $srModel;
		}
		if($model['document_type']!='010'){
			//文件类型不对
			self :: addFailResults($srModel, "message.fail.upload.filename.notfiletype",array());
			return $srModel;
		}
		$sql = "select * from pmt_document_tfile t where document_id='{0}' /*w[t]*/";
		$model2 = self::getRowBySql($sql,array($document_id));
		
		if($model2['original_document_name']!=$file['name']){
			//文件名不对
			self :: addFailResults($srModel, "message.fail.upload.filename.wrong",array($file['name']));
			return $srModel;
		}		
		if($model2['file_size']!=$file_size){
			//文件大小不对
			self :: addFailResults($srModel, "message.fail.upload.filename.sizeerror",array());
			return $srModel;
		}
	
		
		//上传文件
		$spModel2 = array();
		$spModel2['path_id'] = $path_id;
		$spModel2['table_id'] = $table_id;
		$spModel2['table_name'] = $table_name;
		$srModel2 = self::invokeService('AppPmtDocumentService','uploadDocumentFile', $spModel2 );
		if($srModel2['document_id']==null || $srModel2['document_id']==''){
			//文件上传错误
			self :: addFailResults($srModel, "message.fail.upload.filename.upload.exception",array());
			return $srModel;
		}
		
		
		//版本更新
		$spModel3 = array();
		$spModel3['document_id'] = $srModel2['document_id'];
		$spModel3['path_id'] = $path_id;
		$spModel3['table_id'] = $table_id;
		$spModel3['table_name'] = $table_name;	
		$spModel3['oldDocumentIds'] = array($document_id);		
		$spModel3['action'] = 'update_version';		
		$srModel3 = self::invokeService('AppPmtDocumentService','uploadDocumentFileDup', $spModel3 );
	
	 

		self :: addInfoResults($srModel, 'message.info.upload.success',array());
		return $srModel;
	}			
		
	public function getCurrentDocument($spModel) {
		$srModel = array ();
		$old_document_id = $spModel["document_id"];
		$mm = self::queryById2($old_document_id,'pmt_document');
		$document_id = $mm['current_version_id'];
		if($document_id==null||$document_id==''){
			$document_id = $old_document_id;
		}
		
 		$srModel['document'] = self::queryById2($document_id,'pmt_document');
 		$sql = "select * from pmt_document_tfile t where t.document_id='{0}' /*w[t]*/";
 		$srModel['document_tfile'] = self::getRowBySql($sql,array($document_id));
		self :: addInfoResults($srModel, null);
		return $srModel;
	}	
} //end class
?>