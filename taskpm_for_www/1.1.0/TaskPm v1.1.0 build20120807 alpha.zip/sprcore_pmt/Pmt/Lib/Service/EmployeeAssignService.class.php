<?php
 
class EmployeeAssignService extends SrService
{
 
public function queryEmployeeAssign($spModel){
		$srModel = array();

		$where = '';
		
		$where .= self::getCauseIfNotNull("t.id like '%{0}%'",$spModel["query_id"]);		
		$where .= self::getCauseIfNotNull("t.status like '%{0}%'",$spModel["query_status"]);		
		$where .= self::getCauseIfNotNull("t.employee_id = '{0}'",$spModel["query_employee_id"]);		
		$where .= self::getCauseIfNotNull("t.project_id = '{0}'",$spModel["query_project_id"]);		
		$where .= self::getCauseIfNotNull("t.joblevel_id = '{0}'",$spModel["query_joblevel_id"]);		
		$where .= self::getCauseIfNotNull("t.company_id = '{0}'",$spModel["query_company_id"]);		
		$where .= self::getCauseIfNotNull("t.memo like '%{0}%'",$spModel["query_memo"]);		
		$where .= self::getCauseIfNotNull("t.year like '%{0}%'",$spModel["query_year"]);		
		$where .= self::getCauseIfNotNull("t.m1 like '%{0}%'",$spModel["query_m1"]);		
		$where .= self::getCauseIfNotNull("t.m2 like '%{0}%'",$spModel["query_m2"]);		
		$where .= self::getCauseIfNotNull("t.m3 like '%{0}%'",$spModel["query_m3"]);		
		$where .= self::getCauseIfNotNull("t.m4 like '%{0}%'",$spModel["query_m4"]);		
		$where .= self::getCauseIfNotNull("t.m5 like '%{0}%'",$spModel["query_m5"]);		
		$where .= self::getCauseIfNotNull("t.m6 like '%{0}%'",$spModel["query_m6"]);		
		$where .= self::getCauseIfNotNull("t.m7 like '%{0}%'",$spModel["query_m7"]);		
		$where .= self::getCauseIfNotNull("t.m8 like '%{0}%'",$spModel["query_m8"]);		
		$where .= self::getCauseIfNotNull("t.m9 like '%{0}%'",$spModel["query_m9"]);		
		$where .= self::getCauseIfNotNull("t.m10 like '%{0}%'",$spModel["query_m10"]);		
		$where .= self::getCauseIfNotNull("t.m11 like '%{0}%'",$spModel["query_m11"]);		
		$where .= self::getCauseIfNotNull("t.m12 like '%{0}%'",$spModel["query_m12"]);
		$where .= self::getCauseIfNotNull("t.belong_org_id = {0}",$spModel["query_belong_org_id"]);
		$where .= self::getCauseIfNotNull("t.belong_user_id = {0}",$spModel["query_belong_user_id"]);

 
		$sql = "select t.* from pmt_employee_assign t  where 1=1 /*w[t]*/ {$where}  order by id desc";
 

 		$srModel = self::queryPageBySql($sql);


		self::addInfoResults($srModel,null);
		return $srModel;
	}
	
 	public function getEmployeeAssign($spModel){
		$id = $spModel["id"];
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$srModel = array();
		$srModel = self::queryById2($id,"pmt_employee_assign");
		if($srModel!=null){		



		}else{
	
		}

		self::addInfoResults($srModel,null);
		return $srModel;
	}




	

	
public function deleteEmployeeAssign($spModel){
		$id = $spModel["id"];
		$srModel = array();
		$spModel["is_deleted"] = "1";
		
		$srModel = self::update2($id,$spModel,"pmt_employee_assign");

		
		self::addInfoResults($srModel,'message.success.delete',array($srModel["name"]));
		return $srModel;
	}	

}//end class



?>