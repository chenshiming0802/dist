<?php
class AppTaskFavoriteBusiness extends SrService{	

}
?>
