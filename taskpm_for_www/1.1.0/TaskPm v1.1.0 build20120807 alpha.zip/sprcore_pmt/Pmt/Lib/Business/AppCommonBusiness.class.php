<?php
class AppCommonBusiness extends SrService {

	//计算Module的进度信息
	public static function module_calcProgress($spModel){
		return self::task_calcProgress($spModel);
	}
	//任务添加工时信息
	public static function task_addTodayTimeSheet($spModel){
		$srModel = array ();

		$task_id = $spModel['task_id'];//task_id
		$toDay = Sr::sys_date();
		$sql = "select sum(t.hours+t.ext_hours) total_hour from pmt_task_tsheet t where t.task_id={0} /*w[t]*/ and t.occure_date='{1}' and t.belong_user_id='{2}'";
		$total_hour = self::getValue_getRowBySql($sql,array($task_id,$toDay,SrUser::getUserId()),'total_hour');
		$spModel['total_hour'] = $total_hour;
		if($total_hour>0){
			$spModel['total_hour_desc'] = "今天工时{$total_hour}H";
		}
		$srModel['spModel']= $spModel;
		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	/**
	 * Y 值
	 * X 日期间隔
	 * a1 = 初始阶梯值/递减阶梯值
	 * IF(X>0)
	 *      Y = 基数 + 初始阶梯值
	 * ELSE IF(a1>=X)
	 * 		Y = 基数 - ( 初始阶梯值*X + 递减阶梯值*(X-X*X)/2 )
	 * ELSE IF(a1<X)
	 *      Y = 基数 - ( 初始阶梯值*a1 + 递减阶梯值*(a1-a1*a1)/2) - 递减阶梯值*(X-$a1)
	 */
	function calc_task_weight($b_js,$b_csjt,$b_djjt,$x){
		$a1 = $b_csjt / $b_djjt;
		$y = 0 ;
		if($x<0){
			$y = $b_js + $b_csjt;
	 	}else if($a1>=$x){
	 		$y = $b_js - ( $b_csjt*$x + $b_djjt*($x-$x*$x)/2 );
	 	}else if($a1<$x){
	 		$y = $b_js - ( $b_csjt*$a1 + $b_djjt*($a1-$a1*$a1)/2) - $b_djjt*($x-$a1);
	 	}
	 	return $y;
	}
	//计算Task的进度信息
	//usage:
	//	$srModel = self::getValue_invokeBusiness("AppCommonBusiness","task_calcProgress",$srModel,'@','spModel');
	public static function task_calcProgress($spModel){
		$hoursPerDay = C('PMT_HOURS_PER_DAY');
		$to_day = Sr::sys_datetime();
		$srModel = array ();
		$adv_person_day = $spModel['adv_person_day'];
		$forcalc_info_base_day = Sr::sys_get($spModel['forcalc_info_base_day'],$to_day);//用于计算还有多少日子过期的基线日期
		if($forcalc_info_base_day==Sr::sys_date()){
			$forcalc_info_base_day = $to_day;//如果是今天,应该精确到小时
		}


		if($adv_person_day!=null && $adv_person_day!='' && $adv_person_day!='0'){
			//如果填写了预计人日,则需要计算参照进度 = 已填写工时/预计总工时
			$spModel['tsh_progress'] = (float)((float)$spModel['tsh_person_day']/$hoursPerDay*100/(float)$adv_person_day);
			$spModel['tsh_progress'] = round($spModel['tsh_progress'],0);

		}
		$adv_begin_date = $spModel['adv_begin_date'];
		$adv_end_date = $spModel['adv_end_date'];

		if($adv_begin_date!=null && $adv_begin_date!='' && $adv_end_date!=null && $adv_end_date!=''){
			$fenzi = Sr::sys_getDateFromDbString($to_day) - Sr::sys_getDateFromDbString($adv_begin_date.' 08:00:00');
			$fenmu = Sr::sys_getDateFromDbString($adv_end_date.' 17:00:00') - Sr::sys_getDateFromDbString($adv_begin_date.' 08:00:00');

			if($fenzi>0 && $fenmu>0){
				$spModel['adv_progress'] = $fenzi / $fenmu * 100;
				$spModel['adv_progress'] = round($spModel['adv_progress'],0);
				if($spModel['adv_progress']>=100){
					$spModel['adv_progress'] = 100;
				}
			}
		}
		$spModel['adv_work_day'] = Sr::sys_addUnit($spModel['adv_work_day'], "D");
		$spModel['adv_person_day'] = Sr::sys_addUnit($spModel['adv_person_day'], "D");
		$spModel['adv_progress'] = Sr::sys_addUnit($spModel['adv_progress'], "%");
		//$spModel['act_work_day'] = Sr::sys_addUnit($spModel['act_work_day'], "D");
		//$spModel['act_person_day'] = Sr::sys_addUnit($spModel['act_person_day'], "D");
		$spModel['act_progress'] = Sr::sys_addUnit($spModel['act_progress'], "%");
		$spModel['tsh_work_day'] = Sr::sys_addUnit($spModel['tsh_work_day'], "D");
		$spModel['tsh_person_day'] = Sr::sys_addUnit($spModel['tsh_person_day'], "H");
		$spModel['tsh_person_normal_day'] = Sr::sys_addUnit($spModel['tsh_person_normal_day'], "H");
		$spModel['tsh_person_over_day'] = Sr::sys_addUnit($spModel['tsh_person_over_day'], "H");
		$spModel['tsh_progress'] = Sr::sys_addUnit($spModel['tsh_progress'], "%");



		$mm['tsh_work_day'] = Sr::sys_getDateFromDbString($spModel['tsh_end_date']) - Sr::sys_getDateFromDbString($spModel['tsh_begin_date']);

		//计算日期信息的中文描述
		$adv_begin_date = $spModel['adv_begin_date'];
		$adv_end_date = $spModel['adv_end_date'];
		//预计开始间隔时间
		$info_sd_begin_day = (float)Sr::sys_getSepDateByDbString($forcalc_info_base_day,$adv_begin_date.' 08:00:00');
		//预计结束间隔时间
		$info_sd_sd_end = (float)Sr::sys_getSepDateByDbString($forcalc_info_base_day,$adv_end_date.' 17:00:00');
		$spModel['info_sd_begin_day'] = $info_sd_begin_day;
		$spModel['info_sd_sd_end'] = $info_sd_sd_end;
		$str = '';

		$class = "";
		if($info_sd_begin_day<0){
			//还未开始
			$str = "在".(0-$info_sd_begin_day)."天后开始";
			$class = 'dayinfo_readyBegin';
		}else{
			if($info_sd_sd_end<0){
				//正常
				$str = "在".(0-$info_sd_sd_end)."天后结束";
				$class = 'dayinfo_normal';
			}else{
				//已经截止
				$str = "过期".$info_sd_sd_end."天";
				$class = 'dayinfo_alreadyEnd';
			}
		}
		$spModel['dayinfo_class'] = $class;
		$spModel['info_adv_beginendday'] = $str;

		/*
		 * 计算任务重要数
		 *
		 * Z 优先级值
		 * IF(高)
		 *      Z = 递减阶梯值 * 2
		 * ELSE IF(中)
		 *      Z = 递减阶梯值 * 1
		 * ELSE(低)
		 *      Z = 递减阶梯值 * 0
		 *
		 * 后墙:
		 * 	基数=40 初始阶梯值=10 递减阶梯值=2
		 * 预计结束
		 *  基数=30 初始阶梯值=10 递减阶梯值=2
		 * 预计开始
		 *  基数=20 初始阶梯值=10 递减阶梯值=2
		 *
		 */
		 $weight_constraint = 0;
		 if($spModel['constraint_type']=='020' && $spModel['constraint_time']!=''){
 		 	$x = (float)Sr::sys_getSepDateByDbString($forcalc_info_base_day,$spModel['constraint_time']);
		 	$weight_constraint = self::calc_task_weight(40,10,2,$x);

		 }
		 //dump($x."/".$weight_constraint);
		 $weight_sd_begin = 0;
		 if($adv_begin_date!=null&&$adv_begin_date!=''){
		 	$x = 0 - $info_sd_begin_day;
		 	$weight_sd_begin = self::calc_task_weight(20,10,2,$x);
		 }
		 //dump($x."/".$weight_sd_begin);
		 $weight_sd_end = 0;
		 if($adv_end_date!=null&&$adv_end_date!=''){
		 	$x = 0-$info_sd_sd_end;
		 	$weight_sd_end = self::calc_task_weight(30,10,2,$x);
		 }
		 //dump($x."/".$weight_sd_end);
		 $weight_proirity = 0;
		 switch($spModel['proirity']){
			case '010'://高
				$weight_proirity = 10;
				break;
			case '020'://中
				$weight_proirity = 5;
				break;
			case '030'://低
				$weight_proirity = 0;
		}
		//dump($weight_proirity);
		$spModel['emerg_weight']= $weight_constraint + $weight_sd_begin + $weight_sd_end + $weight_proirity;
		/**
		 * 限制日期-必须完成::未过期0.5颗星 过期1.5颗星
		 * 起至时间:: 未开始0颗星 开始未过期1颗星 过期2颗星
		 * 优先级:: 高1颗星 中半颗星 低没有星
		 * (假设:今天截止也是过期)
		 * 备用:指派人:: 参与人0颗星 负责人半颗星
		 */
//		$star = 0;
//		if($spModel['constraint_type']=='020'){
//			if($spModel['constraint_type']!=null && $spModel['constraint_time']<=Sr::sys_date()){
//				$star += 2;
//			}else{
//				$star += 1;
//			}
//		}
//		if($info_sd_begin_day<0){
//			//还未开始
//			$star += 0;
//		}else{
//			if($info_sd_sd_end<=0){
//				//正常
//				 $star += 1;
//			}else{
//				//已经截止
//				$star += 2;
//			}
//		}
//		switch($spModel['proirity']){
//			case '010'://高
//				$star += 1;
//				break;
//			case '020'://中
//				$star += 0.5;
//				break;
//			case '030'://低
//				$star += 0.5;
//		}
		$spModel['star']= $spModel['emerg_weight']/20;

		$srModel['spModel']= $spModel;

		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	//维护progress的任务信息
	public function progress_fillTask($spModel) {
		$srModel = array ();
		$id = $spModel["id"];
		$srModel2 = self :: invokeBusiness("AppCommonBusiness", "progress_getRow", array (
			'table_id' => $id,
			'table_name' => 'pmt_task'
		), 'Pmt');
		$spModel['table_name'] = 'pmt_task';
		$spModel['table_id'] = $id;
		$spModel['adv_work_day'] = Sr::sys_getDateFromDbString($srModel2['adv_end_date']) - Sr::sys_getDateFromDbString($srModel2['adv_begin_date']);
		$spModel['adv_work_day'] = (float)round($spModel['adv_work_day']/86400,0) + 1;
				//dump($spModel);
//		dump($spModel);halt();
		if ($srModel2['id'] == null) {
			$srModel = self :: insert2($spModel, 'pmt_progress');
		} else {
//			Sr::info($spModel);
//			Sr::info('============='.$srModel2['id'].'/'.$spModel['adv_work_day']);
			self :: update2($srModel2['id'], $spModel, "pmt_progress");
		}

		self :: addInfoResults($srModel, null);
		return $srModel;
	}
	//维护progress的任务信息
	public function progress_fillModule($spModel) {
		$srModel = array ();
		$id = $spModel["id"];//module_id
		$srModel2 = self :: invokeBusiness("AppCommonBusiness", "progress_getRow", array (
			'table_id' => $id,
			'table_name' => 'pmt_module'
		), 'Pmt');
		$spModel['table_name'] = 'pmt_module';
		$spModel['table_id'] = $id;
		$spModel['adv_work_day'] = Sr::sys_getDateFromDbString($spModel['adv_end_date']) - Sr::sys_getDateFromDbString($spModel['adv_begin_date']);
		$spModel['adv_work_day'] = round($spModel['adv_work_day']/86400,1) + 1;

		if ($srModel2['id'] == null) {
			$srModel = self :: insert2($spModel, 'pmt_progress');
		} else {
			//dump($spModel);halt();
			self :: update2($srModel2['id'], $spModel, "pmt_progress");
		}

		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	//根据table_id,table_name获取记录
	public function progress_getRow($spModel) {
		$table_id = $spModel['table_id'];
		$table_name = $spModel['table_name'];
		if($table_id!=null&&$table_id!=''){
			$srModel = self :: getRowBySql("select * from pmt_progress t where 1=1 /*w[t]*/  and t.table_id={0} and t.table_name='{1}'", array (
				$table_id,$table_name
			));
		}
		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function progress_getRow2($spModel) {
		$list = $spModel['list'];
		$table_name = $spModel['table_name'];

		$where2 .= self :: getCauseIfNotNull("t.table_name='{0}'", $table_name);
		$sql = "SELECT t.*
			 FROM pmt_progress t
			 WHERE t.table_id IN({-1})  {$where2} /*w[t]*/
			 ";

		$srModel['list'] = self::addListItemInfo(
			 $list,
			 "id",
			 "table_id",
			 "",
			 $sql,
			 array()
		);
		self :: addInfoResults($srModel, null);
		return $srModel;
	}


	//根据table_id,table_name获取记录
	public function progress_version_getRow($spModel) {
		$table_id = $spModel['table_id'];
		$table_name = $spModel['table_name'];
		$spr_version_id = $spModel['spr_version_id'];

		if($table_id!=null&&$table_id!=''){
			$srModel = self :: getRowBySql("select * from pmt_progress_version t where 1=1 /*w[t]*/  and t.table_id={0} and t.table_name='{1}' and spr_version_id={2}", array (
				$table_id,$table_name,$spr_version_id
			));
		}


		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	//
	public function moduleProgress_updateModuleTsheet($spModel){
		$id = $spModel['id']; //Module ID
//		$hoursPerDay = C('PMT_HOURS_PER_DAY');

		$srModel = array ();
		$moduleModel = self :: queryById2($id, "pmt_module");

		$sql = "select * from pmt_progress t where 1=1 /*w[t]*/ and t.table_id={0} and t.table_name='pmt_module'";
		$mmDb = self::getRowBySql($sql,array($id));
		$mm = array();

		$sql2 = " FROM pmt_task_tsheet t,pmt_task t1
WHERE  1=1 /*w[t,t1]*/
AND t.task_id=t1.id and t1.module_id={0}
AND t.status = '100' and t1.status in ('020','050','100')";

		$sql = "select sum(hours) tsh_person_normal_day {$sql2}  ";

		$mm['tsh_person_normal_day'] = Sr::sys_get(self :: getValue_getRowBySql($sql,array($id),'tsh_person_normal_day'),'0');
		//echo "=".$mm['tsh_person_normal_day']."/".$hoursPerDay."==";
//		$mm['tsh_person_normal_day'] = round($mm['tsh_person_normal_day']/$hoursPerDay,1);
		//echo $mm['tsh_person_normal_day']."<BR>";

		$sql = "select sum(ext_hours) tsh_person_over_day {$sql2}  ";
		$mm['tsh_person_over_day'] = Sr::sys_get(self :: getValue_getRowBySql($sql,array($id),'tsh_person_over_day'),'0');
//		$mm['tsh_person_over_day'] = round($mm['tsh_person_over_day']/$hoursPerDay,1);

		$mm['tsh_person_day'] = (float)$mm['tsh_person_normal_day'] + (float)$mm['tsh_person_over_day'];

		$sql = "select min(t.occure_date)  tsh_begin_date  {$sql2}";
		$mm['tsh_begin_date'] = self :: getValue_getRowBySql($sql,array($id),'tsh_begin_date');

		$sql = "select max(t.occure_date)  tsh_end_date  {$sql2}";
		$mm['tsh_end_date'] = self :: getValue_getRowBySql($sql,array($id),'tsh_end_date');

		$mm['tsh_work_day'] = Sr::sys_getDateFromDbString($mm['tsh_end_date']) - Sr::sys_getDateFromDbString($mm['tsh_begin_date']);
		$mm['tsh_work_day'] = round($mm['tsh_work_day']/86400,1);

		self::update2($mmDb['id'],$mm,'pmt_progress');

		self :: addInfoResults($srModel, null);
		return $srModel;
	}
	//工时修改后,任务的progree修改
	public function taskProgress_updateParentTsheet($spModel){
		$id = $spModel['id']; //任务ID
//		$hoursPerDay = C('PMT_HOURS_PER_DAY');

		$srModel = array ();
		$parentModel = self :: queryById2($id, "pmt_task");
		$module_id = $parentModel['module_id'];
		$parent_id = $parentModel['parent_task_id'];

		$sql = "select * from pmt_progress t where 1=1 /*w[t]*/ and t.table_id={0} and t.table_name='pmt_task'";
		$mmDb = self::getRowBySql($sql,array($id));
		$mm = array();

		$sql2 = " FROM pmt_task_tsheet t,sys_help_tree a1,sys_help_tree_detail a2
WHERE  1=1 /*w[t,a1,a2]*/
AND a1.id=a2.help_tree_id
AND a1.table_name='pmt_task'
AND a2.node_value=t.task_id
AND a2.parent_field_value = '{0}' AND t.status = '100' ";

		$sql = "select sum(hours) tsh_person_normal_day {$sql2} ";
		$mm['tsh_person_normal_day'] = Sr::sys_get(self :: getValue_getRowBySql($sql,array($id),'tsh_person_normal_day'),'0');
		//echo "=".$mm['tsh_person_normal_day']."/".$hoursPerDay."==";
//		$mm['tsh_person_normal_day'] = round($mm['tsh_person_normal_day']/$hoursPerDay,1);
		//echo $mm['tsh_person_normal_day']."<BR>";

		$sql = "select sum(ext_hours) tsh_person_over_day {$sql2}  ";
		$mm['tsh_person_over_day'] = Sr::sys_get(self :: getValue_getRowBySql($sql,array($id),'tsh_person_over_day'),'0');
//		$mm['tsh_person_over_day'] = round($mm['tsh_person_over_day']/$hoursPerDay,1);

		$mm['tsh_person_day'] = (float)$mm['tsh_person_normal_day'] + (float)$mm['tsh_person_over_day'];

		$sql = "select min(t.occure_date)  tsh_begin_date  {$sql2}";
		$mm['tsh_begin_date'] = self :: getValue_getRowBySql($sql,array($id),'tsh_begin_date');

		$sql = "select max(t.occure_date)  tsh_end_date  {$sql2}";
		$mm['tsh_end_date'] = self :: getValue_getRowBySql($sql,array($id),'tsh_end_date');

		$mm['tsh_work_day'] = Sr::sys_getDateFromDbString($mm['tsh_end_date']) - Sr::sys_getDateFromDbString($mm['tsh_begin_date']);

		$mm['tsh_work_day'] = round($mm['tsh_work_day']/86400,1);
//		dump($mm['tsh_work_day']);
//		halt();

//		$adv_person_day = $mmDb['adv_person_day'];
//		if($adv_person_day!=null && $adv_person_day!='' && $adv_person_day!='0'){
//			//如果填写了预计人日,则需要计算参照进度
//			$mm['tsh_progress'] = (float)((float)$mm['tsh_person_day']*100/(float)$adv_person_day);
//			$mm['tsh_progress'] = round($mm['tsh_progress'],1);
//		}
//echo $mm['tsh_person_day']."/".$adv_person_day;
//dump($mm['tsh_progress']);
//dump($mm);
		self::update2($mmDb['id'],$mm,'pmt_progress');
		if($parent_id!=null&&$parent_id!=''&&$parent_id!='0'){
			self :: taskProgress_updateParentTsheet(array('id'=>$parent_id));//更新父节点
		}else{
			self::invokeBusiness("AppCommonBusiness","moduleProgress_updateModuleTsheet",array("id"=>$module_id),"Pmt");
		}
		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function module_updateModuleByTaskInfo($spModel){
		$srModel = array();
		$id = $spModel['id'];//Module ID
		$mmDb = self::queryById2($id,"pmt_module");
			$sql2 = " FROM pmt_task t,pmt_progress t1
 WHERE t1.table_id=t.id
 and t1.table_name='pmt_task'
  /*w[t,t1]*/
 and t.status in ('020','050','100')  AND t.module_id={0} and (t.parent_task_id IS NULL OR t.parent_task_id ='0')";
 		$mm = array();
 		$mm['id'] =  $id;
 		$sql = "SELECT MIN(t1.adv_begin_date) adv_begin_date {$sql2} ";
 		$mm['adv_begin_date'] = self :: getValue_getRowBySql($sql, array ($id),'adv_begin_date');
  		$sql = "SELECT MAX(t1.adv_end_date) adv_end_date {$sql2} ";
 		$mm['adv_end_date'] = self :: getValue_getRowBySql($sql, array ($id),'adv_end_date');
 		$sql = "SELECT SUM(t1.adv_person_day) adv_person_day {$sql2} ";
 		$mm['adv_person_day'] = self :: getValue_getRowBySql($sql, array ($id),'adv_person_day');
 		$mm['adv_work_day'] = Sr::sys_getDateFromDbString($mm['adv_end_date']) - Sr::sys_getDateFromDbString($mm['adv_begin_date']);
		$mm['adv_work_day'] = round($mm['adv_work_day']/86400,1) + 1;
		//计算实际进度
		$sql3 = "";
		//$sql3 = " and t1.act_progress IS NOT NULL AND t1.adv_person_day IS NOT NULL";去掉没有设置时间和人日的task
		$sql = "SELECT SUM(t1.act_progress*t1.adv_person_day) wptotal {$sql2} {$sql3}";
		$wptotal = (float)self :: getValue_getRowBySql($sql, array ($id),'wptotal');
		$sql = "SELECT SUM(t1.adv_person_day) wtotal {$sql2} {$sql3}";
		$wtotal = (float)self :: getValue_getRowBySql($sql, array ($id),'wtotal');
		if($wtotal!=null&&$wtotal!=''&&$wtotal!='0'){
			$mm['act_progress'] = round($wptotal/$wtotal,1);
		}else{
			$mm['act_progress'] = 0;
		}


		self::invokeBusiness("AppCommonBusiness","progress_fillModule",$mm,'Pmt');

		$sql = "SELECT DISTINCT t2.user_id FROM pmt_task t1,pmt_task_member t2 WHERE  1=1 /*w[t1,t2]*/ AND t1.id=t2.task_id and t1.module_id={0}";
		$members = self :: queryBySql($sql, array ($id));
		foreach ($members as $key => $m) {
			$user_id_1 = $m['user_id'];
			$cnt = self :: getCountBySql("select * from pmt_module_member t where  1=1 /*w[t]*/ and t.module_id={0} and t.user_id={1}", array (
				$id,
				$user_id_1
			));
			if ($cnt == 0) {
				$memberModel = array ();
				$memberModel['task_id'] = $id;
				$memberModel['user_id'] = $user_id_1;
				self :: insert2($memberModel, "pmt_module_member");
			}
		}

		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	//更新结点的字段(预计开始/预计结束/预计人日/预计成员)
	public function task_updateParentTask($spModel) {
		$id = $spModel['id'];//任务ID
		$srModel = array ();
		$currentModel = self :: queryById2($id, "pmt_task");

		$treeType = $currentModel['spr_tree_type'];
		if($treeType==null||$treeType==''||$treeType=='020'){
			if($currentModel['status']=='050'){
		  		$sql = "select * from pmt_progress t where t.table_id={0} and t.table_name='pmt_task' /*w[t]*/";
		 		$progress_id = self::getValue_getRowBySql($sql,array($id),'id');
		 		$progress = array();
		 		$progress['act_progress'] = 80;
		 		$progress['finish_time'] = Sr::sys_datetime();
		 		self::update2($progress_id,$progress,'pmt_progress');
			}else if($currentModel['status']=='100'){
		  		$sql = "select * from pmt_progress t where t.table_id={0} and t.table_name='pmt_task' /*w[t]*/";
		 		$progress_id = self::getValue_getRowBySql($sql,array($id),'id');
		 		$progress = array();
 				$progress['act_progress'] = 100;
 				$progress['close_time'] = Sr::sys_datetime();
		 		self::update2($progress_id,$progress,'pmt_progress');
			}

		}

		//dump($currentModel);halt();
		$parent_id = $currentModel['parent_task_id'];
		$model = array ();
		$model['id'] = $id;//更新数据的Model

		if ($id != null) {
			$sql2 = " FROM pmt_task t,pmt_progress t1
 WHERE t1.table_id=t.id
 and t1.table_name='pmt_task'
 /*w[t,t1]*/
 and t.status in ('020','050','100') AND t.parent_task_id={0}";

			//020 为固定的任务	\

//			$childCnt = self :: getCountBySql("select t.id {$sql2}", array (
//				$id,
//			));

			if($currentModel['spr_tree_type']!='020'){
				//仅有子任务且计算类型为020：根据子任务字段的才自动计算
				$sql = "SELECT MIN(t1.adv_begin_date) adv_begin_date {$sql2} ";
				$model['adv_begin_date'] = self :: getValue_getRowBySql($sql, array ($id),'adv_begin_date');

				$sql = "SELECT MAX(t1.adv_end_date) adv_end_date {$sql2} ";
				$model['adv_end_date'] = self :: getValue_getRowBySql($sql, array ($id),'adv_end_date');

				$sql = "SELECT SUM(t1.adv_person_day) adv_person_day {$sql2} ";
				$model['adv_person_day'] = self :: getValue_getRowBySql($sql, array ($id),'adv_person_day');

				//calc act_progress (p1w1+p2w2+...+pNwN)/(w1+w2+...+wN)
				$sql3 = "";
				//$sql3 = " and t1.act_progress IS NOT NULL AND t1.adv_person_day IS NOT NULL";去掉没有设置时间和人日的task
				$sql = "SELECT SUM(t1.act_progress*t1.adv_person_day) wptotal {$sql2} {$sql3}";
				$wptotal = (float)self :: getValue_getRowBySql($sql, array ($id),'wptotal');
				$sql = "SELECT SUM(t1.adv_person_day) wtotal {$sql2} {$sql3}";
				$wtotal = (float)self :: getValue_getRowBySql($sql, array ($id),'wtotal');
				if($wtotal==0){
					$model['act_progress'] = 0;
				}else{
					$model['act_progress'] = round($wptotal/$wtotal,1);
				}
			}

			//self :: update2($id, $model, "pmt_task");

			self::invokeBusiness("AppCommonBusiness","progress_fillTask",$model,'Pmt');

			$members = self :: queryBySql("SELECT DISTINCT t2.user_id FROM pmt_task t1,pmt_task_member t2 WHERE  1=1 /*w[t1,t2]*/ AND t1.id=t2.task_id and t1.id={0}", array (
				$id
			));
//				dump(count($members));
//				dump($id);

			foreach ($members as $key => $m) {
				$user_id_1 = $m['user_id'];

				$cnt = self :: getCountBySql("select * from pmt_task_member t where  1=1 /*w[t]*/ and t.task_id={0} and t.user_id={1}", array (
					$id,
					$user_id_1
				));
				if ($cnt == 0) {
					$memberModel = array ();
					$memberModel['task_id'] = $parent_id;
					$memberModel['user_id'] = $user_id_1;
					self :: insert2($memberModel, "pmt_task_member");
				}
			}
		}
		$parent_task = self :: queryById2($parent_id, "pmt_task");
		if($parent_task!=null){
			self :: task_updateParentTask(array (
					'id' => $parent_id
				));
		}else{
			//如果没有父节点,则更新Module
			self::invokeBusiness("AppCommonBusiness","module_updateModuleByTaskInfo",array('id'=>$currentModel['module_id']),'Pmt');
		}

		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function module_addMileStone($spModel) {

		$id = $spModel["id"];
		$srModel = array ();
		//新增里程碑任务
		$sql = "
						   SELECT t1.project_id project_id,t1.id module_id,t3.id type_ms_id,t3.no no,t3.name name,t1.manager_id manager_id,t1.proirity
						   FROM pmt_module t1,pmt_module_type t2,pmt_module_type_ms t3
						   WHERE t1.module_type_id=t2.id
						   AND t2.id=t3.type_id
						   AND  1=1 /*w[t1,t2,t3]*/
						   AND t1.id={0}
						   AND NOT EXISTS(
						     SELECT a1.*
						     FROM pmt_task a1
						     WHERE a1.module_id=t1.id
						     AND a1.type_ms_id=t3.id
						   )
						   ORDER BY t3.no ASC";
		$list = self :: queryBySql($sql, array (
			$id
		));
		foreach ($list as $k => $model) {
			$task_no = self :: task_genNo(array ());
			$model['code'] = $task_no['code'];
			$model['status'] = '020';
			//T000502	       模块创建的任务都是为目录任务
			$model['spr_tree_type'] = '010';
			$srModel = self :: insert2($model, "pmt_task");
			SrTree::addRow(array('table_name'=>'pmt_task','node_value'=>$srModel['id']));
			self::invokeBusiness("AppCommonBusiness","progress_fillTask",$srModel,'Pmt');
		}
		//新增文档目录
		$sql = "SELECT t3.*
FROM pmt_module t1, pmt_module_type t2,pmt_module_type_dpath t3
WHERE t1.module_type_id=t2.id
AND t2.id=t3.type_id and t1.id='{0}' /*w[t1,t2,t3]*/
ORDER BY t3.no ASC
 ";
 		$list = self::queryBySql($sql,array($id));
 		foreach($list as $k=>$item){
 			$sql = "SELECT * FROM pmt_document_path t WHERE t.table_id='{0}' AND t.table_name='{1}' AND t.name='{2}'";
 			$cnt = self::getCountBySql($sql,array($id,'pmt_module',$item['name']));
 			if($cnt==0){
 				$model = array();
 				$model['table_id'] = $id;
 				$model['table_name'] = 'pmt_module';
 				$model['name'] = $item['name'];
 				$model['no'] = $item['no'];
 				$model['parent_id'] = 0;
 				self::insert2($model,'pmt_document_path');
 			}
 		}
		self :: addInfoResults($srModel, null);
		return $srModel;
	}
	public function module_genNo($spModel) {
		$srModel = array ();
		$srModel_seq = SrSeq :: next(array (
			"code" => "pmt_module",
			"len" => 6,
			//"nextType" => "PY"
		));
		$srModel['code'] = str_replace("{-1}", $srModel_seq["val"], "M{-1}");
		self :: addInfoResults($srModel, null);
		return $srModel;
	}
	public function task_genNo($spModel) {
		$srModel = array ();
		$srModel_seq = SrSeq :: next(array (
			"code" => "pmt_task",
			"len" => 6,
			//"nextType" => "PY"
		));
		$srModel['code'] = str_replace("{-1}", $srModel_seq["val"], "T{-1}");
		self :: addInfoResults($srModel, null);
		return $srModel;
	}

} //end class
?>