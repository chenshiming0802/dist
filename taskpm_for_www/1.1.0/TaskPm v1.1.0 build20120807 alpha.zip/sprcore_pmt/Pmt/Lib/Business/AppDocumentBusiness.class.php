<?php
class AppDocumentBusiness extends SrService{	
	//是否是Task的管理者(项目经理/模块负责人/任务负责人)
	function getDocumentsCount($spModel){
		$table_id = $spModel['table_id'];
		$table_name = $spModel['table_name'];
		$path_id = $spModel['path_id'];
		$srModel = array();
		$where = '';
		$where .= self::getCauseIfNotNull("t1.path_id={0}",$path_id);	
		
		$sql = "
SELECT t.* FROM pmt_document t,pmt_document_link t1
WHERE t.id=t1.document_id
AND t1.table_name='{0}' and t.status<>'000' and t.is_current_version='1'
AND t1.table_id in ({1}) 
{$where} /*w[t,t1]*/ 
		";
		$cnt = self::getCountBySql($sql,array($table_name,$table_id));
		$srModel['count'] = $cnt;

		self :: addInfoResults($srModel, null);	
		return $srModel;				
	}	
 
}
?>
