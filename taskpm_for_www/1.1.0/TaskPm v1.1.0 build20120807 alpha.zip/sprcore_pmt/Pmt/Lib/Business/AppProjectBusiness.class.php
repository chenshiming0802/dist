<?php
class AppProjectBusiness extends SrService{
	//RAC模块项目经理设置
	public function rac_updateProjectMember($spModel){
		$srModel = array();
		//dump($spModel);halt();

		$role_id = self::assertNotBlank($spModel,'role_id');
		$dim_table_id = self::assertNotBlank($spModel,'dim_table_id');
		$assign_table_id = self::assertNotBlank($spModel,'assign_table_id');


		$sql = "select * from pmt_project_member t where t.project_id='{0}' and t.user_id={1} /*w[t]*/";
		$model = self::getRowBySql($sql,array($dim_table_id,$assign_table_id));
		//dump($model);halt();
		if($model==null){
			$model = array();
			$model['project_id']=$dim_table_id;
			$model['user_id']=$assign_table_id;
			self::insert2($model,'pmt_project_member');
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	//RAC模块配置人员设置
	public function rac_deleteProjectMember($spModel){
		$srModel = array();
		//dump($spModel);halt();
		$role_id = self::assertNotBlank($spModel,'role_id');
		$dim_table_id = self::assertNotBlank($spModel,'dim_table_id');
		$assign_table_id = self::assertNotBlank($spModel,'assign_table_id');

		$srModel2 = SrRac::hasUserAssignInCurrentDim(array(
			'role_id'=>$role_id,
			'assign_table_id'=>$assign_table_id,
			'dim_table_id'=>$dim_table_id,
		));
		$cnt = (int)$srModel2['count'];
		if($cnt>0){
			$sql = "select * from pmt_project_member t where t.project_id='{0}' and t.user_id={1} /*w[t]*/";
			$list = self::queryBySql($sql,array($dim_table_id,$assign_table_id));
			foreach($list as $model){
				$model['is_deleted']='1';
				self::update2($model['id'],$model,'pmt_project_member');
			}
		}
		//halt();
		self::addInfoResults($srModel,null);
		return $srModel;
	}
}
?>
