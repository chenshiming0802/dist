<?php
include_once(SPR_ROOT_SPATH.'Pmt'."\PmtTools.php");
class TaskSflow extends SrSflowService{
	//修改任务
	function editTaskHf($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$model = self::queryById2($id,"pmt_task");
		if(PmtTools::canEditTask($id)=='1'){
			$srModel["hf"] = "1";
		}else{
			$srModel["hf"] = "0";
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	//新增子任务
	function addChildTaskHf($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$model = self::queryById2($id,"pmt_task");
		if(PmtTools::canAddTask($id)=='1' && $model["spr_tree_type"]=='010'){
			$srModel["hf"] = "1";
		}else{
			$srModel["hf"] = "0";
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	//填写工时
	function fillTimeSheetHf($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$model = self::queryById2($id,"pmt_task");


		if($model["spr_tree_type"]=='020'||$model["spr_tree_type"]=='020'){
			$srModel["hf"] = "1";
		}else{
			$srModel["hf"] = "0";
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}

	//汇报进度
	function fillProgress($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$sflowDId = $spModel["sflow_flow_d_id"];
		$model['id'] = $id;
		$model["act_progress"] = $spModel['act_progress'];
		$model["act_progress_desc"] = $spModel['act_progress_desc'];

//		self::invokeService('TaskService','editTask', $model,"Pmt");
		self::invokeBusiness("AppCommonBusiness","progress_fillTask",$model,'Pmt');
		self::invokeBusiness("AppCommonBusiness","task_updateParentTask",array("id"=>$id),'Pmt');

//		$task = self::queryById2($id,"pmt_task");
		//self::invokeBusiness("AppCommonBusiness","taskProgress_updateParentTsheet",array("id"=>$mmDb['task_id']),"Pmt");
		//halt();
		self::addInfoResults($srModel,null);
		return $srModel;
	}
/*	function fillProgressPage($spModel){
		$srModel = array();
		$srModel['list'] = array();
		$sflowDId = $spModel["sflow_flow_d_id"];
		$id = $spModel["sflow_business_id"];
		$model = self::invokeService('TaskService','getTask', array('id'=>$id));
		$srModel['list']["pmt_task.act_progress"] = "
			<select name='".SrSflow::getInputName("act_progress",$sflowDId)."'>
			<option></option> ".
			Sr::sys_optionsArray(array(
				array('_valueCode_'=>'10','_valueName_'=>'10%'),
				array('_valueCode_'=>'20','_valueName_'=>'20%'),
				array('_valueCode_'=>'30','_valueName_'=>'30%'),
				array('_valueCode_'=>'40','_valueName_'=>'40%'),
				array('_valueCode_'=>'50','_valueName_'=>'50%'),
				array('_valueCode_'=>'60','_valueName_'=>'60%'),
				array('_valueCode_'=>'70','_valueName_'=>'70%'),
				array('_valueCode_'=>'80','_valueName_'=>'80%'),
				array('_valueCode_'=>'90','_valueName_'=>'90%'),
				array('_valueCode_'=>'100','_valueName_'=>'100%'),
			),$model["act_progress"])
			."</select>
		";
		$srModel['list']["pmt_task.act_progress_desc"] = "<textarea name='".SrSflow::getInputName("act_progress_desc",$sflowDId)."' id='".SrSflow::getInputName("act_progress_desc",$sflowDId)."' rows='5' cols='50'>".$model["act_progress_desc"]."</textarea>";

		self::addInfoResults($srModel,null);
		return $srModel;
	}*/
	function fillProgressPage($spModel){
		$view = $spModel['view_refer'];
		$srModel = array();

		$view->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.act_progress_desc','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'act_progress',
			'control_value'=>'1;;PMT19;',
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$view->spModel["act_progress"],
		));
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	function fillProgressHf($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$model = self::queryById2($id,"pmt_task");
		if(PmtTools::canEditTask($id)=='1'&&($model["spr_tree_type"]=='020'||$model["spr_tree_type"]=='020')){
			$srModel["hf"] = "1";
		}else{
			$srModel["hf"] = "0";
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}

	//完成任务
	function finishTask($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$sflowDId = $spModel["sflow_flow_d_id"];
		$model['id'] = $id;

//  		$sql = "select * from pmt_progress t where t.table_id={0} and t.table_name='pmt_task' /*w[t]*/";
// 		$progress_id = self::getValue_getRowBySql($sql,array($id),'id');
// 		$progress = array();
// 		$progress['act_progress'] = 80;
// 		$progress['finish_time'] = Sr::sys_datetime();
// 		self::update2($progress_id,$progress,'pmt_progress');
 		self::invokeBusiness("AppCommonBusiness","task_updateParentTask",array("id"=>$id),'Pmt');

		self::addInfoResults($srModel,null);
		return $srModel;
	}

	function finishTaskHf($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$flag = self::getValue_invokeBusiness("AppTaskBusiness","isTaskManager",array('task_id'=>$id),'Pmt','flag');
		if($flag=='1'){
			$srModel["hf"] = "1";
		}else{
			$srModel["hf"] = "0";
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	//关闭任务
	function closeTask($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$sflowDId = $spModel["sflow_flow_d_id"];
		$model['id'] = $id;

//  		$sql = "select * from pmt_progress t where t.table_id={0} and t.table_name='pmt_task' /*w[t]*/";
// 		$progress_id = self::getValue_getRowBySql($sql,array($id),'id');
// 		$progress = array();
// 		$progress['act_progress'] = 100;
// 		$progress['close_time'] = Sr::sys_datetime();
// 		self::update2($progress_id,$progress,'pmt_progress');
 		self::invokeBusiness("AppCommonBusiness","task_updateParentTask",array("id"=>$id),'Pmt');

		self::addInfoResults($srModel,null);
		return $srModel;
	}
	function closeTaskHf($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$flag = self::getValue_invokeBusiness("AppTaskBusiness","isTaskUpperManager",array('task_id'=>$id),'Pmt','flag');
		if($flag=='1'){
			$srModel["hf"] = "1";
		}else{
			$srModel["hf"] = "0";
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	//退回处理中
	function unFinishTask($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$sflowDId = $spModel["sflow_flow_d_id"];
		$model['id'] = $id;

  		$sql = "select * from pmt_progress t where t.table_id={0} and t.table_name='pmt_task' /*w[t]*/";
 		$progress_id = self::getValue_getRowBySql($sql,array($id),'id');
 		$progress = array();
 		$progress['act_progress'] = 0;
 		$progress['finish_time'] = '';
 		$progress['close_time'] = '';
 		self::update2($progress_id,$progress,'pmt_progress');
//		halt($id);
		self::invokeBusiness("AppCommonBusiness","task_updateParentTask",array("id"=>$id),'Pmt');

		self::addInfoResults($srModel,null);
		return $srModel;
	}
	function unFinishTaskHf($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$model = self::queryById2($id,"pmt_task");
		$project = self::queryById2($model['project_id'],"pmt_project");
		$flag = self::getValue_invokeBusiness("AppTaskBusiness","isTaskManager",array('task_id'=>$id),'Pmt','flag');
		if($flag=='1'){
			$srModel["hf"] = "1";
		}else{
			$srModel["hf"] = "0";
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}


	function convertDirectoryHf($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$model = self::queryById2($id,"pmt_task");
		//import("Pmt.PmtTools");
		//010 目录
		if(PmtTools::canEditTask($id)!='1'||$model["spr_tree_type"]=='010'){
			$srModel["hf"] = "0";
		}else{
			$srModel["hf"] = "1";
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	function convertDirectory($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$sflowDId = $spModel["sflow_flow_d_id"];
		$model = self::queryById2($id,'pmt_task');
		$model['spr_tree_type'] = '010';

 		self::update2($id,$model,'pmt_task');

		self::addInfoResults($srModel,null);
		return $srModel;
	}

	function convertPageHf($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$model = self::queryById2($id,"pmt_task");
		$sql = "select * from pmt_task t where t.parent_task_id='{0}' /*w[t]*/";
		$cnt = self::getCountBySql($sql,array($id));

		//010 目录
		if($model["spr_tree_type"]=='010' && $cnt==0){
			$srModel["hf"] = "1";
		}else{
			$srModel["hf"] = "0";
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	//??page
	function convertPage($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$sflowDId = $spModel["sflow_flow_d_id"];
		$model = self::queryById2($id,'pmt_task');
		$model['spr_tree_type'] = '020';

 		self::update2($id,$model,'pmt_task');

		self::addInfoResults($srModel,null);
		return $srModel;
	}

	function deleteTaskHf($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$model = self::queryById2($id,"pmt_task");
		$sql = "select * from pmt_task t where t.parent_task_id='{0}' /*w[t]*/";
		$cnt1 = self::getCountBySql($sql,array($id));

		//010 目录
		//里程碑不能删除
		if(PmtTools::canEditTask($id)!='1'||$cnt1>0||$model['type_ms_id']>0){
			$srModel["hf"] = "0";
		}else{
			$srModel["hf"] = "1";
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}

	//T000494	       任务可以跨模块移动
	function moveProgressHf($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		//没有子任务才可以移动
		$cnt = self::getCountBySql("select t.* from pmt_task t where t.parent_task_id='{0}' /*w[t]*/",array($id));
		//halt(PmtTools::canEditTask($id));
		//halt($cnt);
		if(PmtTools::canEditTask($id)=='0' || $cnt>0){
			$srModel["hf"] = "0";
		}else{
			$srModel["hf"] = "1";
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	function moveProgressPage($spModel){
		$view = $spModel['view_refer'];
		$id = $spModel["sflow_business_id"];
		$srModel = array();
		$task = self::queryById2($id,"pmt_task");

		$tv_module_id = "1;;;pmt_module;name;SELECT t.id _valueCode_,t.name _valueName_,t.project_id _parentObjectCode_ FROM pmt_module t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()." and project_id=".$task['project_id'];
		$tv_task_id = "1;;;pmt_task;name;SELECT t.id _valueCode_,t.name _valueName_,t.id _childCode_,t.parent_task_id _parentCode_,t.id _childSortNo_,t.module_id _parentObjectCode_  FROM pmt_task t WHERE is_deleted='0' and spr_tree_type='010' and belong_org_id=".SrUser::getOrgId()." and project_id=".$task['project_id'].";module_id";

			$view->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.name','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>'',
			'control_class'=>"  ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$task['name'],
		));

			$view->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.module_id','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'module_id',
			'control_value'=>$tv_module_id,
			'control_class'=>" required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$view->srModel["module_id"],
		));
			$view->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.task_id','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL_2','control_name'=>'parent_task_id',
			'control_value'=>$tv_task_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$view->srModel["parent_task_id"],
		));
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	function moveProgress($spModel){
		$srModel = array();
		$sflowDId = $spModel["sflow_flow_d_id"];
		$id = $spModel["sflow_business_id"];
		$module_id = $spModel["module_id"];
		$parent_task_id = $spModel["parent_task_id"];
		if($module_id==null||$module_id==''){
			self::addFailResults($srModel,"message.exception.param.null",array("module_id"));
			return $srModel;
		}
//		if($parent_task_id==null||$parent_task_id==''){
//			self::addFailResults($srModel,"message.exception.param.null",array("parent_task_id"));
//			return $srModel;
//		}
		$task = self::queryById2($id,"pmt_task");
		$oldParentTaskId = $task['parent_task_id'];

		$model = array();
		$model["id"] = $id;

		$task['module_id'] = $module_id;
		$task['parent_task_id'] = $parent_task_id;
		$task = self::update2($id,$task,"pmt_task");

		SrTree::deleteRow(array('table_name'=>'pmt_task','node_value'=>$id));
		SrTree::addRow(array('table_name'=>'pmt_task','node_value'=>$id));

		//更新新老节点的进度等信息
		if($oldParentTaskId!=null&&$oldParentTaskId!=''){
			//dump($oldParentTaskId);
			self::invokeBusiness("AppCommonBusiness","task_updateParentTask",array("id"=>$oldParentTaskId),'Pmt');
		}

		if($parent_task_id!=null&&$parent_task_id!=''){
			//dump($parent_task_id);
			self::invokeBusiness("AppCommonBusiness","task_updateParentTask",array("id"=>$parent_task_id),'Pmt');
		}
		//self::invokeBusiness("AppCommonBusiness","module_updateModuleByTaskInfo",array('id'=>$task['module_id']),'Pmt');

		//halt();
		//self::invokeBusiness("AppCommonBusiness","module_updateModuleByTaskInfo",array('id'=>$module_id),'Pmt');

		self::addInfoResults($srModel,null);
		return $srModel;
	}


	//T000492	       任务新增添加新增任务和新增目录任务功能
	function addChildDictTaskHf($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$model = self::queryById2($id,"pmt_task");
		if(PmtTools::canAddTask($id)=='1' && $model["spr_tree_type"]=='010'){
			$srModel["hf"] = "1";
		}else{
			$srModel["hf"] = "0";
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}
}
?>
