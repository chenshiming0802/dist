<?php
class Task2FollowLinkSflow extends SrSflowService{	

}
?>
