<?php
class ModuleSflow extends SrSflowService{
 	//完成模块
	function finishModule($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$sflowDId = $spModel["sflow_flow_d_id"];
		$model['id'] = $id;

		self::addInfoResults($srModel,null);
		return $srModel;
	}
	//模块负责人关闭
	function finishModuleHf($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$flag = self::getValue_invokeBusiness("AppModuleBusiness","isModuleManager",array('module_id'=>$id),'Pmt','flag');
		if($flag=='1'){
			$srModel["hf"] = "1";
		}else{
			$srModel["hf"] = "0";
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}

	function stopModule($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$sflowDId = $spModel["sflow_flow_d_id"];
		$model['id'] = $id;
		//TODO
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	//模块负责人暂停
	function stopModuleHf($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$flag = self::getValue_invokeBusiness("AppModuleBusiness","isModuleManager",array('module_id'=>$id),'Pmt','flag');
		if($flag=='1'){
			$srModel["hf"] = "1";
		}else{
			$srModel["hf"] = "0";
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	//激活
	function activeModule($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$sflowDId = $spModel["sflow_flow_d_id"];
		$model['id'] = $id;
		//TODO
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	//模块负责人暂停
	function activeModuleHf($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$flag = self::getValue_invokeBusiness("AppModuleBusiness","isModuleManager",array('module_id'=>$id),'Pmt','flag');
		if($flag=='1'){
			$srModel["hf"] = "1";
		}else{
			$srModel["hf"] = "0";
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}

	//激活
	function closeModule($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$sflowDId = $spModel["sflow_flow_d_id"];
		$model['id'] = $id;

 		$sql = "select * from pmt_progress t where t.table_id={0} and t.table_name='pmt_module' /*w[t]*/";
 		$progress_id = self::getValue_getRowBySql($sql,array($id),'id');
 		$progress = array();
// 		$progress['act_progress'] = 100;
 		$progress['close_time'] = Sr::sys_datetime();
 		self::update2($progress_id,$progress,'pmt_progress');
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	//模块负责人暂停
	function closeModuleHf($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$flag = self::getValue_invokeBusiness("AppModuleBusiness","isModuleManager",array('module_id'=>$id),'Pmt','flag');
		if($flag=='1'){
			$srModel["hf"] = "1";
		}else{
			$srModel["hf"] = "0";
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}

}
?>