<?php
class AppTask2FollowLinkShAction extends SrAction{
	//managerTask2FollowLinkPage:维护
	//viewTask2FollowLinkPage:查看

	public function managerTask2FollowLinkPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('AppTask2FollowLinkShService','getTask2FollowLink', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){

			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}
$this->loadTabView('AppCommonTabView','configTaskEdit', $srModel);
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppTask2FollowLinkShView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function managerTask2FollowLink($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('AppTask2FollowLinkShService','managerTask2FollowLink', $spModel );

		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('managerTask2FollowLinkPage','post',$spModel,$srModel,'1');
	}






	public function viewTask2FollowLinkPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('AppTask2FollowLinkShService','getTask2FollowLink', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
$this->loadTabView('AppCommonTabView','configTaskView', $srModel);
		$this->loadView('AppTask2FollowLinkShView',__FUNCTION__, $spModel );
		return self::forward();
	}
	//T000496	       上线清单任务wiki显示显示页面
	public function viewWikiPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('AppTask2FollowLinkShService','getTask2FollowLink', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadTabView('AppCommonTabView','configTaskView', $srModel);
		$this->loadView('AppTask2FollowLinkShView',__FUNCTION__, $spModel );
		return self::forward();
	}
}
?>
