<?php

class Module2ProgressAction extends SrAction{





public function editModule2ProgressPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('Module2ProgressService','getModule2Progress', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		
$this->loadTabView('AppCommonTabView','configModuleEdit', $srModel);
$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('Module2ProgressView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editModule2Progress($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('Module2ProgressService','editModule2Progress', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editModule2ProgressPage','post',$spModel,$srModel);
	}




	public function viewModule2ProgressPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('Module2ProgressService','getModule2Progress', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
$this->loadTabView('AppCommonTabView','configModuleView', $srModel);		
		$this->loadView('Module2ProgressView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>