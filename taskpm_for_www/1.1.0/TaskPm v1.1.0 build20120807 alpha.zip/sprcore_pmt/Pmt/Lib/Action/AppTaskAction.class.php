<?php
class AppTaskAction extends SrAction{

	public function queryTaskList2($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		$srModel = self::invokeService('AppTaskFavoriteService','indexTaskList', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppTaskView','queryTaskList', $spModel );
		return self::forward();
	}

	public function queryPersonTodayTask($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('AppCommonBarView','selectProject', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		self::setDefaultValue($spModel,"query_user_id",SrUser::getUserId());
		$srModel = self::invokeService('AppTaskService','queryPersonTodayTask', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadTabView('AppCommonTabView','queryUserTask', $spModel);
		$this->loadView('AppTaskView',__FUNCTION__, $spModel );
		return self::forward();
	}

	public function queryTaskList($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('AppCommonBarView','selectProject', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		$srModel = self::invokeService('AppTaskService','queryTaskList', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppTaskView',__FUNCTION__, $spModel );
		return self::forward();
	}

	public function editTaskPage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('TaskService','getTask', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppTaskView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editTask($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('TaskService','editTask', $spModel );
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editTaskPage','post',$spModel,$srModel);
	}

	public function queryDocuments($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppTaskService','queryDocuments', $spModel );

		$action = $spModel["action"];
		if($action=='edit'){
			$this->loadTabView('AppCommonTabView','configTaskEdit', $spModel);
		}else{
			$this->loadTabView('AppCommonTabView','configTaskView', $spModel);
		}
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppTaskView',__FUNCTION__, $spModel );
		return self::forward();
	}

	public function viewTaskIframePage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('TaskService','getTask', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
$this->loadTabView('AppCommonTabView','configTaskView', $srModel);
		$this->loadView('AppTaskView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function viewTaskIframe2Page($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('TaskService','getTask', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
$this->loadTabView('AppCommonTabView','configTaskView', $srModel);
		$this->loadView('AppTaskView',__FUNCTION__, $spModel );
		return self::forward();
	}

	public function editTaskIframePage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('TaskService','getTask', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
$this->loadTabView('AppCommonTabView','configTaskEdit', $srModel);
		$this->loadView('AppTaskView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editTaskIframe2Page($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('TaskService','getTask', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
$this->loadTabView('AppCommonTabView','configTaskEdit', $srModel);
		$this->loadView('AppTaskView',__FUNCTION__, $spModel );
		return self::forward();
	}


	public function managerTask2FollowPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('TaskService','getTask2Follow', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){

			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}
		$this->loadTabView('AppCommonTabView','configTaskEdit', $srModel);
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppTaskView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function managerTask2Follow($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('TaskService','managerTask2Follow', $spModel );

		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('managerTask2DependPage','post',$spModel,$srModel);
	}

	/**
	 * @deprecate
	 */
	public function indexTaskDetail($spModel=array()){
		$spModel=self::getSpModel($spModel);
		self::setDefaultValue($spModel,"query_user_id",SrUser::getUserId());
		$srModel = self::invokeService('AppTaskService','indexTaskDetail', $spModel );
		$this->loadTabView('AppCommonTabView','configTaskView', $spModel);
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();
	}

	public function doMessageSr($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppTaskService','doMessageSr', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::redirectMethod('doMessageSr','post',$spModel,$srModel,'1');
	}
	public function deleteMessageSr($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppTaskService','deleteMessageSr', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::redirectMethod('deleteMessageSr','post',$spModel,$srModel,'1');
	}

	public function viewEmployeeTask($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('','', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		$spModel["query_employee_id"] = $spModel['id'];
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		self::setDefaultValue($spModel,"query_status","020");
		$srModel = self::invokeService('AppTaskService','queryTaskList', $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadTabView('AppCommonTabView','configEmployeeView', $spModel);
		$this->loadView('AppTaskView',__FUNCTION__, $spModel );
		return self::forward();
	}

	public function deleteDocument($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppTaskService','deleteDocument', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::redirectMethod('deleteMessageSr','post',$spModel,$srModel,'1');
	}
}
?>
