<?php

class Task2ProgressAction extends SrAction{










	public function viewTask2ProgressPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('Task2ProgressService','getTask2Progress', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
$this->loadTabView('AppCommonTabView','configTaskView', $srModel);		
		$this->loadView('Task2ProgressView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>