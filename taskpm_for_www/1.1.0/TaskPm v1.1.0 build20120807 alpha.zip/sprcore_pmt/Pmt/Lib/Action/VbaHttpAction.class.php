<?php
class VbaHttpAction extends SrAction{	
	//vbs上传文件
	public function uploadDocumentFile($spModel=array()){
		$_FILES['file']['name'] = Sr::unescape($_FILES['file']['name']);
 		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('VbaHttpService','uploadDocumentFile', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();	
	}	
 	
	//下载文档上传vbs文件
	public function downloadDocumentVbs($spModel=array()){

 		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('VbaHttpService','getCurrentDocument', $spModel );
		$tfile = $srModel['document_tfile'];
		$path = $tfile['path'];		
		$original_document_name = $tfile['original_document_name'];

		$filename = SPR_ROOT_SPATH."".APP_NAME."\Template\document_upload.vbs";
//		dump($srModel);
//		halt($filename);
		$file_size = filesize($filename);
		
 		Header( "Content-type:   application/octet-stream "); 
		Header( "Accept-Ranges:   bytes "); 
		Header( "Accept-Length:   ".$file_size); 
		Header( "Content-Disposition:   attachment;   filename= "   .   $original_document_name.'.vbs'); //.'.v'.$srModel['document']['document_version']
		//   输出文件内容 
		$file   =   fopen($filename, "r "); 
		$file_name = $tfile['original_document_name'];
  		$file_name = iconv("UTF-8","gb2312",$tfile['original_document_name']) ;
		echo "file_name=\"".$file_name."\"\r\n";
		echo "file_size=\"".$tfile['file_size']."\"\r\n";
		echo "document_id=\"".$tfile['document_id']."\"\r\n";
 		echo "host=\"http://".$_SERVER['HTTP_HOST']."/\"\r\n";
		echo   fread($file,$file_size); 		
		fclose($file); 
		exit;			
	}
	
	//判断是否是最新版本的文档
	public function checkIsCurrentDocument($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('AppPmtDocumentService','getDocument', $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();			
	}
}
?>
