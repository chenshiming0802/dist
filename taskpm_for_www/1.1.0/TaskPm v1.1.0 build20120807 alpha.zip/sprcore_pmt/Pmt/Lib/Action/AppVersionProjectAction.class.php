<?php
class AppVersionProjectAction extends SrAction{	
 
	
	public function compareModule($spModel=array()){
		$spModel=self::getSpModel($spModel);	
		if($this->loadBarView('AppCommonBarView','selectProject', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}			
		$srModel = self::invokeService('AppVersionProjectService','compareModule', $spModel );	

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppVersionProjectView',__FUNCTION__, $spModel );
		return self::forward();		
	}

	public function compareTask($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('AppCommonBarView','selectModule', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}			
		$srModel = self::invokeService('AppVersionProjectService','compareTask', $spModel );	

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppVersionProjectView',__FUNCTION__, $spModel );
		return self::forward();		
	}		
}
?>
