<?php
class AppPmtDocumentAction extends SrAction{
	public function queryDocuments($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppPmtDocumentService','queryDocuments', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppPmtDocumentView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function queryDocumentsByCurrentVersionId($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppPmtDocumentService','queryDocumentsByCurrentVersionId', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
//		$this->loadView('AppPmtDocumentView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function uploadDocumentFilePage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppPmtDocumentService','uploadDocumentFilePage', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();
	}
	public function uploadDocumentUrl($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppPmtDocumentService','uploadDocumentUrl', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();
	}
//	public function uploadDocumentFile($spModel=array()){
//		$spModel=self::getSpModel($spModel);
//		$srModel = self::invokeService('AppPmtDocumentService','uploadDocumentFile', $spModel );
//		if(count($srModel['dup_list'])>0){
//			$this->set('uploadDocumentFileDupPage',$spModel,$srModel);
//		}else{
//			$this->set(__FUNCTION__,$spModel,$srModel);
//		}
//		return self::forward();
//	}
	public function uploadDocumentFile($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppPmtDocumentService','uploadDocumentFile', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();
	}
	/**
	 * 自动匹配同名文件
	 */
//	public function uploadDocumentFile($spModel=array()){
//		$spModel=self::getSpModel($spModel);
//		$srModel = self::invokeService('AppPmtDocumentService','uploadDocumentFile', $spModel );
//		if(count($srModel['dup_list'])>0){
//			$this->set('uploadDocumentFileDupPage',$spModel,$srModel);
//		}else{
//			$this->set(__FUNCTION__,$spModel,$srModel);
//		}
//		return self::forward();
//	}

//	public function uploadDocumentFileDup($spModel=array()){
//		$spModel=self::getSpModel($spModel);
//		$srModel = self::invokeService('AppPmtDocumentService','uploadDocumentFileDup', $spModel );
//		$this->set('uploadDocumentFile',$spModel,$srModel);
//		return self::forward();
//	}


 	//�����ĵ�
	public function downloadDocument($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppPmtDocumentService','getDocument', $spModel );
		//dump($srModel);halt();
		switch($srModel['document']['document_type']){
			case '010'://�ļ�����
				$tfile = $srModel['document_tfile'];
				$path = $tfile['path'];
				$original_document_name = $tfile['original_document_name'];
				$download_document_name = $tfile['download_document_name'];
				$file_ostream = $tfile['file_ostream'];

				$fileFullPath = c('FILE_BASE_ROOT')   .   $path.$download_document_name;
				$fileFullPath = str_replace('/','\\',$fileFullPath);
				$file_size = filesize($fileFullPath);//$tfile['file_size'];
				//halt($fileFullPath);

				Header( "Content-type:   application/octet-stream ");
				Header( "Accept-Ranges:   bytes ");
				Header( "Accept-Length:   ".$file_size);
				Header( "Content-Disposition:   attachment;   filename= "   .   $original_document_name);
				//   ����ļ�����
				$file   =   fopen($fileFullPath, "r ");
				echo   fread($file,$file_size);
				fclose($file);
				exit;
				break;
			case '020'://t�ӵ�ַ
				//dump(urldecode(urlencode($srModel['document_turl']['path'])));halt();
				if($srModel['document_turl']['path']!=null){
					echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8">';
					echo "<script>window.location='".$srModel['document_turl']['path']."';</script>";
				}
				break;
		}

		//dump($srModel);halt();



	}

	//����table_id/table_name��ʾ�ĵ��嵥
	public function listTableDocuments($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('AppPmtDocumentService','listTableDocuments', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppPmtDocumentView',__FUNCTION__, $spModel );
		return self::forward();
	}

	//�����ĵ��ϴ�VBS
	public function downloadDocumentVbs($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppPmtDocumentService','getDocument', $spModel );
		$tfile = $srModel['document_tfile'];
		$path = $tfile['path'];
		$original_document_name = $tfile['original_document_name'];

		$filename = SPR_ROOT_SPATH."../Template/document_upload.vbs";
		$file_size = filesize($filename);

 		Header( "Content-type:   application/octet-stream ");
		Header( "Accept-Ranges:   bytes ");
		Header( "Accept-Length:   ".$file_size);
		Header( "Content-Disposition:   attachment;   filename= "   .   $original_document_name.'.v'.$srModel['document_version'].'.vbs');
		//   ����ļ�����
		$file   =   fopen($filename, "r ");
		echo   fread($file,$file_size);
		fclose($file);
		exit;
	}

	public function deleteDocument($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppPmtDocumentService','deleteDocument', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::redirectMethod('deleteMessageSr','post',$spModel,$srModel,'1');
	}
}
?>
