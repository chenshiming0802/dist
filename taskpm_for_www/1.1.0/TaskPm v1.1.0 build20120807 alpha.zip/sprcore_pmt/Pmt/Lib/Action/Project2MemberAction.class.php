<?php

class Project2MemberAction extends SrAction{



	public function managerProject2MemberPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('Project2MemberService','getProject2Member', $spModel );	
		if($srModel['id']==null||$srModel['id'=='']){
			 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}
$this->loadTabView('AppCommonTabView','configProjectEdit', $srModel);
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('Project2MemberView',__FUNCTION__, $spModel );
		return self::forward();
	}	
	public function managerProject2Member($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('Project2MemberService','managerProject2Member', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('managerProject2MemberPage','post',$spModel,$srModel);
	}






	public function viewProject2MemberPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('Project2MemberService','getProject2Member', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
$this->loadTabView('AppCommonTabView','configProjectView', $srModel);		
		$this->loadView('Project2MemberView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>