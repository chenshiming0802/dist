<?php
class AppModuleAction extends SrAction{
	//查看模块的里程碑周期
	//http://127.0.0.1:82/sprcore_all/Pmt/index.php/AppModule/queryModuleMillstoneCycle
	public function queryModuleMillstoneCycle($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('AppCommonBarView','selectModuleType', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		self::setDefaultValue($spModel,'query_status','020');
		self::setDefaultValue($spModel,'grid_display_milestone','1');
		$srModel = self::invokeService('AppModuleService','queryModuleMillstoneCycle', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);

		$this->loadView('AppModuleView',__FUNCTION__, $spModel );
		return self::forward();
	}

	public function viewModuleIframePage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('ModuleService','getModule', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
$this->loadTabView('AppCommonTabView','configModuleView', $srModel);
		$this->loadView('AppModuleView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function viewModuleIframe2Page($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('ModuleService','getModule', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
$this->loadTabView('AppCommonTabView','configModuleView', $srModel);
		$this->loadView('AppModuleView',__FUNCTION__, $spModel );
		return self::forward();
	}
	//Module的文档管理左侧
	public function viewModulePath($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('AppModuleService','viewModulePath', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();
	}

}
?>
