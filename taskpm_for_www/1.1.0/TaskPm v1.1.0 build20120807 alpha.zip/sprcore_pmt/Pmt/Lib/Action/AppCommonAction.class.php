<?php
class AppCommonAction extends SrAction{
	/*批量更新实际进度*/
	public function batchUpdateTaskActProcess($spModel=array()){
		$spModel=self::getSpModel($spModel);
		self::setDefaultValue($spModel,"query_user_id",SrUser::getUserId());
		$srModel = self::invokeService('AppCommonService','batchUpdateTaskActProcess', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();
	}

	public function queryPersonDayStatus($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('AppCommonBarView','selectProject', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		self::setDefaultValue($spModel,"query_user_id",SrUser::getUserId());
		$srModel = self::invokeService('AppCommonService','queryPersonDayStatus', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppCommonView',__FUNCTION__, $spModel );
		return self::forward();
	}

	public function getLeftMenuPage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		self::setDefaultValue($spModel,"query_user_id",SrUser::getUserId());
		$srModel = self::invokeService('AppCommonService','getLeftMenuPage', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();
	}

	public function queryUserTask($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('AppCommonBarView','selectProject', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}

		self::setDefaultValue($spModel,"query_user_id",SrUser::getUserId());
		$srModel = self::invokeService('AppCommonService','queryUserTask', $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadTabView('AppCommonTabView','queryUserTask', $spModel);
		//$this->loadView('AppCommonView',__FUNCTION__, $spModel );
		return self::forward();
	}


	public function taskGantt($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('AppCommonBarView','selectModule', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		$srModel = self::invokeService('AppCommonService','queryTask', $spModel );
		$list = array();
		foreach($srModel['list'] as $key=>$m){
			$m['name'] = str_repeat('&nbsp;&nbsp;',$m["_LEVEL_"]).$m['name'];
			$model = array();

			$model['pID'] = $m["id"];
			$name = $m['_HAS_CHILDREN_']?'<B>'.$m["name"].'</B>':$m["name"];
			$model['pName'] = $name."(".$m['manager_name'].")";
			$model['pStart'] = SrGantt::formatDate($m["adv_begin_date"]);
			$model['pEnd'] = SrGantt::formatDate($m["adv_end_date"]);
			$model['pColor'] = $m["status"]=='100'?"00FF00":"FF0000";
			$model['pLink'] = Sr::sys_sl("/".SPR_ROOT_APATH.'/Pmt/index.php/AppTask/editTaskPage?id='.$m["id"].'&SPR_VIEW_DIVS={div_search_v%3Aname%2Fcode}');
			$model['pMile'] = '';
			$model['pRes'] = implode(' ',$m["array_task_member_name"]);
			//$model['pComp'] = Sr::sys_get($m["progress"],'1');
			$model['pComp'] = '';
			$model['pGroup'] = $m['_HAS_CHILDREN_']?'1':'';
			$model['pParent'] = Sr::sys_get($m["parent_task_id"],'0');
			$model['pOpen'] = '1';
			$model['pDepend'] = '';
			$model['pCaption'] = '';
			$list[] = $model;
		}

 		$srModel['list'] = $list;
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();
	}

}

?>