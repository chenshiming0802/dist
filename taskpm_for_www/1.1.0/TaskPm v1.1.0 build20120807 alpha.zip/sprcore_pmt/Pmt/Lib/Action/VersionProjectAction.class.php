<?php

class VersionProjectAction extends SrAction{

/*
	* http://127.0.0.1:82/sprcore_all/Demo/index.php/VersionProject/queryVersionProject	*/
	public function queryVersionProject($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('','', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		if($this->loadBarView('AppCommonBarView','selectProject', $spModel )===false){
	$this->set(__FUNCTION__,$spModel,array());
	return self::forward();
}
		$srModel = self::invokeService('VersionProjectService','queryVersionProject', $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('VersionProjectView',__FUNCTION__, $spModel );
		return self::forward();
	}

public function editVersionProjectBasePage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('VersionProjectService','getVersionProject', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('VersionProjectView',__FUNCTION__, $spModel );
		return self::forward();	
}
	public function editVersionProjectBase($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('VersionProjectService','editVersionProjectBase', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('viewVersionProjectPage','post',$spModel,$srModel);
	}


public function editVersionProjectPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('VersionProjectService','getVersionProject', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		

$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('VersionProjectView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editVersionProject($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('VersionProjectService','editVersionProject', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editVersionProjectPage','post',$spModel,$srModel);
	}


public function deleteVersionProject($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('VersionProjectService','deleteVersionProject', $spModel );
		
		$this->setIsOutHtml(false);
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('viewVersionProjectPage','post',$spModel,$srModel);
	}

	public function viewVersionProjectPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('VersionProjectService','getVersionProject', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
		
		$this->loadView('VersionProjectView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>