<?php

class ModuleAction extends SrAction{

/*
	* http://127.0.0.1:82/sprcore_all/Demo/index.php/Module/queryModule	*/
	public function queryModule($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('AppCommonBarView','selectProject', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		self::setDefaultValue($spModel,"query_status","020");
		$srModel = self::invokeService('ModuleService','queryModule', $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('ModuleView',__FUNCTION__, $spModel );
		return self::forward();
	}



public function editModulePage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('ModuleService','getModule', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			$srModel['project_id']=Session::get('pmt_current_project_id');
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}
$this->loadTabView('AppCommonTabView','configModuleEdit', $srModel);
$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('ModuleView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editModule($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$spModel["project_id"] = Session::get("pmt_current_project_id");
		$srModel = self::invokeService('ModuleService','editModule', $spModel );

		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editModulePage','post',$spModel,$srModel);
	}


public function deleteModule($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('ModuleService','deleteModule', $spModel );

		$this->setIsOutHtml(false);
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('viewModulePage','post',$spModel,$srModel);
	}

	public function viewModulePage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('ModuleService','getModule', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
$this->loadTabView('AppCommonTabView','configModuleView', $srModel);
		$this->loadView('ModuleView',__FUNCTION__, $spModel );
		return self::forward();
	}
}

?>