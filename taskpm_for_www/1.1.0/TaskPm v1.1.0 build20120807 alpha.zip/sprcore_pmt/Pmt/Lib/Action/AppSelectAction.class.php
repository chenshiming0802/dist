<?php
class AppSelectAction extends SrAction{
	//AppSelect/queryDemoCourseBaseinfo
	public function queryUnFollowTask($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService("AppSelectService","queryUnFollowTask", $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView("AppSelectView",__FUNCTION__, $spModel );
		return self::forward();
	}
	//资源分配情况(查询资源)
	public function queryEmployeeAssignInfo($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService("AppSelectService","queryEmployeeAssignInfo", $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView("AppSelectView",__FUNCTION__, $spModel );
		return self::forward();
	} 
	//资源分配情况(查询资源)
	public function queryUupUser($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService("AppSelectService","queryUupUser", $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView("AppSelectView",__FUNCTION__, $spModel );
		return self::forward();
	} 	
}

?>