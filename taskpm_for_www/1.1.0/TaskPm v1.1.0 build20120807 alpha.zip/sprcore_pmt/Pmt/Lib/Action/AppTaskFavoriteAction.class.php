<?php
class AppTaskFavoriteAction extends SrAction{
	public function doRead($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppTaskFavoriteService','doRead', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::sprAjaxReturn();
	}
	public function unRead($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppTaskFavoriteService','unRead', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::sprAjaxReturn();
	}
	public function doProcess($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppTaskFavoriteService','doProcess', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::sprAjaxReturn();
	}
	public function indexMenu($spModel=array()){
		$spModel=self::getSpModel($spModel);
		self::setDefaultValue($spModel,"query_user_id",SrUser::getUserId());
		$srModel = self::invokeService('AppTaskFavoriteService','indexMenu', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();
	}

	public function indexTaskList($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppTaskFavoriteService','indexTaskList', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppTaskFavoriteView',__FUNCTION__, $spModel );
		return self::forward();
	}


	public function indexTop($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppTaskFavoriteService','indexTop', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();
	}

	public function indexFrame($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppTaskFavoriteService','indexFrame', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();
	}
}
?>
