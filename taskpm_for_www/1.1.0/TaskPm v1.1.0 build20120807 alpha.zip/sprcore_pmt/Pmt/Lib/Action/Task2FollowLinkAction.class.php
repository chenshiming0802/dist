<?php

class Task2FollowLinkAction extends SrAction{


}

?>