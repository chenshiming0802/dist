<?php

class TaskFavoriteAction extends SrAction{

/*
	* http://127.0.0.1:82/sprcore_all/Demo/index.php/TaskFavorite/queryTaskFavorite	*/
	public function queryTaskFavorite($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('','', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		
		$srModel = self::invokeService('TaskFavoriteService','queryTaskFavorite', $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('TaskFavoriteView',__FUNCTION__, $spModel );
		return self::forward();
	}



public function editTaskFavoritePage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('TaskFavoriteService','getTaskFavorite', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		

$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('TaskFavoriteView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editTaskFavorite($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('TaskFavoriteService','editTaskFavorite', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editTaskFavoritePage','post',$spModel,$srModel);
	}


public function deleteTaskFavorite($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('TaskFavoriteService','deleteTaskFavorite', $spModel );
		
		$this->setIsOutHtml(false);
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('viewTaskFavoritePage','post',$spModel,$srModel);
	}

	public function viewTaskFavoritePage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('TaskFavoriteService','getTaskFavorite', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
		
		$this->loadView('TaskFavoriteView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>