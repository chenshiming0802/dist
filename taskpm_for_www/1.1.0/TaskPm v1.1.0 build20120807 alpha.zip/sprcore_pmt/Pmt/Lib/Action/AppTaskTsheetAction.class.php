<?php
class AppTaskTsheetAction extends SrAction{

	public function queryUserShTimes($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('AppCommonBarView','selectProject', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		self::setDefaultValue($spModel,'begin_date',Sr::sys_date());
		self::setDefaultValue($spModel,'total_day',13);


		$srModel = self::invokeService('AppTaskTsheetService','queryUserShTimes', $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppTaskTsheetView',__FUNCTION__, $spModel );
		return self::forward();
	}


	//查询项目&进度&任务的工时信息
	public function getSheetInfoFromProjectModuleTask($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppTaskTsheetService','getSheetInfoFromProjectModuleTask', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppTaskTsheetView',__FUNCTION__, $spModel );
		return self::forward();
	}

	//工时导出
	public function exportBaosightSheet($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppTaskTsheetService','exportBaosightSheet', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppTaskTsheetView',__FUNCTION__, $spModel );
		return self::forward();
	}

	//我要处理
	public function updateTouchTask($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('AppTaskTsheetService','updateTouchTask', $spModel );

		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editTaskPage','get',$spModel,$srModel,'1');
	}
	//工时快捷填写
	public function fillQucikTsheetPage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		self::setDefaultValue($spModel,"query_occure_date",Sr::sys_date(array()));
		$srModel = self::invokeService('AppTaskTsheetService','fillQucikTsheetPage', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppTaskTsheetView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function fillQucikTsheet($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppTaskTsheetService','fillQucikTsheet', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::redirectMethod('fillQucikTsheetPage','post',$spModel,$srModel,'1');
	}
	public function deleteQucikTsheet($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('AppTaskTsheetService','deleteQucikTsheet', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::redirectMethod('fillQucikTsheetPage','post',$spModel,$srModel,'1');
	}
}
?>
