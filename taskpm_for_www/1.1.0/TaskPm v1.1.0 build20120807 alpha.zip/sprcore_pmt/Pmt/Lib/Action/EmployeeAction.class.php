<?php

class EmployeeAction extends SrAction{

/*
	* http://127.0.0.1:82/sprcore_all/Demo/index.php/Employee/queryEmployee	*/
	public function queryEmployee($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('','', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		
		$srModel = self::invokeService('EmployeeService','queryEmployee', $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('EmployeeView',__FUNCTION__, $spModel );
		return self::forward();
	}



public function editEmployeePage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('EmployeeService','getEmployee', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		

$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('EmployeeView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editEmployee($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('EmployeeService','editEmployee', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editEmployeePage','post',$spModel,$srModel);
	}


public function deleteEmployee($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('EmployeeService','deleteEmployee', $spModel );
		
		$this->setIsOutHtml(false);
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('viewEmployeePage','post',$spModel,$srModel);
	}

	public function viewEmployeePage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('EmployeeService','getEmployee', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadTabView('AppCommonTabView','configEmployeeView', $spModel);	
		$this->loadView('EmployeeView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>