<?php

class ProjectAction extends SrAction{

/*
	* http://127.0.0.1:82/sprcore_all/Demo/index.php/Project/queryProject	*/
	public function queryProject($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('','', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		
		$srModel = self::invokeService('ProjectService','queryProject', $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('ProjectView',__FUNCTION__, $spModel );
		return self::forward();
	}



public function editProjectPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('ProjectService','getProject', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		
$this->loadTabView('AppCommonTabView','configProjectEdit', $srModel);
$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('ProjectView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editProject($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('ProjectService','editProject', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editProjectPage','post',$spModel,$srModel);
	}


public function deleteProject($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('ProjectService','deleteProject', $spModel );
		
		$this->setIsOutHtml(false);
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('viewProjectPage','post',$spModel,$srModel);
	}

	public function viewProjectPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('ProjectService','getProject', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
$this->loadTabView('AppCommonTabView','configProjectView', $srModel);		
		$this->loadView('ProjectView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>