<?php
class AppCommonBarView extends SrBarView{

	private $tv_project_id;
	private $tv_module_id;
	private $tv_module_type_id;


	public function __construct(){
		$user_id = SrUser::getUserId();
		//dump($user_id);
		$this->tv_project_id = "1;;;pmt_project;name;SELECT t.id _valueCode_,t.name _valueName_,concat(t.status,'@PMT01@DICT') _groupSort_  FROM pmt_project t WHERE  1=1 /*w[t]*/  AND (EXISTS( SELECT tt1.* FROM pmt_project_member tt1 WHERE t.id=tt1.project_id   /*w[tt1]*/ AND tt1.user_id={$user_id}) OR t.security_type='010' OR t.manager_id={$user_id} OR t.config_user_id={$user_id}) and belong_org_id=".SrUser::getOrgId()."";
		$this->tv_module_id = "1;;;pmt_module;name;SELECT t.id _valueCode_,t.name _valueName_,t.project_id _parentObjectCode_,t.project_id _parentCode_,concat(t.status,'@PMT03@DICT') _groupSort_ FROM pmt_module t WHERE  1=1 /*w[t]*/ and belong_org_id=".SrUser::getOrgId().";project_id";
		$this->tv_module_type_id = "1;;;pmt_project;NAME;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_module_type t WHERE  1=1 /*w[t]*/ ";
	}
	public function selectProject_select(&$spModel){
		$sessp = Session::get("pmt_current_module_id");
		$requp = $spModel['query_project_id'];
		if($sessp!=$requp){
			Session::set("pmt_current_module_id",null);
		}
	}
	public function selectProject($spModel){
		$srModel = array();
		if($_GET['query_module_id']==null||$_GET['query_module_id']==''){

			$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
			$this->download = array("download"=>"0","method"=>"post");
			$this->form = array(
				"name"=>"bar_ff",
				"method"=>"post",
				"action"=>__SELF__,
				"target"=>"_self",
				"onSubmit"=>"",
			);
			$this->addItem(array(
				'div_id'=>'div_bar_view','div_label'=>'','item_line_type'=>'','item_viewauth'=>'',
				'control_type'=>'LABEL','control_name'=>'nav',
				'control_value'=>"",
				'control_class'=>"required",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'当前位置:',
			));
			$this->addItem(array(
				'div_id'=>'div_bar_view','div_label'=>'','item_line_type'=>'','item_viewauth'=>'',
				'control_type'=>'SELECT_SQL','control_name'=>'query_project_id',
				'control_value'=>$this->tv_project_id,
				'control_class'=>"required",'control_param'=>" onChange='a_window_submit(document.bar_ff,new Array());'",'control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'',
			));
	//		$this->addItem(array(
	//				'div_id'=>'div_bar_view',
	//				'control_type'=>'BUTTON','control_name'=>'bar_selected',
	//				'control_value'=>'',
	//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
	//				'value_input'=>'page.button.confirm',
	//			));


			$this->bar_fields = array(
				'query_project_id'=>array(
					'is_required'=>true,
					'session_key'=>'pmt_current_project_id',
					'spModel_key'=>'query_project_id',
				),
			);
		}
		//如果需要回调，则定义回调方法
		$this->callback_method = 'selectProject_select';
		self::addInfoResults($srModel,null);
		return $srModel;
	}


	public function selectModule($spModel){
		$srModel = array();

		if($_GET['query_module_id']==null||$_GET['query_module_id']==''){

			$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
			$this->download = array("download"=>"0","method"=>"post");
			$this->form = array(
				"name"=>"bar_ff",
				"method"=>"post",
				"action"=>__SELF__,
				"target"=>"_self",
				"onSubmit"=>"",
			);
			$this->addItem(array(
				'div_id'=>'div_bar_view','div_label'=>'','item_line_type'=>'','item_viewauth'=>'',
				'control_type'=>'LABEL','control_name'=>'nav',
				'control_value'=>"",
				'control_class'=>"required",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'<B>当前位置:</B>',
			));
			$this->addItem(array(
				'div_id'=>'div_bar_view','div_label'=>'','item_line_type'=>'','item_viewauth'=>'',
				'control_type'=>'SELECT_SQL','control_name'=>'query_project_id',
				'control_value'=>$this->tv_project_id,
				'control_class'=>"required",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'',
			));
			$this->addItem(array(
				'div_id'=>'div_bar_view','div_label'=>'','item_line_type'=>'','item_viewauth'=>'',
				'control_type'=>'SELECT_SQL_2','control_name'=>'query_module_id',
				'control_value'=>self::addSelect2String(array('bar'=>$this->tv_module_id,'prex6'=>'query_')),
				'control_class'=>"required",'control_param'=>" onChange='a_window_submit(document.bar_ff,new Array());'",'control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'',
			));


			$this->bar_fields = array(
				'query_project_id'=>array(
					'is_required'=>true,
					'session_key'=>'pmt_current_project_id',
					'spModel_key'=>'query_project_id',
				),
				'query_module_id'=>array(
					'is_required'=>true,
					'session_key'=>'pmt_current_module_id',
					'spModel_key'=>'query_module_id',
				),
			);
		}

		//如果需要回调，则定义回调方法
		self::addInfoResults($srModel,null);
		return $srModel;
	}

	public function selectModuleType($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"bar_ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);
		$this->addItem(array(
			'div_id'=>'div_bar_view','div_label'=>'','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>"required",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_bar_view','div_label'=>'','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_module_type_id',
			'control_value'=>self::addSelect2String(array('bar'=>$this->tv_module_type_id,'prex6'=>'query_')),
			'control_class'=>"required",'control_param'=>"  onChange='a_window_submit(document.bar_ff,new Array());' ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
//		$this->addItem(array(
//				'div_id'=>'div_bar_view',
//				'control_type'=>'BUTTON','control_name'=>'bar_selected',
//				'control_value'=>'',
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.confirm',
//			));


		$this->bar_fields = array(
			'query_project_id'=>array(
				'is_required'=>true,
				'session_key'=>'pmt_current_project_id',
				'spModel_key'=>'query_project_id',
			),
			'query_module_type_id'=>array(
				'is_required'=>true,
				'session_key'=>'pmt_current_module_type_id',
				'spModel_key'=>'query_module_type_id',
			),
		);
		//如果需要回调，则定义回调方法
		self::addInfoResults($srModel,null);
		return $srModel;
	}
}
?>
