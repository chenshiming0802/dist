<?php
class AppCommonView extends SrView{	
	public function queryPersonDayStatus($spModel){
		$id = $this->srModel['id'];
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/queryPersonDayStatus",
			"target"=>"_self",
			"onSubmit"=>"",
		);	
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));	
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'label.begin_time','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'begin_occure_day',
			'control_value'=>'',
			'control_class'=>"required",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['begin_occure_day'],
			'INFO'=>"",
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'label.end_time','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'end_occure_day',
			'control_value'=>'',
			'control_class'=>"required",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['end_occure_day'],
			'INFO'=>"",
		));	
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(		
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$this->addItems($items);			
		//GRID
		$this->addGrid(array(
			'div_id'=>'div_search','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['details'],'grid_page'=>$this->srModel['details_page'],
			'grid_param'=>array(
				"label.occure_date"=>array(
						'control_type'=>'LABEL','control_name'=>'occure_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'occure_date',
					),
				"label.person_day_type"=>array(
						'control_type'=>'LABEL','control_name'=>'person_day_type[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'person_day_type',						
					),														
				"label.person_day"=>array(
						'control_type'=>'LABEL','control_name'=>'person_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'person_day',
						'div_label'=>'label.person_day',
					),					
				),			
		));		
		
		
 		$ret2 = $this->gridConvertXToY('div_search','grid',array(
			'x_dims'=>array('occure_date[]'),
			'y_dim'=>'person_day_type[]',
			'y_dim_value'=>array('begin'=>'任务开始','end'=>'任务结束','todo'=>'待处理任务'),//
			'list_sort'=>array('occure_date',SORT_STRING,SORT_ASC),
			'is_display'=>'1',
		));	

		$this->addChart(array(
			'div_id'=>'div_search','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'chart',
			'grid_list'=>$ret2['list'],
			'x_dim'=>'occure_date',//categoryField
			'x_dim_desc'=>'访问量',
			'y_dim_desc'=>'访问量',//yTitle
			'line_dims'=>array('begin##person_day'=>'任务开始','end##person_day'=>'任务结束','todo##person_day'=>'待处理任务',),//yField
			'benchmark'=>'todo##person_day',//benchmark
			));	
		//dump($ret2['list']);		
		
		self::addInfoResults($srModel,null);
		return $srModel;	;		
	}	
 	public function queryUserTask($spModel){
 		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);
		
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_task.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_name',
			'control_value'=>$this->tv_name,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_name'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_task.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_code',
			'control_value'=>$this->tv_code,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_code'],
		));
	 
	 
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(		
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
 

		$this->addItems($items);	

		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'view',
				'control_value'=>__URL__."/viewTaskPage?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.view',
			);

		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
				'pmt_task.name'=>array(
					'control_type'=>'TEXT','control_name'=>'name',
					'control_value'=>$this->tv_name,
					'control_class'=>"required",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'name',
				),			
					'pmt_task.code'=>array(
					'control_type'=>'LABEL_PHP','control_name'=>'code',
					'control_value'=>$this->tv_code,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'code',
				),			
					'pmt_task.proirity'=>array(
					'control_type'=>'SELECT_DICT','control_name'=>'proirity',
					'control_value'=>$this->tv_proirity,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'proirity',
				),			
					'pmt_task.module_type_task_id'=>array(
					'control_type'=>'SELECT_SQL_2','control_name'=>'module_type_task_id',
					'control_value'=>$this->tv_module_type_task_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'module_type_task_id',
				),			
					'pmt_task.manager_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'manager_id',
					'control_value'=>$this->tv_manager_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'manager_id',
				),			
					'pmt_task.adv_begin_date'=>array(
					'control_type'=>'INPUT_DATE','control_name'=>'adv_begin_date',
					'control_value'=>$this->tv_adv_begin_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_begin_date',
				),			
					'pmt_task.adv_end_date'=>array(
					'control_type'=>'INPUT_DATE','control_name'=>'adv_end_date',
					'control_value'=>$this->tv_adv_end_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_end_date',
				),			
					'pmt_task.status'=>array(
					'control_type'=>'LABEL_DICT','control_name'=>'status',
					'control_value'=>$this->tv_status,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'status',
				),			
					'pmt_task.progress'=>array(
					'control_type'=>'HIDDEN','control_name'=>'progress',
					'control_value'=>$this->tv_progress,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'progress',
				),			
	
				'operate'=>$buttons,
			),			
		));

		

		self::addInfoResults($srModel,null);
		return $srModel;
 	}	
 
}
?>
