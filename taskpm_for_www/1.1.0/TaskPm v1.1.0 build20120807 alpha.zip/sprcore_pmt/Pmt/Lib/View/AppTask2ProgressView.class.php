<?php
class AppTask2ProgressView extends SrView{	

}
?>
