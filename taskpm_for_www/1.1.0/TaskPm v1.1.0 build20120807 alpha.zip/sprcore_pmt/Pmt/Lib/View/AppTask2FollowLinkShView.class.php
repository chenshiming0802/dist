<?php
class AppTask2FollowLinkShView extends SrView{
	private $tv_task_id;
	private $tv_project_id;
	private $tv_module_id;
	private $tv_parent_task_id;
	private $tv_proirity;
	private $tv_module_type_task_id;
	private $tv_manager_id;
	private $tv_array_task_member;
	private $tv_constraint_type;
	private $tv_ticket_type;
	private $tv_status;
	private $tv_type_ms_id;
	private $tv_work_calc_type;
	private $tv_module_follow_id;

	public function __construct(){
		$this->tv_task_id = "1;;;pmt_task;name;SELECT t.id _valueCode_,t.name _valueName_,t.id _childCode_,t.parent_task_id _parentCode_,t.id _childSortNo_ FROM pmt_task t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()." and t.module_id=".Session::get("pmt_current_module_id")."";
		$this->tv_project_id = "1;;;pmt_project;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_project t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";
		$this->tv_module_id = "1;;;pmt_module;name;SELECT t.id _valueCode_,t.name _valueName_,t.project_id _parentCode_ FROM pmt_module t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId().";project_id";
		$this->tv_parent_task_id = "1;;;pmt_task;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_task t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";
		$this->tv_proirity = "1;;PMT06";
		$this->tv_module_type_task_id = "1;;;pmt_module_type_task;name;SELECT t3.id  _valueCode_,t3.name  _valueName_,t1.id _parentObjectCode_ FROM pmt_module t1,pmt_module_type t2,pmt_module_type_task t3 WHERE t1.is_deleted = '0' AND t2.is_deleted = '0' AND t3.is_deleted='0' AND t1.module_type_id=t2.id  AND t2.id=t3.type_id order by t3.no asc;module_id";
		$this->tv_manager_id = "1;;;uup_user;name;SELECT t.id _valueCode_,t.name _valueName_ FROM uup_user t WHERE is_deleted='0' and org_id=".SrUser::getOrgId()."";
		$this->tv_array_task_member = "1;;;uup_user;name;SELECT t.id _valueCode_,t.name _valueName_ FROM uup_user t WHERE is_deleted='0' and org_id=".SrUser::getOrgId()." ";
		$this->tv_constraint_type = "1;;PMT08";
		$this->tv_ticket_type = "1;;PMT02";
		$this->tv_status = "1;;PMT04";
		$this->tv_type_ms_id = "1;;;pmt_module_type_ms;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_module_type_ms t WHERE is_deleted='0'";
		$this->tv_work_calc_type = "1;;PMT12";

	}



	public function managerTask2FollowLinkPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.'.title',array('displayDiv'=>'false'));
		$this->form = array(
			'name'=>'ff',
			'method'=>'post',
			'action'=>__URL__."/managerTask2FollowLink",
			'target'=>'_self',
			'onSubmit'=>'',
		);
		//$this->srModel['id']?'1':'0'
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.'.title','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>'',
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'code',
			'control_value'=>$this->tv_code,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
			'INFO'=>"",
		));

		//dump($this->srModel);
		//DETAIL BUTTON
		$items = array('div_id'=>'div_search_v','div_label'=>'pmt_task_follow','item_line_type'=>'line','item_viewauth'=>'',);
		$items["items_line"] = array();
		$project_id = $this->srModel['project_id'];
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'adddetail2',
				'control_value'=>__APP__."/AppSelect/queryUnFollowTask?query_project_id={$project_id}&isMulti=1&callbackMethod=selectDetailCallBack&no_in_ids=".Sr::sys_getArrayBarByList($srModel["details"],'task_id','[%2C]')."",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'...',
			);

		$this->addItems($items);
		//GRID
		$buttons = array();
		$buttons[] =array(
						'control_type'=>'BUTTON','control_name'=>'deletedetail',
						'control_value'=>",[id]",
						'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'page.button.delete',
					);
		$this->addGrid(array(
			'div_id'=>'div_search','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['details'],'grid_page'=>$this->srModel['details_page'],
			'grid_param'=>array(

				'pmt_task.code'=>array(
						'control_type'=>'LABEL','control_name'=>'code[]',
						'control_value'=>$this->tv_task_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'code',
						'INFO'=>"TYPE=open&URL=__APP__/Task/viewTaskPage?id=[task_id]",
						'div_label'=>'',
					),
				'pmt_task_tsheet.module_id'=>array(
					'control_type'=>'SELECT_SQL_2','control_name'=>'module_id',
					'control_value'=>$this->tv_module_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'module_id',
					'INFO'=>"TYPE=open&URL=__APP__/Module/viewModulePage?id=[module_id]",
					'div_label'=>'',
				),
				'pmt_task.name'=>array(
						'control_type'=>'LABEL','control_name'=>'name[]',
						'control_value'=>$this->tv_task_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'name',
						'INFO'=>"",
						'div_label'=>'',
					),
				'pmt_task_follow.id'=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_id[]',
						'control_value'=>$this->tv_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'id',
						'INFO'=>"",
						'div_label'=>'',
					),
				'pmt_task.manager_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'manager_id',
					'control_value'=>$this->tv_manager_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'manager_id',
					'INFO'=>"",
					'div_label'=>'',
				),
				'pmt_task.status'=>array(
					'control_type'=>'LABEL_DICT','control_name'=>'status',
					'control_value'=>$this->tv_status,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'status',
					'INFO'=>"",
					'div_label'=>'',
				),
				'pmt_task.adv_begin_date'=>array(
					'control_type'=>'INPUT_DATE','control_name'=>'adv_begin_date',
					'control_value'=>$this->tv_adv_end_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_begin_date',
					'INFO'=>"",
					'div_label'=>'',
				),
				'pmt_task.adv_end_date'=>array(
					'control_type'=>'TEXT','control_name'=>'adv_end_date',
					'control_value'=>$this->tv_adv_person_day,
					'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_end_date',
					'INFO'=>"",
					'div_label'=>'',
				),
				'pmt_task.adv_person_day'=>array(
					'control_type'=>'TEXT','control_name'=>'adv_person_day',
					'control_value'=>$this->tv_adv_person_day,
					'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_person_day',
					'INFO'=>"",
					'div_label'=>'',
				),
				"operate"=>$buttons,
			),
		));

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
					$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);


if($id==null || $id==''){


}else{


}



		self::addInfoResults($srModel,null);
		return $srModel;
	}



	public function viewTask2FollowLinkPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewTask2FollowLinkPage",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'code',
			'control_value'=>$this->tv_code,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
			'INFO'=>"",
		));

//		dump($this->srModel['details']);
		//GRID
		$this->addGrid(array(
			'div_id'=>'div_search','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['details'],'grid_page'=>$this->srModel['details_page'],
			'grid_param'=>array(

				'pmt_task.code'=>array(
						'control_type'=>'LABEL','control_name'=>'code[]',
						'control_value'=>$this->tv_task_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'code',
						'INFO'=>"TYPE=open&URL=__APP__/AppTask/indexTaskDetail?id=[task_id]",
						'div_label'=>'',
					),
				'pmt_task_tsheet.module_id'=>array(
					'control_type'=>'SELECT_SQL_2','control_name'=>'module_id',
					'control_value'=>$this->tv_module_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'module_id',
					'INFO'=>"TYPE=open&URL=__APP__/Module/viewModulePage?id=[module_id]",
					'div_label'=>'',
				),
				'pmt_task.name'=>array(
						'control_type'=>'LABEL','control_name'=>'name[]',
						'control_value'=>$this->tv_task_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'name',
						'INFO'=>"",
						'div_label'=>'',
					),
				'pmt_task_follow.id'=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_id[]',
						'control_value'=>$this->tv_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'id',
						'INFO'=>"",
						'div_label'=>'',
					),
				'pmt_task.manager_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'manager_id',
					'control_value'=>$this->tv_manager_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'manager_id',
					'INFO'=>"",
					'div_label'=>'',
				),
				'pmt_task.status'=>array(
					'control_type'=>'LABEL_DICT','control_name'=>'status',
					'control_value'=>$this->tv_status,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'status',
					'INFO'=>"",
					'div_label'=>'',
				),
				'pmt_task.adv_begin_date'=>array(
					'control_type'=>'INPUT_DATE','control_name'=>'adv_begin_date',
					'control_value'=>$this->tv_adv_end_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_begin_date',
					'INFO'=>"",
					'div_label'=>'',
				),
				'pmt_task.adv_end_date'=>array(
					'control_type'=>'TEXT','control_name'=>'adv_end_date',
					'control_value'=>$this->tv_adv_person_day,
					'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_end_date',
					'INFO'=>"",
					'div_label'=>'',
				),
				'pmt_task.adv_person_day'=>array(
					'control_type'=>'TEXT','control_name'=>'adv_person_day',
					'control_value'=>$this->tv_adv_person_day,
					'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_person_day',
					'INFO'=>"",
					'div_label'=>'',
				),
				),
		));

		//T000511	       上线任务清单画面中下方的按钮需要去除
//		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
//		$srModel_sflow = SrSflow::page_displayButton(array(
//			"sflow_is_add_form"=>"0",
//			"sflow_current_form"=>"ff",
//			"sflow_code"=>"pmt_task",
//			"sflow_business_id"=>$this->srModel["id"],
//			"sflow_business_num"=>$this->srModel["code"],
//			"sflow_from_status"=>$this->srModel[""],
//			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
//			"sflow_return_url"=>__SELF__,
//			"sflow_request_params"=>array(
//			"id"=>$spModel["id"],
//			"pageType"=>$spModel["pageType"],
//			),
//		));
//		$this->hidden_html = $srModel_sflow["divHtml"];
//		$items["items_line"] = $srModel_sflow["buttonArrays"];
/*
		$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>__URL__."/editTask2FollowLinkPage?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);


		$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'update2',
				'control_value'=>__URL__."/managerTask2FollowLinkPage?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);

				$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'delete',
				'control_value'=>__URL__."/deleteTask?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.delete',
			);

Sflow(flow_name,button_name,page_submit_type,page_submit_js):
修改任务信息_上线任务	page.button.update	030	__APP__/Task2FollowLink/editTask2FollowLinkPage?id={1}
新增子任务信息_上线任务	page.button.addchild	030	__APP__/Task2FollowLink/editTask2FollowLinkPage?={1}
删除任务信息_上线任务	page.button.delete	030	__APP__/Task2FollowLink/deleteTask2FollowLink?id={1}
*/

//		$items["items_line"][] = array(
//				'control_type'=>'BUTTON','control_name'=>'close',
//				'control_value'=>"",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.close',
//			);
//		$this->addItems($items);




		self::addInfoResults($srModel,null);
		return $srModel;
	}


	//T000496	       上线清单任务wiki显示显示页面
	public function viewWikiPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl($this->srModel['name'],array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewTask2FollowLinkPage",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>$this->srModel['name'],'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));

		$str = "<BR>";
		$str .= "==发布清单==<BR>";
		foreach($this->srModel['details'] as $key=>$model){

			$module = self::queryById2($model['module_id'],'pmt_module');
			$str .= "===".$model['code'].'.'.$module['name'].':'.$model['name']."===<BR>";
			$str .= "&nbsp;业务对口人:".$model['business_person_name']."<BR>";
			$manager = self::queryById2($model['manager_id'],'uup_user');
			$str .= "&nbsp;负责人:".$manager['name']."<BR>";
			$str .= "&nbsp;任务来源:".$model['url']."<BR>";

			$str .= $model['content']."<BR>";
			$str .= "<BR><BR><BR>";
		}

		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$str,
		));




		self::addInfoResults($srModel,null);
		return $srModel;
	}
}
?>
