<?php
class AppTaskView extends SrView {
	private $tv_proirity;
	private $tv_project_id;
	private $tv_module_id;
	private $tv_parent_task_id;
	private $tv_module_type_task_id;
	private $tv_manager_id;
	private $tv_array_task_member;
	private $tv_constraint_type;
	private $tv_ticket_type;
	private $tv_status;

	public function __construct() {
		$this->tv_proirity = "1;;PMT06";
		$this->tv_project_id = "1;;;pmt_project;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_project t WHERE is_deleted='0' and belong_org_id=" . SrUser :: getOrgId() . "";
		$this->tv_module_id = "1;;;pmt_module;name;SELECT t.id _valueCode_,t.name _valueName_,t.project_id _parentCode_ FROM pmt_module t WHERE is_deleted='0' and belong_org_id=" . SrUser :: getOrgId() . ";project_id";
		$this->tv_parent_task_id = "1;;;pmt_task;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_task t WHERE is_deleted='0' and belong_org_id=" . SrUser :: getOrgId() . "";
		$this->tv_module_type_task_id = "1;;;pmt_module_type_task;name;SELECT t3.id  _valueCode_,t3.name  _valueName_,t1.id _parentCode_ FROM pmt_module t1,pmt_module_type t2,pmt_module_type_task t3 WHERE t1.is_deleted = '0' AND t2.is_deleted = '0' AND t3.is_deleted='0' AND t1.module_type_id=t2.id  AND t2.id=t3.type_id order by t3.no asc;module_id";
		$this->tv_manager_id = "1;;;uup_user;name;SELECT t.id _valueCode_,t.name _valueName_ FROM uup_user t WHERE is_deleted='0' and org_id=" . SrUser :: getOrgId() . "";
		//$this->tv_array_task_member = "1;;;uup_user;name;SELECT t.id _valueCode_,t.name _valueName_ FROM uup_user t WHERE is_deleted='0' and org_id=" . SrUser :: getOrgId() . " ";
		$this->tv_array_task_member = "1;;;uup_user;name;SELECT distinct t.id _valueCode_,t.name _valueName_ FROM uup_user t,pmt_project_member t2 WHERE t2.user_id=t.id and org_id=".SrUser::getOrgId()." /*w[t,t2]*/";
		$this->tv_constraint_type = "1;;PMT08";
		$this->tv_ticket_type = "1;;PMT02";
		$this->tv_status = "1;;PMT04";

	}
public function queryTaskList($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
// 		$this->addItem(array(
//			'div_id'=>'div_search','div_label'=>'pmt_task_tsheet.project_id','item_line_type'=>'','item_viewauth'=>'',
//			'control_type'=>'SELECT_SQL','control_name'=>'query_project_id',
//			'control_value'=>$this->tv_project_id,
//			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
//			'value_input'=>$this->spModel['query_project_id'],
//			'INFO'=>"TYPE=open&URL=__APP__/Project/viewProjectPage%3Fid=[project_id]}",
//		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_task_tsheet.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'query_status',
			'control_value'=>$this->tv_status,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_status'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_task.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_code',
			'control_value'=>$this->tv_code,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_code'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_task.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_name',
			'control_value'=>$this->tv_name,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_name'],
			'INFO'=>"",
		));

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);



		$this->addItems($items);

		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'view',
				//'control_value'=>__APP__."/Task/viewTaskPage?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_value'=>__APP__."/AppTask/indexTaskDetail?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.view',
			);

		if(is_array($this->srModel['list'])){
			foreach($this->srModel['list'] as &$model){
				$model['name'] = $model['name'].'-'.$model['code'];
			}
		}


		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
//				'pmt_task.code'=>array(
//					'control_type'=>'LABEL_PHP','control_name'=>'code',
//					'control_value'=>$this->tv_code,
//					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//					'value_input'=>'code',
//
//					'div_label'=>'',
//				),
					'pmt_module.name'=>array(
					'control_type'=>'LABEL','control_name'=>'name',
					'control_value'=>$this->tv_name,
					'control_class'=>"required",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'module_name',
					'INFO'=>"TYPE=open&URL=__APP__/Module/viewModulePage?id=[module_id]",
					'div_label'=>'',
				),
					'pmt_task.name'=>array(
					'control_type'=>'LABEL','control_name'=>'name',
					'control_value'=>$this->tv_name,
					'control_class'=>"required",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'name',
					//'INFO'=>"TYPE=open&URL=__APP__/Task/viewTaskPage?id=[id]",
					'div_label'=>'',
				),
					'pmt_task.manager_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'manager_id',
					'control_value'=>$this->tv_manager_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'manager_id',
					'INFO'=>"TYPE=open&URL=__APP__/Employee/viewEmployeePage?user_id=[manager_id]",
					'div_label'=>'',
				),
					'pmt_task.adv_begin_date'=>array(
					'control_type'=>'INPUT_DATE','control_name'=>'adv_begin_date',
					'control_value'=>$this->tv_adv_begin_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_begin_date',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.adv_end_date'=>array(
					'control_type'=>'INPUT_DATE','control_name'=>'adv_end_date',
					'control_value'=>$this->tv_adv_end_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_end_date',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.adv_person_day'=>array(
					'control_type'=>'TEXT','control_name'=>'adv_person_day',
					'control_value'=>$this->tv_adv_person_day,
					'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_person_day',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.status'=>array(
					'control_type'=>'LABEL_DICT','control_name'=>'status',
					'control_value'=>$this->tv_status,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'status',
					'INFO'=>"",
					'div_label'=>'',
				),
				/*
					'pmt_task.adv_progress'=>array(
					'control_type'=>'LABEL','control_name'=>'adv_progress',
					'control_value'=>$this->tv_adv_progress,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_progress',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.tsh_progress'=>array(
					'control_type'=>'LABEL','control_name'=>'tsh_progress',
					'control_value'=>$this->tv_tsh_progress,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'tsh_progress',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.act_progress'=>array(
					'control_type'=>'LABEL','control_name'=>'act_progress',
					'control_value'=>$this->tv_act_progress,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'act_progress',
					'INFO'=>"",
					'div_label'=>'',
				),
				*/

				'operate'=>$buttons,
			),
		));




		self::addInfoResults($srModel,null);
		return $srModel;
	}

	public function editTaskPage($spModel) {
		$id = $this->srModel['id'];
		$srModel = array ();
		//$srModel["SPR_VIEW"] = array ();
		$this->title = Sr :: sys_pl(__FUNCTION__ . ".title", array (
			"displayDiv" => "false"
		));
		$this->form = array (
			"name" => "ff",
			"method" => "post",
			"action" => __URL__ . "/editTask",
			"target" => "_self",
			"onSubmit" => "",

		);
		//$this->srModel['id']?"1":"0"

		$this->addItem(array (
			'div_id' => 'div_search_v',
			'div_label' => 'pmt_task.id',
			'item_line_type' => '',
			'item_viewauth' => '',
			'control_type' => 'HIDDEN',
			'control_name' => 'id',
			'control_value' => $this->tv_id,
			'control_class' => " ",
			'control_param' => "  ",
			'control_readonly' => '0',
			'control_viewauth' => '',
			'value_input' => $this->srModel["id"],

		));
		$this->addItem(array (
			'div_id' => 'div_search_v',
			'div_label' => 'pmt_task.name',
			'item_line_type' => 'line',
			'item_viewauth' => '',
			'control_type' => 'TEXT',
			'control_name' => 'name',
			'control_value' => $this->tv_name,
			'control_class' => "required ",
			'control_param' => "  size='100'  ",
			'control_readonly' => '1',
			'control_viewauth' => '',
			'value_input' => $this->srModel["name"],

		));
		$this->addItem(array (
			'div_id' => 'div_search_v',
			'div_label' => 'pmt_task.adv_begin_date',
			'item_line_type' => '',
			'item_viewauth' => '',
			'control_type' => 'INPUT_DATE',
			'control_name' => 'adv_begin_date',
			'control_value' => $this->tv_adv_begin_date,
			'control_class' => " ",
			'control_param' => "  ",
			'control_readonly' => '0',
			'control_viewauth' => '',
			'value_input' => $this->srModel["adv_begin_date"],

		));
		$this->addItem(array (
			'div_id' => 'div_search_v',
			'div_label' => 'pmt_task.adv_end_date',
			'item_line_type' => '',
			'item_viewauth' => '',
			'control_type' => 'INPUT_DATE',
			'control_name' => 'adv_end_date',
			'control_value' => $this->tv_adv_end_date,
			'control_class' => " ",
			'control_param' => "  ",
			'control_readonly' => '0',
			'control_viewauth' => '',
			'value_input' => $this->srModel["adv_end_date"],

		));
		$this->addItem(array (
			'div_id' => 'div_search_v',
			'div_label' => 'pmt_task.manager_id',
			'item_line_type' => '',
			'item_viewauth' => '',
			'control_type' => 'SELECT_SQL',
			'control_name' => 'manager_id',
			'control_value' => $this->tv_manager_id,
			'control_class' => " ",
			'control_param' => "  ",
			'control_readonly' => '0',
			'control_viewauth' => '',
			'value_input' => $this->srModel["manager_id"],

		));
		//T000486	       任务计划中的成员清单没有过滤掉已经删除状态的
		$this->addItem(array (
			'div_id' => 'div_search_v',
			'div_label' => 'pmt_task.array_task_member',
			'item_line_type' => 'line',
			'item_viewauth' => '',
			'control_type' => 'CHECKBOX_SQL',
			'control_name' => 'array_task_member[]',
			//'control_value' => $this->tv_array_task_member,
			'control_value'=>$this->tv_array_task_member." and t2.project_id=".$this->srModel["project_id"],
			'control_param' => '',
			'control_readonly' => '0',
			'control_viewauth' => '',
			'value_input' => $this->srModel["array_task_member"],

		));
		$this->addItem(array (
			'div_id' => 'div_search_v',
			'div_label' => 'pmt_task.adv_person_day',
			'item_line_type' => '',
			'item_viewauth' => '',
			'control_type' => 'TEXT',
			'control_name' => 'adv_person_day',
			'control_value' => $this->tv_adv_person_day,
			'control_class' => " ",
			'control_param' => "  size='4'  ",
			'control_readonly' => '0',
			'control_viewauth' => '',
			'value_input' => $this->srModel["adv_person_day"],

		));

		$items = array (
			'div_id' => 'div_search',
			'div_label' => '',
			'item_line_type' => 'button',
			'item_viewauth' => '',

		);
		$items["items_line"] = array ();
		if(PmtTools::canEditTask($this->srModel["id"])){
			$items["items_line"][] = array (
				'control_type' => 'BUTTON',
				'control_name' => 'update',
				'control_value' => "",
				'control_class' => '',
				'control_param' => '',
				'control_readonly' => '0',
				'control_viewauth' => '',
				'value_input' => 'page.button.update',
			);

		}
		$items["items_line"][] = array (
			'control_type' => 'BUTTON',
			'control_name' => 'close',
			'control_value' => "",
			'control_class' => '',
			'control_param' => '',
			'control_readonly' => '0',
			'control_viewauth' => '',
			'value_input' => 'page.button.close',

		);
		$this->addItems($items);

		$srModel_sflow = SrSflow :: page_displayButton(array (
			"sflow_is_add_form" => "0",
			"sflow_current_form" => "ff",
			"sflow_code" => "pmt_task",
			"sflow_business_id" => $this->srModel["id"],
			"sflow_business_num" => $this->srModel["code"],
			"sflow_from_status" => $this->srModel["status"],
			"sflow_business_type" => $spModel["pageType"], //$spModel["pageType"],
	"sflow_return_url" => __SELF__,
			"sflow_request_params" => array (
				"id" => $spModel["id"],
				"pageType" => $spModel["pageType"],
				"display_buttons" => array (
					'010'
				),
			),
		));
		echo $srModel_sflow["divHtml"];
		$items["items_line"] = $srModel_sflow["buttonArrays"];
		$this->addItems($items);


		if ($this->srModel["project_id"] != null) {
			$this->setControlProperty("div_search_v", "project_id", "control_readonly", "1");
		}
		if ($this->srModel["module_id"] != null) {
			$this->setControlProperty("div_search_v", "module_id", "control_readonly", "1");
		}
		if ($this->srModel["spr_tree_type"] == "010") {
			$this->setControlProperty("div_search_v", "adv_begin_date", "control_readonly", "1");
			$this->setControlProperty("div_search_v", "adv_end_date", "control_readonly", "1");
			$this->setControlProperty("div_search_v", "adv_person_day", "control_readonly", "1");
			$this->setControlProperty("div_search_v", "array_task_member", "control_readonly", "1");
		}


		self :: addInfoResults($srModel, null);
		return $srModel;
	}


	public function queryDocuments($spModel) {
		$table_id = $this->spModel["id"];
		$table_name = 'pmt_task';

		$action = $this->spModel["action"];

		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));

		$items = array('div_id'=>'div_search_v','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		//if($action=='edit'){
			$items["items_line"][] = array(
					'control_type'=>'BUTTON','control_name'=>'upload',
					'control_value'=>__APP__."/AppPmtDocument/uploadDocumentFilePage?table_name={$table_name}&table_id={$table_id}",
					'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'page.button.upload',
				);
		//}




		$this->addItems($items);

		$buttons = array();
//		$buttons[] = array(
//				'control_type'=>'BUTTON','control_name'=>'view',
//				'control_value'=>__APP__."/AppPmtDocument/viewProjectPage?id=[id]",//URL,GRID,REQUEST,SESSION
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.view',
//			);
		$list = array();
//		foreach($this->srModel['list'] as $k=>$model){
//			$model['title2'] = '<b>'.$model['title'].'</b>  (v'.$model['document_version'].' @ '.$model['create_time'].')';
//			$list[] = $model;
//		}
		foreach($this->srModel['list'] as $k=>$model){
			$document_type = Sr::sys_dictValue('PMT17',$model['document_type']);

			$url = Sr::sys_sl(__APP__."/AppPmtDocument/downloadDocument?document_id=".$model['id']);

			$tt1 = '<b>'.$model['title'].'</b>  (v'.$model['document_version'].' @ '.$model['create_time'].')';
			$tt1 = "[{$document_type}]&nbsp;<a href='{$url}' target='_blank'>{$tt1}</a>";

//			$url = __APP__."/VbaHttp/downloadDocumentVbs?document_id=".$model['id'];
			$tt2 = "";
//			switch($model['document_type']){
//				case '010':
// 					$tt2 = "<a href='{$url}' target='_blank'>[上传命令]</a>";
//					break;
//			}
			$url = Sr::sys_sl(__APP__."/AppPmtDocument/uploadDocumentFilePage?table_name=pmt_task&table_id=".$this->spModel['id']."&old_document_id=".$model["id"]);
			$tt2 .= "&nbsp;&nbsp;<a href='{$url}' target='_blank'>[版本升级]</a>";

//			echo "[". $model["current_version_id"]."]";
			if($model["current_version_id"]!=null&&$model["current_version_id"]!=''&&$model["current_version_id"]!='0'&&$model["current_version_id"]!=$model['id']){
				$url = Sr::sys_sl(__APP__."/AppPmtDocument/queryDocumentsByCurrentVersionId?current_version_id=".$model["current_version_id"]);
				$tt2 .= "&nbsp;&nbsp;<a href='{$url}' target='_blank'>[版本清单]</a>";
			}




			if($model['link_belong_user_id']==SrUser::getUserId()){
				$tt2 .= "&nbsp;&nbsp;<B><a href='#' onClick='onClick_itemDelete(\"".Sr::sys_sl(__URL__."/deleteDocument?document_id=".$model["id"]."&task_id=".$this->spModel['id'])."\")'>[删除]</a></B>";
			}


			$model['title2'] = $tt1.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$tt2;


			$list[] = $model;
		}

		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$list,'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
				'pmt_document.title'=>array(
					'control_type'=>'TEXT','control_name'=>'title',
					'control_value'=>$this->tv_code,
					'control_class'=>"required",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'title2',
					//'INFO'=>"TYPE=open&URL=__APP__/AppPmtDocument/downloadDocument?document_id=[id]",
					'div_label'=>'pmt_document.title',
				),
				//'operate'=>$buttons,
			),
		));

		$list = array();
		if(is_array($this->srModel['other_list'])){
			foreach($this->srModel['other_list'] as $k=>$model){
				$task_name = self::sys_queryById2($model['task_id'],'pmt_task','name');
				$model['title2'] = '<b>'.$model['title'].'</b>  (v'.$model['document_version'].' @ '.$model['create_time'].' For ['.$task_name.'])';
				$list[] = $model;
			}
		}
		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'其他任务文档','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid2',
			'grid_list'=>$list,'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
				'pmt_document.title'=>array(
					'control_type'=>'TEXT','control_name'=>'title',
					'control_value'=>$this->tv_code,
					'control_class'=>"required",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'title2',
					'INFO'=>"TYPE=open&URL=__APP__/AppPmtDocument/downloadDocument?document_id=[id]",
					'div_label'=>'pmt_document.title',
				),
				//'operate'=>$buttons,
			),
		));

//		if($action!='edit'){
//			$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
//			$srModel_sflow = SrSflow::page_displayButton(array(
//				"sflow_is_add_form"=>"0",
//				"sflow_current_form"=>"ff",
//				"sflow_code"=>"pmt_task",
//				"sflow_business_id"=>$this->spModel["id"],
//				"sflow_business_num"=>$this->srModel["code"],
//				"sflow_from_status"=>$this->srModel["status"],
//				"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
//				"sflow_return_url"=>__SELF__,
//				"sflow_request_params"=>array(
//				"id"=>$spModel["id"],
//				"pageType"=>$spModel["pageType"],
//				),
//			));
//			$this->hidden_html = $srModel_sflow["divHtml"];
//			$items["items_line"] = $srModel_sflow["buttonArrays"];
//			$items["items_line"][] = array(
//					'control_type'=>'BUTTON','control_name'=>'close',
//					'control_value'=>"",
//					'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//					'value_input'=>'page.button.close',
//				);
//			$this->addItems($items);
//		}



		self::addInfoResults($srModel,null);
		return $srModel;
	}

//	public function viewTaskIframePage($spModel){
//		$id = $this->srModel['id'];
//		$srModel = array();
//
//		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
//		$this->form = array(
//			"name"=>"ff",
//			"method"=>"post",
//			"action"=>__URL__."/viewTaskPage",
//			"target"=>"_self",
//			"onSubmit"=>"",
//		);
//		//$this->srModel['id']?"1":"0"
// 		$this->addItem(array(
//			'div_id'=>'div_blank','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
//			'control_type'=>'IFRAME','control_name'=>'',
//			'control_value'=>'',
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
//			'value_input'=>$this->spModel['iframe_src'],
//			'INFO'=>"",
//		));
//
//		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
//		$srModel_sflow = SrSflow::page_displayButton(array(
//			"sflow_is_add_form"=>"0",
//			"sflow_current_form"=>"ff",
//			"sflow_code"=>"pmt_task",
//			"sflow_business_id"=>$this->srModel["id"],
//			"sflow_business_num"=>$this->srModel["code"],
//			"sflow_from_status"=>$this->srModel["status"],
//			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
//			"sflow_return_url"=>__SELF__,
//			"sflow_request_params"=>array(
//			"id"=>$spModel["id"],
//			"pageType"=>$spModel["pageType"],
//			),
//		));
//		$this->hidden_html = $srModel_sflow["divHtml"];
//		$items["items_line"] = $srModel_sflow["buttonArrays"];
//
//		$items["items_line"][] = array(
//				'control_type'=>'BUTTON','control_name'=>'close',
//				'control_value'=>"",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.close',
//			);
//		$this->addItems($items);
//
//
//
//
//		self::addInfoResults($srModel,null);
//		return $srModel;
//	}
//	public function viewTaskIframe2Page($spModel){
//		$id = $this->srModel['id'];
//		$srModel = array();
//
//		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
//		$this->form = array(
//			"name"=>"ff",
//			"method"=>"post",
//			"action"=>__URL__."/viewTaskPage",
//			"target"=>"_self",
//			"onSubmit"=>"",
//		);
//		//$this->srModel['id']?"1":"0"
// 		$this->addItem(array(
//			'div_id'=>'div_blank','div_label'=>'','item_line_type'=>'left_iframe','item_viewauth'=>'',
//			'control_type'=>'IFRAME','control_name'=>'left_iframe',
//			'control_value'=>'',
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
//			'value_input'=>$this->spModel['iframe_left'],
//			'INFO'=>"",
//		));
// 		$this->addItem(array(
//			'div_id'=>'div_blank','div_label'=>'','item_line_type'=>'right_iframe','item_viewauth'=>'',
//			'control_type'=>'IFRAME','control_name'=>'right_iframe',
//			'control_value'=>'',
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
//			'value_input'=>$this->spModel['iframe_src'],
//			'INFO'=>"",
//		));
//
//		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
//		$srModel_sflow = SrSflow::page_displayButton(array(
//			"sflow_is_add_form"=>"0",
//			"sflow_current_form"=>"ff",
//			"sflow_code"=>"pmt_task",
//			"sflow_business_id"=>$this->srModel["id"],
//			"sflow_business_num"=>$this->srModel["code"],
//			"sflow_from_status"=>$this->srModel["status"],
//			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
//			"sflow_return_url"=>__SELF__,
//			"sflow_request_params"=>array(
//			"id"=>$spModel["id"],
//			"pageType"=>$spModel["pageType"],
//			),
//		));
//		$this->hidden_html = $srModel_sflow["divHtml"];
//		$items["items_line"] = $srModel_sflow["buttonArrays"];
//
//		$items["items_line"][] = array(
//				'control_type'=>'BUTTON','control_name'=>'close',
//				'control_value'=>"",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.close',
//			);
//		$this->addItems($items);
//
//
//
//
//		self::addInfoResults($srModel,null);
//		return $srModel;
//	}
//
//
//	public function editTaskIframePage($spModel){
//		$id = $this->srModel['id'];
//		$srModel = array();
//
//		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
//		$this->form = array(
//			"name"=>"ff",
//			"method"=>"post",
//			"action"=>__URL__."/viewTaskPage",
//			"target"=>"_self",
//			"onSubmit"=>"",
//		);
//		//$this->srModel['id']?"1":"0"
// 		$this->addItem(array(
//			'div_id'=>'div_blank','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
//			'control_type'=>'IFRAME','control_name'=>'',
//			'control_value'=>'',
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
//			'value_input'=>$this->spModel['iframe_src'],
//			'INFO'=>"",
//		));
//
//
//
//
//
//		self::addInfoResults($srModel,null);
//		return $srModel;
//	}
//	public function editTaskIframe2Page($spModel){
//		$id = $this->srModel['id'];
//		$srModel = array();
//
//		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
//		$this->form = array(
//			"name"=>"ff",
//			"method"=>"post",
//			"action"=>__URL__."/viewTaskPage",
//			"target"=>"_self",
//			"onSubmit"=>"",
//		);
//		//$this->srModel['id']?"1":"0"
// 		$this->addItem(array(
//			'div_id'=>'div_blank','div_label'=>'','item_line_type'=>'left_iframe','item_viewauth'=>'',
//			'control_type'=>'IFRAME','control_name'=>'left_iframe',
//			'control_value'=>'',
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
//			'value_input'=>$this->spModel['iframe_left'],
//			'INFO'=>"",
//		));
// 		$this->addItem(array(
//			'div_id'=>'div_blank','div_label'=>'','item_line_type'=>'right_iframe','item_viewauth'=>'',
//			'control_type'=>'IFRAME','control_name'=>'right_iframe',
//			'control_value'=>'',
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
//			'value_input'=>$this->spModel['iframe_src'],
//			'INFO'=>"",
//		));
//
//
//
//
//
//
//		self::addInfoResults($srModel,null);
//		return $srModel;
//	}


	public function queryPersonTodayTask($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));



		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'view',
				'control_value'=>__APP__."/Task/viewTaskPage?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.view',
			);

		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
					'pmt_task.emergency_degree'=>array(
					'control_type'=>'STAR','control_name'=>'emergency_degree',
					'control_value'=>$this->tv_act_progress,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'star',
					'INFO'=>"{NUM:5}",
					'div_label'=>'',
				),
					'pmt_task.module_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'module_id',
					'control_value'=>$this->tv_module_id,
					'control_class'=>"required",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'module_id',
					'INFO'=>"TYPE=open&URL=__APP__/Module/viewModulePage?id=[module_id]",
					'div_label'=>'',
				),
				'pmt_task.code'=>array(
					'control_type'=>'LABEL_PHP','control_name'=>'code',
					'control_value'=>$this->tv_code,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'code',
					'INFO'=>"TYPE=open&URL=__APP__/Task/viewTaskPage?id=[id]",
					'div_label'=>'',
				),
					'pmt_task.name'=>array(
					'control_type'=>'TEXT','control_name'=>'name',
					'control_value'=>$this->tv_name,
					'control_class'=>"required",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'name',
					'INFO'=>"TYPE=open&URL=__APP__/Task/viewTaskPage?id=[id]",
					'div_label'=>'',
				),
					'pmt_task.manager_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'manager_id',
					'control_value'=>$this->tv_manager_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'manager_id',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.adv_begin_date'=>array(
					'control_type'=>'INPUT_DATE','control_name'=>'adv_begin_date',
					'control_value'=>$this->tv_adv_begin_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_begin_date',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.adv_end_date'=>array(
					'control_type'=>'INPUT_DATE','control_name'=>'adv_end_date',
					'control_value'=>$this->tv_adv_end_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_end_date',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.adv_person_day'=>array(
					'control_type'=>'TEXT','control_name'=>'adv_person_day',
					'control_value'=>$this->tv_adv_person_day,
					'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_person_day',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.status'=>array(
					'control_type'=>'LABEL_DICT','control_name'=>'status',
					'control_value'=>$this->tv_status,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'status',
					'INFO'=>"",
					'div_label'=>'',
				),
				/*
					'pmt_task.adv_progress'=>array(
					'control_type'=>'LABEL','control_name'=>'adv_progress',
					'control_value'=>$this->tv_adv_progress,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_progress',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.tsh_progress'=>array(
					'control_type'=>'LABEL','control_name'=>'tsh_progress',
					'control_value'=>$this->tv_tsh_progress,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'tsh_progress',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.act_progress'=>array(
					'control_type'=>'LABEL','control_name'=>'act_progress',
					'control_value'=>$this->tv_act_progress,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'act_progress',
					'INFO'=>"",
					'div_label'=>'',
				),
				*/

				'operate'=>$buttons,
			),
		));




		self::addInfoResults($srModel,null);
		return $srModel;
	}


public function viewEmployeeTask($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
 		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_task_tsheet.project_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_project_id'],
			'INFO'=>"TYPE=open&URL=__APP__/Project/viewProjectPage%3Fid=[project_id]",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_task_tsheet.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'query_status',
			'control_value'=>$this->tv_status,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_status'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_task.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_code',
			'control_value'=>$this->tv_code,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_code'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_task.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_name',
			'control_value'=>$this->tv_name,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_name'],
			'INFO'=>"",
		));

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);



		$this->addItems($items);

		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'view',
				'control_value'=>__APP__."/Task/viewTaskPage?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.view',
			);


//		foreach($this->srModel['list'] as $k=>$model){
//			$this->srModel['list'][$k]['_gridGroupSort_'] = $model["module_name"];
//		}

		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_info'=>'{has_group_select:1,group_select_option:pmt_module.name/pmt_task.manager_id,group_select_key:pmt_module.name}',
			'grid_param'=>array(
				'pmt_module.name'=>array(
					'control_type'=>'LABEL','control_name'=>'name',
					'control_value'=>$this->tv_code,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'module_name',
					'INFO'=>"TYPE=open&URL=__APP__/Module/viewModulePage?id=[id]",
					'div_label'=>'',
				),
				'pmt_task.code'=>array(
					'control_type'=>'LABEL_PHP','control_name'=>'code',
					'control_value'=>$this->tv_code,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'code',
					'INFO'=>"TYPE=open&URL=__APP__/Task/viewTaskPage?id=[id]",
					'div_label'=>'',
				),
					'pmt_task.name'=>array(
					'control_type'=>'TEXT','control_name'=>'name',
					'control_value'=>$this->tv_name,
					'control_class'=>"required",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'name',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.manager_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'manager_id',
					'control_value'=>$this->tv_manager_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'manager_id',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.adv_begin_date'=>array(
					'control_type'=>'INPUT_DATE','control_name'=>'adv_begin_date',
					'control_value'=>$this->tv_adv_begin_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_begin_date',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.adv_end_date'=>array(
					'control_type'=>'INPUT_DATE','control_name'=>'adv_end_date',
					'control_value'=>$this->tv_adv_end_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_end_date',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.adv_person_day'=>array(
					'control_type'=>'TEXT','control_name'=>'adv_person_day',
					'control_value'=>$this->tv_adv_person_day,
					'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_person_day',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.status'=>array(
					'control_type'=>'LABEL_DICT','control_name'=>'status',
					'control_value'=>$this->tv_status,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'status',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.adv_progress'=>array(
					'control_type'=>'LABEL','control_name'=>'adv_progress',
					'control_value'=>$this->tv_adv_progress,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_progress',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.tsh_progress'=>array(
					'control_type'=>'LABEL','control_name'=>'tsh_progress',
					'control_value'=>$this->tv_tsh_progress,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'tsh_progress',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.act_progress'=>array(
					'control_type'=>'LABEL','control_name'=>'act_progress',
					'control_value'=>$this->tv_act_progress,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'act_progress',
					'INFO'=>"",
					'div_label'=>'',
				),

				'operate'=>$buttons,
			),
		));




		self::addInfoResults($srModel,null);
		return $srModel;
	}
}
?>
