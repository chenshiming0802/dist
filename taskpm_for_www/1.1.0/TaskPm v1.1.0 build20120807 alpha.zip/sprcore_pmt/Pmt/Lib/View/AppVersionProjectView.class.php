<?php
class AppVersionProjectView extends SrView{

	private $tv_project_id;
	private $tv_manager_id;
	private $tv_version_value;

	public function __construct(){
		$this->tv_project_id = "1;;;pmt_project;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_project t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";
		$this->tv_manager_id = "1;;;uup_user;name;SELECT t.id _valueCode_,t.name _valueName_ FROM uup_user t WHERE is_deleted='0' and org_id=".SrUser::getOrgId()." ";
	}

	public function compareModule($spModel){

		$this->tv_version_value = "1;CurrentVersion;-1;pmt_version_project;name;SELECT t.id _valueCode_,concat(t.name,' @ ',t.create_time) _valueName_ FROM pmt_version_project t WHERE 1=1 /*w[t]*/ and project_id=".$this->spModel['query_project_id']." and belong_org_id=".SrUser::getOrgId()." order by t.id desc";

		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);
		$buttons = array();
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
 		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_version_project.name','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'version_id_1',
			'control_value'=>$this->tv_version_value,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['version_id_1'],
		));
 		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_version_project.name','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'version_id_2',
			'control_value'=>$this->tv_version_value,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['version_id_2'],
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'label.grid_display_fields','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'CHECKBOX_DICT','control_name'=>'grid_display_fields[]',
			'control_value'=>"1;;PMT13",
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['grid_display_fields'],
		));
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$this->addItems($items);
		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'view',
				'control_value'=>__APP__."/AppVersionProject/compareTask?query_project_id=".$this->spModel['query_project_id']."&query_module_id=[id]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.task',
			);
		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
//					'pmt_module.code'=>array(
//					'control_type'=>'LABEL_PHP','control_name'=>'code',
//					'control_value'=>$this->tv_code,
//					'control_class'=>"",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
//					'value_input'=>'code',
//					'div_label'=>'',
//				),
					'pmt_module.name'=>array(
					'control_type'=>'TEXT','control_name'=>'name',
					'control_value'=>$this->tv_name,
					'control_class'=>"required",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'name',
					'div_label'=>'',
					'INFO'=>"TYPE=open&URL=__APP__/Module/viewModulePage?id=[id]",
				),
					'pmt_module.status'=>array(
					'control_type'=>'LABEL','control_name'=>'status',
					'control_value'=>$this->tv_manager_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'table_status_desc',
					'div_label'=>'',
				),
					'pmt_module.manager_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'manager_id',
					'control_value'=>$this->tv_manager_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'manager_id',
					'div_label'=>'',
				),
				"pmt_module.adv_begin_date"=>array(
						'control_type'=>'LABEL','control_name'=>'adv_begin_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_begin_date',
						'div_label'=>'pmt_progress.adv_begin_date',
					),
				"pmt_module.tsh_begin_date"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_begin_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_begin_date',
						'div_label'=>'pmt_progress.tsh_begin_date',
					),
//				"pmt_module.act_begin_date"=>array(
//						'control_type'=>'LABEL','control_name'=>'act_begin_date[]',
//						'control_value'=>"",
//						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//						'value_input'=>'act_begin_date',
//						'div_label'=>'pmt_progress.act_begin_date',
//					),
				"pmt_module.adv_end_date"=>array(
						'control_type'=>'LABEL','control_name'=>'adv_end_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_end_date',
						'div_label'=>'pmt_progress.adv_end_date',
					),
				"pmt_module.tsh_end_date"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_end_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_end_date',
						'div_label'=>'pmt_progress.tsh_end_date',
					),
//				"pmt_module.act_end_date"=>array(
//						'control_type'=>'LABEL','control_name'=>'act_end_date[]',
//						'control_value'=>"",
//						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//						'value_input'=>'act_end_date',
//						'div_label'=>'pmt_progress.act_end_date',
//					),
				"pmt_module.adv_progress"=>array(
						'control_type'=>'LABEL','control_name'=>'adv_progress[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_progress',
						'div_label'=>'pmt_progress.adv_progress',
					),
				"pmt_module.tsh_progress"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_progress[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_progress',
						'div_label'=>'pmt_progress.tsh_progress',
					),
				"pmt_module.act_progress"=>array(
						'control_type'=>'LABEL','control_name'=>'act_progress[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'act_progress',
						'div_label'=>'pmt_progress.act_progress',
					),
				"pmt_module.adv_person_day"=>array(
						'control_type'=>'LABEL','control_name'=>'adv_person_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_person_day',
						'div_label'=>'pmt_progress.adv_person_day',
					),
//				"pmt_module.act_person_day"=>array(
//						'control_type'=>'LABEL','control_name'=>'act_person_day[]',
//						'control_value'=>"",
//						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//						'value_input'=>'act_person_day',
//						'div_label'=>'pmt_progress.act_person_day',
//					),
				"pmt_module.tsh_person_day"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_person_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_person_day',
						'div_label'=>'pmt_progress.tsh_person_day',
					),
				"pmt_module.tsh_person_over_day"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_person_over_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_person_over_day',
						'div_label'=>'pmt_progress.tsh_person_over_day',
					),
				"pmt_module.adv_work_day"=>array(
						'control_type'=>'LABEL','control_name'=>'adv_work_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_work_day',
						'div_label'=>'pmt_progress.adv_work_day',
					),
				"pmt_module.tsh_work_day"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_work_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_work_day',
						'div_label'=>'pmt_progress.tsh_work_day',
					),

				'operate'=>$buttons,
			),
		));
		$this->bindGridFields("div_results","grid","grid_display_fields[]",array(
			"010"=>array(
				"pmt_module.adv_begin_date",
				"pmt_module.tsh_begin_date",
//				"pmt_module.act_begin_date",
				"pmt_module.adv_end_date",
				"pmt_module.tsh_end_date",
//				"pmt_module.act_end_date",
				),
			"020"=>array(
				"pmt_module.act_progress",
				"pmt_module.adv_progress",
				"pmt_module.tsh_progress",
				),
			"030"=>array(
				"pmt_module.adv_person_day",
				//"pmt_module.act_person_day",
				"pmt_module.tsh_person_day",
				"pmt_module.tsh_person_over_day",
				),
			"040"=>array(
				"pmt_module.adv_work_day",
				"pmt_module.tsh_work_day",
				//"pmt_module.act_work_day",
				)
		));



		self::addInfoResults($srModel,null);
		return $srModel;
	}



	public function compareTask($spModel){

		$this->tv_version_value = "1;CurrentVersion;-1;pmt_version_project;name;SELECT t.id _valueCode_,concat(t.name,' @ ',t.create_time) _valueName_ FROM pmt_version_project t WHERE 1=1 /*w[t]*/ and project_id=".$this->spModel['query_project_id']." and belong_org_id=".SrUser::getOrgId()." order by t.id desc";

		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);
		$buttons = array();
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
 		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_version_project.name','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'version_id_1',
			'control_value'=>$this->tv_version_value,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['version_id_1'],
		));
 		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_version_project.name','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'version_id_2',
			'control_value'=>$this->tv_version_value,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['version_id_2'],
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'label.grid_display_fields','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'CHECKBOX_DICT','control_name'=>'grid_display_fields[]',
			'control_value'=>"1;;PMT13",
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['grid_display_fields'],
		));
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$this->addItems($items);
		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
//					'pmt_task.code'=>array(
//					'control_type'=>'LABEL_PHP','control_name'=>'code',
//					'control_value'=>$this->tv_code,
//					'control_class'=>"",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
//					'value_input'=>'code',
//					'div_label'=>'',
//				),
					'pmt_task.name'=>array(
					'control_type'=>'TEXT','control_name'=>'name',
					'control_value'=>$this->tv_name,
					'control_class'=>"required",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'name',
					'div_label'=>'',
					'INFO'=>"TYPE=open&URL=__APP__/Task/viewTaskPage?id=[id]",
				),
					'pmt_task.status'=>array(
					'control_type'=>'LABEL','control_name'=>'status',
					'control_value'=>$this->tv_manager_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'table_status_desc',
					'div_label'=>'',
				),
					'pmt_task.manager_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'manager_id',
					'control_value'=>$this->tv_manager_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'manager_id',
					'div_label'=>'',
				),
				"pmt_task.adv_begin_date"=>array(
						'control_type'=>'LABEL','control_name'=>'adv_begin_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_begin_date',
						'div_label'=>'pmt_progress.adv_begin_date',
					),
				"pmt_task.tsh_begin_date"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_begin_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_begin_date',
						'div_label'=>'pmt_progress.tsh_begin_date',
					),
//				"pmt_task.act_begin_date"=>array(
//						'control_type'=>'LABEL','control_name'=>'act_begin_date[]',
//						'control_value'=>"",
//						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//						'value_input'=>'act_begin_date',
//						'div_label'=>'pmt_progress.act_begin_date',
//					),
				"pmt_task.adv_end_date"=>array(
						'control_type'=>'LABEL','control_name'=>'adv_end_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_end_date',
						'div_label'=>'pmt_progress.adv_end_date',
					),
				"pmt_task.tsh_end_date"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_end_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_end_date',
						'div_label'=>'pmt_progress.tsh_end_date',
					),
//				"pmt_task.act_end_date"=>array(
//						'control_type'=>'LABEL','control_name'=>'act_end_date[]',
//						'control_value'=>"",
//						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//						'value_input'=>'act_end_date',
//						'div_label'=>'pmt_progress.act_end_date',
//					),
				"pmt_task.adv_progress"=>array(
						'control_type'=>'LABEL','control_name'=>'adv_progress[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_progress',
						'div_label'=>'pmt_progress.adv_progress',
					),
				"pmt_task.tsh_progress"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_progress[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_progress',
						'div_label'=>'pmt_progress.tsh_progress',
					),
				"pmt_task.act_progress"=>array(
						'control_type'=>'LABEL','control_name'=>'act_progress[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'act_progress',
						'div_label'=>'pmt_progress.act_progress',
					),
				"pmt_task.adv_person_day"=>array(
						'control_type'=>'LABEL','control_name'=>'adv_person_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_person_day',
						'div_label'=>'pmt_progress.adv_person_day',
					),
//				"pmt_task.act_person_day"=>array(
//						'control_type'=>'LABEL','control_name'=>'act_person_day[]',
//						'control_value'=>"",
//						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//						'value_input'=>'act_person_day',
//						'div_label'=>'pmt_progress.act_person_day',
//					),
				"pmt_task.tsh_person_day"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_person_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_person_day',
						'div_label'=>'pmt_progress.tsh_person_day',
					),
				"pmt_task.tsh_person_over_day"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_person_over_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_person_over_day',
						'div_label'=>'pmt_progress.tsh_person_over_day',
					),
				"pmt_task.adv_work_day"=>array(
						'control_type'=>'LABEL','control_name'=>'adv_work_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_work_day',
						'div_label'=>'pmt_progress.adv_work_day',
					),
				"pmt_task.tsh_work_day"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_work_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_work_day',
						'div_label'=>'pmt_progress.tsh_work_day',
					),

				//'operate'=>$buttons,
			),
		));
		$this->bindGridFields("div_results","grid","grid_display_fields[]",array(
			"010"=>array(
				"pmt_task.adv_begin_date",
				"pmt_task.tsh_begin_date",
//				"pmt_task.act_begin_date",
				"pmt_task.adv_end_date",
				"pmt_task.tsh_end_date",
//				"pmt_task.act_end_date",
				),
			"020"=>array(
				"pmt_task.act_progress",
				"pmt_task.adv_progress",
				"pmt_task.tsh_progress",
				),
			"030"=>array(
				"pmt_task.adv_person_day",
				//"pmt_task.act_person_day",
				"pmt_task.tsh_person_day",
				"pmt_task.tsh_person_over_day",
				),
			"040"=>array(
				"pmt_task.adv_work_day",
				"pmt_task.tsh_work_day",
				//"pmt_task.act_work_day",
				)
		));



		self::addInfoResults($srModel,null);
		return $srModel;
	}
}
?>
