<?php
class AppTask2ContentView extends SrView{	

}
?>
