<?php

class EmployeeAssignView extends SrView{
	private $tv_status; 
	private $tv_employee_id; 
	private $tv_project_id; 
	private $tv_joblevel_id; 
	private $tv_company_id; 

	public function __construct(){
		$this->tv_status = "1;;PMT15"; 
		$this->tv_employee_id = "1;;;pmt_employee;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_employee t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId().""; 
		$this->tv_project_id = "1;;;pmt_project;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_project t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId().""; 
		$this->tv_joblevel_id = "1;;;pmt_joblevel;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_joblevel t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()." "; 
		$this->tv_company_id = "1;;;pmt_company;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_company t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()." "; 
	
	}

public function queryEmployeeAssign($spModel){
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);
		
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee_assign.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'query_status',
			'control_value'=>$this->tv_status,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_status'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee_assign.employee_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_employee_id',
			'control_value'=>$this->tv_employee_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_employee_id'],
			'INFO'=>"TYPE=open&URL=__APP__/Employee/viewEmployeePage?id=[employee_id]",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee_assign.project_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_project_id'],
			'INFO'=>"TYPE=open&URL=__APP__/Project/viewProjectPage%3Fid=[project_id]",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee_assign.joblevel_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_joblevel_id',
			'control_value'=>$this->tv_joblevel_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_joblevel_id'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee_assign.company_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_company_id',
			'control_value'=>$this->tv_company_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_company_id'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee_assign.year','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_year',
			'control_value'=>$this->tv_year,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_year'],
			'INFO'=>"",
		));
	 
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(		
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);

	
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'appadd',
				'control_value'=>__URL__."/managerEmployeeAssignPage",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.appadd',
			);


		$this->addItems($items);	

		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'view',
				'control_value'=>__URL__."/viewEmployeeAssignPage?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.view',
			);

		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
				'pmt_employee_assign.status'=>array(
					'control_type'=>'LABEL_DICT','control_name'=>'status',
					'control_value'=>$this->tv_status,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'status',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.employee_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'employee_id',
					'control_value'=>$this->tv_employee_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'employee_id',
					'INFO'=>"TYPE=open&URL=__APP__/Employee/viewEmployeePage?id=[employee_id]",
					'div_label'=>'',
				),			
					'pmt_employee_assign.project_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'project_id',
					'control_value'=>$this->tv_project_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'project_id',
					'INFO'=>"TYPE=open&URL=__APP__/Project/viewProjectPage%3Fid=[project_id]",
					'div_label'=>'',
				),			
					'pmt_employee_assign.joblevel_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'joblevel_id',
					'control_value'=>$this->tv_joblevel_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'joblevel_id',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.company_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'company_id',
					'control_value'=>$this->tv_company_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'company_id',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.year'=>array(
					'control_type'=>'TEXT','control_name'=>'year',
					'control_value'=>$this->tv_year,
					'control_class'=>"validate-numbe max-value-3000",'control_param'=>"  size='4'  maxlength='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'year',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m1'=>array(
					'control_type'=>'TEXT','control_name'=>'m1',
					'control_value'=>$this->tv_m1,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m1',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m2'=>array(
					'control_type'=>'TEXT','control_name'=>'m2',
					'control_value'=>$this->tv_m2,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m2',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m3'=>array(
					'control_type'=>'TEXT','control_name'=>'m3',
					'control_value'=>$this->tv_m3,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m3',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m4'=>array(
					'control_type'=>'TEXT','control_name'=>'m4',
					'control_value'=>$this->tv_m4,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m4',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m5'=>array(
					'control_type'=>'TEXT','control_name'=>'m5',
					'control_value'=>$this->tv_m5,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m5',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m6'=>array(
					'control_type'=>'TEXT','control_name'=>'m6',
					'control_value'=>$this->tv_m6,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m6',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m7'=>array(
					'control_type'=>'TEXT','control_name'=>'m7',
					'control_value'=>$this->tv_m7,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m7',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m8'=>array(
					'control_type'=>'TEXT','control_name'=>'m8',
					'control_value'=>$this->tv_m8,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m8',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m9'=>array(
					'control_type'=>'TEXT','control_name'=>'m9',
					'control_value'=>$this->tv_m9,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m9',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m10'=>array(
					'control_type'=>'TEXT','control_name'=>'m10',
					'control_value'=>$this->tv_m10,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m10',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m11'=>array(
					'control_type'=>'TEXT','control_name'=>'m11',
					'control_value'=>$this->tv_m11,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m11',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m12'=>array(
					'control_type'=>'TEXT','control_name'=>'m12',
					'control_value'=>$this->tv_m12,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m12',
					'INFO'=>"",
					'div_label'=>'',
				),			
	
				'operate'=>$buttons,
			),			
		));
		

		

		self::addInfoResults($srModel,null);
		return $srModel;
	}





	public function viewEmployeeAssignPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewEmployeeAssignPage",
			"target"=>"_self",
			"onSubmit"=>"",
		);	
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));	
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.status','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL_DICT','control_name'=>'status',
			'control_value'=>$this->tv_status,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["status"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.employee_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'employee_id',
			'control_value'=>$this->tv_employee_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["employee_id"],
			'INFO'=>"TYPE=open&URL=__APP__/Employee/viewEmployeePage?id=[employee_id]",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.project_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["project_id"],
			'INFO'=>"TYPE=open&URL=__APP__/Project/viewProjectPage%3Fid=[project_id]",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.joblevel_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'joblevel_id',
			'control_value'=>$this->tv_joblevel_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["joblevel_id"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.company_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'company_id',
			'control_value'=>$this->tv_company_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["company_id"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.memo','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'memo',
			'control_value'=>$this->tv_memo,
			'control_class'=>" ",'control_param'=>"ROWS=10 COLS=100  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["memo"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.year','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'year',
			'control_value'=>$this->tv_year,
			'control_class'=>"validate-numbe max-value-3000 ",'control_param'=>"  size='4'  maxlength='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["year"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.m1','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'m1',
			'control_value'=>$this->tv_m1,
			'control_class'=>"validate-numbe max-value-100 ",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["m1"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.m2','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'m2',
			'control_value'=>$this->tv_m2,
			'control_class'=>"validate-numbe max-value-100 ",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["m2"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.m3','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'m3',
			'control_value'=>$this->tv_m3,
			'control_class'=>"validate-numbe max-value-100 ",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["m3"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.m4','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'m4',
			'control_value'=>$this->tv_m4,
			'control_class'=>"validate-numbe max-value-100 ",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["m4"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.m5','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'m5',
			'control_value'=>$this->tv_m5,
			'control_class'=>"validate-numbe max-value-100 ",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["m5"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.m6','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'m6',
			'control_value'=>$this->tv_m6,
			'control_class'=>"validate-numbe max-value-100 ",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["m6"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.m7','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'m7',
			'control_value'=>$this->tv_m7,
			'control_class'=>"validate-numbe max-value-100 ",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["m7"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.m8','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'m8',
			'control_value'=>$this->tv_m8,
			'control_class'=>"validate-numbe max-value-100 ",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["m8"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.m9','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'m9',
			'control_value'=>$this->tv_m9,
			'control_class'=>"validate-numbe max-value-100 ",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["m9"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.m10','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'m10',
			'control_value'=>$this->tv_m10,
			'control_class'=>"validate-numbe max-value-100 ",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["m10"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.m11','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'m11',
			'control_value'=>$this->tv_m11,
			'control_class'=>"validate-numbe max-value-100 ",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["m11"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.m12','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'m12',
			'control_value'=>$this->tv_m12,
			'control_class'=>"validate-numbe max-value-100 ",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["m12"],
			'INFO'=>"",
		));
	
		

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$srModel_sflow = SrSflow::page_displayButton(array(
			"sflow_is_add_form"=>"0",
			"sflow_current_form"=>"ff",
			"sflow_code"=>"pmt_employee_assign",
			"sflow_business_id"=>$this->srModel["id"],
			"sflow_business_num"=>$this->srModel["code"],
			"sflow_from_status"=>$this->srModel["status"],
			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
			"sflow_return_url"=>__SELF__,
			"sflow_request_params"=>array(
			"id"=>$spModel["id"],
			"pageType"=>$spModel["pageType"],
			),
		));		
		$this->hidden_html = $srModel_sflow["divHtml"];
		$items["items_line"] = $srModel_sflow["buttonArrays"];

		$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>__URL__."/editEmployeeAssignPage?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
/*
	
		$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'delete',
				'control_value'=>__URL__."/deleteTask?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.delete',
			);	

Sflow(flow_name,button_name,page_submit_type,page_submit_js):
修改资源分配单	page.button.update	030	__APP__/EmployeeAssign/editEmployeeAssignPage?id={1}
新增子资源分配单	page.button.addchild	030	__APP__/EmployeeAssign/editEmployeeAssignPage?={1}
删除资源分配单	page.button.delete	030	__APP__/EmployeeAssign/deleteEmployeeAssign?id={1}
*/

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);										
		$this->addItems($items);		
 		
 

		
		self::addInfoResults($srModel,null);
		return $srModel;		
	}	
}
 
?>