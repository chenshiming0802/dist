<?php
class AppModule2ContentView extends SrView{	

}
?>
