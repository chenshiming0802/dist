<?php

class TaskTsheetView extends SrView{
	private $tv_project_id;
	private $tv_module_id;
	private $tv_task_id;
	private $tv_task_status;
	private $tv_time_type;
	private $tv_status;
	private $tv_belong_user_id;

	public function __construct(){
		$this->tv_project_id = "1;;;pmt_project;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_project t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";
		$this->tv_module_id = "1;;;pmt_module;name;SELECT t.id _valueCode_,t.name _valueName_,t.project_id _parentObjectCode_ FROM pmt_module t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId().";project_id";
		$this->tv_task_id = "1;;;pmt_task;name;SELECT t.id _valueCode_,t.name _valueName_,t.id _childCode_,t.parent_task_id _parentCode_,t.id _childSortNo_,t.module_id _parentObjectCode_,(CASE WHEN t.spr_tree_type='020' OR t.work_calc_type='020'  THEN '0' ELSE '1' END)  _isOptGroup_ FROM pmt_task t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId().";module_id";
 		$this->tv_time_type = "1;;PMT07";
		$this->tv_status = "1;;PMT09";
		$this->tv_belong_user_id = "1;;;uup_user;name;SELECT t.id _valueCode_,t.name _valueName_ FROM uup_user t WHERE is_deleted='0' and org_id=".SrUser::getOrgId()."";
		$this->tv_task_status = "1;;PMT04";
	}

public function queryTaskTsheet($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
//		$this->addItem(array(
//			'div_id'=>'div_search','div_label'=>'pmt_task_tsheet.project_id','item_line_type'=>'','item_viewauth'=>'',
//			'control_type'=>'SELECT_SQL','control_name'=>'query_project_id',
//			'control_value'=>$this->tv_project_id,
//			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
//			'value_input'=>$this->spModel['query_project_id'],
//			'INFO'=>"TYPE=open&URL=__APP__/Project/viewProjectPage%3Fid=[project_id]",
//		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_task_tsheet.occure_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'query_occure_date',
			'control_value'=>$this->tv_occure_date,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_occure_date'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_task_tsheet.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'query_status',
			'control_value'=>$this->tv_status,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_status'],
			'INFO'=>"",
		));

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'insert',
				'control_value'=>__URL__."/editTaskTsheetPage",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.insert',
			);


		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'viewTimeSheetWeek',
				'control_value'=>__URL__."/managerTaskTsheetPage",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.viewTimeSheetWeek',
			);

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'fillQucikTsheet',
				'control_value'=>__URL__."/managerTaskTsheetPage",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.fillQucikTsheet',
			);


		$this->addItems($items);

		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'view',
				'control_value'=>__URL__."/viewTaskTsheetPage?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.view',
			);

		$list = &$this->srModel['list'];
		foreach($list as $key=>$model){
			if(in_array($model['status'],array('020')) && $model['project_manager_id']==SrUser::getUserId()){
				$list[$key]['can_audit'] = 0;
			}else{
				$list[$key]['can_audit'] = 1;
			}
		}

		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
				"label.select"=>array(
					'control_type'=>'CHECKBOX','control_name'=>'id[]',
					'control_value'=>'[id]',
					'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'can_audit',
					'value_input'=>'',
				),
					'pmt_task_tsheet.belong_user_id'=>array(
					'control_type'=>'LABEL_SQL','control_name'=>'belong_user_id',
					'control_value'=>$this->tv_belong_user_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'belong_user_id',
					'INFO'=>"TYPE=open&URL=__APP__/Employee/viewEmployeePage?user_id=[belong_user_id]",
					'div_label'=>'',
				),
					'pmt_task_tsheet.hours'=>array(
					'control_type'=>'LABEL','control_name'=>'hours',
					'control_value'=>$this->tv_hours,
					'control_class'=>"required validate-numbe max-value-100",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'hours',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task_tsheet.ext_hours'=>array(
					'control_type'=>'LABEL','control_name'=>'ext_hours',
					'control_value'=>$this->tv_ext_hours,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'ext_hours',
					'INFO'=>"",
					'div_label'=>'',
				),
//				'pmt_task_tsheet.project_id'=>array(
//					'control_type'=>'SELECT_SQL','control_name'=>'project_id',
//					'control_value'=>$this->tv_project_id,
//					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//					'value_input'=>'project_id',
//					'INFO'=>"TYPE=open&URL=__APP__/Project/viewProjectPage%3Fid=[project_id]",
//					'div_label'=>'',
//				),
					'pmt_task_tsheet.module_id'=>array(
					'control_type'=>'LABEL_SQL','control_name'=>'module_id',
					'control_value'=>$this->tv_module_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'module_id',
					'INFO'=>"TYPE=open&URL=__APP__/Module/viewModulePage?id=[module_id]",
					'div_label'=>'',
				),
					'pmt_task_tsheet.task_id'=>array(
					'control_type'=>'LABEL_SQL','control_name'=>'task_id',
					'control_value'=>$this->tv_task_id,
					'control_class'=>"required",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'task_id',
					'INFO'=>"TYPE=open&URL=__APP__/Task/viewTaskPage?id=[task_id]",
					'div_label'=>'',
				),
					'pmt_task.status'=>array(
					'control_type'=>'LABEL_DICT','control_name'=>'task_status',
					'control_value'=>$this->tv_task_status,
					'control_class'=>"required",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'task_status',
					'div_label'=>'',
				),
					'pmt_task_tsheet.occure_date'=>array(
					'control_type'=>'LABEL','control_name'=>'occure_date',
					'control_value'=>$this->tv_occure_date,
					'control_class'=>"required",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'occure_date',
					'INFO'=>"",
					'div_label'=>'',
				),

					'pmt_task_tsheet.status'=>array(
					'control_type'=>'LABEL_DICT','control_name'=>'status[]',
					'control_value'=>$this->tv_status,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'status',
					'INFO'=>"",
					'div_label'=>'',
				),


				'operate'=>$buttons,
			),
			'grid_label_param'=>array(
				"label.select"=>array(
					'control_type'=>'CHECKBOX','control_name'=>'ids',
					'control_value'=>'',
					'control_class'=>'','control_param'=>"onClick=\"a_checkAll(this,'id[]')\"",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'',
				),
			),
		));

		$items = array('div_id'=>'div_grid_b','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'audit',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.audit',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'reject',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.reject',
			);
		$this->addItems($items);



		self::addInfoResults($srModel,null);
		return $srModel;
	}




public function editTaskTsheetPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/editTaskTsheet",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.project_id','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["project_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.module_id','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL_2','control_name'=>'module_id',
			'control_value'=>$this->tv_module_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["module_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.task_id','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL_2','control_name'=>'task_id',
			'control_value'=>$this->tv_task_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["task_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.occure_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'occure_date',
			'control_value'=>$this->tv_occure_date,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["occure_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.hours','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'hours',
			'control_value'=>$this->tv_hours,
			'control_class'=>"required validate-numbe max-value-100 ",'control_param'=>"  size='4'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["hours"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.ext_hours','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'ext_hours',
			'control_value'=>$this->tv_ext_hours,
			'control_class'=>"validate-numbe max-value-100 ",'control_param'=>"  size='4'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["ext_hours"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_DICT','control_name'=>'status',
			'control_value'=>$this->tv_status,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["status"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.memo','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'memo',
			'control_value'=>$this->tv_memo,
			'control_class'=>" ",'control_param'=>"ROWS=10 COLS=100  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["memo"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.belong_user_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_SQL','control_name'=>'belong_user_id',
			'control_value'=>$this->tv_belong_user_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["belong_user_id"],
		));



		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$status = $this->srModel['status'];
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'save',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>($status==null||$status=='010')?'0':'1',
				'value_input'=>'page.button.save',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'submitb',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>($status==null||$status=='010')?'0':'1',
				'value_input'=>'page.button.submit',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>($status==null||$status=='010')?'1':'0',
				'value_input'=>'page.button.update',
			);
					$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);


if($id==null || $id==''){
if($_GET['task_id']!=null && $_GET['task_id']!=''){
	$this->setControlProperty("div_search_v","project_id","control_readonly","1");
	$this->setControlProperty("div_search_v","module_id","control_readonly","1");
	$this->setControlProperty("div_search_v","task_id","control_readonly","1");
}

}else{


}


		self::addInfoResults($srModel,null);
		return $srModel;
	}
	public function viewTaskTsheetPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewTaskTsheetPage",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.project_id','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["project_id"],
			'INFO'=>"TYPE=open&URL=__APP__/Project/viewProjectPage%3Fid=[project_id]",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.module_id','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL_2','control_name'=>'module_id',
			'control_value'=>$this->tv_module_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["module_id"],
			'INFO'=>"TYPE=open&URL=__APP__/Module/viewModulePage?id=[module_id]",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.task_id','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL_2','control_name'=>'task_id',
			'control_value'=>$this->tv_task_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["task_id"],
			'INFO'=>"TYPE=open&URL=__APP__/Task/viewTaskPage?id=[task_id]",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.occure_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'occure_date',
			'control_value'=>$this->tv_occure_date,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["occure_date"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.hours','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'hours',
			'control_value'=>$this->tv_hours,
			'control_class'=>"required validate-numbe max-value-100 ",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["hours"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.ext_hours','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'ext_hours',
			'control_value'=>$this->tv_ext_hours,
			'control_class'=>"validate-numbe max-value-100 ",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["ext_hours"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_DICT','control_name'=>'status',
			'control_value'=>$this->tv_status,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["status"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.memo','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'memo',
			'control_value'=>$this->tv_memo,
			'control_class'=>" ",'control_param'=>"ROWS=10 COLS=100  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["memo"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task_tsheet.belong_user_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_SQL','control_name'=>'belong_user_id',
			'control_value'=>$this->tv_belong_user_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["belong_user_id"],
			'INFO'=>"TYPE=open&URL=__APP__/Employee/viewEmployeePage?user_id=".$this->srModel["belong_user_id"]."",
		));



		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$srModel_sflow = SrSflow::page_displayButton(array(
			"sflow_is_add_form"=>"0",
			"sflow_current_form"=>"ff",
			"sflow_code"=>"pmt_task_tsheet",
			"sflow_business_id"=>$this->srModel["id"],
			"sflow_business_num"=>$this->srModel["code"],
			"sflow_from_status"=>$this->srModel["status"],
			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
			"sflow_return_url"=>__SELF__,
			"sflow_request_params"=>array(
			"id"=>$spModel["id"],
			"pageType"=>$spModel["pageType"],
			),
		));
		$this->hidden_html = $srModel_sflow["divHtml"];
		$items["items_line"] = $srModel_sflow["buttonArrays"];
/*
		$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>__URL__."/editTaskTsheetPage?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);

		$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'delete',
				'control_value'=>__URL__."/deleteTask?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.delete',
			);

Sflow(flow_name,button_name,page_submit_type,page_submit_js):
修改工时填报	page.button.update	030	__APP__/TaskTsheet/editTaskTsheetPage?id={1}
新增子工时填报	page.button.addchild	030	__APP__/TaskTsheet/editTaskTsheetPage?={1}
删除工时填报	page.button.delete	030	__APP__/TaskTsheet/deleteTaskTsheet?id={1}
*/

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);




		self::addInfoResults($srModel,null);
		return $srModel;
	}
}

?>