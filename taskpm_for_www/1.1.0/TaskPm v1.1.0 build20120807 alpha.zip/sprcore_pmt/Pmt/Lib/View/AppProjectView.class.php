<?php
class AppProjectView extends SrView{	
	public function viewProjectIframePage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewProjectPage",
			"target"=>"_self",
			"onSubmit"=>"",
		);	
		//$this->srModel['id']?"1":"0"
 
 		$this->addItem(array(
			'div_id'=>'div_blank','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'IFRAME','control_name'=>'',
			'control_value'=>'',
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
			'value_input'=>$this->spModel['iframe_src'],
			'INFO'=>"",
		));				

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$srModel_sflow = SrSflow::page_displayButton(array(
			"sflow_is_add_form"=>"0",
			"sflow_current_form"=>"ff",
			"sflow_code"=>"pmt_Project",
			"sflow_business_id"=>$this->srModel["id"],
			"sflow_business_num"=>$this->srModel["code"],
			"sflow_from_status"=>$this->srModel["status"],
			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
			"sflow_return_url"=>__SELF__,
			"sflow_request_params"=>array(
			"id"=>$spModel["id"],
			"pageType"=>$spModel["pageType"],
			),
		));		
		$this->hidden_html = $srModel_sflow["divHtml"];
		$items["items_line"] = $srModel_sflow["buttonArrays"];
 

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);										
		$this->addItems($items);		
 		
 

		
		self::addInfoResults($srModel,null);
		return $srModel;		
	}	
}
?>
