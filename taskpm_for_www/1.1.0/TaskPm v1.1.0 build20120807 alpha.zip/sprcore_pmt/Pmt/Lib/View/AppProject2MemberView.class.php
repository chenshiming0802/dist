<?php
class AppProject2MemberView extends SrView{	

}
?>
