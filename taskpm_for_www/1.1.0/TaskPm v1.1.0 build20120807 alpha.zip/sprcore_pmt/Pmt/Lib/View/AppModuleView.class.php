<?php
class AppModuleView extends SrView{
	private $tv_project_id;
	private $tv_module_type_id;
	private $tv_status;
	private $tv_proirity;
	private $tv_manager_id;
//	private $tv_depend_module_id;

	public function __construct(){
		$this->tv_project_id = "1;;;pmt_project;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_project t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";
		$this->tv_module_type_id = "1;;;pmt_module_type;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_module_type t WHERE is_deleted='0' ";
		$this->tv_status = "1;;PMT03";
		$this->tv_proirity = "1;;PMT06";
		$this->tv_manager_id = "1;;;uup_user;name;SELECT distinct t.id _valueCode_,t.name _valueName_ FROM uup_user t,pmt_project_member t2 WHERE t2.user_id=t.id and org_id=".SrUser::getOrgId()." /*w[t,t2]*/";
//		$this->tv_depend_module_id = "1;;;pmt_module;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_module t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";

	}
	public function queryModuleMillstoneCycle($spModel){

		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/queryModuleMillstoneCycle",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'label.grid_display_fields','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'CHECKBOX_DICT','control_name'=>'grid_display_fields[]',
			'control_value'=>"1;;PMT13",
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['grid_display_fields'],
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'label.grid_display_milestone','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'grid_display_milestone',
			'control_value'=>"1;;SYS01",
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['grid_display_milestone'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'query_status',
			'control_value'=>$this->tv_status,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_status'],
			'INFO'=>"",
		));
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$this->addItems($items);
		//GRID
		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['details_page'],
			'grid_param'=>array(
//				"pmt_project.name"=>array(
//						'control_type'=>'LABEL_SQL','control_name'=>'project_id[]',
//						'control_value'=>"1;;;pmt_project;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_project t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."",
//						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//						'value_input'=>'project_id',
//					),
				"pmt_module.name"=>array(
						'control_type'=>'LABEL_SQL','control_name'=>'module_id[]',
						'control_value'=>"1;;;pmt_module;name;SELECT t.id _valueCode_,t.name _valueName_,t.project_id _parentCode_ FROM pmt_module t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId().";project_id",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'module_id',
					),
				"pmt_module_type.type"=>array(
						'control_type'=>'LABEL','control_name'=>'ms_name[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'ms_name',
					),

				"pmt_module.adv_begin_date"=>array(
						'control_type'=>'LABEL','control_name'=>'moduleinfo_adv_begin_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'moduleinfo_adv_begin_date',
						'div_label'=>'pmt_progress.adv_begin_date',
					),
				"pmt_module.tsh_begin_date"=>array(
						'control_type'=>'LABEL','control_name'=>'moduleinfo_tsh_begin_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'moduleinfo_tsh_begin_date',
						'div_label'=>'pmt_progress.tsh_begin_date',
					),
//				"pmt_module.act_begin_date"=>array(
//						'control_type'=>'LABEL','control_name'=>'moduleinfo_act_begin_date[]',
//						'control_value'=>"",
//						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//						'value_input'=>'moduleinfo_act_begin_date',
//						'div_label'=>'pmt_progress.act_begin_date',
//					),
				"pmt_module.adv_end_date"=>array(
						'control_type'=>'LABEL','control_name'=>'moduleinfo_adv_end_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'moduleinfo_adv_end_date',
						'div_label'=>'pmt_progress.adv_end_date',
					),
				"pmt_module.tsh_end_date"=>array(
						'control_type'=>'LABEL','control_name'=>'moduleinfo_tsh_end_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'moduleinfo_tsh_end_date',
						'div_label'=>'pmt_progress.tsh_end_date',
					),
//				"pmt_module.act_end_date"=>array(
//						'control_type'=>'LABEL','control_name'=>'moduleinfo_act_end_date[]',
//						'control_value'=>"",
//						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//						'value_input'=>'moduleinfo_act_end_date',
//						'div_label'=>'pmt_progress.act_end_date',
//					),
				"pmt_module.adv_progress"=>array(
						'control_type'=>'LABEL','control_name'=>'moduleinfo_adv_progress[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'moduleinfo_adv_progress',
						'div_label'=>'pmt_module.adv_progress',
					),
				"pmt_module.tsh_progress"=>array(
						'control_type'=>'LABEL','control_name'=>'moduleinfo_tsh_progress[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'moduleinfo_tsh_progress',
						'div_label'=>'pmt_module.tsh_progress',
					),
				"pmt_module.act_progress"=>array(
						'control_type'=>'LABEL','control_name'=>'moduleinfo_act_progress[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'moduleinfo_act_progress',
						'div_label'=>'pmt_module.act_progress',
					),
				"pmt_module.adv_person_day"=>array(
						'control_type'=>'LABEL','control_name'=>'moduleinfo_adv_person_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'moduleinfo_adv_person_day',
						'div_label'=>'pmt_progress.adv_person_day',
					),
//				"pmt_module.act_person_day"=>array(
//						'control_type'=>'LABEL','control_name'=>'moduleinfo_act_person_day[]',
//						'control_value'=>"",
//						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//						'value_input'=>'moduleinfo_act_person_day',
//						'div_label'=>'pmt_progress.act_person_day',
//					),
				"pmt_module.tsh_person_day"=>array(
						'control_type'=>'LABEL','control_name'=>'moduleinfo_tsh_person_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'moduleinfo_tsh_person_day',
						'div_label'=>'pmt_progress.tsh_person_day',
					),
				"pmt_module.tsh_person_over_day"=>array(
						'control_type'=>'LABEL','control_name'=>'moduleinfo_tsh_person_over_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'moduleinfo_tsh_person_over_day',
						'div_label'=>'pmt_progress.tsh_person_over_day',
					),
				"pmt_module.adv_work_day"=>array(
						'control_type'=>'LABEL','control_name'=>'moduleinfo_adv_work_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'moduleinfo_adv_work_day',
						'div_label'=>'pmt_progress.adv_work_day',
					),
				"pmt_module.tsh_work_day"=>array(
						'control_type'=>'LABEL','control_name'=>'moduleinfo_tsh_work_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'moduleinfo_tsh_work_day',
						'div_label'=>'pmt_progress.tsh_work_day',
					),
//				"pmt_module.act_work_day"=>array(
//						'control_type'=>'LABEL','control_name'=>'moduleinfo_act_work_day[]',
//						'control_value'=>"",
//						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//						'value_input'=>'moduleinfo_act_work_day',
//						'div_label'=>'pmt_progress.act_work_day',
//					),

				"pmt_progress.adv_begin_date"=>array(
						'control_type'=>'LABEL','control_name'=>'adv_begin_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_begin_date',
						'div_label'=>'pmt_progress.adv_begin_date',
					),
				"pmt_progress.tsh_begin_date"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_begin_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_begin_date',
						'div_label'=>'pmt_progress.tsh_begin_date',
					),
//				"pmt_progress.act_begin_date"=>array(
//						'control_type'=>'LABEL','control_name'=>'act_begin_date[]',
//						'control_value'=>"",
//						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//						'value_input'=>'act_begin_date',
//						'div_label'=>'pmt_progress.act_begin_date',
//					),

				"pmt_progress.adv_end_date"=>array(
						'control_type'=>'LABEL','control_name'=>'adv_end_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_end_date',
						'div_label'=>'pmt_progress.adv_end_date',
					),
				"pmt_progress.tsh_end_date"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_end_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_end_date',
						'div_label'=>'pmt_progress.tsh_end_date',
					),
//				"pmt_progress.act_end_date"=>array(
//						'control_type'=>'LABEL','control_name'=>'act_end_date[]',
//						'control_value'=>"",
//						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//						'value_input'=>'act_end_date',
//						'div_label'=>'pmt_progress.act_end_date',
//					),

				"pmt_progress.adv_work_day"=>array(
						'control_type'=>'LABEL','control_name'=>'adv_work_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_work_day',
						'div_label'=>'pmt_progress.adv_work_day',
					),
				"pmt_progress.tsh_work_day"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_work_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_work_day',
						'div_label'=>'pmt_progress.tsh_work_day',
					),
//				"pmt_progress.act_work_day"=>array(
//						'control_type'=>'LABEL','control_name'=>'act_work_day[]',
//						'control_value'=>"",
//						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//						'value_input'=>'act_work_day',
//						'div_label'=>'pmt_progress.act_work_day',
//					),

				"pmt_progress.adv_person_day"=>array(
						'control_type'=>'LABEL','control_name'=>'adv_person_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_person_day',
						'div_label'=>'pmt_progress.adv_person_day',
					),
				"pmt_progress.tsh_person_day"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_person_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_person_day',
						'div_label'=>'pmt_progress.tsh_person_day',
					),
//				"pmt_progress.act_person_day"=>array(
//						'control_type'=>'LABEL','control_name'=>'act_person_day[]',
//						'control_value'=>"",
//						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//						'value_input'=>'act_person_day',
//						'div_label'=>'pmt_progress.act_person_day',
//					),
				"pmt_progress.tsh_person_over_day"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_person_over_day[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_person_over_day',
						'div_label'=>'pmt_progress.tsh_person_over_day',
					),

				"pmt_progress.adv_progress"=>array(
						'control_type'=>'LABEL','control_name'=>'adv_progress[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_progress',
						'div_label'=>'pmt_progress.adv_progress',
					),
				"pmt_progress.tsh_progress"=>array(
						'control_type'=>'LABEL','control_name'=>'tsh_progress[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsh_progress',
						'div_label'=>'pmt_progress.tsh_progress',
					),
				"pmt_progress.act_progress"=>array(
						'control_type'=>'LABEL','control_name'=>'act_progress[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'act_progress',
						'div_label'=>'pmt_progress.act_progress',
					),
				),
		));
		//'div_label'=>'pmt_progress.act_progress',
		$this->bindGridFields("div_results","grid","grid_display_fields[]",array(
			"010"=>array(
				"pmt_module.adv_begin_date",
				"pmt_module.tsh_begin_date",
//				"pmt_module.act_begin_date",
				"pmt_module.adv_end_date",
				"pmt_module.tsh_end_date",
//				"pmt_module.act_end_date",
				"pmt_progress.adv_begin_date",
				"pmt_progress.tsh_begin_date",
//				"pmt_progress.act_begin_date",
				"pmt_progress.adv_end_date",
				"pmt_progress.tsh_end_date",
//				"pmt_progress.act_end_date",
				),
			"020"=>array(
				"pmt_module.act_progress",
				"pmt_module.adv_progress",
				"pmt_module.tsh_progress",
				"pmt_progress.adv_progress",
				"pmt_progress.tsh_progress",
				"pmt_progress.act_progress",
				),
			"030"=>array(
				"pmt_module.adv_person_day",
				//"pmt_module.act_person_day",
				"pmt_module.tsh_person_day",
				"pmt_module.tsh_person_over_day",
				"pmt_progress.adv_person_day",
				//"pmt_progress.act_person_day",
				"pmt_progress.tsh_person_day",
				"pmt_progress.tsh_person_over_day",
				),
			"040"=>array(
				"pmt_module.adv_work_day",
				"pmt_module.tsh_work_day",
				//"pmt_module.act_work_day",
				"pmt_progress.adv_work_day",
				"pmt_progress.tsh_work_day",
				//"pmt_progress.act_work_day",
				)
		));

		$this->gridConvertXToY('div_results','grid',array(
			'x_dims'=>array('project_id[]','module_id[]',
				'moduleinfo_adv_begin_date[]',
				'moduleinfo_tsh_begin_date[]',
				'moduleinfo_act_begin_date[]',
				'moduleinfo_adv_end_date[]',
				'moduleinfo_tsh_end_date[]',
				'moduleinfo_act_end_date[]',
				'moduleinfo_act_progress[]',
				'moduleinfo_adv_progress[]',
				'moduleinfo_tsh_progress[]',
				'moduleinfo_adv_person_day[]',
				//'moduleinfo_act_person_day[]',
				'moduleinfo_tsh_person_day[]',
				'moduleinfo_tsh_person_over_day[]',
				'moduleinfo_adv_work_day[]',
				'moduleinfo_tsh_work_day[]',
				//'moduleinfo_act_work_day[]',
				),
			'y_dim'=>'ms_name[]',
			'y_dim_value'=>$this->srModel['pmt_module_type_list'],
			'is_display'=>$this->spModel['grid_display_milestone'],
		));


		self::addInfoResults($srModel,null);
		return $srModel;
	}

//	public function viewModuleIframePage($spModel){
//		$id = $this->srModel['id'];
//		$srModel = array();
//
//		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
//		$this->form = array(
//			"name"=>"ff",
//			"method"=>"post",
//			"action"=>__URL__."/viewModulePage",
//			"target"=>"_self",
//			"onSubmit"=>"",
//		);
//		//$this->srModel['id']?"1":"0"
//
// 		$this->addItem(array(
//			'div_id'=>'div_blank','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
//			'control_type'=>'IFRAME','control_name'=>'',
//			'control_value'=>'',
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
//			'value_input'=>$this->spModel['iframe_src'],
//			'INFO'=>"",
//		));
//
//		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
//		$srModel_sflow = SrSflow::page_displayButton(array(
//			"sflow_is_add_form"=>"0",
//			"sflow_current_form"=>"ff",
//			"sflow_code"=>"pmt_module",
//			"sflow_business_id"=>$this->srModel["id"],
//			"sflow_business_num"=>$this->srModel["code"],
//			"sflow_from_status"=>$this->srModel["status"],
//			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
//			"sflow_return_url"=>__SELF__,
//			"sflow_request_params"=>array(
//			"id"=>$spModel["id"],
//			"pageType"=>$spModel["pageType"],
//			),
//		));
//		$this->hidden_html = $srModel_sflow["divHtml"];
//		$items["items_line"] = $srModel_sflow["buttonArrays"];
//
//
//		$items["items_line"][] = array(
//				'control_type'=>'BUTTON','control_name'=>'close',
//				'control_value'=>"",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.close',
//			);
//		$this->addItems($items);
//
//
//
//
//		self::addInfoResults($srModel,null);
//		return $srModel;
//	}
//	public function viewModuleIframe2Page($spModel){
//		$id = $this->srModel['id'];
//		$srModel = array();
//
//		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
//		$this->form = array(
//			"name"=>"ff",
//			"method"=>"post",
//			"action"=>__URL__."/viewModulePage",
//			"target"=>"_self",
//			"onSubmit"=>"",
//		);
//		//$this->srModel['id']?"1":"0"
//
// 		$this->addItem(array(
//			'div_id'=>'div_blank','div_label'=>'','item_line_type'=>'left_iframe','item_viewauth'=>'',
//			'control_type'=>'IFRAME','control_name'=>'left_iframe',
//			'control_value'=>'',
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
//			'value_input'=>$this->spModel['iframe_left'],
//			'INFO'=>"",
//		));
// 		$this->addItem(array(
//			'div_id'=>'div_blank','div_label'=>'','item_line_type'=>'right_iframe','item_viewauth'=>'',
//			'control_type'=>'IFRAME','control_name'=>'right_iframe',
//			'control_value'=>'',
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
//			'value_input'=>$this->spModel['iframe_src'],
//			'INFO'=>"",
//		));
//
//		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
//		$srModel_sflow = SrSflow::page_displayButton(array(
//			"sflow_is_add_form"=>"0",
//			"sflow_current_form"=>"ff",
//			"sflow_code"=>"pmt_module",
//			"sflow_business_id"=>$this->srModel["id"],
//			"sflow_business_num"=>$this->srModel["code"],
//			"sflow_from_status"=>$this->srModel["status"],
//			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
//			"sflow_return_url"=>__SELF__,
//			"sflow_request_params"=>array(
//			"id"=>$spModel["id"],
//			"pageType"=>$spModel["pageType"],
//			),
//		));
//		$this->hidden_html = $srModel_sflow["divHtml"];
//		$items["items_line"] = $srModel_sflow["buttonArrays"];
//
//
//		$items["items_line"][] = array(
//				'control_type'=>'BUTTON','control_name'=>'close',
//				'control_value'=>"",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.close',
//			);
//		$this->addItems($items);
//
//
//
//
//		self::addInfoResults($srModel,null);
//		return $srModel;
//	}


}
?>
