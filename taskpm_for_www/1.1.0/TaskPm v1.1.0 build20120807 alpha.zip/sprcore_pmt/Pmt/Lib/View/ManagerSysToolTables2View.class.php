<?php

class ManagerSysToolTables2View extends SrView{
	private $tv_table_has_status; 
	private $tv_child_type; 
	private $tv_is_tree; 
	private $tv_field_type; 
	private $tv_has_query_clause; 
	private $tv_has_query_result; 

	public function __construct(){
		$this->tv_table_has_status = "1;;SYS01"; 
		$this->tv_child_type = "1;;SYS05"; 
		$this->tv_is_tree = "1;;SYS01"; 
		$this->tv_field_type = "1;;SYS04"; 
		$this->tv_has_query_clause = "1;;SYS10"; 
		$this->tv_has_query_result = "1;;SYS09"; 
	
	}

public function querySysToolTables2($spModel){
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);
		
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
 
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(		
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'insert',
				'control_value'=>__URL__."/editSysToolTables2Page",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.insert',
			);	

	
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'manager',
				'control_value'=>__URL__."/managerSysToolTables2Page",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.insert',
			);


		$this->addItems($items);	

		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'view',
				'control_value'=>__URL__."/viewSysToolTables2Page?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.view',
			);

		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
				'sys_tool_table2.table_name'=>array(
					'control_type'=>'TEXT','control_name'=>'table_name',
					'control_value'=>$this->tv_table_name,
					'control_class'=>"required",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'table_name',
					'div_label'=>'',
				),			
					'sys_tool_table2.code_module'=>array(
					'control_type'=>'TEXT','control_name'=>'code_module',
					'control_value'=>$this->tv_code_module,
					'control_class'=>"required",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'code_module',
					'div_label'=>'',
				),			
					'sys_tool_table2.table_has_status'=>array(
					'control_type'=>'SELECT_DICT','control_name'=>'table_has_status',
					'control_value'=>$this->tv_table_has_status,
					'control_class'=>"required",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'table_has_status',
					'div_label'=>'',
				),			
					'sys_tool_table2.table_status_field'=>array(
					'control_type'=>'TEXT','control_name'=>'table_status_field',
					'control_value'=>$this->tv_table_status_field,
					'control_class'=>"",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'table_status_field',
					'div_label'=>'',
				),			
					'sys_tool_table2.is_tree'=>array(
					'control_type'=>'SELECT_DICT','control_name'=>'is_tree',
					'control_value'=>$this->tv_is_tree,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'is_tree',
					'div_label'=>'',
				),			
	
				'operate'=>$buttons,
			),			
		));
		

		

		self::addInfoResults($srModel,null);
		return $srModel;
	}

	
	public function managerSysToolTables2Page($spModel){
		$id = $this->srModel['id'];
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.'.title',array('displayDiv'=>'false'));
		$this->form = array(
			'name'=>'ff',
			'method'=>'post',
			'action'=>__URL__."/managerSysToolTables2",
			'target'=>'_self',
			'onSubmit'=>'',
		);	
		//$this->srModel['id']?'1':'0'
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.'.title','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>'',
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));		
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'table_name',
			'control_value'=>$this->tv_table_name,
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_desc','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'table_desc',
			'control_value'=>$this->tv_table_desc,
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_desc"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.code_module','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'code_module',
			'control_value'=>$this->tv_code_module,
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["code_module"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.code_module_method','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'code_module_method',
			'control_value'=>$this->tv_code_module_method,
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["code_module_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_has_status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'table_has_status',
			'control_value'=>$this->tv_table_has_status,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_has_status"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_status_field','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'table_status_field',
			'control_value'=>$this->tv_table_status_field,
			'control_class'=>" ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_status_field"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_status_save','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'table_status_save',
			'control_value'=>$this->tv_table_status_save,
			'control_class'=>" ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_status_save"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_status_submit','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'table_status_submit',
			'control_value'=>$this->tv_table_status_submit,
			'control_class'=>" ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_status_submit"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.child_type','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'child_type',
			'control_value'=>$this->tv_child_type,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["child_type"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.child_type_value','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'child_type_value',
			'control_value'=>$this->tv_child_type_value,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["child_type_value"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.is_tree','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'is_tree',
			'control_value'=>$this->tv_is_tree,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["is_tree"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.tree_parent_field','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'tree_parent_field',
			'control_value'=>$this->tv_tree_parent_field,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["tree_parent_field"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_info','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'table_info',
			'control_value'=>$this->tv_table_info,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_info"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.query_sql_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'query_sql_method',
			'control_value'=>$this->tv_query_sql_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["query_sql_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_query_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_query_method',
			'control_value'=>$this->tv_before_query_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_query_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_update_page_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_update_page_method',
			'control_value'=>$this->tv_before_update_page_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_update_page_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_add_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_add_method',
			'control_value'=>$this->tv_before_add_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_add_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_update_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_update_method',
			'control_value'=>$this->tv_before_update_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_update_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_delete_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_delete_method',
			'control_value'=>$this->tv_before_delete_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_delete_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_get_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_get_method',
			'control_value'=>$this->tv_before_get_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_get_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_query_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_query_method',
			'control_value'=>$this->tv_after_query_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_query_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_update_page_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_update_page_method',
			'control_value'=>$this->tv_after_update_page_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_update_page_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_update_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_update_method',
			'control_value'=>$this->tv_after_update_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_update_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_delete_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_delete_method',
			'control_value'=>$this->tv_after_delete_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_delete_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_get_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_get_method',
			'control_value'=>$this->tv_after_get_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_get_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_query_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_query_method',
			'control_value'=>$this->tv_after_db_query_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=100  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_query_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_add_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_add_method',
			'control_value'=>$this->tv_after_db_add_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_add_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_update_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_update_method',
			'control_value'=>$this->tv_after_db_update_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_update_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_au_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_au_method',
			'control_value'=>$this->tv_after_db_au_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_au_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_delete_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_delete_method',
			'control_value'=>$this->tv_after_db_delete_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_delete_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_get_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_get_method',
			'control_value'=>$this->tv_after_db_get_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_get_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_db_add_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_db_add_method',
			'control_value'=>$this->tv_before_db_add_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_db_add_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_db_update_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_db_update_method',
			'control_value'=>$this->tv_before_db_update_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_db_update_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_db_au_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_db_au_method',
			'control_value'=>$this->tv_before_db_au_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_db_au_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_db_delete_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_db_delete_method',
			'control_value'=>$this->tv_before_db_delete_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_db_delete_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_db_get_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_db_get_method',
			'control_value'=>$this->tv_before_db_get_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_db_get_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_view_query_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_view_query_method',
			'control_value'=>$this->tv_after_view_query_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_view_query_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_view_add_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_view_add_method',
			'control_value'=>$this->tv_after_view_add_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_view_add_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_view_update_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_view_update_method',
			'control_value'=>$this->tv_after_view_update_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_view_update_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_view_get_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_view_get_method',
			'control_value'=>$this->tv_after_view_get_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_view_get_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.add_default_value_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'add_default_value_method',
			'control_value'=>$this->tv_add_default_value_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["add_default_value_method"],
		));
	

		//DETAIL BUTTON
		$items = array('div_id'=>'div_search_v','div_label'=>'sys_tool_table_field2','item_line_type'=>'line','item_viewauth'=>'',);
		$items["items_line"] = array();

	
		$items["items_line"][] = array(			
				'control_type'=>'TEXT','control_name'=>'detail_add_count',
				'control_value'=>"",
				'control_class'=>"",'control_param'=>'size="2"','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'',
			);
		$items["items_line"][] = array(			
				'control_type'=>'BUTTON','control_name'=>'adddetail1',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.add.detail',
			);		
			
		$this->addItems($items);		
		//GRID
		$buttons = array();
		$buttons[] =array(
						'control_type'=>'BUTTON','control_name'=>'deletedetail',
						'control_value'=>"id",
						'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'page.button.delete',
					);
		$this->addGrid(array(
			'div_id'=>'div_search','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['details'],'grid_page'=>$this->srModel['details_page'],
			'grid_param'=>array(

				'sys_tool_table_field2.id'=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_id[]',
						'control_value'=>$this->tv_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'id',
						'div_label'=>'',
					),
				'sys_tool_table_field2.table_id'=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_table_id[]',
						'control_value'=>$this->tv_table_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'table_id',
						'div_label'=>'',
					),
				'sys_tool_table_field2.field_name'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_field_name[]',
						'control_value'=>$this->tv_field_name,
						'control_class'=>"required",'control_param'=>"  size='12'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'field_name',
						'div_label'=>'',
					),
				'sys_tool_table_field2.field_desc'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_field_desc[]',
						'control_value'=>$this->tv_field_desc,
						'control_class'=>"required",'control_param'=>"  size='10'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'field_desc',
						'div_label'=>'',
					),
				'sys_tool_table_field2.field_type'=>array(
						'control_type'=>'SELECT_DICT','control_name'=>'detail_field_type[]',
						'control_value'=>$this->tv_field_type,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'field_type',
						'div_label'=>'',
					),
				'sys_tool_table_field2.field_type_value'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_field_type_value[]',
						'control_value'=>$this->tv_field_type_value,
						'control_class'=>"",'control_param'=>"  size='8'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'field_type_value',
						'div_label'=>'',
					),
				'sys_tool_table_field2.field_type_desc_value'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_field_type_desc_value[]',
						'control_value'=>$this->tv_field_type_desc_value,
						'control_class'=>"",'control_param'=>"  size='6'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'field_type_desc_value',
						'div_label'=>'',
					),
				'sys_tool_table_field2.field_class'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_field_class[]',
						'control_value'=>$this->tv_field_class,
						'control_class'=>"",'control_param'=>"  size='6'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'field_class',
						'div_label'=>'',
					),
				'sys_tool_table_field2.size_display'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_size_display[]',
						'control_value'=>$this->tv_size_display,
						'control_class'=>"",'control_param'=>"  size='4'  maxlength='4'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'size_display',
						'div_label'=>'',
					),
				'sys_tool_table_field2.size_max'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_size_max[]',
						'control_value'=>$this->tv_size_max,
						'control_class'=>"",'control_param'=>"  size='4'  maxlength='4'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'size_max',
						'div_label'=>'',
					),
				'sys_tool_table_field2.item_line_class'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_item_line_class[]',
						'control_value'=>$this->tv_item_line_class,
						'control_class'=>"",'control_param'=>"  size='6'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'item_line_class',
						'div_label'=>'',
					),
				'sys_tool_table_field2.item_control_class'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_item_control_class[]',
						'control_value'=>$this->tv_item_control_class,
						'control_class'=>"",'control_param'=>"  size='6'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'item_control_class',
						'div_label'=>'',
					),
				'sys_tool_table_field2.has_query_clause'=>array(
						'control_type'=>'SELECT_DICT','control_name'=>'detail_has_query_clause[]',
						'control_value'=>$this->tv_has_query_clause,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'has_query_clause',
						'div_label'=>'',
					),
				'sys_tool_table_field2.has_query_result'=>array(
						'control_type'=>'SELECT_DICT','control_name'=>'detail_has_query_result[]',
						'control_value'=>$this->tv_has_query_result,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'has_query_result',
						'div_label'=>'',
					),
				'sys_tool_table_field2.field_no'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_field_no[]',
						'control_value'=>$this->tv_field_no,
						'control_class'=>"",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'field_no',
						'div_label'=>'',
					),
				'sys_tool_table_field2.item_control_param'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_item_control_param[]',
						'control_value'=>$this->tv_item_control_param,
						'control_class'=>"",'control_param'=>"  size='6'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'item_control_param',
						'div_label'=>'',
					),
				'sys_tool_table_field2.item_info'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_item_info[]',
						'control_value'=>$this->tv_item_info,
						'control_class'=>"",'control_param'=>"  size='5'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'item_info',
						'div_label'=>'',
					),
				"operate"=>$buttons,
			),			
		));		
	
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
					$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);										
		$this->addItems($items);
		

if($id==null || $id==''){
		

}else{
		

}


		
		self::addInfoResults($srModel,null);
		return $srModel;		
	}


public function editSysToolTables2Page($spModel){
		$id = $this->srModel['id'];
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/editSysToolTables2",
			"target"=>"_self",
			"onSubmit"=>"",
		);	
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));		
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'table_name',
			'control_value'=>$this->tv_table_name,
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_desc','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'table_desc',
			'control_value'=>$this->tv_table_desc,
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_desc"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.code_module','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'code_module',
			'control_value'=>$this->tv_code_module,
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["code_module"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.code_module_method','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'code_module_method',
			'control_value'=>$this->tv_code_module_method,
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["code_module_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_has_status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'table_has_status',
			'control_value'=>$this->tv_table_has_status,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_has_status"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_status_field','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'table_status_field',
			'control_value'=>$this->tv_table_status_field,
			'control_class'=>" ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_status_field"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_status_save','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'table_status_save',
			'control_value'=>$this->tv_table_status_save,
			'control_class'=>" ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_status_save"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_status_submit','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'table_status_submit',
			'control_value'=>$this->tv_table_status_submit,
			'control_class'=>" ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_status_submit"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.child_type','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'child_type',
			'control_value'=>$this->tv_child_type,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["child_type"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.child_type_value','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'child_type_value',
			'control_value'=>$this->tv_child_type_value,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["child_type_value"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.is_tree','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'is_tree',
			'control_value'=>$this->tv_is_tree,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["is_tree"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.tree_parent_field','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'tree_parent_field',
			'control_value'=>$this->tv_tree_parent_field,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["tree_parent_field"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_info','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'table_info',
			'control_value'=>$this->tv_table_info,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_info"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.query_sql_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'query_sql_method',
			'control_value'=>$this->tv_query_sql_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["query_sql_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_query_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_query_method',
			'control_value'=>$this->tv_before_query_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_query_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_update_page_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_update_page_method',
			'control_value'=>$this->tv_before_update_page_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_update_page_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_add_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_add_method',
			'control_value'=>$this->tv_before_add_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_add_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_update_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_update_method',
			'control_value'=>$this->tv_before_update_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_update_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_delete_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_delete_method',
			'control_value'=>$this->tv_before_delete_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_delete_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_get_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_get_method',
			'control_value'=>$this->tv_before_get_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_get_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_query_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_query_method',
			'control_value'=>$this->tv_after_query_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_query_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_update_page_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_update_page_method',
			'control_value'=>$this->tv_after_update_page_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_update_page_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_update_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_update_method',
			'control_value'=>$this->tv_after_update_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_update_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_delete_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_delete_method',
			'control_value'=>$this->tv_after_delete_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_delete_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_get_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_get_method',
			'control_value'=>$this->tv_after_get_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_get_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_query_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_query_method',
			'control_value'=>$this->tv_after_db_query_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=100  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_query_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_add_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_add_method',
			'control_value'=>$this->tv_after_db_add_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_add_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_update_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_update_method',
			'control_value'=>$this->tv_after_db_update_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_update_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_au_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_au_method',
			'control_value'=>$this->tv_after_db_au_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_au_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_delete_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_delete_method',
			'control_value'=>$this->tv_after_db_delete_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_delete_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_get_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_get_method',
			'control_value'=>$this->tv_after_db_get_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_get_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_db_add_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_db_add_method',
			'control_value'=>$this->tv_before_db_add_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_db_add_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_db_update_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_db_update_method',
			'control_value'=>$this->tv_before_db_update_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_db_update_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_db_au_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_db_au_method',
			'control_value'=>$this->tv_before_db_au_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_db_au_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_db_delete_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_db_delete_method',
			'control_value'=>$this->tv_before_db_delete_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_db_delete_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_db_get_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_db_get_method',
			'control_value'=>$this->tv_before_db_get_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_db_get_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_view_query_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_view_query_method',
			'control_value'=>$this->tv_after_view_query_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_view_query_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_view_add_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_view_add_method',
			'control_value'=>$this->tv_after_view_add_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_view_add_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_view_update_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_view_update_method',
			'control_value'=>$this->tv_after_view_update_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_view_update_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_view_get_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_view_get_method',
			'control_value'=>$this->tv_after_view_get_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_view_get_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.add_default_value_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'add_default_value_method',
			'control_value'=>$this->tv_add_default_value_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["add_default_value_method"],
		));
	 
 
		
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
					$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);										
		$this->addItems($items);				


if($id==null || $id==''){
		

}else{
		

}

		
		self::addInfoResults($srModel,null);
		return $srModel;		
	}
	public function viewSysToolTables2Page($spModel){
		$id = $this->srModel['id'];
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewSysToolTables2Page",
			"target"=>"_self",
			"onSubmit"=>"",
		);	
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));	
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'table_name',
			'control_value'=>$this->tv_table_name,
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_desc','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'table_desc',
			'control_value'=>$this->tv_table_desc,
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_desc"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.code_module','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'code_module',
			'control_value'=>$this->tv_code_module,
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["code_module"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.code_module_method','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'code_module_method',
			'control_value'=>$this->tv_code_module_method,
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["code_module_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_has_status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'table_has_status',
			'control_value'=>$this->tv_table_has_status,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_has_status"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_status_field','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'table_status_field',
			'control_value'=>$this->tv_table_status_field,
			'control_class'=>" ",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_status_field"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_status_save','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'table_status_save',
			'control_value'=>$this->tv_table_status_save,
			'control_class'=>" ",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_status_save"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_status_submit','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'table_status_submit',
			'control_value'=>$this->tv_table_status_submit,
			'control_class'=>" ",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_status_submit"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.child_type','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'child_type',
			'control_value'=>$this->tv_child_type,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["child_type"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.child_type_value','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'child_type_value',
			'control_value'=>$this->tv_child_type_value,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["child_type_value"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.is_tree','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'is_tree',
			'control_value'=>$this->tv_is_tree,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["is_tree"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.tree_parent_field','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'tree_parent_field',
			'control_value'=>$this->tv_tree_parent_field,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["tree_parent_field"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.table_info','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'table_info',
			'control_value'=>$this->tv_table_info,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_info"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.query_sql_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'query_sql_method',
			'control_value'=>$this->tv_query_sql_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["query_sql_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_query_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_query_method',
			'control_value'=>$this->tv_before_query_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_query_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_update_page_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_update_page_method',
			'control_value'=>$this->tv_before_update_page_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_update_page_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_add_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_add_method',
			'control_value'=>$this->tv_before_add_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_add_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_update_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_update_method',
			'control_value'=>$this->tv_before_update_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_update_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_delete_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_delete_method',
			'control_value'=>$this->tv_before_delete_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_delete_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_get_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_get_method',
			'control_value'=>$this->tv_before_get_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_get_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_query_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_query_method',
			'control_value'=>$this->tv_after_query_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_query_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_update_page_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_update_page_method',
			'control_value'=>$this->tv_after_update_page_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_update_page_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_update_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_update_method',
			'control_value'=>$this->tv_after_update_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_update_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_delete_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_delete_method',
			'control_value'=>$this->tv_after_delete_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_delete_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_get_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_get_method',
			'control_value'=>$this->tv_after_get_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_get_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_query_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_query_method',
			'control_value'=>$this->tv_after_db_query_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=100  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_query_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_add_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_add_method',
			'control_value'=>$this->tv_after_db_add_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_add_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_update_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_update_method',
			'control_value'=>$this->tv_after_db_update_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_update_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_au_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_au_method',
			'control_value'=>$this->tv_after_db_au_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_au_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_delete_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_delete_method',
			'control_value'=>$this->tv_after_db_delete_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_delete_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_db_get_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_db_get_method',
			'control_value'=>$this->tv_after_db_get_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_db_get_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_db_add_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_db_add_method',
			'control_value'=>$this->tv_before_db_add_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_db_add_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_db_update_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_db_update_method',
			'control_value'=>$this->tv_before_db_update_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_db_update_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_db_au_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_db_au_method',
			'control_value'=>$this->tv_before_db_au_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_db_au_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_db_delete_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_db_delete_method',
			'control_value'=>$this->tv_before_db_delete_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_db_delete_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.before_db_get_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'before_db_get_method',
			'control_value'=>$this->tv_before_db_get_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["before_db_get_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_view_query_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_view_query_method',
			'control_value'=>$this->tv_after_view_query_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_view_query_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_view_add_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_view_add_method',
			'control_value'=>$this->tv_after_view_add_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_view_add_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_view_update_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_view_update_method',
			'control_value'=>$this->tv_after_view_update_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_view_update_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.after_view_get_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'after_view_get_method',
			'control_value'=>$this->tv_after_view_get_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["after_view_get_method"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_tool_table2.add_default_value_method','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'add_default_value_method',
			'control_value'=>$this->tv_add_default_value_method,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["add_default_value_method"],
		));
	
	
		//GRID
		$this->addGrid(array(
			'div_id'=>'div_search','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['details'],'grid_page'=>$this->srModel['details_page'],
			'grid_param'=>array(

				"sys_tool_table_field2.id"=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_id[]',
						'control_value'=>$this->tv_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'id',
						'div_label'=>'',
					),
				"sys_tool_table_field2.table_id"=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_table_id[]',
						'control_value'=>$this->tv_table_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'table_id',
						'div_label'=>'',
					),
				"sys_tool_table_field2.field_name"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_field_name[]',
						'control_value'=>$this->tv_field_name,
						'control_class'=>"required",'control_param'=>"  size='12'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'field_name',
						'div_label'=>'',
					),
				"sys_tool_table_field2.field_desc"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_field_desc[]',
						'control_value'=>$this->tv_field_desc,
						'control_class'=>"required",'control_param'=>"  size='10'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'field_desc',
						'div_label'=>'',
					),
				"sys_tool_table_field2.field_type"=>array(
						'control_type'=>'SELECT_DICT','control_name'=>'detail_field_type[]',
						'control_value'=>$this->tv_field_type,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'field_type',
						'div_label'=>'',
					),
				"sys_tool_table_field2.field_type_value"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_field_type_value[]',
						'control_value'=>$this->tv_field_type_value,
						'control_class'=>"",'control_param'=>"  size='8'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'field_type_value',
						'div_label'=>'',
					),
				"sys_tool_table_field2.field_type_desc_value"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_field_type_desc_value[]',
						'control_value'=>$this->tv_field_type_desc_value,
						'control_class'=>"",'control_param'=>"  size='6'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'field_type_desc_value',
						'div_label'=>'',
					),
				"sys_tool_table_field2.field_class"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_field_class[]',
						'control_value'=>$this->tv_field_class,
						'control_class'=>"",'control_param'=>"  size='6'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'field_class',
						'div_label'=>'',
					),
				"sys_tool_table_field2.size_display"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_size_display[]',
						'control_value'=>$this->tv_size_display,
						'control_class'=>"",'control_param'=>"  size='4'  maxlength='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'size_display',
						'div_label'=>'',
					),
				"sys_tool_table_field2.size_max"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_size_max[]',
						'control_value'=>$this->tv_size_max,
						'control_class'=>"",'control_param'=>"  size='4'  maxlength='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'size_max',
						'div_label'=>'',
					),
				"sys_tool_table_field2.item_line_class"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_item_line_class[]',
						'control_value'=>$this->tv_item_line_class,
						'control_class'=>"",'control_param'=>"  size='6'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'item_line_class',
						'div_label'=>'',
					),
				"sys_tool_table_field2.item_control_class"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_item_control_class[]',
						'control_value'=>$this->tv_item_control_class,
						'control_class'=>"",'control_param'=>"  size='6'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'item_control_class',
						'div_label'=>'',
					),
				"sys_tool_table_field2.has_query_clause"=>array(
						'control_type'=>'SELECT_DICT','control_name'=>'detail_has_query_clause[]',
						'control_value'=>$this->tv_has_query_clause,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'has_query_clause',
						'div_label'=>'',
					),
				"sys_tool_table_field2.has_query_result"=>array(
						'control_type'=>'SELECT_DICT','control_name'=>'detail_has_query_result[]',
						'control_value'=>$this->tv_has_query_result,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'has_query_result',
						'div_label'=>'',
					),
				"sys_tool_table_field2.field_no"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_field_no[]',
						'control_value'=>$this->tv_field_no,
						'control_class'=>"",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'field_no',
						'div_label'=>'',
					),
				"sys_tool_table_field2.item_control_param"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_item_control_param[]',
						'control_value'=>$this->tv_item_control_param,
						'control_class'=>"",'control_param'=>"  size='6'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'item_control_param',
						'div_label'=>'',
					),
				"sys_tool_table_field2.item_info"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_item_info[]',
						'control_value'=>$this->tv_item_info,
						'control_class'=>"",'control_param'=>"  size='5'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'item_info',
						'div_label'=>'',
					),			),			
		));		

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$srModel_sflow = SrSflow::page_displayButton(array(
			"sflow_is_add_form"=>"0",
			"sflow_current_form"=>"ff",
			"sflow_code"=>"sys_tool_table2",
			"sflow_business_id"=>$this->srModel["id"],
			"sflow_business_num"=>$this->srModel["code"],
			"sflow_from_status"=>$this->srModel[""],
			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
			"sflow_return_url"=>__SELF__,
			"sflow_request_params"=>array(
			"id"=>$spModel["id"],
			"pageType"=>$spModel["pageType"],
			),
		));		
		$this->hidden_html = $srModel_sflow["divHtml"];
		$items["items_line"] = $srModel_sflow["buttonArrays"];
/*
		$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>__URL__."/editSysToolTables2Page?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
	
			
		$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'update2',
				'control_value'=>__URL__."/managerSysToolTables2Page?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
		
				$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'delete',
				'control_value'=>__URL__."/deleteTask?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.delete',
			);	

Sflow(flow_name,button_name,page_submit_type,page_submit_js):
修改生成器配置表	page.button.update	030	__APP__/ManagerSysToolTables2/editSysToolTables2Page?id={1}
新增子生成器配置表	page.button.addchild	030	__APP__/ManagerSysToolTables2/editSysToolTables2Page?={1}
删除生成器配置表	page.button.delete	030	__APP__/ManagerSysToolTables2/deleteSysToolTables2?id={1}
*/

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);										
		$this->addItems($items);		
 		
 

		
		self::addInfoResults($srModel,null);
		return $srModel;		
	}	
}
 
?>