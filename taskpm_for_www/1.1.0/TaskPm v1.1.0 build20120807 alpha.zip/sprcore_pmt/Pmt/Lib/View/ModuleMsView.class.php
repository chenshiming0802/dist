<?php

class ModuleMsView extends SrView{
	private $tv_code; 
	private $tv_task_id; 
	private $tv_type_ms_id; 

	public function __construct(){
		$this->tv_code = "M{-1};pmt_module;6;PY;"; 
		$this->tv_task_id = "1;;;pmt_task;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_task t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()." and (t.parent_task_id is null or t.parent_task_id='0')"; 
		$this->tv_type_ms_id = "1;;;pmt_module_type_ms;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_module_type_ms t WHERE is_deleted='0'"; 
	
	}

	public function queryModuleMs($spModel){
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);
		
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.project_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'query_project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_project_id'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.module_type_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'query_module_type_id',
			'control_value'=>$this->tv_module_type_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_module_type_id'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_code',
			'control_value'=>$this->tv_code,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_code'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_name',
			'control_value'=>$this->tv_name,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_name'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.manager_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'query_manager_id',
			'control_value'=>$this->tv_manager_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_manager_id'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.adv_begin_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'query_adv_begin_date',
			'control_value'=>$this->tv_adv_begin_date,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_adv_begin_date'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.adv_end_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'query_adv_end_date',
			'control_value'=>$this->tv_adv_end_date,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_adv_end_date'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.content','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'query_content',
			'control_value'=>$this->tv_content,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_content'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.url','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'query_url',
			'control_value'=>$this->tv_url,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_url'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'query_status',
			'control_value'=>$this->tv_status,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_status'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.proirity','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'query_proirity',
			'control_value'=>$this->tv_proirity,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_proirity'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.depend_module_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'query_depend_module_id',
			'control_value'=>$this->tv_depend_module_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_depend_module_id'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'query_id',
			'control_value'=>$this->tv_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_id'],
		));
	 
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(		
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'insert',
				'control_value'=>__URL__."/editModuleMsPage",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.insert',
			);	
			
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'manager',
				'control_value'=>__URL__."/managerModuleMsPage",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.insert',
			);
		$this->addItems($items);	

		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'view',
				'control_value'=>__URL__."/viewModuleMsPage?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.view',
			);

		$buttons[] =array(
				'control_type'=>'BUTTON','control_name'=>'delete',
				'control_value'=>__URL__."/deleteModuleMs[id]",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.delete',
			);
		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
				'pmt_module.project_id'=>array(
					'control_type'=>'HIDDEN','control_name'=>'project_id',
					'control_value'=>$this->tv_project_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'project_id',
				),			
					'pmt_module.module_type_id'=>array(
					'control_type'=>'HIDDEN','control_name'=>'module_type_id',
					'control_value'=>$this->tv_module_type_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'module_type_id',
				),			
					'pmt_module.code'=>array(
					'control_type'=>'LABEL','control_name'=>'code',
					'control_value'=>$this->tv_code,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'code',
				),			
					'pmt_module.name'=>array(
					'control_type'=>'LABEL','control_name'=>'name',
					'control_value'=>$this->tv_name,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'name',
				),			
					'pmt_module.manager_id'=>array(
					'control_type'=>'HIDDEN','control_name'=>'manager_id',
					'control_value'=>$this->tv_manager_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'manager_id',
				),			
					'pmt_module.adv_begin_date'=>array(
					'control_type'=>'HIDDEN','control_name'=>'adv_begin_date',
					'control_value'=>$this->tv_adv_begin_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_begin_date',
				),			
					'pmt_module.adv_end_date'=>array(
					'control_type'=>'HIDDEN','control_name'=>'adv_end_date',
					'control_value'=>$this->tv_adv_end_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_end_date',
				),			
					'pmt_module.content'=>array(
					'control_type'=>'HIDDEN','control_name'=>'content',
					'control_value'=>$this->tv_content,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'content',
				),			
					'pmt_module.url'=>array(
					'control_type'=>'HIDDEN','control_name'=>'url',
					'control_value'=>$this->tv_url,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'url',
				),			
					'pmt_module.status'=>array(
					'control_type'=>'HIDDEN','control_name'=>'status',
					'control_value'=>$this->tv_status,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'status',
				),			
					'pmt_module.proirity'=>array(
					'control_type'=>'HIDDEN','control_name'=>'proirity',
					'control_value'=>$this->tv_proirity,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'proirity',
				),			
					'pmt_module.depend_module_id'=>array(
					'control_type'=>'HIDDEN','control_name'=>'depend_module_id',
					'control_value'=>$this->tv_depend_module_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'depend_module_id',
				),			
					'pmt_module.id'=>array(
					'control_type'=>'HIDDEN','control_name'=>'id',
					'control_value'=>$this->tv_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'id',
				),			
	
				'operate'=>$buttons,
			),			
		));

		

		self::addInfoResults($srModel,null);
		return $srModel;
	}
	
	public function managerModuleMsPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.'.title',array('displayDiv'=>'false'));
		$this->form = array(
			'name'=>'ff',
			'method'=>'post',
			'action'=>__URL__."/managerModuleMs",
			'target'=>'_self',
			'onSubmit'=>'',
		);	
		//$this->srModel['id']?'1':'0'
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.'.title','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>'',
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));		
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.project_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["project_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.module_type_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'module_type_id',
			'control_value'=>$this->tv_module_type_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["module_type_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'code',
			'control_value'=>$this->tv_code,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.manager_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'manager_id',
			'control_value'=>$this->tv_manager_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["manager_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.adv_begin_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'adv_begin_date',
			'control_value'=>$this->tv_adv_begin_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_begin_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.adv_end_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'adv_end_date',
			'control_value'=>$this->tv_adv_end_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_end_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.content','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'content',
			'control_value'=>$this->tv_content,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["content"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.url','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'url',
			'control_value'=>$this->tv_url,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["url"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'status',
			'control_value'=>$this->tv_status,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["status"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.proirity','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'proirity',
			'control_value'=>$this->tv_proirity,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["proirity"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.depend_module_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'depend_module_id',
			'control_value'=>$this->tv_depend_module_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["depend_module_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));
	

		//DETAIL BUTTON
		$items = array('div_id'=>'div_search_v','div_label'=>'pmt_module_milestone','item_line_type'=>'line','item_viewauth'=>'',);
		$items["items_line"] = array();

	
		$items["items_line"][] = array(			
				'control_type'=>'TEXT','control_name'=>'detail_add_count',
				'control_value'=>"",
				'control_class'=>"",'control_param'=>'size="2"','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'',
			);
		$items["items_line"][] = array(			
				'control_type'=>'BUTTON','control_name'=>'adddetail1',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.add.detail',
			);		
			
		$this->addItems($items);		
		//GRID
		$buttons = array();
		$buttons[] =array(
						'control_type'=>'BUTTON','control_name'=>'deletedetail',
						'control_value'=>"id",
						'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'page.button.delete',
					);
		$this->addGrid(array(
			'div_id'=>'div_search','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'grid_list'=>$this->srModel['details'],'grid_page'=>$this->srModel['details_page'],
			'grid_param'=>array(

				'pmt_module_milestone.id'=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_id[]',
						'control_value'=>$this->tv_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'id',
					),
				'pmt_module_milestone.module_id'=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_module_id[]',
						'control_value'=>$this->tv_module_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'module_id',
					),
				'pmt_module_milestone.task_id'=>array(
						'control_type'=>'SELECT_SQL','control_name'=>'detail_task_id[]',
						'control_value'=>$this->tv_task_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'task_id',
					),
				'pmt_module_milestone.type_ms_id'=>array(
						'control_type'=>'LABEL_SQL','control_name'=>'detail_type_ms_id[]',
						'control_value'=>$this->tv_type_ms_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'type_ms_id',
					),
				'pmt_module_milestone.adv_begin_date'=>array(
						'control_type'=>'INPUT_DATE','control_name'=>'detail_adv_begin_date[]',
						'control_value'=>$this->tv_adv_begin_date,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'adv_begin_date',
					),
				'pmt_module_milestone.adv_end_date'=>array(
						'control_type'=>'INPUT_DATE','control_name'=>'detail_adv_end_date[]',
						'control_value'=>$this->tv_adv_end_date,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'adv_end_date',
					),
				'pmt_module_milestone.adv_person_day'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_adv_person_day[]',
						'control_value'=>$this->tv_adv_person_day,
						'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'adv_person_day',
					),
				'pmt_module_milestone.progress'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_progress[]',
						'control_value'=>$this->tv_progress,
						'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'progress',
					),
				'pmt_module_milestone.memo'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_memo[]',
						'control_value'=>$this->tv_memo,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'memo',
					),
				'pmt_module_milestone.no'=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_no[]',
						'control_value'=>$this->tv_no,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'no',
					),
				"operate"=>$buttons,
			),			
		));		
	
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
	

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'submitb',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.submit',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);										
		$this->addItems($items);																		
		
		self::addInfoResults($srModel,null);
		return $srModel;		
	}	

	public function editModuleMsPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/editModuleMs",
			"target"=>"_self",
			"onSubmit"=>"",
		);	
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));		
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.project_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["project_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.module_type_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'module_type_id',
			'control_value'=>$this->tv_module_type_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["module_type_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'code',
			'control_value'=>$this->tv_code,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.manager_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'manager_id',
			'control_value'=>$this->tv_manager_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["manager_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.adv_begin_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'adv_begin_date',
			'control_value'=>$this->tv_adv_begin_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_begin_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.adv_end_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'adv_end_date',
			'control_value'=>$this->tv_adv_end_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_end_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.content','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'content',
			'control_value'=>$this->tv_content,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["content"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.url','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'url',
			'control_value'=>$this->tv_url,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["url"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'status',
			'control_value'=>$this->tv_status,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["status"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.proirity','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'proirity',
			'control_value'=>$this->tv_proirity,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["proirity"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.depend_module_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'depend_module_id',
			'control_value'=>$this->tv_depend_module_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["depend_module_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));
	 
 
		
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();


		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'submitb',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.submit',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);										
		$this->addItems($items);																		
		
		self::addInfoResults($srModel,null);
		return $srModel;		
	}


	public function viewModuleMsPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewModuleMsPage",
			"target"=>"_self",
			"onSubmit"=>"",
		);	
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));	
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.project_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["project_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.module_type_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'module_type_id',
			'control_value'=>$this->tv_module_type_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["module_type_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'code',
			'control_value'=>$this->tv_code,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.manager_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'manager_id',
			'control_value'=>$this->tv_manager_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["manager_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.adv_begin_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'adv_begin_date',
			'control_value'=>$this->tv_adv_begin_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_begin_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.adv_end_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'adv_end_date',
			'control_value'=>$this->tv_adv_end_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_end_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.content','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'content',
			'control_value'=>$this->tv_content,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["content"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.url','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'url',
			'control_value'=>$this->tv_url,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["url"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'status',
			'control_value'=>$this->tv_status,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["status"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.proirity','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'proirity',
			'control_value'=>$this->tv_proirity,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["proirity"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.depend_module_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'depend_module_id',
			'control_value'=>$this->tv_depend_module_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["depend_module_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));
	
	
		//GRID
		$this->addGrid(array(
			'div_id'=>'div_search','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'grid_list'=>$this->srModel['details'],'grid_page'=>$this->srModel['details_page'],
			'grid_param'=>array(

				"pmt_module_milestone.id"=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_id[]',
						'control_value'=>$this->tv_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'id',
					),
				"pmt_module_milestone.module_id"=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_module_id[]',
						'control_value'=>$this->tv_module_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'module_id',
					),
				"pmt_module_milestone.task_id"=>array(
						'control_type'=>'SELECT_SQL','control_name'=>'detail_task_id[]',
						'control_value'=>$this->tv_task_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'task_id',
					),
				"pmt_module_milestone.type_ms_id"=>array(
						'control_type'=>'LABEL_SQL','control_name'=>'detail_type_ms_id[]',
						'control_value'=>$this->tv_type_ms_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'type_ms_id',
					),
				"pmt_module_milestone.adv_begin_date"=>array(
						'control_type'=>'INPUT_DATE','control_name'=>'detail_adv_begin_date[]',
						'control_value'=>$this->tv_adv_begin_date,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_begin_date',
					),
				"pmt_module_milestone.adv_end_date"=>array(
						'control_type'=>'INPUT_DATE','control_name'=>'detail_adv_end_date[]',
						'control_value'=>$this->tv_adv_end_date,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_end_date',
					),
				"pmt_module_milestone.adv_person_day"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_adv_person_day[]',
						'control_value'=>$this->tv_adv_person_day,
						'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'adv_person_day',
					),
				"pmt_module_milestone.progress"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_progress[]',
						'control_value'=>$this->tv_progress,
						'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'progress',
					),
				"pmt_module_milestone.memo"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_memo[]',
						'control_value'=>$this->tv_memo,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'memo',
					),
				"pmt_module_milestone.no"=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_no[]',
						'control_value'=>$this->tv_no,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'no',
					),			),			
		));		

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$srModel_sflow = SrSflow::page_displayButton(array(
			"sflow_is_add_form"=>"0",
			"sflow_current_form"=>"ff",
			"sflow_code"=>"pmt_module",
			"sflow_business_id"=>$this->srModel["id"],
			"sflow_business_num"=>$this->srModel["code"],
			"sflow_from_status"=>$this->srModel[""],
			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
			"sflow_return_url"=>__SELF__,
			"sflow_request_params"=>array(
			"id"=>$spModel["id"],
			"pageType"=>$spModel["pageType"],
			),
		));		
		echo $srModel_sflow["divHtml"];	
		$items["items_line"] = $srModel_sflow["buttonArrays"];
		$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>__URL__."/editModuleMsPage?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
	
			
		$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'update2',
				'control_value'=>__URL__."/managerModuleMsPage?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
		
					
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);										
		$this->addItems($items);		

		
		self::addInfoResults($srModel,null);
		return $srModel;		
	}	
}
 
?>