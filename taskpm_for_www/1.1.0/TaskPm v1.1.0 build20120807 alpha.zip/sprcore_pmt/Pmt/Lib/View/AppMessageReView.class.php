<?php
class AppMessageReView extends SrView{	

}
?>
