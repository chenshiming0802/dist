<?php
class AppPmtDocumentView extends SrView{

	public function queryDocuments($spModel) {
		$table_id = $this->spModel["table_id"];
		$table_name = $this->spModel["table_name"];
		$table_ids = $this->spModel["table_ids"];

		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'upload',
				'control_value'=>__APP__."/AppPmtDocument/uploadDocumentFilePage?table_name={$table_name}&table_id={$table_id}&table_ids={$table_ids}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.upload',
			);



		$this->addItems($items);

		$buttons = array();
//		$buttons[] = array(
//				'control_type'=>'BUTTON','control_name'=>'view',
//				'control_value'=>__APP__."/AppPmtDocument/viewProjectPage?id=[id]",//URL,GRID,REQUEST,SESSION
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.view',
//			);
		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
				'pmt_document.title'=>array(
					'control_type'=>'TEXT','control_name'=>'title',
					'control_value'=>$this->tv_code,
					'control_class'=>"required",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'title',
					'INFO'=>"TYPE=open&URL=__APP__/AppPmtDocument/downloadDocument?document_id=[id]",
					'div_label'=>'pmt_document.title',
				),
				'pmt_document.document_version'=>array(
					'control_type'=>'TEXT','control_name'=>'document_version',
					'control_value'=>$this->tv_code,
					'control_class'=>"required",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'document_version',
					'INFO'=>"",
					'div_label'=>'pmt_document.document_version',
				),
				'pmt_document.create_time'=>array(
					'control_type'=>'TEXT','control_name'=>'create_time',
					'control_value'=>$this->tv_code,
					'control_class'=>"required",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'create_time',
					'INFO'=>"",
					'div_label'=>'create_time',
				),
				//'operate'=>$buttons,
			),
		));




		self::addInfoResults($srModel,null);
		return $srModel;
	}


	public function listTableDocuments($spModel) {
		$table_id = $this->spModel["table_id"];
		$path_id = $this->spModel["path_id"];
		$table_name = $this->spModel["table_name"];

		$action = $this->spModel["action"];

		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));

		$items = array('div_id'=>'div_search_v','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		//if($action=='edit'){
			$items["items_line"][] = array(
					'control_type'=>'BUTTON','control_name'=>'upload',
					'control_value'=>__APP__."/AppPmtDocument/uploadDocumentFilePage?table_name={$table_name}&table_id={$table_id}&path_id={$path_id}",
					'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'page.button.upload',
				);
		//}




		$this->addItems($items);

		$buttons = array();
//		$buttons[] = array(
//				'control_type'=>'BUTTON','control_name'=>'view',
//				'control_value'=>__APP__."/AppPmtDocument/viewProjectPage?id=[id]",//URL,GRID,REQUEST,SESSION
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.view',
//			);
		$list = array();
		foreach($this->srModel['list'] as $k=>$model){
			$document_type = Sr::sys_dictValue('PMT17',$model['document_type']);
			$url = Sr::sys_sl(__APP__."/AppPmtDocument/downloadDocument?document_id=".$model['id']);
			$tt1 = '<b>'.$model['title'].'</b>  (v'.$model['document_version'].' @ '.$model['create_time'].')';
			$tt1 = "[{$document_type}]&nbsp;<a href='{$url}' target='_blank'>{$tt1}</a>";

			$url = __APP__."/VbaHttp/downloadDocumentVbs?document_id=".$model['id'];
			$tt2 = "";
//			switch($model['document_type']){
//				case '010':
// 					$tt2 = "<a href='{$url}' target='_blank'>[上传命令]</a>";
//					break;
//			}


			if($model['link_belong_user_id']==SrUser::getUserId()){
				$tt2 .= "&nbsp;<a href='#' onClick='onClick_itemDelete(\"".Sr::sys_sl(__URL__."/deleteDocument?document_id=".$model["id"]."&table_id=".$this->spModel['table_id']."&table_name=".$this->spModel['table_name'])."\")'>[删除]</a>";
			}


			$model['title2'] = $tt1.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$tt2;


			$list[] = $model;
		}

		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$list,'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
				'pmt_document.title'=>array(
					'control_type'=>'TEXT','control_name'=>'title',
					'control_value'=>$this->tv_code,
					'control_class'=>"required",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'title2',
					//'INFO'=>"TYPE=open&URL=__APP__/AppPmtDocument/downloadDocument?document_id=[id]",
					'div_label'=>'pmt_document.title',
				),
				//'operate'=>$buttons,
			),
		));






		self::addInfoResults($srModel,null);
		return $srModel;
	}
}
?>
