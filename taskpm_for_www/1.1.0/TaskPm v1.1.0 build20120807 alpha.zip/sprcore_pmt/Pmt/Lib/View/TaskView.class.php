<?php

class TaskView extends SrView{
	private $tv_project_id;
	private $tv_module_id;
	private $tv_parent_task_id;
	private $tv_proirity;
	private $tv_module_type_task_id;
	private $tv_manager_id;
	private $tv_array_task_member;
	private $tv_constraint_type;
	private $tv_ticket_type;
	private $tv_status;
	private $tv_type_ms_id;
	private $tv_work_calc_type;
	private $tv_module_follow_id;
	private $tv_follow_task_id;

	public function __construct(){
		$this->tv_project_id = "1;;;pmt_project;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_project t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";
		$this->tv_module_id = "1;;;pmt_module;name;SELECT t.id _valueCode_,t.name _valueName_,t.project_id _parentCode_ FROM pmt_module t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId().";project_id";
		$this->tv_parent_task_id = "1;;;pmt_task;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_task t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";
		$this->tv_proirity = "1;;PMT06";
		$this->tv_module_type_task_id = "1;;;pmt_module_type_task;name;SELECT t3.id  _valueCode_,t3.name  _valueName_,t1.id _parentObjectCode_ FROM pmt_module t1,pmt_module_type t2,pmt_module_type_task t3 WHERE t1.is_deleted = '0' AND t2.is_deleted = '0' AND t3.is_deleted='0' AND t1.module_type_id=t2.id  AND t2.id=t3.type_id ;module_id";
		$this->tv_manager_id = "1;;;uup_user;name;SELECT distinct t.id _valueCode_,t.name _valueName_ FROM uup_user t,pmt_project_member t2 WHERE t2.user_id=t.id and org_id=".SrUser::getOrgId()." /*w[t,t2]*/";
		$this->tv_array_task_member = "1;;;uup_user;name;SELECT distinct t.id _valueCode_,t.name _valueName_ FROM uup_user t,pmt_project_member t2 WHERE t2.user_id=t.id and org_id=".SrUser::getOrgId()." /*w[t,t2]*/";
		$this->tv_constraint_type = "1;;PMT08";
		$this->tv_ticket_type = "1;;PMT02";
		$this->tv_status = "1;;PMT04";
		$this->tv_type_ms_id = "1;;;pmt_module_type_ms;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_module_type_ms t WHERE is_deleted='0'";
		$this->tv_work_calc_type = "1;;PMT12";
		$this->tv_module_follow_id = "1;;;pmt_module_type_follow;name;SELECT t3.id  _valueCode_,t3.name  _valueName_,t1.id _parentObjectCode_ FROM pmt_module t1,pmt_module_type t2,pmt_module_type_follow t3,pmt_module_type_follow_frm t4 WHERE t1.module_type_id = t2.id  AND t3.id=t4.follow_id AND t2.id = t4.type_id /*w[t1,t2,t3,t4]*/ ;module_id";
		$this->tv_follow_task_id = "1;;;pmt_task;name;SELECT t.id _valueCode_,CONCAT(t.name) _valueName_,t2.follow_id  _parentObjectCode_ FROM pmt_task t, pmt_module_type_follow_dst t2 WHERE t.module_type_task_id=t2.module_task_type_id and t.status='020'  AND t.belong_org_id=".SrUser::getOrgId()." /*w[t,t2]*/;module_follow_id";//CONCAT(t.code,'#',t.name)

	}

public function queryTask($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);


		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'plan',
				'control_value'=>__URL__."/managerTaskPage",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.plan',
			);


		$this->addItems($items);

		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'view',
				//'control_value'=>__URL__."/viewTaskPage?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_value'=>__APP__."/AppTask/indexTaskDetail?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.view',
			);

		foreach($this->srModel['list'] as &$model){
			$model['name_code'] = trim($model['name']).'-'.$model['code'].'';
			$model['name'] = trim($model['name']).'-'.$model['code'].'';
		}

		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
//				'pmt_task.code'=>array(
//					'control_type'=>'LABEL_PHP','control_name'=>'code',
//					'control_value'=>$this->tv_code,
//					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//					'value_input'=>'code',
//					'INFO'=>"TYPE=open&URL=__APP__/Task/viewTaskPage%3Fid=[id]",
//					'div_label'=>'',
//				),
					'pmt_task.name'=>array(
					'control_type'=>'LABEL','control_name'=>'name',
					'control_value'=>$this->tv_name,
					'control_class'=>"required",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'name',
					//'INFO'=>"TYPE=open&URL=__APP__/Task/viewTaskPage%3Fid=[id]",
					'div_label'=>'',
				),
					'pmt_task.manager_id'=>array(
					'control_type'=>'LABEL_SQL','control_name'=>'manager_id',
					'control_value'=>$this->tv_manager_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'manager_id',
					'INFO'=>"TYPE=open&URL=__APP__/Employee/viewEmployeePage%3Fuser_id=[manager_id]",
					'div_label'=>'',
				),
					'pmt_task.adv_begin_date'=>array(
					'control_type'=>'LABEL','control_name'=>'adv_begin_date',
					'control_value'=>$this->tv_adv_begin_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_begin_date',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.adv_end_date'=>array(
					'control_type'=>'LABEL','control_name'=>'adv_end_date',
					'control_value'=>$this->tv_adv_end_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_end_date',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.adv_person_day'=>array(
					'control_type'=>'LABEL','control_name'=>'adv_person_day',
					'control_value'=>$this->tv_adv_person_day,
					'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_person_day',
					'INFO'=>"",
					'div_label'=>'',
				),
				//T000497
//					'pmt_task.status'=>array(
//					'control_type'=>'LABEL_DICT','control_name'=>'status',
//					'control_value'=>$this->tv_status,
//					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//					'value_input'=>'status',
//					'INFO'=>"",
//					'div_label'=>'',
//				),
					'pmt_task.proirity'=>array(
					'control_type'=>'LABEL_DICT','control_name'=>'proirity',
					'control_value'=>$this->tv_proirity,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'proirity',
					'INFO'=>"",
				),
				/*
					'pmt_task.adv_progress'=>array(
					'control_type'=>'LABEL','control_name'=>'adv_progress',
					'control_value'=>$this->tv_adv_progress,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_progress',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.tsh_progress'=>array(
					'control_type'=>'LABEL','control_name'=>'tsh_progress',
					'control_value'=>$this->tv_tsh_progress,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'tsh_progress',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.act_progress'=>array(
					'control_type'=>'LABEL','control_name'=>'act_progress',
					'control_value'=>$this->tv_act_progress,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'act_progress',
					'INFO'=>"",
					'div_label'=>'',
				),
				*/

				'operate'=>$buttons,
			),
		));




		self::addInfoResults($srModel,null);
		return $srModel;
	}




public function editTaskPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/editTask",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));


		//T000506	       任务添加从其他系统读取任务详情功能
		if(count($this->srModel['source_config'])>0){
			$source_id_array = array();
			$source_id_array[''] = '';
			foreach($this->srModel['source_config'] as $vv){
				$source_id_array[$vv['id']] = $vv['name'];
			}

			$items = array('div_id'=>'div_search_v','div_label'=>'label.task.source','item_line_type'=>'line','item_viewauth'=>'',);
			$items["items_line"] = array();
			$items["items_line"][] = array(
					'control_type'=>'SELECT_ARRAY','control_name'=>'source_id',
					'control_value'=>$source_id_array,
					'control_class'=>'','control_param'=>'','control_readonly'=>'0',
					'control_viewauth'=>'',
					'value_input'=>$this->srModel["source_id"],
				);
	 		$items["items_line"][] = array(
					'control_type'=>'TEXT','control_name'=>'source_value',
					'control_value'=>"",
					'control_class'=>'','control_param'=>' size="60" ','control_readonly'=>'0',
					'control_viewauth'=>'',
					'value_input'=>$this->srModel["source_value"],
				);
	 		$items["items_line"][] = array(
					'control_type'=>'BUTTON','control_name'=>'getinfo',
					'control_value'=>"",
					'control_class'=>'','control_param'=>'','control_readonly'=>'0',
					'control_viewauth'=>'',
					'value_input'=>'buttom.task.getinfo',
				);

			$this->addItems($items);
		}



			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.project_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["project_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.module_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'module_id',
			'control_value'=>$this->tv_module_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["module_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_PHP','control_name'=>'code',
			'control_value'=>$this->tv_code,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.parent_task_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'parent_task_id',
			'control_value'=>$this->tv_parent_task_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["parent_task_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.name','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>"required ",'control_param'=>"  size='100'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.proirity','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'proirity',
			'control_value'=>$this->tv_proirity,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["proirity"],
		));
		$rr = '0';
		if($id!=null&&$id!=''){
			$rr = '1';
		}
			$module_type = self::addSelect2String(array('bar'=>$this->tv_module_type_task_id,'suf5'=>" and t1.id='".$this->srModel['module_id']."'"));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.module_type_task_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'module_type_task_id',
			'control_value'=>$module_type,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["module_type_task_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.manager_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'manager_id',
			'control_value'=>$this->tv_manager_id." and t2.project_id=".$this->srModel["project_id"],
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["manager_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.business_person_name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'business_person_name',
			'control_value'=>'',
			'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["business_person_name"],
		));

		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.array_task_member','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'CHECKBOX_SQL','control_name'=>'array_task_member[]',
			'control_value'=>$this->tv_array_task_member." and t2.project_id=".$this->srModel["project_id"],
			'control_class'=>"required ",'control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["array_task_member"],
		));
		//T000493	       任务修改和新增画面添加时间的快捷选择按钮
		$items = array('div_id'=>'div_search_v','div_label'=>'task.advtime.shortupbutton','item_line_type'=>'line','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'currentDate',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'buttom.fixtask.current.date',
			);
 		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'nextDate',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'buttom.fixtask.next.date',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'nextNextDate',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'buttom.fixtask.nextnext.date',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'currentWeek',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'buttom.fixtask.current.week',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'nextWeek',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'buttom.fixtask.next.week',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'currentMonth',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'buttom.fixtask.current.month',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'nextMonth',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'buttom.fixtask.next.month',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'nextWeek1',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'buttom.fixtask.next.week.1',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'nextWeek2',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'buttom.fixtask.next.week.2',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'nextWeek3',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'buttom.fixtask.next.week.3',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'nextWeek4',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'buttom.fixtask.next.week.4',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'nextWeek5',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'buttom.fixtask.next.week.5',
			);
		$this->addItems($items);


			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.adv_begin_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'adv_begin_date',
			'control_value'=>$this->tv_adv_begin_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_begin_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.adv_end_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'adv_end_date',
			'control_value'=>$this->tv_adv_end_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_end_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.adv_person_day','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'adv_person_day',
			'control_value'=>$this->tv_adv_person_day,
			'control_class'=>" ",'control_param'=>"  size='4'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_person_day"],
		));
		//T000500	       去除任务的约束类型，约束时间修改为最后期限
//			$this->addItem(array(
//			'div_id'=>'div_search_v','div_label'=>'pmt_task.constraint_type','item_line_type'=>'','item_viewauth'=>'',
//			'control_type'=>'SELECT_DICT','control_name'=>'constraint_type',
//			'control_value'=>$this->tv_constraint_type,
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
//			'value_input'=>$this->srModel["constraint_type"],
//		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.constraint_time','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'constraint_time',
			'control_value'=>$this->tv_constraint_time,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["constraint_time"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.ticket_type','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'ticket_type',
			'control_value'=>$this->tv_ticket_type,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["ticket_type"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_DICT','control_name'=>'status',
			'control_value'=>$this->tv_status,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["status"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.no','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'no',
			'control_value'=>$this->tv_no,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["no"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.type_ms_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'type_ms_id',
			'control_value'=>$this->tv_type_ms_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["type_ms_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.tsh_progress','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'tsh_progress',
			'control_value'=>$this->tv_tsh_progress,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["tsh_progress"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.work_calc_type','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'work_calc_type',
			'control_value'=>$this->tv_work_calc_type,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["work_calc_type"],
		));
			$module_follow = self::addSelect2String(array('bar'=>$this->tv_module_follow_id,'suf5'=>" and t1.id='".$this->srModel['module_id']."'"));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.module_follow_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'module_follow_id',
			'control_value'=>$module_follow,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["module_follow_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.follow_task_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL_2','control_name'=>'follow_task_id',
			'control_value'=>self::addSelect2String(array('bar'=>$this->tv_follow_task_id,'suf5'=>" and t.project_id=".$this->srModel["project_id"])),
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["follow_task_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.content','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'RICKEDIT','control_name'=>'content',
			'control_value'=>$this->tv_content,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["content"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.url','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTURL','control_name'=>'url',
			'control_value'=>$this->tv_url,
			'control_class'=>" ",'control_param'=>"  size='100'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["url"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.spr_tree_type','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'spr_tree_type',
			'control_value'=>'',
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["spr_tree_type"],
		));


		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$status = $this->srModel['status'];
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'save',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>($status==null||$status=='010')?'0':'1',
				'value_input'=>'page.button.save',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'submitb',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>($status==null||$status=='010')?'0':'1',
				'value_input'=>'page.button.submit',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>($status==null||$status=='010')?'1':'0',
				'value_input'=>'page.button.update',
			);
					$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);

		if($this->srModel["project_id"]!=null){
			$this->setControlProperty("div_search_v","project_id","control_readonly","1");
		}
		if($this->srModel["module_id"]!=null){
			$this->setControlProperty("div_search_v","module_id","control_readonly","1");
		}
		if($this->srModel["spr_tree_type"]=="010"){
			$this->setControlProperty("div_search_v","adv_begin_date","control_readonly","1");
			$this->setControlProperty("div_search_v","adv_end_date","control_readonly","1");
			$this->setControlProperty("div_search_v","adv_person_day","control_readonly","1");
			$this->setControlProperty("div_search_v","array_task_member","control_readonly","1");
		}
if($id==null || $id==''){


}else{
if($this->srModel["spr_tree_type"]=="020"){
	$this->setControlProperty("div_search_v","adv_begin_date","control_readonly","0");
	$this->setControlProperty("div_search_v","adv_end_date","control_readonly","0");
	$this->setControlProperty("div_search_v","adv_person_day","control_readonly","0");
	$this->setControlProperty("div_search_v","array_task_member","control_readonly","0");
}

}


		self::addInfoResults($srModel,null);
		return $srModel;
	}

//T000492	       任务新增添加新增任务和新增目录任务功能
public function editTaskPage_010($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/editTask",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.project_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["project_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.module_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'module_id',
			'control_value'=>$this->tv_module_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["module_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_PHP','control_name'=>'code',
			'control_value'=>$this->tv_code,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.parent_task_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'parent_task_id',
			'control_value'=>$this->tv_parent_task_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["parent_task_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.name','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>"required ",'control_param'=>"  size='100'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.proirity','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'proirity',
			'control_value'=>$this->tv_proirity,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["proirity"],
		));
		$rr = '0';
		if($id!=null&&$id!=''){
			$rr = '1';
		}
			$module_type = self::addSelect2String(array('bar'=>$this->tv_module_type_task_id,'suf5'=>" and t1.id='".$this->srModel['module_id']."'"));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.module_type_task_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'module_type_task_id',
			'control_value'=>$module_type,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["module_type_task_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.manager_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'manager_id',
			'control_value'=>$this->tv_manager_id." and t2.project_id=".$this->srModel["project_id"],
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["manager_id"],
		));

			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_DICT','control_name'=>'status',
			'control_value'=>$this->tv_status,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["status"],
		));


			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.content','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'RICKEDIT','control_name'=>'content',
			'control_value'=>$this->tv_content,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["content"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.url','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTURL','control_name'=>'url',
			'control_value'=>$this->tv_url,
			'control_class'=>" ",'control_param'=>"  size='100'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["url"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.spr_tree_type','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'spr_tree_type',
			'control_value'=>'',
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["spr_tree_type"],
		));


		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$status = $this->srModel['status'];
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'save',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>($status==null||$status=='010')?'0':'1',
				'value_input'=>'page.button.save',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'submitb',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>($status==null||$status=='010')?'0':'1',
				'value_input'=>'page.button.submit',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>($status==null||$status=='010')?'1':'0',
				'value_input'=>'page.button.update',
			);
					$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);

		if($this->srModel["project_id"]!=null){
			$this->setControlProperty("div_search_v","project_id","control_readonly","1");
		}
		if($this->srModel["module_id"]!=null){
			$this->setControlProperty("div_search_v","module_id","control_readonly","1");
		}




		self::addInfoResults($srModel,null);
		return $srModel;
	}



	public function viewTaskPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewTaskPage",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.project_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["project_id"],
			'INFO'=>"TYPE=open&URL=__APP__/Project/viewProjectPage%3Fid=".$this->srModel["project_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.module_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'module_id',
			'control_value'=>$this->tv_module_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["module_id"],
			'INFO'=>"TYPE=open&URL=__APP__/Module/viewModulePage?id=".$this->srModel["module_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_PHP','control_name'=>'code',
			'control_value'=>$this->tv_code,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.parent_task_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'parent_task_id',
			'control_value'=>$this->tv_parent_task_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["parent_task_id"],
			'INFO'=>"TYPE=open&URL=__APP__/Task/viewTaskPage?id=[parent_task_id]",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.name','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>"required ",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.proirity','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'proirity',
			'control_value'=>$this->tv_proirity,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["proirity"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.module_type_task_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL_2','control_name'=>'module_type_task_id',
			'control_value'=>$this->tv_module_type_task_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["module_type_task_id"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.manager_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'manager_id',
			'control_value'=>$this->tv_manager_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["manager_id"],
			'INFO'=>"TYPE=open&URL=__APP__/Employee/viewEmployeePage?user_id=".$this->srModel["manager_id"]."",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.business_person_name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'business_person_name',
			'control_value'=>'',
			'control_class'=>" ",'control_param'=>"",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["business_person_name"],
			'INFO'=>"",
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.array_task_member','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'CHECKBOX_SQL','control_name'=>'array_task_member[]',
			'control_value'=>$this->tv_array_task_member,
			'control_class'=>" ",'control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["array_task_member"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.adv_begin_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'adv_begin_date',
			'control_value'=>$this->tv_adv_begin_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_begin_date"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.adv_end_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'adv_end_date',
			'control_value'=>$this->tv_adv_end_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_end_date"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.adv_person_day','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'adv_person_day',
			'control_value'=>$this->tv_adv_person_day,
			'control_class'=>" ",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_person_day"],
			'INFO'=>"",
		));
		//T000500	       去除任务的约束类型，约束时间修改为最后期限
//			$this->addItem(array(
//			'div_id'=>'div_search_v','div_label'=>'pmt_task.constraint_type','item_line_type'=>'','item_viewauth'=>'',
//			'control_type'=>'SELECT_DICT','control_name'=>'constraint_type',
//			'control_value'=>$this->tv_constraint_type,
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//			'value_input'=>$this->srModel["constraint_type"],
//			'INFO'=>"",
//		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.constraint_time','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'constraint_time',
			'control_value'=>$this->tv_constraint_time,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["constraint_time"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_DICT','control_name'=>'status',
			'control_value'=>$this->tv_status,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["status"],
			'INFO'=>"",
		));

			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.tsh_progress','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'tsh_progress',
			'control_value'=>$this->tv_tsh_progress,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["tsh_progress"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.module_follow_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL_2','control_name'=>'module_follow_id',
			'control_value'=>$this->tv_module_follow_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["module_follow_id"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.follow_task_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL_2','control_name'=>'follow_task_id',
			'control_value'=>$this->tv_follow_task_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["follow_task_id"],
			'INFO'=>"TYPE=open&URL=__APP__/Task/viewTaskPage?id=[follow_task_id]",
		));



		self::addInfoResults($srModel,null);
		return $srModel;
	}
}

?>