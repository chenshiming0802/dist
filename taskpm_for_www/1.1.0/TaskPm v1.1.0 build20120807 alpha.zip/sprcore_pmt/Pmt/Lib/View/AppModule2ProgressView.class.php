<?php
class AppModule2ProgressView extends SrView{	

}
?>
