<?php

class Task2ContentView extends SrView{

	public function __construct(){

	}






public function editTask2ContentPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/editTask2Content",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'code',
			'control_value'=>$this->tv_code,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.content','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'RICKEDIT','control_name'=>'content',
			'control_value'=>$this->tv_content,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["content"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.url','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTURL','control_name'=>'url',
			'control_value'=>$this->tv_url,
			'control_class'=>" ",'control_param'=>"  size='100'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["url"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));



		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
					$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);


if($id==null || $id==''){


}else{


}


		self::addInfoResults($srModel,null);
		return $srModel;
	}
	public function viewTask2ContentPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewTask2ContentPage",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'code',
			'control_value'=>$this->tv_code,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.content','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'RICKEDIT','control_name'=>'content',
			'control_value'=>$this->tv_content,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["content"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.url','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTURL','control_name'=>'url',
			'control_value'=>$this->tv_url,
			'control_class'=>" ",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["url"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
			'INFO'=>"",
		));



//		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
//		$srModel_sflow = SrSflow::page_displayButton(array(
//			"sflow_is_add_form"=>"0",
//			"sflow_current_form"=>"ff",
//			"sflow_code"=>"pmt_task",
//			"sflow_business_id"=>$this->srModel["id"],
//			"sflow_business_num"=>$this->srModel["code"],
//			"sflow_from_status"=>$this->srModel[""],
//			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
//			"sflow_return_url"=>__SELF__,
//			"sflow_request_params"=>array(
//			"id"=>$spModel["id"],
//			"pageType"=>$spModel["pageType"],
//			),
//		));
//		$this->hidden_html = $srModel_sflow["divHtml"];
//		$items["items_line"] = $srModel_sflow["buttonArrays"];
///*
//		$items["items_line"][] =array(
//				'control_type'=>'BUTTON','control_name'=>'update',
//				'control_value'=>__URL__."/editTask2ContentPage?id={$id}",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.update',
//			);
//
//		$items["items_line"][] =array(
//				'control_type'=>'BUTTON','control_name'=>'delete',
//				'control_value'=>__URL__."/deleteTask?id={$id}",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.delete',
//			);
//
//Sflow(flow_name,button_name,page_submit_type,page_submit_js):
//修改任务信息_内容	page.button.update	030	__APP__/Task2Content/editTask2ContentPage?id={1}
//新增子任务信息_内容	page.button.addchild	030	__APP__/Task2Content/editTask2ContentPage?={1}
//删除任务信息_内容	page.button.delete	030	__APP__/Task2Content/deleteTask2Content?id={1}
//*/
//
//		$items["items_line"][] = array(
//				'control_type'=>'BUTTON','control_name'=>'close',
//				'control_value'=>"",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.close',
//			);
//		$this->addItems($items);




		self::addInfoResults($srModel,null);
		return $srModel;
	}
}

?>