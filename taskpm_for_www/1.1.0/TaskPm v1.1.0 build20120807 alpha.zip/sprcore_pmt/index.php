<SCRIPT LANGUAGE="JavaScript">
<!--
	window.location='SprUup/index.php/Login';
//-->
</SCRIPT> 