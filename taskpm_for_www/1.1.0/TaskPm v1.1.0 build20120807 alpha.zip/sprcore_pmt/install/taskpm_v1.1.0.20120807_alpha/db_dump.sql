--pmt_company--
CREATE TABLE `pmt_company` (   `id` int(11) NOT NULL auto_increment,   `code` varchar(100) collate utf8_unicode_ci default NULL COMMENT '代码',   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `memo` text collate utf8_unicode_ci COMMENT '备注',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='公司';
 
--pmt_depart--
CREATE TABLE `pmt_depart` (   `id` int(11) NOT NULL auto_increment,   `code` varchar(100) collate utf8_unicode_ci default NULL COMMENT '代码',   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `memo` text collate utf8_unicode_ci COMMENT '备注',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='部门';
 
--pmt_document--
CREATE TABLE `pmt_document` (   `id` int(11) NOT NULL auto_increment,   `document_type` varchar(3) collate utf8_unicode_ci default NULL COMMENT '文档类型',   `title` varchar(100) collate utf8_unicode_ci default NULL COMMENT '标题',   `status` text collate utf8_unicode_ci COMMENT '状态',   `content` text collate utf8_unicode_ci COMMENT '描述',   `is_current_version` varchar(3) collate utf8_unicode_ci default NULL COMMENT '是否当前版本',   `current_version_id` int(11) default NULL COMMENT '当前版本文件',   `document_version` int(11) default NULL COMMENT '文件版本',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='文档信息';
 
--pmt_document_link--
CREATE TABLE `pmt_document_link` (   `id` int(11) NOT NULL auto_increment,   `table_id` int(11) default NULL COMMENT '业务ID',   `table_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `document_id` int(11) default NULL COMMENT '文件',   `path_id` int(11) default NULL COMMENT '路径',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`),   KEY `ix_pmt_document_link` (`table_id`,`table_name`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='任务前置关系';
 
--pmt_document_path--
CREATE TABLE `pmt_document_path` (   `id` int(11) NOT NULL auto_increment,   `table_id` int(11) default NULL COMMENT '业务ID',   `table_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `no` varchar(3) collate utf8_unicode_ci default NULL COMMENT ' 次序',   `parent_id` int(11) default NULL COMMENT '文件',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='文档路径';
 
--pmt_document_tfile--
CREATE TABLE `pmt_document_tfile` (   `id` int(11) NOT NULL auto_increment,   `document_id` int(11) default NULL COMMENT '文件',   `original_document_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '原始文件名',   `download_document_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '下载文件名',   `path` varchar(200) collate utf8_unicode_ci default NULL COMMENT '下载路径',   `file_ext` varchar(100) collate utf8_unicode_ci default NULL COMMENT '后缀',   `file_ostream` varchar(100) collate utf8_unicode_ci default NULL COMMENT '流格式',   `file_size` int(11) default NULL COMMENT '文件大小',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='文件类型文档';
 
--pmt_document_turl--
CREATE TABLE `pmt_document_turl` (   `id` int(11) NOT NULL auto_increment,   `document_id` int(11) default NULL COMMENT '文件',   `original_document_name` varchar(300) collate utf8_unicode_ci default NULL COMMENT '原始文档名',   `path` varchar(500) collate utf8_unicode_ci default NULL COMMENT '下载路径',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='文件类型文档';
 
--pmt_employee--
CREATE TABLE `pmt_employee` (   `id` int(11) NOT NULL auto_increment,   `user_id` int(11) default NULL COMMENT '登录帐号',   `emp_no` varchar(100) collate utf8_unicode_ci default NULL COMMENT '工号',   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '姓名',   `joblevel_id` int(11) default NULL COMMENT '岗位级别',   `depart_id` int(11) default NULL COMMENT '所属部门',   `company_id` int(11) default NULL COMMENT '所属公司',   `status` varchar(3) collate utf8_unicode_ci default NULL COMMENT '入职状态',   `memo` text collate utf8_unicode_ci COMMENT '备注',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='职员信息';
INSERT INTO `pmt_employee` VALUES ('-1', '-1', '空缺', '空缺', '0', '0', '0', '010', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
 
--pmt_employee_assign--
CREATE TABLE `pmt_employee_assign` (   `id` int(11) NOT NULL auto_increment,   `project_id` int(11) default NULL COMMENT '项目',   `employee_id` int(11) default NULL COMMENT '职员',   `project_joblevel_id` int(11) default NULL COMMENT '项目岗位',   `joblevel_id` int(11) default NULL COMMENT '职位岗位',   `company_id` int(11) default NULL COMMENT '所属公司',   `memo` text collate utf8_unicode_ci COMMENT '备注',   `year` int(11) default NULL COMMENT '年份',   `m1` int(11) default '0' COMMENT '1月',   `m2` int(11) default '0' COMMENT '2月',   `m3` int(11) default '0' COMMENT '3月',   `m4` int(11) default '0' COMMENT '4月',   `m5` int(11) default '0' COMMENT '5月',   `m6` int(11) default '0' COMMENT '6月',   `m7` int(11) default '0' COMMENT '7月',   `m8` int(11) default '0' COMMENT '8月',   `m9` int(11) default '0' COMMENT '9月',   `m10` int(11) default '0' COMMENT '10月',   `m11` int(11) default '0' COMMENT '11月',   `m12` int(11) default '0' COMMENT '12月',   `status` varchar(3) collate utf8_unicode_ci default NULL COMMENT '状态',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='资源分配单';
 
--pmt_joblevel--
CREATE TABLE `pmt_joblevel` (   `id` int(11) NOT NULL auto_increment,   `code` varchar(100) collate utf8_unicode_ci default NULL COMMENT '代码',   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `memo` text collate utf8_unicode_ci COMMENT '备注',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='岗位级别';
INSERT INTO `pmt_joblevel` VALUES ('1', '010', '岗位见习生', '', '0', '200006', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `pmt_joblevel` VALUES ('2', '020', '软件测试员 ', '', '0', '200006', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `pmt_joblevel` VALUES ('3', '020', '程序员', '', '0', '200006', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `pmt_joblevel` VALUES ('4', '030', '中级程序员', '', '0', '200006', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `pmt_joblevel` VALUES ('5', '040', '高级程序员', '', '0', '200006', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `pmt_joblevel` VALUES ('6', '050', '系统分析助理', '', '0', '200006', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `pmt_joblevel` VALUES ('7', '060', '工程师', '', '0', '200006', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `pmt_joblevel` VALUES ('8', '070', '工程师', '', '0', '200006', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `pmt_joblevel` VALUES ('9', '080', '高级项目经理', '', '0', '200006', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
 
--pmt_message_re--
CREATE TABLE `pmt_message_re` (   `id` int(11) NOT NULL auto_increment,   `table_id` int(11) default NULL COMMENT '项目',   `table_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `title` varchar(100) collate utf8_unicode_ci default NULL COMMENT '标题',   `content` text collate utf8_unicode_ci COMMENT '内容',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='留言信息';
 
--pmt_module--
CREATE TABLE `pmt_module` (   `id` int(11) NOT NULL auto_increment,   `project_id` int(11) default NULL COMMENT '项目',   `module_type_id` int(11) default NULL COMMENT '模块类型',   `code` varchar(100) collate utf8_unicode_ci default NULL COMMENT '代码',   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `manager_id` int(11) default NULL COMMENT '模块负责人',   `content` text collate utf8_unicode_ci COMMENT '描述',   `url` varchar(100) collate utf8_unicode_ci default NULL COMMENT '链接地址',   `status` varchar(3) collate utf8_unicode_ci default NULL COMMENT '状态:PM03',   `proirity` varchar(3) collate utf8_unicode_ci default NULL COMMENT '优先级:PM06',   `depend_module_id` int(11) default NULL COMMENT '依赖模块',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='项目模块';
 
--pmt_module_member--
CREATE TABLE `pmt_module_member` (   `id` int(11) NOT NULL auto_increment,   `module_id` int(11) default NULL COMMENT '项目',   `user_id` int(11) default NULL COMMENT '成员',   `adv_begin_date` date default NULL COMMENT '预计开始时间',   `adv_end_date` date default NULL COMMENT '预计截至时间',   `user_rate` int(11) default NULL COMMENT '使用率',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='项目模块成员';
 
--pmt_module_type--
CREATE TABLE `pmt_module_type` (   `id` int(11) NOT NULL auto_increment,   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='模块类型';
INSERT INTO `pmt_module_type` VALUES ('1', '软件开发', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type` VALUES ('2', '软件运维', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type` VALUES ('3', '综合管理', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
 
--pmt_module_type_dpath--
CREATE TABLE `pmt_module_type_dpath` (   `id` int(11) NOT NULL auto_increment,   `type_id` int(11) default NULL COMMENT '模块类型',   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `no` varchar(3) collate utf8_unicode_ci default NULL COMMENT ' 次序',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='模块类型文档目录';
INSERT INTO `pmt_module_type_dpath` VALUES ('10', '1', '项目立项', '010', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('11', '1', '项目计划', '020', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('12', '1', '需求分析', '030', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('13', '1', '基本设计', '040', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('14', '1', '系统测试', '050', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('15', '1', '上线准备', '060', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('16', '1', '项目周报', '070', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('17', '1', '会议纪要', '080', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('18', '1', '故障报告', '090', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('19', '1', '软件规范', '100', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('20', '1', '需求变更', '110', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('21', '1', '操作手册', '120', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('22', '1', '参考资料', '130', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('23', '2', '项目立项', '010', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('24', '2', '项目计划', '020', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('25', '2', '需求分析', '030', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('26', '2', '基本设计', '040', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('27', '2', '系统测试', '050', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('28', '2', '上线准备', '060', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('29', '2', '项目周报', '070', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('30', '2', '会议纪要', '080', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('31', '2', '故障报告', '090', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('32', '2', '软件规范', '100', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('33', '2', '需求变更', '110', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('34', '2', '操作手册', '120', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_dpath` VALUES ('35', '2', '参考资料', '130', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
 
--pmt_module_type_follow--
CREATE TABLE `pmt_module_type_follow` (   `id` int(11) NOT NULL auto_increment,   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `no` varchar(3) collate utf8_unicode_ci default NULL COMMENT ' 次序',   `implement_class` varchar(100) collate utf8_unicode_ci default NULL COMMENT '实现类',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='模块类型后续任务';
INSERT INTO `pmt_module_type_follow` VALUES ('9', '上线', '010', 'AppTask2FollowLinkSh', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
 
--pmt_module_type_follow_dst--
CREATE TABLE `pmt_module_type_follow_dst` (   `id` int(11) NOT NULL auto_increment,   `follow_id` int(11) default NULL,   `module_task_type_id` int(11) default NULL COMMENT '后续任务类型',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='模块类型后续任务归属Task的类型';
INSERT INTO `pmt_module_type_follow_dst` VALUES ('11', '9', '3', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_follow_dst` VALUES ('12', '9', '6', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
 
--pmt_module_type_follow_frm--
CREATE TABLE `pmt_module_type_follow_frm` (   `id` int(11) NOT NULL auto_increment,   `follow_id` int(11) default NULL,   `type_id` int(11) default NULL COMMENT '任务类型',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='模块类型后续任务的Module类型（';
INSERT INTO `pmt_module_type_follow_frm` VALUES ('13', '9', '1', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_follow_frm` VALUES ('14', '9', '2', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
 
--pmt_module_type_ms--
CREATE TABLE `pmt_module_type_ms` (   `id` int(11) NOT NULL auto_increment,   `type_id` int(11) default NULL COMMENT '模块类型',   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `no` varchar(3) collate utf8_unicode_ci default NULL COMMENT ' 次序',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='模块类型里程碑';
INSERT INTO `pmt_module_type_ms` VALUES ('1', '1', '需求分析', '010', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_ms` VALUES ('2', '1', '系统设计', '020', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_ms` VALUES ('3', '1', '系统开发', '030', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_ms` VALUES ('4', '1', '系统测试', '040', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_ms` VALUES ('5', '1', '更新上线', '050', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_ms` VALUES ('6', '1', '运行实施', '060', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_ms` VALUES ('7', '2', '运维阶段', '010', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_ms` VALUES ('8', '3', '综合管理', '010', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
 
--pmt_module_type_task--
CREATE TABLE `pmt_module_type_task` (   `id` int(11) NOT NULL auto_increment,   `type_id` int(11) default NULL COMMENT '模块类型',   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `no` varchar(3) collate utf8_unicode_ci default NULL COMMENT ' 次序',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='模块类型任务类型';
INSERT INTO `pmt_module_type_task` VALUES ('1', '1', 'BUG处理', '010', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_task` VALUES ('2', '1', '新增需求', '020', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_task` VALUES ('3', '1', '系统更新上线', '030', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_task` VALUES ('4', '2', 'BUG处理', '010', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_task` VALUES ('5', '2', '新增需求', '020', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_task` VALUES ('6', '2', '系统更新上线', '030', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_task` VALUES ('7', '1', '业务咨询', '025', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_task` VALUES ('9', '2', '业务咨询', '040', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
INSERT INTO `pmt_module_type_task` VALUES ('10', '3', '综合管理', '010', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
 
--pmt_progress--
CREATE TABLE `pmt_progress` (   `id` int(11) NOT NULL auto_increment,   `table_id` int(11) default NULL COMMENT '项目',   `table_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `adv_begin_date` date default NULL COMMENT '预计开始时间',   `adv_end_date` date default NULL COMMENT '预计结束时间',   `adv_work_day` float default NULL COMMENT '预计工期',   `adv_person_day` float(11,2) default NULL COMMENT '预计人日',   `adv_progress` float default NULL COMMENT '[废除]计划进度',   `act_begin_date` date default NULL COMMENT '实际开始时间',   `act_end_date` date default NULL COMMENT '实际结束时间',   `act_work_day` float default NULL COMMENT '实际工期',   `act_person_day` float(11,2) default NULL COMMENT '实际耗时',   `act_progress` float default NULL COMMENT '当前估算进度',   `act_progress_desc` varchar(500) collate utf8_unicode_ci default NULL COMMENT '当前进度描述',   `tsh_begin_date` date default NULL COMMENT '工时开始时间',   `tsh_end_date` date default NULL COMMENT '工时结束时间',   `tsh_work_day` float default NULL COMMENT '工时工期',   `tsh_person_day` float(11,2) default NULL COMMENT '实际工时',   `tsh_person_normal_day` float default NULL COMMENT '正常工时',   `tsh_person_over_day` float default NULL COMMENT '加班工时',   `tsh_progress` float default NULL COMMENT '[废除]实际参考进度',   `finish_time` date default NULL COMMENT '完成时间',   `close_time` date default NULL COMMENT '关闭时间',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`),   KEY `ix_pmt_progress_table_id` (`table_id`),   KEY `ix_pmt_progress_table_name` (`table_name`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='进度信息';
 
--pmt_progress_version--
CREATE TABLE `pmt_progress_version` (   `id` int(11) NOT NULL auto_increment,   `table_id` int(11) default NULL COMMENT '项目',   `table_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `adv_begin_date` date default NULL COMMENT '预计开始时间',   `adv_end_date` date default NULL COMMENT '预计结束时间',   `adv_work_day` float default NULL COMMENT '预计工期',   `adv_person_day` float(11,2) default NULL COMMENT '预计人日',   `adv_progress` float default NULL COMMENT '[废除]计划进度',   `act_begin_date` date default NULL COMMENT '实际开始时间',   `act_end_date` date default NULL COMMENT '实际结束时间',   `act_work_day` float default NULL COMMENT '实际工期',   `act_person_day` float(11,2) default NULL COMMENT '实际耗时',   `act_progress` float default NULL COMMENT '当前估算进度',   `act_progress_desc` varchar(500) collate utf8_unicode_ci default NULL COMMENT '当前进度描述',   `tsh_begin_date` date default NULL COMMENT '工时开始时间',   `tsh_end_date` date default NULL COMMENT '工时结束时间',   `tsh_work_day` float default NULL COMMENT '工时工期',   `tsh_person_day` float(11,2) default NULL COMMENT '实际工时',   `tsh_person_normal_day` float default NULL COMMENT '正常工时',   `tsh_person_over_day` float default NULL COMMENT '加班工时',   `tsh_progress` float default NULL COMMENT '[废除]实际参考进度',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   `table_status` varchar(3) collate utf8_unicode_ci default NULL COMMENT '实体状态',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='进度信息(版本)';
 
--pmt_project--
CREATE TABLE `pmt_project` (   `id` int(11) NOT NULL auto_increment,   `code` varchar(100) collate utf8_unicode_ci default NULL COMMENT '代码',   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `manager_id` int(11) default NULL COMMENT '项目经理',   `adv_begin_date` date default NULL COMMENT '预计开始时间',   `config_user_id` int(11) NOT NULL COMMENT '配置管理员',   `adv_end_date` date default NULL COMMENT '预计结束时间',   `customer_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '项目客户',   `project_level` varchar(3) collate utf8_unicode_ci default NULL COMMENT '项目级别',   `content` text collate utf8_unicode_ci COMMENT '描述',   `url` varchar(100) collate utf8_unicode_ci default NULL COMMENT '链接地址',   `status` varchar(3) collate utf8_unicode_ci default NULL COMMENT '状态:PMT01',   `security_type` varchar(3) collate utf8_unicode_ci NOT NULL COMMENT '安全级别',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='项目信息';
 
--pmt_project_joblevel--
CREATE TABLE `pmt_project_joblevel` (   `id` int(11) NOT NULL auto_increment,   `code` varchar(100) collate utf8_unicode_ci default NULL COMMENT '代码',   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `memo` text collate utf8_unicode_ci COMMENT '备注',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='项目岗位级别';
 
--pmt_project_member--
CREATE TABLE `pmt_project_member` (   `id` int(11) NOT NULL auto_increment,   `project_id` int(11) default NULL COMMENT '项目',   `user_id` int(11) default NULL COMMENT '成员',   `adv_begin_date` date default NULL COMMENT '预计开始时间',   `adv_end_date` date default NULL COMMENT '预计截至时间',   `user_rate` int(11) default NULL COMMENT '使用率',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='项目成员';
 
--pmt_task--
CREATE TABLE `pmt_task` (   `id` int(11) NOT NULL auto_increment,   `project_id` int(11) default NULL COMMENT '项目',   `module_id` int(11) default NULL COMMENT '项目模块',   `parent_task_id` int(11) default NULL COMMENT ' 父任务',   `code` varchar(100) collate utf8_unicode_ci default NULL COMMENT '代码',   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `module_type_task_id` int(11) default NULL COMMENT '任务类型',   `manager_id` int(11) default NULL COMMENT '项目经理',   `content` text collate utf8_unicode_ci COMMENT '描述',   `url` varchar(100) collate utf8_unicode_ci default NULL COMMENT '链接地址',   `ticket_type` varchar(3) collate utf8_unicode_ci default NULL COMMENT '任务类型:PMT02',   `status` varchar(3) collate utf8_unicode_ci default NULL COMMENT '状态:PM04',   `proirity` varchar(3) collate utf8_unicode_ci default NULL COMMENT '优先级:PM06',   `constraint_type` varchar(3) collate utf8_unicode_ci default NULL COMMENT '约束类型',   `constraint_time` date default NULL COMMENT '约束时间',   `no` int(11) default NULL COMMENT '次序',   `spr_tree_type` varchar(3) collate utf8_unicode_ci default NULL COMMENT '树节点类型:SYS07',   `type_ms_id` int(11) default NULL COMMENT '里程碑',   `work_calc_type` varchar(3) collate utf8_unicode_ci default NULL COMMENT '工作量计算',   `business_person_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '业务对口人',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   `source_id` int(11) default NULL COMMENT '来源ID',   `source_value` varchar(50) collate utf8_unicode_ci default NULL COMMENT '来源值',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='任务信息';
 
--pmt_task_depend--
CREATE TABLE `pmt_task_depend` (   `id` int(11) NOT NULL auto_increment,   `task_id` int(11) default NULL COMMENT '项目',   `depend_task_id` int(11) default NULL COMMENT '前置任务',   `depend_type` varchar(3) collate utf8_unicode_ci default NULL COMMENT '前置关系',   `delay_day` int(11) default NULL COMMENT '延迟天数',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='任务前置关系';
 
--pmt_task_favorite--
CREATE TABLE `pmt_task_favorite` (   `id` int(11) NOT NULL auto_increment,   `task_id` int(11) default NULL COMMENT '任务',   `type` varchar(3) collate utf8_unicode_ci default NULL COMMENT '收藏类型',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`),   KEY `ix_pmt_task_favorite_task_id` (`task_id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='任务收藏夹';
 
--pmt_task_follow--
CREATE TABLE `pmt_task_follow` (   `id` int(11) NOT NULL auto_increment,   `task_id` int(11) default NULL COMMENT '任务',   `module_follow_id` int(11) default NULL COMMENT '后续处理类型',   `follow_task_id` int(11) default NULL COMMENT '后续处理任务',   `desc` varchar(300) collate utf8_unicode_ci default NULL COMMENT '描述',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='后续任务';
 
--pmt_task_member--
CREATE TABLE `pmt_task_member` (   `id` int(11) NOT NULL auto_increment,   `task_id` int(11) default NULL COMMENT '项目',   `user_id` int(11) default NULL COMMENT '成员',   `adv_begin_date` date default NULL COMMENT '预计开始时间',   `adv_end_date` date default NULL COMMENT '预计截至时间',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`),   KEY `ix_pmt_task_member_task_id` (`task_id`),   KEY `ix_pmt_task_member_user_id` (`user_id`),   KEY `ix_pmt_task_member_is_deleted` (`is_deleted`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='任务成员';
 
--pmt_task_source_config--
CREATE TABLE `pmt_task_source_config` (   `id` int(11) NOT NULL auto_increment,   `name` varchar(50) collate utf8_unicode_ci default NULL COMMENT '来源名称',   `get_url` varchar(255) collate utf8_unicode_ci default NULL COMMENT '获取信息URL',   `depend_method` varchar(255) collate utf8_unicode_ci default NULL COMMENT '依赖',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='任务来源配置';
 
--pmt_task_tsheet--
CREATE TABLE `pmt_task_tsheet` (   `id` int(11) NOT NULL auto_increment,   `task_id` int(11) default NULL COMMENT '任务',   `hours` float(11,1) default NULL COMMENT '正常工时',   `ext_hours` float(11,1) NOT NULL COMMENT '加班工时',   `time_type` varchar(3) collate utf8_unicode_ci default NULL COMMENT '[废弃]工作类型PMT06',   `occure_date` date default NULL COMMENT '发生时间',   `memo` varchar(500) collate utf8_unicode_ci default NULL COMMENT '备注',   `status` varchar(3) collate utf8_unicode_ci default NULL COMMENT '状态:PM04',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`),   KEY `ix_pmt_task_tsheet_task_id` (`task_id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='任务工时';
 
--pmt_version_project--
CREATE TABLE `pmt_version_project` (   `id` int(11) NOT NULL auto_increment,   `project_id` int(11) default NULL COMMENT '项目',   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `memo` varchar(500) collate utf8_unicode_ci default NULL COMMENT '描述',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='项目信息(版本)';
 
--rac_privilege--
CREATE TABLE `rac_privilege` (   `id` int(11) NOT NULL auto_increment,   `code` varchar(100) collate utf8_unicode_ci default NULL COMMENT '代码',   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `memo` varchar(100) collate utf8_unicode_ci default NULL COMMENT '备注',   `dim_table_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '维度实体表',   `is_current_dim_parent` varchar(3) collate utf8_unicode_ci default NULL COMMENT '父权限是否当前维度',   `parent_privilege_code` varchar(100) collate utf8_unicode_ci default NULL COMMENT '父维度权限',   `after_call_business_module` varchar(10) collate utf8_unicode_ci default NULL COMMENT '执行完调用方法模块类名',   `after_call_business_class` varchar(50) collate utf8_unicode_ci default NULL COMMENT '执行完调用方法类名',   `after_call_method` varchar(100) collate utf8_unicode_ci default NULL COMMENT '执行完调用方法',   `after_delete_method` varchar(100) collate utf8_unicode_ci default NULL COMMENT '执行完删除方法',   `after_fill_field` varchar(100) collate utf8_unicode_ci default NULL COMMENT '执行完自动置入值字段名',   `is_only_one` varchar(3) collate utf8_unicode_ci default NULL COMMENT '是否只有一个成员',   `system_id` int(11) default NULL COMMENT '参考所属系统',   `no` varchar(3) collate utf8_unicode_ci default NULL COMMENT '排序',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`),   UNIQUE KEY `NewIndex1` (`code`) ) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO `rac_privilege` VALUES ('1', 'PMT', '菜单:项目管理PMTT', '', '', '', '', '', '', '', '', '', '', '200003', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('2', 'PMT10', '菜单:项目信息', '', '', '', '', '', '', '', '', '', '', '200003', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('3', 'PMT20', '菜单:模块管理', '', '', '', '', '', '', '', '', '', '', '200003', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('4', 'PMT40', '菜单:任务信息', '', '', '', '', '', '', '', '', '', '', '200003', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('5', 'PMT43', '菜单:任务查询', '', '', '', '', '', '', '', '', '', '', '200003', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('6', 'PMT45', '菜单:我的任务', '', '', '', '', '', '', '', '', '', '', '200003', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('7', 'PMT50', '菜单:工时填报', '', '', '', '', '', '', '', '', '', '', '200003', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('8', 'PMT60', '菜单:基线管理', '', '', '', '', '', '', '', '', '', '', '200003', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('14', 'RDS', '菜单:租赁管理', '', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('15', 'RDS10', '菜单:基础数据', '', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('16', 'RDS1010', '菜单:基础数据#设备维护', '', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('17', 'RDS1020', '菜单:基础数据#客户管理', '', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('18', 'RDS20', '菜单:销售管理', '', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('19', 'RDS2010', '菜单:销售管理#订单管理', '', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('20', 'RDS2020', '菜单:销售管理#销售客户管理', '', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('21', 'RDS30', '菜单:仓库管理', '', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('22', 'RDS3010', '菜单:仓库管理#库存管理', '', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('23', 'RDS3020', '菜单:仓库管理#订单管理', '', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('24', 'RDS40', '菜单:财务管理', '', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('25', 'RDS4010', '菜单:财务管理#订单管理', '', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('26', 'RDS50', '菜单:业务监察', '', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('27', 'RDS5010', '菜单:业务监察#订单管理', '', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('28', 'RDS5020', '菜单:业务监察#订单管理(分公司)', '', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('30', 'PMT#R#3001', '业务:项目经理权限', '配合业务中的项目经理字段', 'PMT_PROJECT', '', '', 'Pmt', 'AppProjectBusiness', 'rac_updateProjectMember', 'rac_deleteProjectMember', 'manager_id', '1', '200003', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('31', 'PMT#R#3002', '业务:项目配置权限', '配合业务中的配置人员字段', 'PMT_PROJECT', '', '', 'Pmt', 'AppProjectBusiness', 'rac_updateProjectMember', 'rac_deleteProjectMember', 'config_user_id', '1', '200003', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('32', 'PMT#R#3003', '业务:项目成员权限', '', 'PMT_PROJECT', '', '', 'Pmt', 'AppProjectBusiness', 'rac_updateProjectMember', 'rac_deleteProjectMember', '', '', '200003', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('37', 'PMT#B#0001', '业务:项目新增', '项目新增权限', '', '', '', '', '', '', '', '', '', '200003', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('38', 'PMT#B#0002', '业务:项目配置权限', '项目修改/成员设置', 'PMT_PROJECT', '', '', '', '', '', '', '', '', '200003', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('39', 'PMT#B#0003', '业务:项目角色设置', '项目角色的设置(项目经理不能设置)', 'PMT_PROJECT', '', '', '', '', '', '', '', '', '200003', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('40', 'RDS60', '菜单:报备管理', '', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('41', 'RDS#B#0001', '业务:总公司', '用于定义是否总公司', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('42', 'RDS#B#0002', '业务:分公司', '用于定义是否分公司', '', '', '', '', '', '', '', '', '', '200001', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('43', 'UUP70', '菜单:公告查看', 'PMT项目的公告查看', '', '', '', '', '', '', '', '', '', '200003', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('44', 'UUP70#B#0001', '业务:公告维护', '公告维护管理', '', '', '', '', '', '', '', '', '', '200003', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('45', 'UUP50', '菜单:帐号管理', '', '', '', '', '', '', '', '', '', '0', '1000', '', '1', '1', '0', '2012-02-15 12:39:13', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('46', 'RDS#R#2005', '租赁分公司监管', '', '', '0', '', '', '', '', '', '', '', '200001', '', '1', '1', '0', '2012-02-19 13:57:38', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('47', 'RDS#R#2004', '租赁仓管', '', '', '0', '', '', '', '', '', '', '0', '200001', '', '1', '1', '0', '2012-02-19 13:58:21', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('48', 'RDS#R#2003', '租令销售', '', '', '0', '', '', '', '', '', '', '0', '200001', '', '1', '1', '0', '2012-02-19 13:59:02', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('49', 'RDS#R#2002', '租赁总公司监管', '', '', '0', '', '', '', '', '', '', '0', '200001', '', '1', '1', '0', '2012-02-19 13:59:22', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_privilege` VALUES ('50', 'RDS#R#2001', '租赁财务', '', '', '0', '', '', '', '', '', '', '0', '200001', '', '1', '1', '0', '2012-02-19 13:59:52', '1', '0000-00-00 00:00:00', '0'); 
 
--rac_role--
CREATE TABLE `rac_role` (   `id` int(11) NOT NULL auto_increment,   `dim_id` int(11) default NULL,   `code` varchar(100) collate utf8_unicode_ci default NULL COMMENT '代码',   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `memo` text collate utf8_unicode_ci COMMENT '描述',   `is_only_one` varchar(3) collate utf8_unicode_ci default NULL COMMENT '是否只有一个成员',   `is_current_dim_parent` varchar(3) collate utf8_unicode_ci default NULL COMMENT '父权限是否当前维度',   `parent_privilege_code` varchar(100) collate utf8_unicode_ci default NULL COMMENT '父维度权限',   `assign_function_code` varchar(100) collate utf8_unicode_ci default NULL COMMENT '授权权限代码',   `select_url` varchar(500) collate utf8_unicode_ci default NULL COMMENT '实体选择URL',   `no` varchar(3) collate utf8_unicode_ci default NULL COMMENT '排序',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=3006 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO `rac_role` VALUES ('1000', '1', '', '任务类型公司', 'PMT任務管理', '1', '1', '', '', '/Pmt/index.php/AppSelect/queryEmployeeAssignInfo', '010', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-01-28 16:03:13', '1'); 
INSERT INTO `rac_role` VALUES ('1001', '1', '', '租令订单总公司', '租赁业务模块,有销售/仓库/监管和财务等业务上的权限', '', '', '', '', '/Pmt/index.php/AppSelect/queryEmployeeAssignInfo', '020', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-01-26 23:17:14', '1'); 
INSERT INTO `rac_role` VALUES ('1002', '1', '', '租赁订单分公司', '租赁业务模块,有销售/仓库和监管等业务上的权限', '', '', '', '', '', '030', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-01-26 23:18:12', '1'); 
INSERT INTO `rac_role` VALUES ('2001', '2', '', '租赁财务', '', '', '1', 'RDS#B#0001', '', '', '030', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-02-19 14:00:12', '1'); 
INSERT INTO `rac_role` VALUES ('2002', '2', '', '租赁总公司监管', '', '', '1', 'RDS#B#0001', '', '', '040', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-02-19 14:00:29', '1'); 
INSERT INTO `rac_role` VALUES ('2003', '2', '', '租令销售', '', '', '1', 'RDS', '', '', '010', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-02-19 14:00:42', '1'); 
INSERT INTO `rac_role` VALUES ('2004', '2', '', '租赁仓管', '', '', '1', 'RDS', '', '', '020', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-02-19 14:01:00', '1'); 
INSERT INTO `rac_role` VALUES ('2005', '2', '', '租赁分公司监管', '', '', '', 'RDS#B#0002', '', '', '030', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-02-19 14:01:13', '1'); 
INSERT INTO `rac_role` VALUES ('2101', '2', '', '项目配置角色', '', '1', '', 'PMT', '', '', '020', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-01-28 15:50:35', '1'); 
INSERT INTO `rac_role` VALUES ('2102', '2', '', '部门经理角色', '', '', '', 'PMT', '', '', '010', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role` VALUES ('2103', '2', '', 'PMT游客', '', '', '', 'PMT', '', '', '000', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role` VALUES ('2201', '2', '', '帐号管理', '登录帐号维护', '', '', '', '', '', '000', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-02-15 12:41:48', '1'); 
INSERT INTO `rac_role` VALUES ('3001', '3', '', '项目经理', '', '1', '', '', 'PMT#B#0002', '/Pmt/index.php/AppSelect/queryUupUser', '010', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-02-15 15:20:18', '1'); 
INSERT INTO `rac_role` VALUES ('3002', '3', '', '项目配置', '', '1', '', '', '', '/Pmt/index.php/AppSelect/queryUupUser', '020', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-02-15 15:20:10', '1'); 
INSERT INTO `rac_role` VALUES ('3003', '3', '', '项目成员', '', '', '', '', '', '/Pmt/index.php/AppSelect/queryUupUser', '030', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-02-15 15:19:59', '1'); 
INSERT INTO `rac_role` VALUES ('3004', '2', '', '公告维护角色', '', '0', '', 'PMT', '', '', '', '1', '1', '0', '2012-01-28 15:51:06', '1', '2012-01-28 16:03:27', '1'); 
INSERT INTO `rac_role` VALUES ('3005', '0', '', '', '', '', '', '', '', '', '', '0', '0', '', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
 
--rac_role_assign--
CREATE TABLE `rac_role_assign` (   `id` int(11) NOT NULL auto_increment,   `role_id` int(11) default NULL COMMENT '角色',   `dim_table_id` int(11) default NULL COMMENT '维度ID',   `assign_table_id` int(11) default NULL COMMENT '授权实体ID',   `assign_user_id` int(11) default NULL COMMENT '授权帐号ID',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=303 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO `rac_role_assign` VALUES ('2', '1000', '-100', '2', '2', '1', '1', '1', '2012-03-03 13:24:50', '1', '2012-03-04 00:10:19', '2'); 
INSERT INTO `rac_role_assign` VALUES ('236', '1000', '-100', '1', '1', '1', '1', '1', '2012-02-05 12:30:53', '1', '2012-02-05 12:39:14', '1'); 
INSERT INTO `rac_role_assign` VALUES ('237', '1000', '-100', '1', '1', '1', '1', '1', '2012-02-05 12:39:18', '1', '2012-02-05 12:39:33', '1'); 
INSERT INTO `rac_role_assign` VALUES ('238', '1000', '-100', '1', '1', '1', '1', '1', '2012-02-05 12:40:46', '1', '2012-02-05 12:40:49', '1'); 
INSERT INTO `rac_role_assign` VALUES ('239', '1000', '-100', '1', '1', '1', '1', '1', '2012-02-05 12:40:53', '1', '2012-02-05 12:40:56', '1'); 
INSERT INTO `rac_role_assign` VALUES ('240', '1000', '-100', '1', '1', '1', '1', '1', '2012-02-05 12:41:21', '1', '2012-02-05 12:42:12', '1'); 
INSERT INTO `rac_role_assign` VALUES ('241', '1000', '-100', '1', '1', '1', '1', '1', '2012-02-05 12:42:17', '1', '2012-02-05 12:43:09', '1'); 
INSERT INTO `rac_role_assign` VALUES ('242', '3004', '-100', '1', '1', '1', '1', '0', '2012-02-05 12:43:08', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_assign` VALUES ('243', '2101', '-100', '1', '1', '1', '1', '0', '2012-02-05 12:43:09', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_assign` VALUES ('254', '3001', '39', '1', '1', '1', '1', '1', '2012-02-05 14:41:25', '1', '2012-07-24 22:17:02', '200019'); 
INSERT INTO `rac_role_assign` VALUES ('255', '3001', '35', '1', '1', '1', '1', '0', '2012-02-05 19:51:27', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_assign` VALUES ('291', '3004', '-100', '2', '2', '2', '2', '0', '2012-03-04 00:10:18', '2', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_assign` VALUES ('292', '2103', '-100', '2', '2', '2', '2', '0', '2012-03-04 00:10:18', '2', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_assign` VALUES ('293', '2201', '-100', '2', '2', '2', '2', '0', '2012-03-04 00:10:18', '2', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_assign` VALUES ('294', '2102', '-100', '2', '2', '2', '2', '0', '2012-03-04 00:10:18', '2', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_assign` VALUES ('295', '2101', '-100', '2', '2', '2', '2', '0', '2012-03-04 00:10:18', '2', '0000-00-00 00:00:00', '0'); 
 
--rac_role_dim--
CREATE TABLE `rac_role_dim` (   `id` int(11) NOT NULL auto_increment,   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `code` varchar(100) collate utf8_unicode_ci default NULL COMMENT '代码',   `assign_table_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '授权实体表',   `dim_table_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '维度实体表',   `user_relate_type` varchar(3) collate utf8_unicode_ci default NULL COMMENT '帐号对照关系:RAC01',   `user_relate_value` varchar(300) collate utf8_unicode_ci default NULL COMMENT '帐号对照备用值',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO `rac_role_dim` VALUES ('1', '公司角色类型', 'UUP_ORG_TYPE', 'UUP_ORG', '', '', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_dim` VALUES ('2', '员工角色类型', 'UUP_USER_TYPE', 'UUP_USER', 'UUP_ORG', '', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_dim` VALUES ('3', 'PMT项目成员类型', 'PMT_PROJECT_ROLE', 'UUP_USER', 'PMT_PROJECT', '', '', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
 
--rac_role_privilege--
CREATE TABLE `rac_role_privilege` (   `id` int(11) NOT NULL auto_increment,   `privilege_id` int(11) default NULL,   `role_id` int(11) default NULL,   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO `rac_role_privilege` VALUES ('5', '1', '1000', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-01-25 22:59:08', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('6', '2', '1000', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-01-25 22:59:08', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('7', '3', '1000', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-01-25 22:59:08', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('8', '4', '1000', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-01-25 22:59:08', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('9', '5', '1000', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-01-25 22:59:08', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('10', '6', '1000', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-01-25 22:59:08', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('11', '7', '1000', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-01-25 22:59:08', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('12', '8', '1000', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-01-25 22:59:08', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('13', '9', '1000', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-01-25 22:59:08', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('14', '10', '1000', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-01-25 22:59:08', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('15', '11', '1000', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-01-25 22:59:08', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('16', '12', '1000', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-01-25 22:59:08', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('17', '13', '1000', '0', '0', '0', '0000-00-00 00:00:00', '0', '2012-01-25 22:59:08', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('18', '14', '1001', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('19', '15', '1001', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('20', '16', '1001', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('21', '17', '1001', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('22', '18', '1001', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('23', '19', '1001', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('24', '20', '1001', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('25', '21', '1001', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('26', '22', '1001', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('27', '23', '1001', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('28', '24', '1001', '0', '0', '1', '0000-00-00 00:00:00', '0', '2012-01-26 23:10:24', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('29', '25', '1001', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('30', '26', '1001', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('31', '27', '1001', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('32', '28', '1001', '0', '0', '1', '0000-00-00 00:00:00', '0', '2012-01-26 23:17:14', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('33', '1', '2101', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('34', '2', '2101', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('35', '3', '2101', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('36', '4', '2101', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('37', '5', '2101', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('38', '6', '2101', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('39', '7', '2101', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('40', '8', '2101', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('41', '1', '2102', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('42', '2', '1001', '0', '0', '1', '0000-00-00 00:00:00', '0', '2012-01-26 23:13:32', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('43', '3', '2102', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('44', '4', '2102', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('45', '5', '2102', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('46', '6', '2102', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('47', '7', '2102', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('48', '8', '2102', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('49', '9', '2102', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('50', '10', '2102', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('51', '11', '2102', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('52', '12', '2102', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('53', '13', '2102', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('54', '1', '2103', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('56', '3', '2103', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('57', '4', '2103', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('58', '5', '2103', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('59', '6', '2103', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('60', '7', '2103', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('61', '8', '2103', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('62', '29', '2101', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('63', '29', '2102', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('64', '30', '3001', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('65', '31', '3002', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('66', '32', '3003', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('67', '33', '2101', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('68', '34', '2101', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('69', '26', '1000', '1', '1', '1', '2012-01-25 22:59:04', '1', '2012-01-25 22:59:08', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('70', '35', '2101', '1', '1', '0', '2012-01-25 23:38:28', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('71', '32', '2101', '1', '1', '0', '2012-01-25 23:38:28', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('72', '31', '2101', '1', '1', '0', '2012-01-25 23:38:28', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('73', '30', '2101', '1', '1', '0', '2012-01-25 23:38:28', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('74', '35', '3001', '1', '1', '0', '2012-01-26 11:52:31', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('75', '8', '3001', '1', '1', '0', '2012-01-26 11:52:31', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('76', '7', '3001', '1', '1', '0', '2012-01-26 11:52:31', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('77', '6', '3001', '1', '1', '0', '2012-01-26 11:52:31', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('78', '5', '3001', '1', '1', '0', '2012-01-26 11:52:31', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('79', '4', '3001', '1', '1', '0', '2012-01-26 11:52:31', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('80', '3', '3001', '1', '1', '0', '2012-01-26 11:52:31', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('82', '1', '3001', '1', '1', '0', '2012-01-26 11:52:31', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('83', '39', '3001', '1', '1', '0', '2012-01-26 17:16:04', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('84', '38', '2101', '1', '1', '0', '2012-01-26 21:29:35', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('85', '37', '2101', '1', '1', '0', '2012-01-26 21:29:35', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('86', '9', '3002', '1', '1', '0', '2012-01-26 21:45:13', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('87', '8', '3002', '1', '1', '0', '2012-01-26 21:45:13', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('88', '7', '3002', '1', '1', '0', '2012-01-26 21:45:13', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('89', '6', '3002', '1', '1', '0', '2012-01-26 21:45:13', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('90', '5', '3002', '1', '1', '0', '2012-01-26 21:45:13', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('91', '4', '3002', '1', '1', '0', '2012-01-26 21:45:13', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('92', '3', '3002', '1', '1', '0', '2012-01-26 21:45:13', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('94', '1', '3002', '1', '1', '0', '2012-01-26 21:46:10', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('95', '20', '2003', '1', '1', '0', '2012-01-26 23:02:20', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('96', '19', '2003', '1', '1', '0', '2012-01-26 23:02:20', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('97', '18', '2003', '1', '1', '0', '2012-01-26 23:02:20', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('98', '14', '2003', '1', '1', '0', '2012-01-26 23:02:20', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('99', '40', '2003', '1', '1', '0', '2012-01-26 23:03:32', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('100', '23', '2004', '1', '1', '0', '2012-01-26 23:04:07', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('101', '22', '2004', '1', '1', '0', '2012-01-26 23:04:07', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('102', '21', '2004', '1', '1', '0', '2012-01-26 23:04:07', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('103', '14', '2004', '1', '1', '0', '2012-01-26 23:04:07', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('104', '25', '2001', '1', '1', '0', '2012-01-26 23:04:42', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('105', '24', '2001', '1', '1', '0', '2012-01-26 23:04:42', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('106', '14', '2001', '1', '1', '0', '2012-01-26 23:04:42', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('107', '42', '1001', '1', '1', '1', '2012-01-26 23:10:07', '1', '2012-01-26 23:16:59', '1'); 
INSERT INTO `rac_role_privilege` VALUES ('108', '41', '1001', '1', '1', '0', '2012-01-26 23:10:07', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('109', '40', '1001', '1', '1', '0', '2012-01-26 23:10:07', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('110', '42', '1002', '1', '1', '0', '2012-01-26 23:18:12', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('111', '40', '1002', '1', '1', '0', '2012-01-26 23:18:12', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('112', '28', '1002', '1', '1', '0', '2012-01-26 23:18:12', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('113', '26', '1002', '1', '1', '0', '2012-01-26 23:18:12', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('114', '23', '1002', '1', '1', '0', '2012-01-26 23:18:12', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('115', '22', '1002', '1', '1', '0', '2012-01-26 23:18:12', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('116', '21', '1002', '1', '1', '0', '2012-01-26 23:18:12', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('117', '20', '1002', '1', '1', '0', '2012-01-26 23:18:12', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('118', '19', '1002', '1', '1', '0', '2012-01-26 23:18:12', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('119', '18', '1002', '1', '1', '0', '2012-01-26 23:18:12', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('120', '14', '1002', '1', '1', '0', '2012-01-26 23:18:12', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('121', '27', '2002', '1', '1', '0', '2012-01-26 23:21:58', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('122', '26', '2002', '1', '1', '0', '2012-01-26 23:21:58', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('123', '14', '2002', '1', '1', '0', '2012-01-26 23:21:58', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('124', '28', '2005', '1', '1', '0', '2012-01-26 23:22:30', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('125', '26', '2005', '1', '1', '0', '2012-01-26 23:22:30', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('126', '14', '2005', '1', '1', '0', '2012-01-26 23:22:30', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('127', '43', '1000', '1', '1', '0', '2012-01-28 15:49:49', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('128', '43', '3004', '1', '1', '0', '2012-01-28 15:51:17', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('129', '44', '1000', '1', '1', '0', '2012-01-28 16:03:13', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('130', '44', '3004', '1', '1', '0', '2012-01-28 16:03:27', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('131', '43', '3003', '1', '1', '0', '2012-01-30 12:58:32', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('132', '7', '3003', '1', '1', '0', '2012-01-30 12:58:32', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('133', '6', '3003', '1', '1', '0', '2012-01-30 12:58:32', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('134', '5', '3003', '1', '1', '0', '2012-01-30 12:58:32', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('135', '4', '3003', '1', '1', '0', '2012-01-30 12:58:32', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('136', '3', '3003', '1', '1', '0', '2012-01-30 12:58:32', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('138', '1', '3003', '1', '1', '0', '2012-01-30 12:58:32', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('139', '45', '2201', '1', '1', '0', '2012-02-15 12:41:48', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('140', '50', '2001', '1', '1', '0', '2012-02-19 14:00:12', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('141', '49', '2002', '1', '1', '0', '2012-02-19 14:00:29', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('142', '48', '2003', '1', '1', '0', '2012-02-19 14:00:42', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('143', '47', '2004', '1', '1', '0', '2012-02-19 14:01:00', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('144', '46', '2005', '1', '1', '0', '2012-02-19 14:01:13', '1', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('145', '15', '2004', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `rac_role_privilege` VALUES ('146', '16', '2004', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
 
--sys_help_tree--
CREATE TABLE `sys_help_tree` (   `id` int(11) NOT NULL auto_increment,   `table_name` varchar(30) collate utf8_unicode_ci default NULL COMMENT '数据表',   `node_field_name` varchar(30) collate utf8_unicode_ci default NULL COMMENT '结点字段',   `parent_field_name` varchar(30) collate utf8_unicode_ci default NULL COMMENT '父节点字段',   `cause_where` varchar(100) collate utf8_unicode_ci default NULL COMMENT 'Where条件',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='树形业务辅助表';
INSERT INTO `sys_help_tree` VALUES ('15', 'pmt_task', 'id', 'parent_task_id', 'is_deleted=\'0\'', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0', '0'); 
 
--sys_help_tree_detail--
CREATE TABLE `sys_help_tree_detail` (   `id` int(11) NOT NULL auto_increment,   `help_tree_id` int(11) NOT NULL COMMENT '主表ID',   `node_value` varchar(30) collate utf8_unicode_ci default NULL COMMENT '结点值',   `parent_field_value` varchar(30) collate utf8_unicode_ci default NULL COMMENT '父节点值',   `tree_level` int(11) NOT NULL COMMENT '层数',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`),   KEY `NewIndex1` (`help_tree_id`),   KEY `NewIndex2` (`node_value`),   KEY `NewIndex3` (`parent_field_value`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='树形业务辅助明细表';
 
--sys_key_set--
CREATE TABLE `sys_key_set` (   `id` int(11) NOT NULL auto_increment COMMENT 'ID',   `code` varchar(50) NOT NULL COMMENT '代码',   `name` varchar(50) NOT NULL COMMENT '名称',   `is_deleted` varchar(2) default NULL COMMENT '删除标记',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=100047 DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='数据字典集合';
INSERT INTO `sys_key_set` VALUES ('1', 'SYS01', 'SYS#是否:SYS01', '0'); 
INSERT INTO `sys_key_set` VALUES ('2', 'SYS02', 'SYS#字段类型:SYS02', '0'); 
INSERT INTO `sys_key_set` VALUES ('3', 'SYS03', 'SYS:子表关联类型#SYS03', '0'); 
INSERT INTO `sys_key_set` VALUES ('4', 'SYS04', 'SYS#生成器2字段类型:SYS04', '0'); 
INSERT INTO `sys_key_set` VALUES ('5', 'SYS05', 'SYS#生成器2子项新增类型：SYS05', '0'); 
INSERT INTO `sys_key_set` VALUES ('6', 'SYS06', 'SYS#工作流初始状态类型:SYS04', '0'); 
INSERT INTO `sys_key_set` VALUES ('14', 'xin_bie', '性别', '0'); 
INSERT INTO `sys_key_set` VALUES ('1000', 'UUP03', 'UUP#功能类型:UUP03', '0'); 
INSERT INTO `sys_key_set` VALUES ('1001', 'UUP02', 'UUP#组织类型:UUP02', '0'); 
INSERT INTO `sys_key_set` VALUES ('1002', 'UUP01', 'UUP#父组织关系:UUP01', '0'); 
INSERT INTO `sys_key_set` VALUES ('100001', 'HM07', '设备实体#设备类型HM07', '0'); 
INSERT INTO `sys_key_set` VALUES ('100002', 'HM01', '客户实体#客户类型:HM01', '0'); 
INSERT INTO `sys_key_set` VALUES ('100003', 'HM02', '客户实体#客户规模:HM02', '0'); 
INSERT INTO `sys_key_set` VALUES ('100004', 'HM09', '设备库存#调整类型HM09', '0'); 
INSERT INTO `sys_key_set` VALUES ('100005', 'HM03', '订单#订单类型:HM03', '0'); 
INSERT INTO `sys_key_set` VALUES ('100006', 'HM08', '订单#订单状态:HM08', '0'); 
INSERT INTO `sys_key_set` VALUES ('100007', 'HM06', '订单#支付方式:HM06', '0'); 
INSERT INTO `sys_key_set` VALUES ('100008', 'HM04', '订单#财务状态:HM04', '0'); 
INSERT INTO `sys_key_set` VALUES ('100009', 'HM05', '订单#是否含税:HM05', '0'); 
INSERT INTO `sys_key_set` VALUES ('100011', 'HM10', '订单#支付标记:HM10', '0'); 
INSERT INTO `sys_key_set` VALUES ('100012', 'HM11', '仓库库存日志单据类型:HM11', '0'); 
INSERT INTO `sys_key_set` VALUES ('100013', 'HM12', '仓库库存日志进仓出仓标志:HM12', '0'); 
INSERT INTO `sys_key_set` VALUES ('100014', 'PMS01', 'PMS#模块类型#PMS01', '0'); 
INSERT INTO `sys_key_set` VALUES ('100015', 'PMS02', 'PMS#优先级#PMS02', '0'); 
INSERT INTO `sys_key_set` VALUES ('100016', 'PMS03', 'PMS#FAQ类型#PMS03', '0'); 
INSERT INTO `sys_key_set` VALUES ('100017', 'PMT01', 'PMTT:项目状态#PMT01', '0'); 
INSERT INTO `sys_key_set` VALUES ('100018', 'PMT03', 'PMTT:模块状态#PMT03', '0'); 
INSERT INTO `sys_key_set` VALUES ('100019', 'PMT06', 'PMTT:优先级#PMT06', '0'); 
INSERT INTO `sys_key_set` VALUES ('100020', 'PMT04', 'PMTT:任务状态:PMT04', '0'); 
INSERT INTO `sys_key_set` VALUES ('100021', 'PMT05', 'PMTT:Ticket状态#PMT05', '0'); 
INSERT INTO `sys_key_set` VALUES ('100022', 'PMT02', 'PMTT:任务状态(生成Ticket)#PMT02', '0'); 
INSERT INTO `sys_key_set` VALUES ('100023', 'PMT07', 'PMTT:工时类型#PMT07', '0'); 
INSERT INTO `sys_key_set` VALUES ('100024', 'PMT08', 'PMTT:任务约束类型#PMT08', '0'); 
INSERT INTO `sys_key_set` VALUES ('100025', 'SYS07', 'SYS#树节点类型:SYS07', '0'); 
INSERT INTO `sys_key_set` VALUES ('100026', 'SYS08', 'SYS#工作流按钮提交类型:SYS08', '0'); 
INSERT INTO `sys_key_set` VALUES ('100027', 'PMT09', 'PMTT:工时状态:PMT09', '0'); 
INSERT INTO `sys_key_set` VALUES ('100028', 'PMT10', 'PMTT:项目级别#PMT10', '0'); 
INSERT INTO `sys_key_set` VALUES ('100029', 'PMT11', 'PMTT:前置任务关系#PMT11', '0'); 
INSERT INTO `sys_key_set` VALUES ('100030', 'SYS09', 'SYS#生成器查维类型:SYS09', '0'); 
INSERT INTO `sys_key_set` VALUES ('100031', 'SYS10', 'SYS:生成器查询#SYS10', '0'); 
INSERT INTO `sys_key_set` VALUES ('100032', 'PMT12', 'PMTT:任务工作量计算类型#PMT12', '0'); 
INSERT INTO `sys_key_set` VALUES ('100033', 'PMT13', 'PMTT:生命周期字段显示#PMT13', '0'); 
INSERT INTO `sys_key_set` VALUES ('100034', 'SYS11', 'SYS:月份#SYS11', '0'); 
INSERT INTO `sys_key_set` VALUES ('100035', 'PMT14', 'PMTT:资源状态#PMT14', '0'); 
INSERT INTO `sys_key_set` VALUES ('100036', 'PMT15', 'PMTT:资源配置单状态#PMT15', '0'); 
INSERT INTO `sys_key_set` VALUES ('100037', 'PMT16', 'PMTT:资源申请年#PMT16', '0'); 
INSERT INTO `sys_key_set` VALUES ('100038', 'PMT17', 'PMTT:文档类型#PMT17', '0'); 
INSERT INTO `sys_key_set` VALUES ('100039', 'PMT18', 'PMTT:项目安全级别#PMT08', '0'); 
INSERT INTO `sys_key_set` VALUES ('100040', 'RAC01', 'RAC:角色维度帐号对照关系类型#RAC01', '0'); 
INSERT INTO `sys_key_set` VALUES ('100041', 'UUP04', 'UUP:公告状态#UUP04', '0'); 
INSERT INTO `sys_key_set` VALUES ('100042', 'UUP05', 'UUP:公告标题颜色#UUP05', '0'); 
INSERT INTO `sys_key_set` VALUES ('100043', 'UUP06', 'UUP:公告类型#UUP06', '0'); 
INSERT INTO `sys_key_set` VALUES ('100044', 'HM13', '订单#订单子项上下午#HM13', '0'); 
INSERT INTO `sys_key_set` VALUES ('100045', 'HM14', '订单#订单公司#HM14', '0'); 
INSERT INTO `sys_key_set` VALUES ('100046', 'PMT19', 'PMTT:汇报进度#PMT19', '0'); 
 
--sys_key_value--
CREATE TABLE `sys_key_value` (   `id` int(11) NOT NULL auto_increment COMMENT 'ID',   `code` varchar(50) NOT NULL COMMENT '代码',   `name` varchar(50) NOT NULL COMMENT '名称',   `seq` varchar(10) default NULL COMMENT '排列次序',   `key_id` int(11) NOT NULL COMMENT 'KeyID',   `is_deleted` varchar(50) NOT NULL COMMENT '是否删除',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=215 DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='数据字典值';
INSERT INTO `sys_key_value` VALUES ('1', 'M', '男', '1', '14', '0'); 
INSERT INTO `sys_key_value` VALUES ('2', 'F', '女', '2', '14', '0'); 
INSERT INTO `sys_key_value` VALUES ('3', 'TEXT', 'TEXT输入框', '010', '2', '0'); 
INSERT INTO `sys_key_value` VALUES ('4', 'DICT', 'DICT数据字典', '020', '2', '0'); 
INSERT INTO `sys_key_value` VALUES ('5', 'SQL', 'SQL数据下拉', '030', '2', '0'); 
INSERT INTO `sys_key_value` VALUES ('6', '0', '否', '1', '1', '0'); 
INSERT INTO `sys_key_value` VALUES ('7', '1', '是', '2', '1', '0'); 
INSERT INTO `sys_key_value` VALUES ('10', '010', '菜单', '010', '1000', '0'); 
INSERT INTO `sys_key_value` VALUES ('11', '020', '按钮', '020', '1000', '0'); 
INSERT INTO `sys_key_value` VALUES ('12', '030', '业务权限', '030', '1000', '0'); 
INSERT INTO `sys_key_value` VALUES ('13', '010', '附属子公司', '010', '1002', '0'); 
INSERT INTO `sys_key_value` VALUES ('14', '020', '所属客户', '020', '1002', '0'); 
INSERT INTO `sys_key_value` VALUES ('15', '010', '总公司', '010', '1001', '0'); 
INSERT INTO `sys_key_value` VALUES ('16', '020', '子公司', '020', '1001', '0'); 
INSERT INTO `sys_key_value` VALUES ('17', '030', '客户公司', '030', '1001', '0'); 
INSERT INTO `sys_key_value` VALUES ('18', '010', '同传', '010', '100001', '0'); 
INSERT INTO `sys_key_value` VALUES ('19', '020', '无线导览', '020', '100001', '0'); 
INSERT INTO `sys_key_value` VALUES ('20', '030', '表决器', '030', '100001', '0'); 
INSERT INTO `sys_key_value` VALUES ('21', 'LAB', 'LABEL标签属性', '040', '2', '0'); 
INSERT INTO `sys_key_value` VALUES ('22', 'DAT', 'DATE日期输入框', '050', '2', '0'); 
INSERT INTO `sys_key_value` VALUES ('23', '010', '外资', '010', '100002', '0'); 
INSERT INTO `sys_key_value` VALUES ('24', '020', '中外合资', '020', '100002', '0'); 
INSERT INTO `sys_key_value` VALUES ('25', '030', '内资', '030', '100002', '0'); 
INSERT INTO `sys_key_value` VALUES ('26', '040', '国营', '040', '100002', '0'); 
INSERT INTO `sys_key_value` VALUES ('27', '050', '其他', '050', '100002', '0'); 
INSERT INTO `sys_key_value` VALUES ('28', '010', '50人以下', '010', '100003', '0'); 
INSERT INTO `sys_key_value` VALUES ('29', '020', '50-100人', '020', '100003', '0'); 
INSERT INTO `sys_key_value` VALUES ('30', '030', '100-200人', '030', '100003', '0'); 
INSERT INTO `sys_key_value` VALUES ('31', '040', '200人以上', '040', '100003', '0'); 
INSERT INTO `sys_key_value` VALUES ('32', '010', '增加', '010', '100004', '0'); 
INSERT INTO `sys_key_value` VALUES ('33', '020', '减少', '020', '100004', '0'); 
INSERT INTO `sys_key_value` VALUES ('34', 'T', '同传', '010', '100005', '0'); 
INSERT INTO `sys_key_value` VALUES ('35', 'W', '无线导览', '020', '100005', '0'); 
INSERT INTO `sys_key_value` VALUES ('36', 'B', '表决器', '030', '100005', '0'); 
INSERT INTO `sys_key_value` VALUES ('37', '010', '草稿订单', '010', '100006', '0'); 
INSERT INTO `sys_key_value` VALUES ('38', '020', '仓库待确认', '020', '100006', '0'); 
INSERT INTO `sys_key_value` VALUES ('39', '030', '仓库已确认', '030', '100006', '0'); 
INSERT INTO `sys_key_value` VALUES ('40', '040', '合同号待确认', '040', '100006', '0'); 
INSERT INTO `sys_key_value` VALUES ('41', '050', '订单生效', '050', '100006', '0'); 
INSERT INTO `sys_key_value` VALUES ('42', '060', '订单执行中', '060', '100006', '0'); 
INSERT INTO `sys_key_value` VALUES ('43', '070', '订单执行完成', '070', '100006', '0'); 
INSERT INTO `sys_key_value` VALUES ('44', '080', '订单归档', '080', '100006', '0'); 
INSERT INTO `sys_key_value` VALUES ('45', '100', '订单强制终止', '100', '100006', '0'); 
INSERT INTO `sys_key_value` VALUES ('46', '010', '汇款', '010', '100007', '0'); 
INSERT INTO `sys_key_value` VALUES ('47', '020', '银行转帐', '020', '100007', '0'); 
INSERT INTO `sys_key_value` VALUES ('48', '030', '现金支付', '030', '100007', '0'); 
INSERT INTO `sys_key_value` VALUES ('49', '010', '含税', '010', '100009', '0'); 
INSERT INTO `sys_key_value` VALUES ('50', '020', '不含税', '020', '100009', '0'); 
INSERT INTO `sys_key_value` VALUES ('53', '015', '仓库驳回', '015', '100006', '0'); 
INSERT INTO `sys_key_value` VALUES ('54', '035', '合同号驳回', '035', '100006', '0'); 
INSERT INTO `sys_key_value` VALUES ('55', '0', '未付', '010', '100011', '0'); 
INSERT INTO `sys_key_value` VALUES ('56', '1', '已付', '020', '100011', '0'); 
INSERT INTO `sys_key_value` VALUES ('57', 'S', '手拉手', '040', '100005', '0'); 
INSERT INTO `sys_key_value` VALUES ('58', 'RTX', 'AREA输入框', '060', '2', '0'); 
INSERT INTO `sys_key_value` VALUES ('59', 'SQW', 'SQL数据单选', '070', '2', '0'); 
INSERT INTO `sys_key_value` VALUES ('60', '010', '仓库手动维护', '010', '100012', '0'); 
INSERT INTO `sys_key_value` VALUES ('61', '020', '订单', '020', '100012', '0'); 
INSERT INTO `sys_key_value` VALUES ('63', '010', '进仓', '010', '100013', '0'); 
INSERT INTO `sys_key_value` VALUES ('64', '020', '出仓', '020', '100013', '0'); 
INSERT INTO `sys_key_value` VALUES ('65', '010', '弹出选择', '010', '3', '0'); 
INSERT INTO `sys_key_value` VALUES ('66', '020', '新增选择', '020', '3', '0'); 
INSERT INTO `sys_key_value` VALUES ('67', 'TEXT', 'TEXT', '020', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('68', 'LABEL', 'LABEL', '060', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('69', 'LABEL_SQL', 'LABEL_SQL', '070', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('70', 'LABEL_DICT', 'LABEL_DICT', '080', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('71', 'HIDDEN', 'HIDDEN', '010', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('72', 'TEXTAREA', 'TEXTAREA', '030', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('73', 'SELECT_DICT', 'SELECT_DICT', '090', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('74', 'SELECT_SQL', 'SELECT_SQL', '100', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('75', 'CHECKBOX', 'CHECKBOX', '110', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('76', 'CHECKBOX_DICT', 'CHECKBOX_DICT', '120', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('77', 'CHECKBOX_SQL', 'CHECKBOX_SQL', '130', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('78', 'INPUT_DATE', 'INPUT_DATE', '050', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('79', '000', '没有字表', '010', '5', '0'); 
INSERT INTO `sys_key_value` VALUES ('80', '010', '页面新增子项', '020', '5', '0'); 
INSERT INTO `sys_key_value` VALUES ('81', '020', '弹出选择新增子项', '030', '5', '0'); 
INSERT INTO `sys_key_value` VALUES ('82', 'RICKEDIT', 'RICKEDIT', '040', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('83', '010', '未启动', '', '100014', '0'); 
INSERT INTO `sys_key_value` VALUES ('84', '020', '进行中', '', '100014', '0'); 
INSERT INTO `sys_key_value` VALUES ('85', '030', '暂停中', '', '100014', '0'); 
INSERT INTO `sys_key_value` VALUES ('86', '090', '关闭', '', '100014', '0'); 
INSERT INTO `sys_key_value` VALUES ('87', '010', '低', '', '100015', '0'); 
INSERT INTO `sys_key_value` VALUES ('88', '020', '中', '', '100015', '0'); 
INSERT INTO `sys_key_value` VALUES ('89', '030', '高', '', '100015', '0'); 
INSERT INTO `sys_key_value` VALUES ('90', '080', '已解决', '', '100014', '0'); 
INSERT INTO `sys_key_value` VALUES ('91', '010', '所有状态', '010', '6', '0'); 
INSERT INTO `sys_key_value` VALUES ('92', '020', '包含状态', '020', '6', '0'); 
INSERT INTO `sys_key_value` VALUES ('93', '030', '包含外状态', '030', '6', '0'); 
INSERT INTO `sys_key_value` VALUES ('94', '010', '草稿', '010', '100016', '0'); 
INSERT INTO `sys_key_value` VALUES ('95', '020', '发布', '020', '100016', '0'); 
INSERT INTO `sys_key_value` VALUES ('96', '030', '废弃', '030', '100016', '0'); 
INSERT INTO `sys_key_value` VALUES ('97', '310', '订单调整待审', '310', '100006', '0'); 
INSERT INTO `sys_key_value` VALUES ('98', '320', '订单调整审核', '', '100006', '1'); 
INSERT INTO `sys_key_value` VALUES ('99', '320', '订单调整驳回', '320', '100006', '0'); 
INSERT INTO `sys_key_value` VALUES ('100', '010', '草稿', '010', '100017', '0'); 
INSERT INTO `sys_key_value` VALUES ('101', '020', '已提交', '020', '100017', '0'); 
INSERT INTO `sys_key_value` VALUES ('102', '030', '进行中', '030', '100017', '1'); 
INSERT INTO `sys_key_value` VALUES ('103', '090', '暂停', '090', '100017', '0'); 
INSERT INTO `sys_key_value` VALUES ('104', '100', '关闭', '100', '100017', '0'); 
INSERT INTO `sys_key_value` VALUES ('105', '060', '关闭', '060', '100017', '1'); 
INSERT INTO `sys_key_value` VALUES ('106', 'SELECT_DICT_2', 'SELECT_DICT_2', '105', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('107', 'SELECT_SQL_2', 'SELECT_SQL_2', '106', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('108', '010', '草稿', '010', '100018', '0'); 
INSERT INTO `sys_key_value` VALUES ('109', '020', '已提交', '020', '100018', '0'); 
INSERT INTO `sys_key_value` VALUES ('110', '090', '暂停', '090', '100018', '0'); 
INSERT INTO `sys_key_value` VALUES ('111', '100', '关闭', '100', '100018', '0'); 
INSERT INTO `sys_key_value` VALUES ('112', '010', '高', '010', '100019', '0'); 
INSERT INTO `sys_key_value` VALUES ('113', '020', '中', '020', '100019', '0'); 
INSERT INTO `sys_key_value` VALUES ('114', '030', '低', '030', '100019', '0'); 
INSERT INTO `sys_key_value` VALUES ('115', '010', '草稿', '010', '100020', '0'); 
INSERT INTO `sys_key_value` VALUES ('116', '020', '处理中', '020', '100020', '0'); 
INSERT INTO `sys_key_value` VALUES ('117', '090', '暂停', '090', '100020', '1'); 
INSERT INTO `sys_key_value` VALUES ('118', '100', '已关闭', '100 ', '100020', '0'); 
INSERT INTO `sys_key_value` VALUES ('119', '010', '草稿', '010', '100021', '0'); 
INSERT INTO `sys_key_value` VALUES ('120', '020', '提交', '020', '100021', '0'); 
INSERT INTO `sys_key_value` VALUES ('121', '090', '暂停', '090', '100021', '0'); 
INSERT INTO `sys_key_value` VALUES ('122', '100', '关闭', '100', '100021', '0'); 
INSERT INTO `sys_key_value` VALUES ('123', '010', '正常上班', '010', '100023', '0'); 
INSERT INTO `sys_key_value` VALUES ('124', '020', '日常加班', '020', '100023', '0'); 
INSERT INTO `sys_key_value` VALUES ('125', '030', '周末加班', '030', '100023', '0'); 
INSERT INTO `sys_key_value` VALUES ('126', 'LABEL_SEQ', 'LABEL_SEQ', '082', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('128', '020', 'Must Finish On', '020', '100024', '0'); 
INSERT INTO `sys_key_value` VALUES ('130', 'LABEL_PHP', 'LABEL_PHP', '081', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('131', '010', '目录', '010', '100025', '0'); 
INSERT INTO `sys_key_value` VALUES ('132', '020', '叶子', '020', '100025', '0'); 
INSERT INTO `sys_key_value` VALUES ('133', '010', '工作流提交', '010', '100026', '0'); 
INSERT INTO `sys_key_value` VALUES ('134', '020', 'JS提交', '020', '100026', '0'); 
INSERT INTO `sys_key_value` VALUES ('135', '030', '跳转地址', '030', '100026', '0'); 
INSERT INTO `sys_key_value` VALUES ('136', '010', '草稿', '010', '100027', '0'); 
INSERT INTO `sys_key_value` VALUES ('137', '020', '待确认', '020', '100027', '0'); 
INSERT INTO `sys_key_value` VALUES ('138', '030', '驳回', '030', '100027', '0'); 
INSERT INTO `sys_key_value` VALUES ('139', '100', '已确认', '100', '100027', '0'); 
INSERT INTO `sys_key_value` VALUES ('140', '010', 'A级', '010', '100028', '0'); 
INSERT INTO `sys_key_value` VALUES ('141', '020', 'B级', '020', '100028', '0'); 
INSERT INTO `sys_key_value` VALUES ('142', '030', 'C级', '030', '100028', '0'); 
INSERT INTO `sys_key_value` VALUES ('143', '040', 'D级', '040', '100028', '0'); 
INSERT INTO `sys_key_value` VALUES ('144', '010', 'FF', '010', '100029', '0'); 
INSERT INTO `sys_key_value` VALUES ('145', '020', 'FS', '020', '100029', '0'); 
INSERT INTO `sys_key_value` VALUES ('146', '030', 'SF', '030', '100029', '0'); 
INSERT INTO `sys_key_value` VALUES ('147', '040', 'SS', '040', '100029', '0'); 
INSERT INTO `sys_key_value` VALUES ('148', '000', '无', '000', '100030', '0'); 
INSERT INTO `sys_key_value` VALUES ('149', '011', '查维', '010', '100030', '0'); 
INSERT INTO `sys_key_value` VALUES ('150', '010', '查', '020', '100030', '0'); 
INSERT INTO `sys_key_value` VALUES ('151', '001', '维', '030', '100030', '0'); 
INSERT INTO `sys_key_value` VALUES ('152', '000', '无', '000', '100031', '0'); 
INSERT INTO `sys_key_value` VALUES ('153', '011', '页后', '010', '100031', '0'); 
INSERT INTO `sys_key_value` VALUES ('154', '010', '仅页', '020', '100031', '0'); 
INSERT INTO `sys_key_value` VALUES ('155', '001', '仅后', '030', '100031', '0'); 
INSERT INTO `sys_key_value` VALUES ('156', '010', '完全分解', '010', '100032', '0'); 
INSERT INTO `sys_key_value` VALUES ('157', '020', '部分分解', '020', '100032', '0'); 
INSERT INTO `sys_key_value` VALUES ('158', '050', '已完成', '030', '100020', '0'); 
INSERT INTO `sys_key_value` VALUES ('159', 'TEXTURL', 'TEXTURL', '035', '4', '0'); 
INSERT INTO `sys_key_value` VALUES ('160', '010', '时间', '010', '100033', '0'); 
INSERT INTO `sys_key_value` VALUES ('161', '020', '进度', '020', '100033', '0'); 
INSERT INTO `sys_key_value` VALUES ('162', '030', '人日', '030', '100033', '0'); 
INSERT INTO `sys_key_value` VALUES ('163', '040', '工期', '040', '100033', '0'); 
INSERT INTO `sys_key_value` VALUES ('164', '050', '里程碑', '050', '100033', '1'); 
INSERT INTO `sys_key_value` VALUES ('165', '050', '完成', '050', '100018', '0'); 
INSERT INTO `sys_key_value` VALUES ('166', '1', '1月', '010', '100034', '0'); 
INSERT INTO `sys_key_value` VALUES ('167', '2', '2月', '020', '100034', '0'); 
INSERT INTO `sys_key_value` VALUES ('168', '3', '3月', '030', '100034', '0'); 
INSERT INTO `sys_key_value` VALUES ('169', '4', '4月', '040', '100034', '0'); 
INSERT INTO `sys_key_value` VALUES ('170', '5', '5月', '050', '100034', '0'); 
INSERT INTO `sys_key_value` VALUES ('171', '6', '6月', '060', '100034', '0'); 
INSERT INTO `sys_key_value` VALUES ('172', '7', '7月', '070', '100034', '0'); 
INSERT INTO `sys_key_value` VALUES ('173', '8', '8月', '080', '100034', '0'); 
INSERT INTO `sys_key_value` VALUES ('174', '9', '9月', '090', '100034', '0'); 
INSERT INTO `sys_key_value` VALUES ('175', '10', '10月', '100', '100034', '0'); 
INSERT INTO `sys_key_value` VALUES ('176', '11', '11月', '110', '100034', '0'); 
INSERT INTO `sys_key_value` VALUES ('177', '12', '12月', '120', '100034', '0'); 
INSERT INTO `sys_key_value` VALUES ('178', '010', '在职', '010', '100035', '0'); 
INSERT INTO `sys_key_value` VALUES ('179', '020', '离职', '020', '100035', '0'); 
INSERT INTO `sys_key_value` VALUES ('180', '030', '产假', '030', '100035', '0'); 
INSERT INTO `sys_key_value` VALUES ('181', '010', '草稿', '010', '100036', '0'); 
INSERT INTO `sys_key_value` VALUES ('182', '020', '已确认', '020', '100036', '0'); 
INSERT INTO `sys_key_value` VALUES ('183', '2011', '2011', '010', '100037', '0'); 
INSERT INTO `sys_key_value` VALUES ('184', '2012', '2012', '020', '100037', '0'); 
INSERT INTO `sys_key_value` VALUES ('185', '2013', '2013', '030', '100037', '0'); 
INSERT INTO `sys_key_value` VALUES ('186', '2014', '2014', '040', '100037', '0'); 
INSERT INTO `sys_key_value` VALUES ('187', '010', '文件附件', '010', '100038', '0'); 
INSERT INTO `sys_key_value` VALUES ('188', '020', '网页链接', '020', '100038', '0'); 
INSERT INTO `sys_key_value` VALUES ('189', '010', '公开', '010', '100039', '0'); 
INSERT INTO `sys_key_value` VALUES ('190', '020', '仅成员可见', '020', '100039', '0'); 
INSERT INTO `sys_key_value` VALUES ('191', '010', '无关系', '010', '100040', '0'); 
INSERT INTO `sys_key_value` VALUES ('192', '020', 'SQL关系', '020', '100040', '0'); 
INSERT INTO `sys_key_value` VALUES ('193', '010', '草稿', '010', '100041', '0'); 
INSERT INTO `sys_key_value` VALUES ('194', '020', '提交', '020', '100041', '0'); 
INSERT INTO `sys_key_value` VALUES ('195', 'black', '黑色', '010', '100042', '0'); 
INSERT INTO `sys_key_value` VALUES ('196', 'red', '红色', '020', '100042', '0'); 
INSERT INTO `sys_key_value` VALUES ('197', 'green', '绿色', '030', '100042', '0'); 
INSERT INTO `sys_key_value` VALUES ('198', '010', '内容公告', '010', '100043', '0'); 
INSERT INTO `sys_key_value` VALUES ('199', '020', '链接公告', '020', '100043', '0'); 
INSERT INTO `sys_key_value` VALUES ('201', 'P', '百乐萌', '010', '100045', '0'); 
INSERT INTO `sys_key_value` VALUES ('202', 'D', '鼎迈', '020', '100045', '0'); 
INSERT INTO `sys_key_value` VALUES ('203', 'Q', '圣其', '030', '100045', '0'); 
INSERT INTO `sys_key_value` VALUES ('204', 'M', '蒙汉', '040', '100045', '0'); 
INSERT INTO `sys_key_value` VALUES ('205', '10', '10', '010', '100046', '0'); 
INSERT INTO `sys_key_value` VALUES ('206', '20', '20', '020', '100046', '0'); 
INSERT INTO `sys_key_value` VALUES ('207', '30', '30', '030', '100046', '0'); 
INSERT INTO `sys_key_value` VALUES ('208', '40', '40', '040', '100046', '0'); 
INSERT INTO `sys_key_value` VALUES ('209', '50', '50', '050', '100046', '0'); 
INSERT INTO `sys_key_value` VALUES ('210', '60', '60', '060', '100046', '0'); 
INSERT INTO `sys_key_value` VALUES ('211', '70', '70', '070', '100046', '0'); 
INSERT INTO `sys_key_value` VALUES ('212', '80', '80', '080', '100046', '0'); 
INSERT INTO `sys_key_value` VALUES ('213', '90', '90', '090', '100046', '0'); 
INSERT INTO `sys_key_value` VALUES ('214', '100', '100', '100', '100046', '0'); 
 
--sys_mail_list--
CREATE TABLE `sys_mail_list` (   `id` int(11) NOT NULL auto_increment,   `subject` varchar(100) collate utf8_unicode_ci default NULL COMMENT '标题',   `from` varchar(100) collate utf8_unicode_ci default NULL COMMENT '发信人',   `from_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '发信人姓名',   `to` varchar(100) collate utf8_unicode_ci default NULL COMMENT '收信人',   `to_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '收信人姓名',   `toOth` varchar(100) collate utf8_unicode_ci default NULL COMMENT 'toOth',   `content` text collate utf8_unicode_ci COMMENT '内容',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `update_table_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '实际更新表名',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='邮件清单';
 
--sys_mail_list_file--
CREATE TABLE `sys_mail_list_file` (   `id` int(11) NOT NULL auto_increment,   `mail_list_id` int(11) default NULL COMMENT '邮件',   `original_document_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '原始文件名',   `download_document_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '下载文件名',   `path` varchar(200) collate utf8_unicode_ci default NULL COMMENT '下载路径',   `file_ext` varchar(100) collate utf8_unicode_ci default NULL COMMENT '后缀',   `file_size` int(11) default NULL COMMENT '文件大小',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `update_table_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '实际更新表名',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='邮件';
 
--sys_notify_log--
CREATE TABLE `sys_notify_log` (   `id` int(11) NOT NULL auto_increment,   `notify_type` varchar(3) collate utf8_unicode_ci default NULL COMMENT '通知类型',   `notify_code` varchar(100) collate utf8_unicode_ci default NULL COMMENT '通知工具号码',   `table_name` varchar(20) collate utf8_unicode_ci default NULL COMMENT '业务表名',   `table_code` varchar(100) collate utf8_unicode_ci default NULL COMMENT '业务关键字',   `title` varchar(100) collate utf8_unicode_ci default NULL COMMENT ' 标题',   `content` varchar(255) collate utf8_unicode_ci default NULL COMMENT '内容',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='010:邮件020:短信';
 
--sys_sequence--
CREATE TABLE `sys_sequence` (   `id` int(11) NOT NULL auto_increment COMMENT 'id',   `code` varchar(100) collate utf8_unicode_ci NOT NULL COMMENT '编号',   `name` varchar(100) collate utf8_unicode_ci NOT NULL COMMENT '名称',   `row_1` varchar(100) collate utf8_unicode_ci NOT NULL COMMENT '名称',   `row_2` varchar(100) collate utf8_unicode_ci NOT NULL COMMENT '名称',   `row_3` varchar(100) collate utf8_unicode_ci NOT NULL COMMENT '名称',   `row_4` varchar(100) collate utf8_unicode_ci NOT NULL COMMENT '名称',   `row_5` varchar(100) collate utf8_unicode_ci NOT NULL COMMENT '名称',   `val` int(11) default NULL,   `is_deleted` varchar(2) collate utf8_unicode_ci NOT NULL COMMENT '删除状态',   `create_user_id` int(11) NOT NULL COMMENT '创建人',   `create_time` datetime NOT NULL COMMENT '创建时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `update_time` datetime default NULL COMMENT '修改时间',   `sys_row_1` varchar(100) collate utf8_unicode_ci default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='序列号实体';
 
--sys_sflow--
CREATE TABLE `sys_sflow` (   `id` int(11) NOT NULL auto_increment,   `code` varchar(100) collate utf8_unicode_ci default NULL COMMENT '代码',   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '名称',   `module_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '所在模块名',   `table_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '管理表名(可以为view,但必须包含实际更新表名所有字段)',   `bs_field` varchar(100) collate utf8_unicode_ci default NULL COMMENT '单据号字段',   `bs_field_wheresql` varchar(100) collate utf8_unicode_ci default NULL COMMENT '单据号字段查询WHERE条件',   `bs_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '单据名称',   `status_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '状态名称',   `status_field` varchar(100) collate utf8_unicode_ci default NULL COMMENT '状态字段',   `status_dict` varchar(100) collate utf8_unicode_ci default NULL COMMENT '状态数据字典',   `flow_class` varchar(100) collate utf8_unicode_ci default NULL COMMENT '工作流实现类',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `update_table_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '实际更新表名',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='状态流';
INSERT INTO `sys_sflow` VALUES ('1', 'hm_rds_order', '订单状态流', 'HmRds', 'hm_rds_order', 'order_num', 'is_deleted=\'0\'', '订单号', '订单状态', 'status', 'HM08', 'HmRds.Sflow.HmRdsOrderSflow', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', 'hm_rds_order'); 
INSERT INTO `sys_sflow` VALUES ('2', 'pmt_project', 'PMTT项目', 'Pmt', 'pmt_project', 'code', 'is_deleted=\'0\'', '项目', '项目状态', 'status', 'PMT01', 'Pmt.Sflow.ProjectSflow', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', 'pmt_project'); 
INSERT INTO `sys_sflow` VALUES ('3', 'pmt_module', 'PMTT模块', 'Pmt', 'pmt_module', 'code', 'is_deleted=\'0\'', '模块', '模块状态', 'status', 'PMT03', 'Pmt.Sflow.ModuleSflow', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', 'pmt_module'); 
INSERT INTO `sys_sflow` VALUES ('4', 'pmt_task', 'PMTT任务', 'Pmt', 'pmt_task', 'code', 'is_deleted=\'0\'', '任务', '任务状态', 'status', 'PMT04', 'Pmt.Sflow.TaskSflow', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', 'pmt_task'); 
INSERT INTO `sys_sflow` VALUES ('5', 'pmt_task_tsheet', '任务工时', 'Pmt', 'pmt_task_tsheet', 'id', 'is_deleted=\'0\'', '工时', '工时状态', 'status', 'PMT09', 'Pmt.Sflow.TaskTsheetSflow', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', 'pmt_task_tsheet'); 
 
--sys_sflow_d--
CREATE TABLE `sys_sflow_d` (   `id` int(11) NOT NULL auto_increment,   `flow_d_code` varchar(3) collate utf8_unicode_ci default NULL COMMENT '工作流子项代码(id*10)',   `flow_d_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '工作流子项名称',   `has_openwindow` varchar(3) collate utf8_unicode_ci default '0' COMMENT '[废弃]是否有弹出框:SYS01',   `flow_id` int(11) default NULL COMMENT '工作流',   `from_status_type` varchar(3) collate utf8_unicode_ci default NULL COMMENT '节点类型010:全部,020:范围内,030:范围外',   `dst_status` varchar(100) collate utf8_unicode_ci default NULL COMMENT '目的状态值',   `user_content` text collate utf8_unicode_ci COMMENT '用户提示内容',   `flow_method` varchar(100) collate utf8_unicode_ci default NULL COMMENT '工作流实现方法',   `function_code` varchar(100) collate utf8_unicode_ci default NULL COMMENT '权限代码,多条逗号分隔',   `business_type` varchar(100) collate utf8_unicode_ci default NULL COMMENT '节点业务类型',   `operation_message` varchar(100) collate utf8_unicode_ci default NULL COMMENT '操作结果',   `no` varchar(3) collate utf8_unicode_ci default NULL COMMENT '排序',   `button_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '按钮名称',   `page_submit_type` varchar(3) collate utf8_unicode_ci default NULL COMMENT '前台页面类型',   `page_submit_js` varchar(100) collate utf8_unicode_ci default NULL COMMENT '前台页面提交值',   `return_url_param` varchar(100) collate utf8_unicode_ci default NULL COMMENT '跳转url的参数',   `input_add_method` varchar(100) collate utf8_unicode_ci default NULL COMMENT '页面新增元素方法',   `has_function_method` varchar(100) collate utf8_unicode_ci default NULL COMMENT '是否有该功能判断方法',   `is_user_function` varchar(3) collate utf8_unicode_ci default NULL COMMENT '是否当前用户权限:SYS01',   `is_user_field` varchar(100) collate utf8_unicode_ci default '0' COMMENT '用户字段',   `is_org_function` varchar(3) collate utf8_unicode_ci default NULL COMMENT '是否当前公司权限:SYS01',   `is_org_field` varchar(100) collate utf8_unicode_ci default '0' COMMENT '公司权限',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='状态流项定义';
INSERT INTO `sys_sflow_d` VALUES ('1', '10', '订单保存', '0', '1', '020', '010', '', 'sumitOrder', '', 'xs', 'message.info.order.save', '000', 'button.save', '020', 'a_window_submit_withoutvalidate(document.ff);', '', '', '', '1', 'sale_user_id', '1', 'org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('2', '20', '订单提交', '0', '1', '020', '020', '', 'sumitOrder', '', 'xs', 'message.info.order.submit', '010', 'button.submit', '010', '', '', '', '', '1', 'sale_user_id', '1', 'org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('3', '30', '订单设备驳回', '1', '1', '020', '015', '驳回原因:', '', '', 'cg', 'message.info.order.ware.reject', '020', 'button.ware.equip.reject', '000', '', '', '', '', '0', '', '1', 'org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('4', '40', '订单设备确认', '0', '1', '020', '030', '审核通过意见是:', 'confirmCgOrder', '', 'cg', 'message.info.order.ware.confirm', '030', 'button.ware.equip.confirm', '010', '', '', '', '', '0', '', '1', 'org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('6', '60', '订单页面关闭', '0', '1', '010', '', '', '', '', '', '', '099', 'page.button.close', '020', 'window.close();', '', '', '', '0', '', '1', 'org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('7', '70', '订单删除', '0', '1', '020', '', '删除订单的原因:', 'deleteOrder', '', 'xs', 'message.success.delete', '080', 'button.delete', '020', 'deleteOrder();', '', '', '', '0', '', '1', 'org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('8', '80', '合同号录入', '1', '1', '020', '040', '', 'updateContactNum', '', 'jc', 'message.info.order.contactnum.inut', '040', 'button.contactnum.input', '000', '', '', 'updateContactNumPage', '', '0', '', '0', 'org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('9', '90', '合同号驳回', '1', '1', '020', '035', '驳回原因:', '', '', 'xs', 'message.fail.order.contactnum.reject', '050', 'button.contactnum.reject', '000', '', '', '', '', '0', '', '1', 'org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('10', '100', '合同号确认', '0', '1', '020', '050', '', '', '', 'xs', 'message.info.order.contactnum.confirm', '060', 'button.contactnum.confirm', '010', '', '', '', '', '0', '', '1', 'org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('11', '110', '订单指派执行', '1', '1', '020', '060', '备注', 'confirmExecutePerson', '', 'cg', 'message.info.order.executeperson.confirm', '070', 'button.executeperson.confirm', '000', '', '', 'confirmExecutePersonPage', '', '0', '', '1', 'org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('12', '120', '设备归还,订单执行结束', '1', '1', '020', '070', '备注', 'confirmExecuteFinish', '', 'cg', 'message.info.order.execute.complete', '080', 'button.executeperson.complete', '000', '', '', 'confirmExecuteFinishPage', 'confirmExecuteFinishHf', '0', '', '1', 'org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('13', '130', '财务预付款确认', '1', '1', '020', '', '备注:', 'confirmAdvAmount', '', 'cw', 'message.info.order.advamount.confirm', '090', 'button.advamount.confirm', '000', '', '', 'confirmAdvAmountPage', 'confirmAdvAmountHf', '0', '', '0', 'org_id', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('14', '140', '尾款支付确认', '1', '1', '020', '', '备注:', 'confirmFinalAmount', '', 'cw', 'message.info.order.finalamount.confirm', '091', 'button.finalamount.confirm', '000', '', '', 'confirmFinalAmountPage', 'confirmFinalAmountHf', '0', '', '0', 'org_id', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('15', '150', '订单终止', '1', '1', '020', '100', '备注:', 'terminateOrder', '', 'jc', 'message.info.order.terminate.confirm', '110', 'button.terminate.confirm', '000', '', '', '', '', '0', '0', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('16', '160', '订单开票', '1', '1', '010', '', '备注:', 'billInvoice', '', 'cw', 'message.info.order.bill.invoice', '129', 'button.bill.invoice', '000', '', '', 'billInvoicePage', 'billInvoiceHf', '0', '0', '0', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('17', '170', '备注填写', '1', '1', '010', '', '备注：', '', '', '', 'message.info.order.memo.save', '130', 'button.order.memo', '000', '', '', '', '', '', '0', '', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('18', '180', '订单调整', '0', '1', '020', '310', '', '', '', 'xs', '', '140', 'button.apply.order.sumbit', '020', 'orderApplySubmit();', '', '', '', '1', 'sale_user_id', '1', 'org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('19', '190', '订单调整审核', '0', '1', '020', '', '', 'confirmOrderApply', '', 'cg', 'message.info.orderapply.ware.confirm', '150', 'button.orderapply.equip.confirm', '010', '', '', '', '', '0', '0', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('20', '200', '订单审核驳回', '1', '1', '020', '320', '备注:', 'rejectOrderApply', '', 'cg', 'message.info.orderapply.ware.reject', '160', 'button.orderapply.equip.reject', '000', '', '', '', '', '0', '0', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('21', '210', '订单调整删除', '1', '1', '020', '320', '备注:', 'cancelOrderApply', '', 'xs', 'message.info.orderapply.ware.cancel', '170', 'button.orderapply.equip.cancel', '000', '', '', '', '', '1', 'sale_user_id', '1', 'org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('22', '220', '订单支付', '1', '1', '010', '', '备注:', 'payOrder', '', 'cw', 'message.info.order.pay', '180', 'button.order.pay', '000', '', '', 'payOrderPage', '', '0', '0', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('23', '230', '奖金', '1', '1', '010', '', '备注:', 'calcBonus', '', 'cw', 'message.info.calc.bonus', '190', 'button.order.bonus', '000', '', '', 'calcBonusPage', 'calcBonusHf', '0', '0', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('24', '240', '成本', '1', '1', '010', '', '备注:', 'calcActualCost', '', 'cw', 'message.info.calc.actualcost', '200', 'button.order.actual_cost', '000', '', '', 'calcActualCostPage', 'calcActualCostHf', '0', '0', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('25', '250', '回扣', '1', '1', '010', '', '备注:', 'calcRebate', '', 'cw', 'message.info.rebate', '210', 'button.order.rebate', '000', '', '', 'calcRebatePage', 'calcRebateHf', '0', '0', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('26', '260', '修复并关闭', '0', '2', '020', '100', '', '', 'PMT#B#0002', '', 'message.success.operate', '010', 'page.button.fixclose', '010', '', '', '', '', '0', '0', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('27', '270', '关闭模块', '0', '3', '020', '100', '', 'closeModule', '', '', 'message.success.operate', '010', 'page.button.close.module', '010', '', '', '', 'closeModuleHf', '0', '0', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('28', '280', '完成任务', '0', '4', '020', '050', '', 'finishTask', '', '', 'message.success.operate', '010', 'page.button.finish.task', '010', '', '', '', 'finishTaskHf', '0', 'belong_user_id', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('29', '290', '修改任务', '0', '4', '010', '', '', '', '', '', '', '020', 'page.button.update', '030', '__APP__/Task/editTaskPage?id={1}', '', '', 'editTaskHf', '0', 'belong_user_id', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('30', '300', '新增子任务', '0', '4', '010', '', '', '', '', '', '', '030', 'page.button.addchild', '030', '__APP__/Task/editTaskPage?id=&parent_task_id={1}&spr_tree_type=020&id=', '', '', 'addChildTaskHf', '0', 'belong_user_id', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('31', '310', '删除任务', '0', '4', '010', '', '', '', '', '', '', '040', 'page.button.delete', '030', '__APP__/Task/deleteTask?id={1}', '', '', 'deleteTaskHf', '1', 'belong_user_id', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('32', '320', '修改项目信息', '0', '2', '010', '', '', '', 'PMT#B#0002,PMT#B#0003', '', '', '020', 'page.button.update', '030', '__APP__/Project/editProjectPage?id={1}', '', '', '', '0', '0', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('33', '330', '删除项目信息', '0', '2', '010', '', '', '', 'PMT#B#0002', '', '', '030', 'page.button.delete', '030', '__APP__/Project/deleteProject?id={1}', '', '', '', '0', '0', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('34', '340', '修改模块模块', '0', '3', '010', '', '', '', '', '', 'message.success.operate', '', 'page.button.update', '030', '__APP__/Module/editModulePage?id={1}', '', '', '', '1', 'belong_user_id', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('35', '350', '删除模块模块', '0', '3', '010', '', '', '', '', '', 'message.success.operate', '', 'page.button.delete', '030', '__APP__/Module/deleteModule?id={1}', '', '', '', '1', 'belong_user_id', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('36', '360', '修改工时填报', '0', '5', '020', '', '', '', '', '', '', '010', 'page.button.update', '030', '__APP__/TaskTsheet/editTaskTsheetPage?id={1}', '', '', '', '1', 'belong_user_id', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('37', '370', '删除工时填报', '0', '5', '020', '', '', '', '', '', '', '020', 'page.button.delete', '030', '__APP__/TaskTsheet/deleteTaskTsheet?id={1}', '', '', '', '1', 'belong_user_id', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('38', '380', '审核工时', '0', '5', '020', '100', '', 'confirmTsheet', '', '', '', '030', 'page.button.audit', '010', '', '', '', 'confirmTimeSheetHf', '0', 'belong_user_id', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('39', '390', '驳回工时', '1', '5', '020', '010', '驳回的原因：', '', '', '', '', '040', 'page.button.reject', '000', '', '', '', 'rejectTimeSheetHf', '0', 'belong_user_id', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('40', '400', '填写工时', '0', '4', '010', '', '', '', '', '', '', '050', 'page.button.filltimesheet', '030', '__APP__/TaskTsheet/editTaskTsheetPage?task_id={1}', '', '', 'fillTimeSheetHf', '0', '0', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('41', '410', '汇报进度', '1', '4', '010', '', '备注:', 'fillProgress', '', '', 'message.success.operate', '060', 'page.button.fillprogress', '000', '', '', 'fillProgressPage', 'fillProgressHf', '0', '0', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('42', '420', '关闭任务', '0', '4', '020', '100', '', 'closeTask', '', '', 'message.success.operate', '070', 'page.button.close.task', '010', '', '', '', 'closeTaskHf', '0', '0', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('43', '430', '退回完成和关闭任务', '1', '4', '020', '020', '退回的原因；', 'unFinishTask', '', '', 'message.success.operate', '080', 'page.button.unfinish.task', '000', '', '', '', 'unFinishTaskHf', '0', '0', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('44', '440', '完成模块', '0', '3', '020', '050', '', 'finishModule', '', '', 'message.success.operate', '', 'page.button.finish.module', '010', '', '', '', 'finishModuleHf', '0', '0', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('45', '450', '暂停模块', '0', '3', '020', '090', '', 'stopModule', '', '', 'message.success.operate', '', 'page.button.stop.module', '010', '', '', '', 'stopModuleHf', '0', '0', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('46', '460', '激活模块', '1', '3', '020', '020', '激活的原因:', 'activeModule', '', '', 'message.success.operate', '', 'page.button.active.module', '000', '', '', '', 'activeModuleHf', '0', '0', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('47', '470', '奖金支付', '1', '1', '010', '', '', 'confirmBonusPay', '', 'cw', 'message.success.operate', '230', 'button.order.bonus_pay', '000', '', '', '', 'confirmBonusPayHf', '0', '0', '0', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('48', '480', '任务转为目录', '0', '4', '010', '', '', 'convertDirectory', '', '', 'message.success.operate', '060', 'page.button.convert.directory', '010', '', '', '', 'convertDirectoryHf', '0', '0', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('49', '490', '任务转为叶子', '0', '4', '010', '', '', 'convertPage', '', '', 'message.success.operate', '070', 'page.button.convert.page', '010', '', '', '', 'convertPageHf', '0', '0', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('50', '500', '模块查看任务清单', '0', '3', '010', '', '', '', '', '', '', '', 'page.button.list.task', '030', '__APP__/Task/queryTask?query_module_id={1}', '', '', '', '0', '0', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('51', '510', '项目查看模块清单', '0', '2', '010', '', '', '', 'PMT#B#0002', '', '', '', 'page.button.list.module', '030', '__APP__/Module/queryModule?query_project_id={1}', '', '', '', '0', '0', '1', 'belong_org_id', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('52', '520', '处理任务', '0', '4', '010', '', '', '', '', '', '', '051', 'page.button.taskprocess', '030', '__APP__/AppTaskTsheet/fillQucikTsheetPage?add_task_id={1}', '', '', 'fillTimeSheetHf', '0', '0', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('53', '530', '移动任务', '1', '4', '', '', '', 'moveProgress', '', '', 'message.success.operate', '070', 'page.button.moveprogress', '000', '', '', 'moveProgressPage', 'moveProgressHf', '0', 'belong_user_id', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('55', '550', '新增子目录', '0', '4', '010', '', '', '', '', '', '', '035', 'page.button.addchilddict', '030', '__APP__/Task/editTaskPage?id=&parent_task_id={1}&spr_tree_type=010&id=', '', '', 'addChildDictTaskHf', '0', 'belong_user_id', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d` VALUES ('56', '560', '激活项目', '0', '2', '020', '020', '', '', 'PMT#B#0002', '', 'message.success.operate', '040', 'page.button.active', '010', '', '', '', '', '0', '0', '1', 'belong_org_id', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
 
--sys_sflow_d_from--
CREATE TABLE `sys_sflow_d_from` (   `id` int(11) NOT NULL auto_increment,   `flow_d_id` int(11) default NULL COMMENT '工作流',   `from_status` varchar(100) collate utf8_unicode_ci default NULL COMMENT '起始状态值',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='状态流项来源状态定义';
INSERT INTO `sys_sflow_d_from` VALUES ('1', '1', '', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('2', '1', '010', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('3', '2', '', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('4', '2', '010', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('5', '3', '020', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('6', '1', '015', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('7', '2', '015', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('8', '4', '020', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('9', '7', '010', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('10', '7', '015', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('11', '8', '030', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('12', '9', '040', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('13', '10', '040', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('14', '8', '035', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('15', '11', '050', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('16', '12', '060', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('17', '13', '050', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('18', '13', '060', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('19', '13', '070', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('20', '14', '050', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('21', '14', '060', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('22', '14', '070', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('23', '15', '030', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('24', '15', '035', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('25', '15', '040', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('26', '15', '050', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('28', '15', '060', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('29', '11', '060', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('30', '19', '310', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('31', '20', '310', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('32', '21', '320', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('33', '18', '030', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('34', '18', '040', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('35', '18', '050', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('36', '18', '060', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('37', '18', '035', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('38', '18', '310', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('39', '18', '320', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('40', '36', '010', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('42', '36', '030', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('43', '37', '010', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('45', '37', '030', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('46', '38', '020', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('47', '39', '020', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('48', '28', '020', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('49', '42', '050', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('50', '43', '050', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('51', '43', '100', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('52', '36', '020', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('54', '27', '050', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('55', '44', '020', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('56', '45', '020', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('57', '45', '050', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('58', '46', '050', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('59', '46', '090', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('60', '46', '100', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('61', '26', '020', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `sys_sflow_d_from` VALUES ('62', '56', '100', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
 
--sys_sflow_log--
CREATE TABLE `sys_sflow_log` (   `id` int(11) NOT NULL auto_increment,   `flow_id` int(11) NOT NULL,   `flow_d_id` int(11) NOT NULL,   `org_id` int(11) default NULL COMMENT '公司',   `org_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '公司名称',   `user_id` int(11) default NULL COMMENT '员工',   `user_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '员工名称',   `from_status` varchar(100) collate utf8_unicode_ci default NULL COMMENT '起始状态值',   `dst_status` varchar(100) collate utf8_unicode_ci default NULL COMMENT '目的状态值',   `business_id` varchar(100) collate utf8_unicode_ci default NULL COMMENT '业务单据记录ID',   `business_num` varchar(100) collate utf8_unicode_ci default NULL COMMENT '业务单据号',   `user_content` varchar(100) collate utf8_unicode_ci default NULL COMMENT '审核意见',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='状态流日志';
 
--sys_software_version--
CREATE TABLE `sys_software_version` (   `id` int(11) NOT NULL auto_increment,   `module_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '模块名',   `version_line` varchar(100) collate utf8_unicode_ci default NULL COMMENT '版本号',   `version_type` varchar(100) collate utf8_unicode_ci default NULL COMMENT '版本类型patch补丁,release释放,beta公测,dev内测',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='软件版本';
INSERT INTO `sys_software_version` VALUES ('1', 'pmt', 'v1.1.0.20120807_alpha', 'alpha', '0', '2012-08-07 22:49:29', '0', '0000-00-00 00:00:00', '0'); 
 
--sys_tool_table--
CREATE TABLE `sys_tool_table` (   `id` int(11) NOT NULL auto_increment COMMENT 'ID',   `table_name` varchar(50) NOT NULL COMMENT '表名',   `table_desc` varchar(50) NOT NULL COMMENT '描述',   `function_code` varchar(50) default NULL COMMENT '功能代码',   `child_type` varchar(3) default NULL COMMENT '子表关联类型#SYS03',   `child_table` varchar(50) default NULL COMMENT '子表名',   `child_id_field` varchar(50) default NULL COMMENT '子表关联字段',   `table_status_field` varchar(50) default NULL COMMENT '主表状态字段',   `table_status_save` varchar(30) default NULL COMMENT '主表草稿状态',   `table_status_submit` varchar(30) default NULL COMMENT '主表提交状态',   `child_entity_id_field` varchar(50) default NULL COMMENT '子表实体关联字段',   `child_entity_select_url` varchar(200) default NULL COMMENT '子表选择URL',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='数据表结构';
 
--sys_tool_table2--
CREATE TABLE `sys_tool_table2` (   `id` int(11) NOT NULL auto_increment COMMENT 'ID',   `table_name` varchar(50) NOT NULL COMMENT '表名',   `table_desc` varchar(50) NOT NULL COMMENT '描述',   `code_module` varchar(50) default NULL COMMENT '代码模块名',   `code_module_method` varchar(50) default NULL COMMENT '代码方法名',   `table_has_status` varchar(50) default NULL COMMENT '是否有状态',   `table_status_field` varchar(50) default NULL COMMENT '主表状态字段',   `table_status_save` varchar(30) default NULL COMMENT '主表草稿状态',   `table_status_submit` varchar(30) default NULL COMMENT '主表提交状态',   `child_type` varchar(30) default NULL COMMENT '子项新增类型',   `child_type_value` varchar(500) default NULL COMMENT '子项新增类型值',   `table_info` text COMMENT '相关属性',   `query_sql_method` text COMMENT '查询SQL方法',   `is_tree` varchar(3) default NULL COMMENT '是否树形',   `tree_parent_field` text COMMENT '树形父节点',   `before_query_method` text COMMENT '查询前的方法',   `before_update_page_method` text COMMENT '修改页前的方法',   `before_update_method` text COMMENT '修改前的方法',   `before_delete_method` text COMMENT '删除前的方法',   `before_get_method` text COMMENT 'Get前的方法',   `after_query_method` text COMMENT '查询后的方法',   `after_update_page_method` text COMMENT '修改页后的方法',   `after_update_method` text COMMENT '修改后的方法',   `after_delete_method` text COMMENT '删除后的方法',   `after_get_method` text COMMENT 'Get后的方法',   `after_db_query_method` text COMMENT 'Query后的方法',   `after_db_add_method` text COMMENT '新增后的方法',   `after_db_update_method` text COMMENT '修改后的方法',   `after_db_au_method` text COMMENT '增改后的方法',   `after_db_delete_method` text COMMENT '删除后的方法',   `after_db_get_method` text COMMENT 'Get后的方法',   `before_db_add_method` text COMMENT '修改前的方法',   `before_db_update_method` text COMMENT '修改前的方法',   `before_db_au_method` text COMMENT '增改前的方法',   `before_db_delete_method` text COMMENT '删除前的方法',   `before_db_get_method` text COMMENT 'Get前的方法',   `after_view_query_method` text COMMENT 'VIEW查询后',   `after_view_add_method` text COMMENT 'VIEW新增后',   `after_view_update_method` text COMMENT 'VIEW修改后',   `after_view_get_method` text COMMENT 'VIEW查看后',   `add_default_value_method` text COMMENT '创建时加默认',   `is_deleted` varchar(2) character set utf8 collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `is_belong_user` varchar(3) default NULL COMMENT '帐号私有',   `is_belong_org` varchar(3) default NULL COMMENT '组织私有',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='数据表结构';
 
--sys_tool_table_field--
CREATE TABLE `sys_tool_table_field` (   `id` int(11) NOT NULL auto_increment COMMENT 'ID',   `table_id` int(11) NOT NULL COMMENT '表名',   `field_name` char(50) default NULL COMMENT '字段名',   `field_type` char(50) default NULL COMMENT '字段类型',   `field_type_value` text COMMENT '字段类型值',   `field_class` char(50) default NULL COMMENT '值限制',   `default_value` char(50) default NULL COMMENT '默认值',   `field_desc` char(50) default NULL COMMENT '描述',   `field_no` char(10) default NULL COMMENT '字段顺序',   `is_manual` char(10) default NULL COMMENT '是否手动',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='数据表字段';
 
--sys_tool_table_field2--
CREATE TABLE `sys_tool_table_field2` (   `id` int(11) NOT NULL auto_increment COMMENT 'ID',   `table_id` int(11) NOT NULL COMMENT '表名',   `field_name` char(50) default NULL COMMENT '字段名',   `field_type` char(50) default NULL COMMENT '字段类型',   `field_type_value` text COMMENT '字段类型值（代码）',   `field_type_desc_value` text COMMENT '字段类型值（非代码）',   `field_class` char(50) default NULL COMMENT '值限制',   `field_desc` char(50) default NULL COMMENT '描述',   `field_no` char(10) default NULL COMMENT '字段顺序',   `is_deleted` varchar(2) default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `has_query_clause` varchar(3) default NULL COMMENT '是否查询条件',   `has_query_result` varchar(3) default NULL COMMENT '是否查询结果',   `size_display` int(11) default NULL COMMENT '显示长度',   `size_max` int(11) default NULL COMMENT '最大长度',   `item_line_class` varchar(50) default NULL COMMENT 'ITEM类型',   `item_control_class` varchar(50) default NULL COMMENT '控件CLASS',   `item_control_param` varchar(50) default NULL COMMENT '控件参数',   `item_info` text COMMENT 'INFO',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='数据表字段';
 
--sys_user_log--
CREATE TABLE `sys_user_log` (   `id` int(11) NOT NULL auto_increment,   `user_id` int(11) default NULL COMMENT '登录帐号',   `user_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '帐号姓名',   `org_id` int(11) default NULL COMMENT '登录组织',   `org_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '组织名称',   `sr_result` varchar(10) collate utf8_unicode_ci default NULL COMMENT '执行结果',   `sr_message` varchar(100) collate utf8_unicode_ci default NULL COMMENT '执行结果信息',   `content` varchar(200) collate utf8_unicode_ci default NULL COMMENT '内容',   `http_referer` varchar(100) collate utf8_unicode_ci default NULL COMMENT '来源',   `http_user_agent` varchar(100) collate utf8_unicode_ci default NULL COMMENT '客户端信息',   `request_method` varchar(100) collate utf8_unicode_ci default NULL COMMENT '提交方法',   `request_uri` varchar(100) collate utf8_unicode_ci default NULL COMMENT 'URL地址',   `ip_addr` varchar(100) collate utf8_unicode_ci default NULL COMMENT 'IP地址',   `post_info` text collate utf8_unicode_ci COMMENT 'POST参数',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `domain_id` int(11) default NULL COMMENT '域',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `sr_message_param` varchar(200) collate utf8_unicode_ci default NULL COMMENT '执行结果参数',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='业务日志';
 
--sys_version--
CREATE TABLE `sys_version` (   `id` int(11) NOT NULL auto_increment,   `table_name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '数据表',   `table_id` int(11) default NULL COMMENT '数据ID',   `name` varchar(100) collate utf8_unicode_ci default NULL COMMENT '基线名称',   `memo` text collate utf8_unicode_ci COMMENT '基线描述',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `spr_version_id` int(11) default NULL,   `spr_version_fid` int(11) default NULL,   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='数据版本';
 
--test--
CREATE TABLE `test` (   `name` varchar(100) collate utf8_unicode_ci default NULL,   `names` text collate utf8_unicode_ci ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO `test` VALUES ('\';', '\';\r\n\r\n\\n\r\n\r\n-'); 
 
--uup_domain--
CREATE TABLE `uup_domain` (   `id` int(11) NOT NULL auto_increment,   `code` varchar(50) collate utf8_unicode_ci default NULL COMMENT '域代码',   `name` varchar(50) collate utf8_unicode_ci default NULL COMMENT '域名称',   `memo` text collate utf8_unicode_ci COMMENT '描述',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='业务域';
INSERT INTO `uup_domain` VALUES ('1', 'MAINDOMAIN', '主业务域', '', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
 
--uup_function--
CREATE TABLE `uup_function` (   `id` int(11) NOT NULL auto_increment,   `domain_id` int(11) default NULL COMMENT '业务域',   `system_id` int(11) default NULL COMMENT '业务系统',   `code` varchar(50) collate utf8_unicode_ci default NULL COMMENT '功能代码',   `name` varchar(50) collate utf8_unicode_ci default NULL COMMENT '功能名称',   `type` varchar(50) collate utf8_unicode_ci default NULL COMMENT '功能类型',   `url` varchar(200) collate utf8_unicode_ci default NULL COMMENT 'URL地址',   `memo` text collate utf8_unicode_ci COMMENT '描述',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `parent_function_id` int(11) default NULL COMMENT '父功能',   `no` varchar(3) collate utf8_unicode_ci default NULL COMMENT '排列顺序',   `is_assign` varchar(3) collate utf8_unicode_ci default NULL COMMENT '是否授权',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=200050 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='业务功能';
INSERT INTO `uup_function` VALUES ('1', '1', '1', 'SPR', 'SPR管理', '010', '', '', '0', '0000-00-00 00:00:00', '0', '2012-02-09 22:31:21', '1', '0', '000', '0'); 
INSERT INTO `uup_function` VALUES ('2', '1', '1', 'SPR10', '数据表管理', '010', 'ManagerSysToolTables2/querySysToolTables2', '', '0', '0000-00-00 00:00:00', '0', '2011-08-13 14:46:28', '1', '1', '010', '0'); 
INSERT INTO `uup_function` VALUES ('3', '1', '2', 'SPR20', '数据字典管理', '010', 'SysKeySet/querySysKeySet', '', '0', '0000-00-00 00:00:00', '0', '2011-08-13 14:45:28', '1', '1', '020', '0'); 
INSERT INTO `uup_function` VALUES ('4', '1', '1', 'SPR30', '数据字典值', '010', 'SysKeyValue/querySysKeyValue', '', '1', '0000-00-00 00:00:00', '0', '2011-08-13 14:45:31', '1', '1', '030', '0'); 
INSERT INTO `uup_function` VALUES ('5', '1', '1', 'SRP50', '工作流定义项管理', '010', 'SysSflow/querySysSflow', '', '0', '0000-00-00 00:00:00', '1', '2011-08-13 19:08:19', '1', '1', '050', '0'); 
INSERT INTO `uup_function` VALUES ('6', '1', '3', 'SPR00', '测试页面', '010', 'DemoStudent2/queryDemoStudent', '', '0', '2011-06-18 12:24:03', '1', '2012-01-21 10:10:08', '1', '1', '000', '0'); 
INSERT INTO `uup_function` VALUES ('7', '1', '2', 'UUP05', '日志查看', '010', 'SysUserLog/querySysUserLog', '', '0', '2011-06-18 14:59:34', '1', '2011-07-02 16:33:37', '1', '1000', '000', '1'); 
INSERT INTO `uup_function` VALUES ('8', '1', '3', 'SPR01', '测试页面2', '010', 'DemoStudent2/queryDemoStudent?query_name=csm&name=csm', '', '0', '2011-06-30 22:26:16', '1', '2011-07-24 09:08:09', '1', '1', '001', '0'); 
INSERT INTO `uup_function` VALUES ('1000', '1', '1000', 'UUP', '系统管理', '010', '', '', '0', '0000-00-00 00:00:00', '0', '2012-02-09 22:27:15', '1', '0', '010', '1'); 
INSERT INTO `uup_function` VALUES ('1001', '1', '1000', 'UUP10', '业务域管理', '010', 'Domain/queryDomain', '', '0', '0000-00-00 00:00:00', '0', '2012-02-09 22:30:54', '1', '1', '110', '0'); 
INSERT INTO `uup_function` VALUES ('1002', '1', '1000', 'UUP20', '应用包管理', '010', 'System/querySystem', '', '0', '0000-00-00 00:00:00', '0', '2012-02-09 22:31:03', '1', '1', '120', '0'); 
INSERT INTO `uup_function` VALUES ('1003', '1', '1000', 'UUP30', '功能管理', '010', 'Function/queryFunction', '', '0', '0000-00-00 00:00:00', '0', '2012-02-09 22:31:21', '1', '1', '130', '0'); 
INSERT INTO `uup_function` VALUES ('1004', '1', '1000', 'UUP40', '组织管理', '010', 'Org/queryOrg', '', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1000', '040', '0'); 
INSERT INTO `uup_function` VALUES ('1005', '1', '1000', 'UUP50', '账号管理', '010', 'User/queryUser', '', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1000', '050', '0'); 
INSERT INTO `uup_function` VALUES ('1006', '1', '1000', 'UUP60', '修改密码', '010', 'AppUser/resetPassword', '', '0', '0000-00-00 00:00:00', '1', '0000-00-00 00:00:00', '0', '1000', '060', '0'); 
INSERT INTO `uup_function` VALUES ('200000', '1', '200000', 'PMS', '项目管理', '010', '', '', '0', '2011-08-02 22:08:44', '1', '2011-08-08 21:45:57', '1', '0', '020', '1'); 
INSERT INTO `uup_function` VALUES ('200001', '1', '200000', 'PMS10', '项目团队', '010', 'Project/queryProject', '', '0', '2011-08-02 22:09:17', '1', '0000-00-00 00:00:00', '0', '200000', '010', '1'); 
INSERT INTO `uup_function` VALUES ('200002', '1', '200000', 'PMS20', '工作模块', '010', 'Module/queryModule?SPR_DEFAULT_query_status=020', '', '0', '2011-08-02 22:09:54', '1', '0000-00-00 00:00:00', '0', '200000', '020', '1'); 
INSERT INTO `uup_function` VALUES ('200003', '1', '200000', 'PMS30', '任务详情', '010', 'ModuleTask/queryModuleTask', '', '0', '2011-08-02 22:10:41', '1', '2011-08-08 21:49:15', '1', '200000', '030', '1'); 
INSERT INTO `uup_function` VALUES ('200004', '1', '200001', 'RDS', '租赁管理', '010', '', '', '0', '2011-08-08 21:46:23', '1', '0000-00-00 00:00:00', '0', '0', '030', '1'); 
INSERT INTO `uup_function` VALUES ('200005', '1', '200001', 'RDS10', '基础数据', '010', '', '', '0', '2011-08-08 21:46:45', '1', '2011-08-08 21:48:27', '1', '200004', '010', '1'); 
INSERT INTO `uup_function` VALUES ('200006', '1', '200001', 'RDS20', '销售管理', '010', '', '', '0', '2011-08-08 21:47:02', '1', '2011-08-08 21:48:34', '1', '200004', '020', '1'); 
INSERT INTO `uup_function` VALUES ('200007', '1', '200001', 'RDS30', '仓库管理', '010', '', '', '0', '2011-08-08 21:47:16', '1', '2011-08-08 21:48:41', '1', '200004', '030', '1'); 
INSERT INTO `uup_function` VALUES ('200008', '1', '200001', 'RDS40', '财务管理', '010', '', '', '0', '2011-08-08 21:47:38', '1', '2011-08-08 21:48:47', '1', '200004', '040', '1'); 
INSERT INTO `uup_function` VALUES ('200009', '1', '200001', 'RDS1010', '设备维护', '010', 'HmEquip/queryHmEquip', '', '0', '2011-08-08 21:49:47', '1', '0000-00-00 00:00:00', '0', '200005', '010', '1'); 
INSERT INTO `uup_function` VALUES ('200010', '1', '200001', 'RDS1020', '客户管理', '010', 'HmCustomer/queryHmCustomer?query_all=1', '', '0', '2011-08-08 21:50:16', '1', '2011-11-07 21:27:17', '1', '200005', '020', '1'); 
INSERT INTO `uup_function` VALUES ('200011', '1', '200001', 'RDS3010', '库存管理', '010', 'HmWareAmount/queryHmWareAmount', '', '0', '2011-08-08 21:51:02', '1', '0000-00-00 00:00:00', '0', '200007', '010', '1'); 
INSERT INTO `uup_function` VALUES ('200012', '1', '200001', 'RDS2010', '订单管理', '010', 'HmRdsOrder/queryXsHmRdsOrder', '', '0', '2011-08-08 21:51:47', '1', '0000-00-00 00:00:00', '0', '200006', '010', '1'); 
INSERT INTO `uup_function` VALUES ('200013', '1', '200001', 'RDS50', '业务监察', '010', '', '', '0', '2011-08-08 21:52:16', '1', '0000-00-00 00:00:00', '0', '200004', '050', '1'); 
INSERT INTO `uup_function` VALUES ('200014', '1', '200001', 'RDS3020', '订单管理', '010', 'HmRdsOrder/queryCgHmRdsOrder', '', '0', '2011-08-08 21:52:45', '1', '0000-00-00 00:00:00', '0', '200007', '020', '1'); 
INSERT INTO `uup_function` VALUES ('200015', '1', '200001', 'RDS4010', '订单管理', '010', 'HmRdsOrder/queryCwHmRdsOrder', '', '0', '2011-08-08 21:53:13', '1', '0000-00-00 00:00:00', '0', '200008', '010', '1'); 
INSERT INTO `uup_function` VALUES ('200016', '1', '200001', 'RDS5010', '订单管理', '010', 'HmRdsOrder/queryJcHmRdsOrder', '', '0', '2011-08-08 21:53:44', '1', '0000-00-00 00:00:00', '0', '200013', '010', '1'); 
INSERT INTO `uup_function` VALUES ('200017', '1', '200001', 'RDS60', '报备管理', '010', 'HmOrderRecord/queryHmOrderRecord', '', '0', '2011-08-08 21:54:15', '1', '0000-00-00 00:00:00', '0', '200004', '060', '1'); 
INSERT INTO `uup_function` VALUES ('200018', '1', '200000', 'PMS40', 'FAQ类型维护', '010', 'Faqtype/queryFaqtype', '', '0', '2011-08-15 12:41:54', '1', '0000-00-00 00:00:00', '0', '200000', '040', '1'); 
INSERT INTO `uup_function` VALUES ('200019', '1', '200000', 'PMS050', 'FAQ维护', '010', 'Faq/queryFaq', '', '0', '2011-08-15 12:42:40', '1', '0000-00-00 00:00:00', '0', '200000', '050', '1'); 
INSERT INTO `uup_function` VALUES ('200020', '1', '200000', 'PMS060', 'FAQ查找', '010', 'Function/searchFaq', '', '0', '2011-08-15 13:12:13', '1', '0000-00-00 00:00:00', '0', '200000', '060', '1'); 
INSERT INTO `uup_function` VALUES ('200021', '1', '200000', 'PMS25', '工作模块(日历)', '010', 'Module/queryModule2', '', '0', '2011-08-15 15:37:12', '1', '0000-00-00 00:00:00', '0', '200000', '025', '1'); 
INSERT INTO `uup_function` VALUES ('200022', '1', '200002', 'BNT10', '记录管理', '010', 'Line/queryLine', '', '0', '2011-09-09 14:58:22', '1', '2011-09-09 14:58:58', '1', '200023', '010', '1'); 
INSERT INTO `uup_function` VALUES ('200023', '1', '200002', 'BNT', '备份记录', '010', '', '', '0', '2011-09-09 14:58:43', '1', '0000-00-00 00:00:00', '0', '0', '040', '1'); 
INSERT INTO `uup_function` VALUES ('200024', '1', '200003', 'PMT', 'TaskPm', '010', '', '', '0', '2011-09-10 23:49:07', '1', '2012-01-28 15:47:55', '1', '0', '050', '1'); 
INSERT INTO `uup_function` VALUES ('200025', '1', '200003', 'PMT10', '项目信息', '010', 'Project/queryProject', '', '0', '2011-09-10 23:50:01', '1', '0000-00-00 00:00:00', '0', '200024', '010', '1'); 
INSERT INTO `uup_function` VALUES ('200026', '1', '200003', 'PMT20', '模块管理', '010', 'Module/queryModule', '', '0', '2011-09-12 23:38:49', '1', '0000-00-00 00:00:00', '0', '200024', '020', '1'); 
INSERT INTO `uup_function` VALUES ('200027', '1', '200003', 'PMT30', '模块里程碑', '010', 'ModuleMs/queryModuleMs', '', '1', '2011-09-14 17:24:35', '1', '2011-09-25 19:18:16', '1', '200024', '030', '1'); 
INSERT INTO `uup_function` VALUES ('200028', '1', '200003', 'PMT40', '任务信息', '010', 'Task/queryTask?query_status=020', '', '0', '2011-09-14 21:56:44', '1', '0000-00-00 00:00:00', '0', '200024', '040', '1'); 
INSERT INTO `uup_function` VALUES ('200029', '1', '200003', 'PMT50', '工时填报', '010', 'TaskTsheet/queryTaskTsheet', '', '0', '2011-09-15 13:31:15', '1', '0000-00-00 00:00:00', '0', '200024', '050', '1'); 
INSERT INTO `uup_function` VALUES ('200030', '1', '200003', 'PMT45', '我的任务', '010', 'AppTaskFavorite/indexFrame', '', '0', '2011-09-26 22:40:37', '1', '2012-01-17 20:35:50', '1', '200024', '045', '1'); 
INSERT INTO `uup_function` VALUES ('200031', '1', '1', 'SRP60', '系统功能', '010', 'AppCommon/listFunction', '', '0', '2011-10-05 16:52:43', '1', '0000-00-00 00:00:00', '0', '1', '060', '0'); 
INSERT INTO `uup_function` VALUES ('200032', '1', '200003', 'PMT60', '基线管理', '010', 'VersionProject/queryVersionProject', '', '0', '2011-10-09 12:27:12', '1', '2011-10-17 22:37:31', '1', '200024', '060', '1'); 
INSERT INTO `uup_function` VALUES ('200033', '1', '200003', 'PMT70', '项目状况', '010', '', '', '0', '2011-10-21 15:42:33', '1', '0000-00-00 00:00:00', '0', '200024', '070', '1'); 
INSERT INTO `uup_function` VALUES ('200034', '1', '200003', 'PMT7010', '工作量统计', '010', 'AppCommon/queryPersonDayStatus', '', '0', '2011-10-21 15:44:06', '1', '2011-11-15 17:35:48', '1', '200033', '010', '1'); 
INSERT INTO `uup_function` VALUES ('200035', '1', '200001', 'RDS2020', '销售客户管理', '010', 'HmCustomer/queryHmCustomer', '', '0', '2011-11-07 21:26:25', '1', '0000-00-00 00:00:00', '0', '200006', '020', '1'); 
INSERT INTO `uup_function` VALUES ('200036', '1', '200003', 'PMT7020', '工时分析报表', '010', 'AppChart/queryPersonDay', '', '0', '2011-11-15 17:36:55', '1', '0000-00-00 00:00:00', '0', '200033', '020', '1'); 
INSERT INTO `uup_function` VALUES ('200037', '1', '200003', 'PMT43', '任务查询', '010', 'AppTask/queryTaskList', '', '0', '2011-12-06 23:18:10', '1', '0000-00-00 00:00:00', '0', '200024', '042', '1'); 
INSERT INTO `uup_function` VALUES ('200038', '1', '200001', 'RDS5020', '订单管理(分公司)', '010', 'HmRdsOrder/queryFenJcHmRdsOrder', '', '0', '2011-12-21 20:42:25', '1', '0000-00-00 00:00:00', '0', '200013', '020', '1'); 
INSERT INTO `uup_function` VALUES ('200039', '1', '200003', 'PMT80', '资源管理', '010', '', '', '0', '2011-12-26 14:44:12', '1', '0000-00-00 00:00:00', '0', '200024', '080', '1'); 
INSERT INTO `uup_function` VALUES ('200040', '1', '200003', 'PMT8010', '项目资源配置', '010', 'AppEmployeeAssign/queryEmployeeAssign', '', '0', '2011-12-26 14:45:59', '1', '0000-00-00 00:00:00', '0', '200039', '010', '1'); 
INSERT INTO `uup_function` VALUES ('200041', '1', '200003', 'PMT8020', '资源管理', '010', 'Employee/queryEmployee', '', '0', '2011-12-26 14:46:46', '1', '0000-00-00 00:00:00', '0', '200039', '020', '1'); 
INSERT INTO `uup_function` VALUES ('200045', '1', '200004', 'SPR70', 'RAC角色管理', '010', 'Role/queryRole', '', '0', '2012-01-25 23:14:55', '1', '0000-00-00 00:00:00', '0', '1', '070', '0'); 
INSERT INTO `uup_function` VALUES ('200046', '1', '200004', 'SPR80', 'RAC权限管理', '010', 'RacPrivilege/queryRacPrivilege', '', '0', '2012-01-25 23:15:32', '1', '0000-00-00 00:00:00', '0', '1', '080', '0'); 
INSERT INTO `uup_function` VALUES ('200047', '1', '1000', 'UUP70', '公告管理', '010', 'News/queryNews', '', '0', '2012-01-28 15:47:31', '1', '2012-01-28 15:47:55', '1', '200024', '006', '1'); 
INSERT INTO `uup_function` VALUES ('200048', '1', '1000', 'UUP70', '组织配置字段', '010', 'OrgConfigField/queryOrgConfigField', '', '0', '2012-02-09 22:24:28', '1', '2012-02-09 22:27:02', '1', '1', '090', '0'); 
INSERT INTO `uup_function` VALUES ('200049', '1', '1000', 'UUP35', '配置管理', '010', 'AppOrgConfigField/editOrgConfigPage', '', '0', '2012-02-09 22:25:18', '1', '2012-02-09 22:27:15', '1', '1000', '035', '0'); 
 
--uup_news--
CREATE TABLE `uup_news` (   `id` int(11) NOT NULL auto_increment,   `title` varchar(100) collate utf8_unicode_ci default NULL COMMENT '标题',   `title_color` varchar(10) collate utf8_unicode_ci default NULL COMMENT '标题颜色',   `status` varchar(3) collate utf8_unicode_ci default NULL COMMENT '状态',   `public_date` date default NULL COMMENT '开始发布时间',   `type` varchar(3) collate utf8_unicode_ci default NULL COMMENT '公告类型',   `type_content` text collate utf8_unicode_ci COMMENT '公告内容',   `type_url` varchar(200) collate utf8_unicode_ci default NULL COMMENT '公告链接',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
 
--uup_org--
CREATE TABLE `uup_org` (   `id` int(11) NOT NULL auto_increment,   `code` varchar(50) collate utf8_unicode_ci default NULL COMMENT '组织代码',   `name` varchar(50) collate utf8_unicode_ci default NULL COMMENT '组织名称',   `type` varchar(50) collate utf8_unicode_ci default NULL COMMENT '组织类型',   `memo` text collate utf8_unicode_ci COMMENT '描述',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   `b_code` varchar(11) collate utf8_unicode_ci default NULL COMMENT '组织业务标识',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=200014 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='组织';
INSERT INTO `uup_org` VALUES ('1', 'superadmin', '管理组织', '010', '', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', ''); 
INSERT INTO `uup_org` VALUES ('2', 'C00001', '业务组织', '', '', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', ''); 
 
--uup_org_config--
CREATE TABLE `uup_org_config` (   `id` int(11) NOT NULL auto_increment,   `config_field_id` int(11) default NULL COMMENT '配置字段',   `field_value` varchar(100) collate utf8_unicode_ci default NULL COMMENT '配置字段值',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
 
--uup_org_config_field--
CREATE TABLE `uup_org_config_field` (   `id` int(11) NOT NULL auto_increment,   `div_label` varchar(30) collate utf8_unicode_ci default NULL,   `control_type` varchar(30) collate utf8_unicode_ci default NULL,   `control_name` varchar(30) collate utf8_unicode_ci default NULL,   `control_value` varchar(30) collate utf8_unicode_ci default NULL,   `control_class` varchar(100) collate utf8_unicode_ci default NULL,   `control_param` varchar(100) collate utf8_unicode_ci default NULL,   `value_input_default` varchar(100) collate utf8_unicode_ci default NULL,   `function_code` varchar(30) collate utf8_unicode_ci default NULL,   `system_id` int(11) default NULL,   `no` varchar(10) collate utf8_unicode_ci default NULL COMMENT '排序',   `memo` varchar(100) collate utf8_unicode_ci default NULL COMMENT '描述',   `belong_user_id` int(11) default NULL COMMENT '所属人',   `belong_org_id` int(11) default NULL COMMENT '所述组织',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
 
--uup_org_tree--
CREATE TABLE `uup_org_tree` (   `id` int(11) NOT NULL auto_increment,   `domain_id` int(11) default NULL COMMENT '业务域',   `org_id` int(11) default NULL COMMENT '组织',   `parent_org_id` int(11) default NULL COMMENT '父组织',   `type` varchar(50) collate utf8_unicode_ci default NULL COMMENT '组织关系类型',   `memo` text collate utf8_unicode_ci COMMENT '描述',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=200013 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='组织关系';
 
--uup_system--
CREATE TABLE `uup_system` (   `id` int(11) NOT NULL auto_increment,   `domain_id` int(11) default NULL COMMENT '业务域',   `code` varchar(50) collate utf8_unicode_ci default NULL COMMENT '系统代码',   `name` varchar(50) collate utf8_unicode_ci default NULL COMMENT '系统名称',   `url` varchar(100) collate utf8_unicode_ci default NULL COMMENT '链接地址',   `memo` text collate utf8_unicode_ci COMMENT '描述',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=200005 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='业务应用包';
INSERT INTO `uup_system` VALUES ('1', '1', 'Spt', '工具应用包', '/__SPR_ROOT_APATH__/SprTools/index.php/', '', '0', '0000-00-00 00:00:00', '0', '2012-01-16 21:15:39', '1'); 
INSERT INTO `uup_system` VALUES ('2', '1', 'Spr', '核心应用包', '/__SPR_ROOT_APATH__/SprPage/index.php/', '', '0', '2011-06-18 15:02:13', '1', '2012-01-16 21:15:35', '1'); 
INSERT INTO `uup_system` VALUES ('3', '1', 'Dmo', '测试系统', '/__SPR_ROOT_APATH__/Demo/index.php/', '', '0', '0000-00-00 00:00:00', '0', '2012-01-16 21:15:21', '1'); 
INSERT INTO `uup_system` VALUES ('1000', '1', 'Uup', '权限应用包', '/__SPR_ROOT_APATH__/SprUup/index.php/', '', '0', '0000-00-00 00:00:00', '0', '2012-01-16 21:15:14', '1'); 
INSERT INTO `uup_system` VALUES ('200000', '1', 'Pms', '项目管理', '/__SPR_ROOT_APATH__/Pms/index.php/', '', '0', '2011-08-02 22:07:12', '1', '2012-01-16 21:12:23', '1'); 
INSERT INTO `uup_system` VALUES ('200001', '1', 'Rds', '鼎迈订单', '/__SPR_ROOT_APATH__/HmRds/index.php/', '', '0', '2011-08-08 21:43:08', '1', '2012-01-16 21:15:09', '1'); 
INSERT INTO `uup_system` VALUES ('200002', '1', 'Bnt', '备份记录', '/__SPR_ROOT_APATH__/Bnt/index.php/', '', '0', '2011-09-09 14:56:48', '1', '2012-01-16 21:12:58', '1'); 
INSERT INTO `uup_system` VALUES ('200003', '1', 'Pmt', 'TaskPm', '/__SPR_ROOT_APATH__/Pmt/index.php/', '', '0', '2011-09-10 23:47:11', '1', '2012-01-21 10:10:00', '1'); 
INSERT INTO `uup_system` VALUES ('200004', '1', 'Rac', '授权模块', '/__SPR_ROOT_APATH__/SprRac/index.php/', '', '0', '2012-01-25 23:09:53', '1', '0000-00-00 00:00:00', '0'); 
 
--uup_user--
CREATE TABLE `uup_user` (   `id` int(11) NOT NULL auto_increment,   `org_id` int(11) default NULL COMMENT '所属组织',   `code` varchar(50) collate utf8_unicode_ci default NULL COMMENT '账号代码',   `name` varchar(50) collate utf8_unicode_ci default NULL COMMENT '账号名称',   `psd` varchar(50) collate utf8_unicode_ci default NULL COMMENT '密码',   `type` varchar(50) collate utf8_unicode_ci default NULL COMMENT '账号类型',   `phone` varchar(50) collate utf8_unicode_ci default NULL COMMENT '电话',   `mobile` varchar(50) collate utf8_unicode_ci default NULL COMMENT '手机',   `mail` varchar(100) collate utf8_unicode_ci default NULL COMMENT 'Mail',   `mail_psd` varchar(50) collate utf8_unicode_ci default NULL COMMENT 'Mail密码',   `memo` text collate utf8_unicode_ci COMMENT '描述',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=200046 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='账号';
INSERT INTO `uup_user` VALUES ('1', '1', 'superadmin', 'superadmin', 'admin', '', '001', '001', '001', '', '001', '0', '0000-00-00 00:00:00', '0', '2011-08-07 12:16:00', '1'); 
INSERT INTO `uup_user` VALUES ('2', '2', 'C00001', '组织管理员', '21232f297a57a5a743894a0e4a801fc3', '', '', '', '', '', '', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
  
--uup_user_domain--
CREATE TABLE `uup_user_domain` (   `id` int(11) NOT NULL auto_increment,   `user_id` int(11) default NULL COMMENT '账号',   `domain_id` int(11) default NULL COMMENT '业务域',   `org_id` int(11) default NULL COMMENT '所属组织',   `type` varchar(50) collate utf8_unicode_ci default NULL COMMENT '账号类型',   `is_deleted` varchar(2) collate utf8_unicode_ci default NULL COMMENT '是否删除',   `create_time` datetime default NULL COMMENT '创建时间',   `create_user_id` int(11) default NULL COMMENT '创建人',   `update_time` datetime default NULL COMMENT '修改时间',   `update_user_id` int(11) default NULL COMMENT '修改人',   PRIMARY KEY  (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=200013 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='账号';
INSERT INTO `uup_user_domain` VALUES ('1', '1', '1', '1', '010', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
INSERT INTO `uup_user_domain` VALUES ('2', '2', '1', '2', '010', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'); 
 
