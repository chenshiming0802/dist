<?php
$confArray = array(
	'SPR_SECURE_URLS'=>array(
		'SprSflowAction#*',
		'SysUserLogAction#*',
	)
);
$confArray = array_merge(include(SPR_CONFIG_PATH."/config.php"),$confArray);
return $confArray;
?>