<?php
return array(
	'viewMailPage.title'=>'邮件查看',
);

?>