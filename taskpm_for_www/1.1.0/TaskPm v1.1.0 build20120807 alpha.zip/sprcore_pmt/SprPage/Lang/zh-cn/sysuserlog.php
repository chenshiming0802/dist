<?php
return array(
	'querySysUserLog.title'=>'查询业务日志',
	'saveSysUserLogPage.title'=>'新增业务日志',
	'editSysUserLogPage.title'=>'修改业务日志',
);

?>