<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='sys_key_set'
//common.php:
$lanArray = array_merge($lanArray,include("DB.sys_key_set.php"));
*/
return array(
'sys_mail_list'=>'邮件内容',

'sys_mail_list.id'=>'ID',
'sys_mail_list.subject'=>'标题',
'sys_mail_list.from'=>'发信人',
'sys_mail_list.from_name'=>'发信人姓名',
'sys_mail_list.to'=>'收信人',
'sys_mail_list.to_name'=>'收信人姓名',
'sys_mail_list.content'=>'内容',
'sys_mail_list.files'=>'附件',

);

?>