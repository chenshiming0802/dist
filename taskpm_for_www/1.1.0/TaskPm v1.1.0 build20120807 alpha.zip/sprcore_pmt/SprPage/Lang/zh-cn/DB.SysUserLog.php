<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'demo'
//common.php:
$lanArray = array_merge($lanArray,include("DB.sys_user_log.php"));
*/
return array(
'sys_user_log.id'=>'',
'sys_user_log.org_id'=>'登录组织',
'sys_user_log.org_name'=>'组织名称',
'sys_user_log.user_id'=>'登录帐号',
'sys_user_log.user_name'=>'帐号姓名',
'sys_user_log.domain_id'=>'域',
'sys_user_log.content'=>'内容',
'sys_user_log.sr_message_param'=>'执行结果参数',
'sys_user_log.sr_message'=>'执行结果信息',
'sys_user_log.sr_result'=>'执行结果',
'sys_user_log.ip_addr'=>'IP地址',
'sys_user_log.request_uri'=>'URL地址',
'sys_user_log.post_info'=>'POST参数',
'sys_user_log.http_referer'=>'来源',
'sys_user_log.http_user_agent'=>'客户端信息',
'sys_user_log.request_method'=>'提交方法',
'sys_user_log.is_deleted'=>'是否删除',
'sys_user_log.create_time'=>'创建时间',
'sys_user_log.create_user_id'=>'创建人',
'sys_user_log.update_time'=>'修改时间',
'sys_user_log.update_user_id'=>'修改人',

);

?>