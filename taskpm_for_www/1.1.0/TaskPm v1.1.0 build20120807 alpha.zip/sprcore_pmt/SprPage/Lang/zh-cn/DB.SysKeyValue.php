<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='sys_key_value'
//common.php:
$lanArray = array_merge($lanArray,include("DB.sys_key_value.php"));
*/
return array(
'sys_key_value'=>'数据字典VALUE',

'sys_key_value.code'=>'代码',
'sys_key_value.name'=>'名称',
'sys_key_value.seq'=>'排列次序',
'sys_key_value.id'=>'ID',);

?>