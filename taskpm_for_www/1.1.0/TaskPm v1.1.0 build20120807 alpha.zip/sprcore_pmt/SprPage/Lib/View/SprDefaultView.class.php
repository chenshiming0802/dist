<?php

class SprDefaultView extends SrView{
	public function viewIframe($spModel){
		$title = $this->spModel['SPR_TAB_VIEW_TYPE_TITLE'];
		$value1 = $this->spModel['SPR_TAB_VIEW_TYPE_VALUE1'];
		$srModel = array();

		$this->title = Sr::sys_pl($title,array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
 		$this->addItem(array(
			'div_id'=>'div_blank','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'IFRAME','control_name'=>'',
			'control_value'=>'',
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
			'value_input'=>Sr::sys_sl($value1),
			'INFO'=>"",
		));

//		$items["items_line"][] = array(
//				'control_type'=>'BUTTON','control_name'=>'close',
//				'control_value'=>"",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.close',
//			);
//		$this->addItems($items);




		self::addInfoResults($srModel,null);
		return $srModel;
	}
	public function view2Iframe($spModel){
		$title = $this->spModel['SPR_TAB_VIEW_TYPE_TITLE'];
		$value1 = $this->spModel['SPR_TAB_VIEW_TYPE_VALUE1'];
		$value2 = $this->spModel['SPR_TAB_VIEW_TYPE_VALUE2'];
		$srModel = array();

		$this->title = Sr::sys_pl($title,array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
 		$this->addItem(array(
			'div_id'=>'div_blank','div_label'=>'','item_line_type'=>'left_iframe','item_viewauth'=>'',
			'control_type'=>'IFRAME','control_name'=>'left_iframe',
			'control_value'=>'',
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
			'value_input'=>Sr::sys_sl($value1),
			'INFO'=>"",
		));
 		$this->addItem(array(
			'div_id'=>'div_blank','div_label'=>'','item_line_type'=>'right_iframe','item_viewauth'=>'',
			'control_type'=>'IFRAME','control_name'=>'right_iframe',
			'control_value'=>'',
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
			'value_input'=>Sr::sys_sl($value2),
			'INFO'=>"",
		));


		self::addInfoResults($srModel,null);
		return $srModel;
	}

}

?>