<?php

class SysKeySetView extends SrView{

	public function querySysKeySet($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'sys_key_set.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_code',
			'control_value'=>"",
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_code'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'sys_key_set.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_name',
			'control_value'=>"",
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_name'],
		));

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'insert',
				'control_value'=>__URL__."/editSysKeySetPage",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.insert',
			);

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'manager',
				'control_value'=>__URL__."/managerSysKeySetPage",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.insert',
			);
		$this->addItems($items);

		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'view',
				'control_value'=>__URL__."/viewSysKeySetPage?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.view',
			);
		$buttons[] =array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>__URL__."/editSysKeySetPage?id=[id]",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);

		$buttons[] =array(
				'control_type'=>'BUTTON','control_name'=>'update2',
				'control_value'=>__URL__."/managerSysKeySetPage?id=[id]",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
		$buttons[] =array(
				'control_type'=>'BUTTON','control_name'=>'delete',
				'control_value'=>__URL__."/deleteSysKeySet[id]",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.delete',
			);
		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
				'sys_key_set.code'=>array(
					'control_type'=>'TEXT','control_name'=>'code',
					'control_value'=>"",
					'control_class'=>"required",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'code',
				),
					'sys_key_set.name'=>array(
					'control_type'=>'TEXT','control_name'=>'name',
					'control_value'=>"",
					'control_class'=>"required",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'name',
				),

				'operate'=>$buttons,
			),
		));



		self::addInfoResults($srModel,null);
		return $srModel;
	}

	public function managerSysKeySetPage($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.'.title',array('displayDiv'=>'false'));
		$this->form = array(
			'name'=>'ff',
			'method'=>'post',
			'action'=>__URL__."/managerSysKeySet",
			'target'=>'_self',
			'onSubmit'=>'',
		);
		//$this->srModel['id']?'1':'0'
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.'.title','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>'',
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_key_set.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>"",
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_key_set.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'code',
			'control_value'=>"",
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_key_set.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'name',
			'control_value'=>"",
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));


		//DETAIL BUTTON
		$items = array('div_id'=>'div_search_v','div_label'=>'sys_key_value','item_line_type'=>'line','item_viewauth'=>'',);
		$items["items_line"] = array();


		$items["items_line"][] = array(
				'control_type'=>'TEXT','control_name'=>'detail_add_count',
				'control_value'=>"",
				'control_class'=>"",'control_param'=>'size="2"','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'adddetail1',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.add.detail',
			);
		$this->addItems($items);
		//GRID
		$buttons = array();
		$buttons[] =array(
						'control_type'=>'BUTTON','control_name'=>'deletedetail',
						'control_value'=>"id",
						'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'page.button.delete',
					);
		$this->addGrid(array(
			'div_id'=>'div_search','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'grid_list'=>$this->srModel['details'],'grid_page'=>$this->srModel['details_page'],
			'grid_param'=>array(

				'sys_key_value.code'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_code[]',
						'control_value'=>"",
						'control_class'=>"required",'control_param'=>"  size='10'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'code',
					),
				'sys_key_value.name'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_name[]',
						'control_value'=>"",
						'control_class'=>"required",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'name',
					),
				'sys_key_value.seq'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_seq[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'seq',
					),
				'sys_key_value.id'=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_id[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'id',
					),
				"operate"=>$buttons,
			),
		));

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();


		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'submitb',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.submit',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);

		self::addInfoResults($srModel,null);
		return $srModel;
	}

	public function editSysKeySetPage($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/editSysKeySet",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_key_set.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>"",
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_key_set.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'code',
			'control_value'=>"",
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_key_set.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'name',
			'control_value'=>"",
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));



		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'save',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.save',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);

		self::addInfoResults($srModel,null);
		return $srModel;
	}


	public function viewSysKeySetPage($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewSysKeySetPage",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_key_set.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>"",
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_key_set.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'code',
			'control_value'=>"",
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_key_set.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'name',
			'control_value'=>"",
			'control_class'=>"required ",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));


		//GRID
		$this->addGrid(array(
			'div_id'=>'div_search','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'grid_list'=>$this->srModel['details'],'grid_page'=>$this->srModel['details_page'],
			'grid_param'=>array(

				"sys_key_value.code"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_code[]',
						'control_value'=>"",
						'control_class'=>"required",'control_param'=>"  size='10'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'code',
					),
				"sys_key_value.name"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_name[]',
						'control_value'=>"",
						'control_class'=>"required",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'name',
					),
				"sys_key_value.seq"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_seq[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'seq',
					),
				"sys_key_value.id"=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_id[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'id',
					),			),
		));


		self::addInfoResults($srModel,null);
		return $srModel;
	}
}

?>