<?php

class SprMailView extends SrView{
	public function viewMailPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_mail_list.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_mail_list.subject','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'subject',
			'control_value'=>'',
			'control_class'=>" ",'control_param'=>"     ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["subject"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_mail_list.from','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL','sys_mail_list'=>'name',
			'control_value'=>'',
			'control_class'=>"required ",'control_param'=>"     ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["from"].' '.$this->srModel["from_name"],
			'INFO'=>"",
		));

		$ss = "<ul>";
		foreach($this->srModel["files"] as $model){
			$ss .= "<li><a href='__URL__/dowloadAttach?id=".$model['id']."' target='_blank'>".$model['original_document_name']."</a></li>";
		}
		$ss .= "</ul>";

			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_mail_list.files','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL','sys_mail_list'=>'name',
			'control_value'=>'',
			'control_class'=>" ",'control_param'=>"     ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$ss,
			'INFO'=>"",
		));


			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_mail_list.content','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL','sys_mail_list'=>'name',
			'control_value'=>'',
			'control_class'=>" ",'control_param'=>"     ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["content"],
			'INFO'=>"",
		));




//		$items = array('div_id'=>'div_search_v','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
//		$items["items_line"] = array();
//		$items["items_line"][] = array(
//				'control_type'=>'BUTTON','control_name'=>'close',
//				'control_value'=>"",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.close',
//			);
//		$this->addItems($items);


		self::addInfoResults($srModel,null);
		return $srModel;
	}

}

?>