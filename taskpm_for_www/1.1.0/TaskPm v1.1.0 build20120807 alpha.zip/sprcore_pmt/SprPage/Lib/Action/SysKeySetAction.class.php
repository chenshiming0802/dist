<?php

class SysKeySetAction extends SrAction{
 
	/*
	* http://127.0.0.1:82/sprcore_all/SprPage/index.php/SysKeySet/querySysKeySet	*/
	public function querySysKeySet($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('SysKeySetService','querySysKeySet', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('SysKeySetView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function managerSysKeySetPage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('SysKeySetService','getSysKeySet', $spModel );	
		if($srModel['id']==null||$srModel['id'=='']){
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('SysKeySetView',__FUNCTION__, $spModel );
		return self::forward();
	}	
	public function managerSysKeySet($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('SysKeySetService','managerSysKeySet', $spModel );
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('managerSysKeySetPage','post',$spModel,$srModel);
	}
	public function editSysKeySetPage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('SysKeySetService','getSysKeySet', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('SysKeySetView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editSysKeySet($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('SysKeySetService','editSysKeySet', $spModel );
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editSysKeySetPage','post',$spModel,$srModel);
	}
	public function deleteSysKeySet($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('SysKeySetService','deleteSysKeySet', $spModel );
		$this->setIsOutHtml(false);
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('querySysKeySet','post',$spModel,$srModel);
	}
	public function viewSysKeySetPage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('SysKeySetService','getSysKeySet', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('SysKeySetView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>