<?php
class SprSflowAction extends SrAction{
	public function editFlowStatus($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService("SprSflowService","editFlowStatus", $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('SprSflowView',__FUNCTION__, $spModel );
		return self::forward();
	}

	public function submitFlowStatus($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService("SprSflowService","submitFlowStatus", $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
//		SrLog::save(array(
//			"srModel"=>$srModel,
//			"content"=>Sr::sys_l($srModel["message"],$srModel["params"]),
//		));
		if($srModel['sys_sflow_d']['page_submit_type']=='000'){
			//如果是000,弹出页面式的工作流回复,则结束后刷新父页面
			return self::forward();
		}else{
			//如果是010,则跳转到return地址
			if($srModel["sflow_return_url"]!=null&&$srModel["sflow_return_url"]!=''){
				self::redirect($srModel["sflow_return_url"],'post',$spModel,$srModel);
			}else{
				self::redirect($spModel["SPR_CURRENT_URL"],'post',$spModel,$srModel);
			}
		}

	}

	public function submitBatchFlowStatus($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService("SprSflowService","submitBatchFlowStatus", $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);

		self::redirect($srModel["sflow_return_url"],'post',$spModel,$srModel,'1');
	}

	public function queryFlowStatusByBusinessId($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService("SprSflowService","queryFlowStatus", $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();
	}
}
?>