<?php
// 本文档自动生成，仅供测试运行
class SprMailAction extends SrAction
{
	/*
	 * http://127.0.0.1/sprcore_all/SprPage/index.php/sprMail/viewMailPage?id=50
	 */
	public function viewMailPage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService("SprMailService","viewMailPage", $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('SprMailView',__FUNCTION__, $spModel );
		return self::forward();
	}

	public function dowloadAttach($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService("SprMailService","dowloadAttach", $spModel );

 		$path = $srModel['path'];
		$original_document_name = $srModel['original_document_name'];
		$download_document_name = $srModel['download_document_name'];
		$fileFullPath = c('FILE_BASE_ROOT')   .   $path.$download_document_name;
		$fileFullPath = str_replace('/','\\',$fileFullPath);
		$file_size = filesize($fileFullPath);//$tfile['file_size'];
		//halt($fileFullPath);
		Header( "Content-type:   application/octet-stream ");
		Header( "Accept-Ranges:   bytes ");
		Header( "Accept-Length:   ".$file_size);
		Header( "Content-Disposition:   attachment;   filename= "   .   $original_document_name);
		//   ����ļ�����
		$file   =   fopen($fileFullPath, "r ");
		echo   fread($file,$file_size);
		fclose($file);
		exit;
	}

}
?>