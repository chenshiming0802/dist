<?php
class SysUserLogAction extends SrAction{

	public function querySysUserLog($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService("SysUserLogService","querySysUserLog", $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();
	}
 	public function viewSysUserLogPage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService("SysUserLogService","getSysUserLog", $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();		
	}
	public function saveSysUserLogPage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$this->set(__FUNCTION__,$spModel);
		return self::forward();		
	}
 
	public function saveSysUserLog($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService("SysUserLogService","saveSysUserLog", $spModel );
		$this->setIsOutHtml(false);
		self::saveSysUserLogPage($spModel)->fillSrModel2($spModel,$srModel);
		return self::forward();			
		
	}
	
	public function editSysUserLogPage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService("SysUserLogService","getSysUserLog", $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();		
	}
	
	public function editSysUserLog($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService("SysUserLogService","editSysUserLog", $spModel );
		$this->setIsOutHtml(false);
		$spModel["id"] = $srModel["id"];	
		self::editSysUserLogPage($spModel)->fillSrModel2($spModel,$srModel);
		return self::forward();		
	}	
	
	public function deleteSysUserLog($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService("SysUserLogService","deleteSysUserLog", $spModel );
		$this->setIsOutHtml(false);
		$spModel["id"] = $srModel["id"];	
		$srModel = self::querySysUserLog($spModel)->fillSrModel($srModel);
		$this->set($this->actionMethod,$spModel,$srModel);	
		$this->setIsOutHtml(true);
		return self::forward();		
	}			
}
 
?>