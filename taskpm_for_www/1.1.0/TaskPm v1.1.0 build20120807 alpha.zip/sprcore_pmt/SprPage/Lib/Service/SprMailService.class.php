<?php
class SprMailService extends SrService
{
	public function viewMailPage($spModel){
		$id = self::assertNotBlank($spModel,"id");
		$srModel = array();
		$model = self::queryById2($id,"sys_mail_list");
		if($model!==null){
			$sql = "select t.* from sys_mail_list_file t where t.mail_list_id='{0}'";
			$model['files'] = self::queryBySql($sql,array($model['id']));
		}
		$srModel = $model;

		self::addInfoResults($srModel,null);
		return $srModel;
	}

	public function dowloadAttach($spModel){
		$id = self::assertNotBlank($spModel,"id");
		$srModel = array();

		$srModel = self::queryById2($id,'sys_mail_list_file');

		self::addInfoResults($srModel,null);
		return $srModel;
	}


}
?>