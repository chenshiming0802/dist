<?php 
class SysUserLogService extends SrService
{
 	public function querySysUserLog($spModel){
		$srModel = array();
		$sql = "select * from sys_user_log t where t.is_deleted='0' ";
		
		
		
		$sql .= self::getCauseIfNotNull("t.org_name like '%{0}%'",$spModel["org_name"]);
		
		
		$sql .= self::getCauseIfNotNull("t.user_name like '%{0}%'",$spModel["user_name"]);
		
		
		$sql .= self::getCauseIfNotNull("t.content like '%{0}%'",$spModel["content"]);
		
		$sql .= self::getCauseIfNotNull("t.sr_message_param like '%{0}%'",$spModel["sr_message_param"]);
		
		$sql .= self::getCauseIfNotNull("t.sr_message like '%{0}%'",$spModel["sr_message"]);
		
		$sql .= self::getCauseIfNotNull("t.sr_result like '%{0}%'",$spModel["sr_result"]);
		
		$sql .= self::getCauseIfNotNull("t.ip_addr like '%{0}%'",$spModel["ip_addr"]);
		
		$sql .= self::getCauseIfNotNull("t.request_uri like '%{0}%'",$spModel["request_uri"]);
		
		$sql .= self::getCauseIfNotNull("t.post_info like '%{0}%'",$spModel["post_info"]);
		
		$sql .= self::getCauseIfNotNull("t.http_referer like '%{0}%'",$spModel["http_referer"]);
		
		$sql .= self::getCauseIfNotNull("t.http_user_agent like '%{0}%'",$spModel["http_user_agent"]);
		
		$sql .= self::getCauseIfNotNull("t.request_method like '%{0}%'",$spModel["request_method"]);
		
		
		
		
		
				
		$sql .= " order by id desc";
 		$srModel = self::queryPageBySql($sql);
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	public function getSysUserLog($spModel){
		$srModel = array();
		$srModel = self::queryById2($spModel["id"],"sys_user_log");
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	public function saveSysUserLog($spModel){
		$srModel = array();
		$srModel = self::insert2($spModel,"sys_user_log");
		self::addInfoResults($srModel,'message.success.save',array($srModel["name"]));
		return $srModel;
	}

	public function editSysUserLog($spModel){	
		$srModel = array();
		$srModel = self::update2($spModel["id"],$spModel,"sys_user_log");
		self::addInfoResults($srModel,'message.success.update',array($srModel["name"]));
		return $srModel;
	}	
	public function deleteSysUserLog($spModel){	
		$srModel = array();
		$spModel["is_deleted"] = "1";
		$srModel = self::update2($spModel["id"],$spModel,"sys_user_log");
		self::addInfoResults($srModel,'message.success.delete',array($srModel["name"]));
		return $srModel;
	}	
//	public function deleteSysUserLog($spModel){	
//		$srModel = array();
//		$srModel = self::delete2($spModel["id"],"sys_user_log");
//		self::addInfoResults($srModel,'message.success.delete',array($srModel["name"]));
//		return $srModel;
//	}	
}//end class

?>