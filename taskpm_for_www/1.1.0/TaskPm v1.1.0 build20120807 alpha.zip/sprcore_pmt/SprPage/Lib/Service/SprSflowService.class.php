<?php
class SprSflowService extends SrService
{
	public function submitBatchFlowStatus($spModel){
		$srModel = array();
		$flow_d_id = self::assertNotBlank($spModel,"sflow_flow_d_id");//sflow_d#id
		$business_id_field = self::assertNotBlank($spModel,"sflow_business_id_field");//for sflow_business_id field
		$business_num_field = self::assertNotBlank($spModel,"sflow_business_num_field");//for sflow_business_num field
		$sflow_return_url = Sr::sys_get($spModel['sflow_return_url'],$spModel['SPR_CURRENT_URL']);
//		$from_status_field = self::assertNotBlank($spModel,"sflow_from_status_field");//for sflow_from_status field

		$dModel = self::queryById2($flow_d_id,"sys_sflow_d");

		$business_ids = $spModel[$business_id_field];
		$business_nums = $spModel[$business_num_field];
//		$from_statuss = $spModel[$from_status_field];
		foreach($business_ids as $key=>$model){
			self::submitFlowStatus(array(
				'sflow_flow_d_id'=>$flow_d_id,
				'sflow_business_id'=>$business_ids[$key],
				'sflow_business_num'=>$business_nums[$key],
				'need_sflow_from_status'=>'0',
				'sflow_return_url'=>$sflow_return_url,
//				'sflow_from_status'=>$from_statuss[$key],
			));
		}

		self::addInfoResults($srModel,$dModel["operation_message"],array());
		return $srModel;
	}

	public function editFlowStatus($spModel){
		$srModel = array();
		$summary = SrUser :: getUserSummary();
		$flow_d_id = $spModel["sflow_flow_d_id"];
		if($flow_d_id==null){
			throw_exception(Sr::sys_l("message.sflow.exception.paramerror",array()));
		}
		//初始化数据
		$dModel = self::queryById2($flow_d_id,"sys_sflow_d");
		$srModel['sys_sflow_d'] = $dModel;
		$mModel = self::queryById2($dModel["flow_id"],"sys_sflow");
		$srModel['sys_sflow'] = $mModel;
		//TODO

		self::addInfoResults($srModel,null);
		return $srModel;
	}

	public function submitFlowStatus($spModel){
		$srModel = array();
		$summary = SrUser :: getUserSummary();
		$flow_d_id = $spModel["sflow_flow_d_id"];//
		$sys_user_content = $spModel['sflow_user_content'];//提交的用户内容
		$business_id = $spModel["sflow_business_id"];//业务单据号
		$business_num = $spModel["sflow_business_num"];//业务单据号
		$return_url = $spModel["sflow_return_url"];//返回的URL
		$from_status = $spModel["sflow_from_status"];
		$need_from_status = Sr::sys_get($spModel["need_sflow_from_status"],'1');
		$dst_status = $spModel["sflow_dst_status"];//备用
		//TODO:判断过来的初始状态是否OK
		if($flow_d_id==null){
			throw_exception(Sr::sys_l("message.sflow.exception.paramerror",array()));
		}

		//初始化数据
		$dModel = self::queryById2($flow_d_id,"sys_sflow_d");
		$srModel['sys_sflow_d'] = $dModel;
		$mModel = self::queryById2($dModel["flow_id"],"sys_sflow");

		//查找业务记录
		if($business_id!=null){
			//只有单据ID不为空才可以校验
			$sql = "select * from ".$mModel["table_name"]." where 1=1 and id=".$business_id; //and ".$mModel["bs_field"]."='{$business_num}'
			if($mModel["bs_field_wheresql"]!=''){
				$sql .= " and ".$mModel["bs_field_wheresql"];
			}

			$businesModel = self::getRowBySql($sql,array());

			if($need_from_status=='0'){
				//如果为0,则不需要校验from_status
				$from_status = $businesModel[$mModel["status_field"]];
			}

			if($businesModel[$mModel["status_field"]]!=$from_status){
				//dump($mModel["status_field"]);
				//dump($sql);
				//dump($businesModel[$mModel["status_field"]]);
				//记录状态不符(可能已经被更换)
				throw_exception(Sr::sys_l("message.sflow.exception.bussiness.status.error",array($from_status)));
			}

			$srModel2 = SrSflow::hasCurrentFlowD(array(
				"dModel"=>$dModel,
				"mModel"=>$mModel,
				"businesModel"=>$businesModel,
				"business_id"=>$business_id,
				"spModel2"=>$spModel,
			));
		 	if($srModel2["has_method"]=="0"){
		 		throw_exception(Sr::sys_l($srModel2["error_message"],$srModel2["error_params"]));
		 	}

		}else{
			if($from_status!=null && $from_status!=''){
				//记录状态不符(可能已经被更换)
				throw_exception(Sr::sys_l("message.sflow.exception.bussiness.status.error",array($from_status)));
			}
		}


		//更新业务记录状态
		if($dModel["dst_status"]!=''&&$dModel["dst_status"]!=''){
			$businesModel2 = array();
			if($from_status!=$dModel["dst_status"]){
				$businesModel2[$mModel["status_field"]] = $dModel["dst_status"];
			}
//			dump($businesModel2);
			$businesModel2 = self::update2($businesModel["id"],$businesModel2,$mModel["update_table_name"]);
//			dump($businesModel2);halt();
			if($business_num==null){
				$business_num = $businesModel2[$mModel["bs_field"]];
			}
		}

		//回调实现函数
		$beanName = $mModel["flow_class"];
		$methodName = $dModel["flow_method"];
		$spModel["sflow_dst_status"] = $dModel["dst_status"];
		$sflow_method_business_id = null;

		if($beanName!=null && $beanName!='' && $methodName!=null && $methodName!=''){
			$srModel2 = Sr::sys_callSpMethod($beanName,$methodName,$spModel);

			if($srModel2[Sr::SRMODEL_RESULTS()][0]=="fail"){
				$srModel2["sflow_return_url"] = $return_url;
				return $srModel2;
			}
			$sflow_method_business_id = $srModel2["sflow_method_business_id"];
			if($business_id==null){
				$business_id = $sflow_method_business_id;
			}
			if($business_id==null){
				throw_exception(Sr::sys_l("message.sflow.exception.sflowmethod.add.return",array($beanName,$methodName,"sflow_method_business_id")));
			}
		}


		$messageArray = SrSflow::getMessageArray(array(
			"business_num"=>$business_num,
			"business_id"=>$business_id,
			"from_status"=>$from_status,
			"dst_status"=>$dst_status,
			"return_url"=>$return_url,
		));

		//记录日志
		$logModel = array();
		$logModel["flow_id"] = $mModel["id"];
		$logModel["flow_d_id"] = $dModel["id"];
		$logModel["org_id"] = $summary->orgId;
		$logModel["org_name"] = $summary->orgName;
		$logModel["user_id"] = $summary->userId;
		$logModel["user_name"] = $summary->userName;
		$logModel["from_status"] = $from_status;
		$logModel["dst_status"] = $dModel["dst_status"];
		$logModel["business_id"] = $business_id;
		$logModel["business_num"] = $business_num;
		$logModel["user_content"] = $sys_user_content;
		self::insert2($logModel,"sys_sflow_log");


		$return_url_param = $dModel["return_url_param"];
		if($return_url_param==null || $return_url_param==''){
			$return_url_param = $return_url;
		}
		$return_url_param = Sr::sys_messageFormat($return_url_param,$messageArray);
		$srModel["sflow_return_url"] = $return_url_param;
		if($srModel["sflow_return_url"]==null){
			throw_exception(Sr::sys_l("message.exception.sys.sflow_return_url.notfound",array($beanName,$methodName)));
		}
		L(include SPR_ROOT_SPATH.'\\'.$mModel['module_name'].'\Lang\zh-cn\common.php');

		//halt(Sr::sys_l($dModel["operation_message"],array()));
		$srModel["message"] = $dModel["operation_message"];
		$srModel["params"] = $messageArray;
		//halt(Sr::sys_l($srModel["message"],$srModel["params"]));
		SrLog::save(array(
			"srModel"=>$srModel,
			"content"=>Sr::sys_l($srModel["message"],$srModel["params"]),
		));
		//返回
		self::addInfoResults($srModel,$dModel["operation_message"],$messageArray);
		return $srModel;
	}

 	public function queryFlowStatus($spModel){
		$srModel = array();
		$sql = "
			SELECT
			  t2.flow_d_name,
			  t1.org_name,
			  t1.user_name,
			  t1.business_num,
			  t1.user_content,
			  t1.from_status,
			  t1.dst_status,
			  t1.create_time,
			  t2.user_content    user_tips,
			  t3.bs_name,
			  t3.status_name,
			  t3.status_dict
			FROM sys_sflow_log t1,
			  sys_sflow_d t2,
			  sys_sflow t3
			WHERE 1=1
			    AND t1.flow_d_id = t2.id
			    AND t1.flow_id = t3.id
		";


		$sql .= self::getCauseIfNotNull("t1.business_id = '{0}'",$spModel["business_id"]);
		$sql .= " order by t1.id asc";
 		$srModel['list'] = self::queryBySql($sql);
		self::addInfoResults($srModel,null);
		return $srModel;
	}


}
?>