<?php
define('THINK_PATH','../ThinkPHP/');  //框架路径
define('APP_NAME','SprPage');  // 项目名字
define('APP_PATH','.'); //项目路径
require(THINK_PATH."/ThinkPHP.php"); //加载框架
require("../SprPage/Lib/Spr/index.php");//加在Spr规范
App::run();
?>