<?php

@deldir(dirname(__FILE__).'\HmRds/Runtime');
@deldir(dirname(__FILE__).'\Pms/Runtime');
@deldir(dirname(__FILE__).'\Pmt/Runtime');
@deldir(dirname(__FILE__).'\Bnt/Runtime');
@deldir(dirname(__FILE__).'\SprPage/Runtime');
@deldir(dirname(__FILE__).'\SprTools/Runtime');
@deldir(dirname(__FILE__).'\SprUup/Runtime');
@deldir(dirname(__FILE__).'\SprRac/Runtime');

function deldir($dir) {
  //echo '<hr>'.$dir;
  $dh=opendir($dir);
  while ($file=readdir($dh)) {
    if($file!="." && $file!="..") {
      $fullpath=$dir."/".$file;
      if(!is_dir($fullpath)) {
          unlink($fullpath);
      } else {
          deldir($fullpath);
      }
    }
  }

  closedir($dh);
  
  if(rmdir($dir)) {
    return true;
  } else {
    return false;
  }
}

?>