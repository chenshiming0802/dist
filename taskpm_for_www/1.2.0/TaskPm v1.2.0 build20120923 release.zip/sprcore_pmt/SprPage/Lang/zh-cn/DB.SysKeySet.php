<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='sys_key_set'
//common.php:
$lanArray = array_merge($lanArray,include("DB.sys_key_set.php"));
*/
return array(
'sys_key_set'=>'数据字典SET',

'sys_key_set.id'=>'ID',
'sys_key_set.code'=>'代码',
'sys_key_set.name'=>'名称',);

?>