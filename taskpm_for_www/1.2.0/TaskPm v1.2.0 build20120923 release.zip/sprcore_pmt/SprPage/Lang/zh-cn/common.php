<?php

$lanArray = array(

);
$lanArray = array_merge(include(SPR_INDEX_PATH."/lang/".LANG_SET."/common.php"),$lanArray);
//数据库语言包
$lanArray = array_merge($lanArray,include("DB.SysUserLog.php"));
$lanArray = array_merge($lanArray,include("DB.SysKeyValue.php"));
$lanArray = array_merge($lanArray,include("DB.SysKeySet.php"));
$lanArray = array_merge($lanArray,include("DB.SprMailList.php"));

return $lanArray;

?>