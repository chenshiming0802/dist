<?php
return array(
	'querySysKeySet.title'=>'查询数据字典SET',
	'saveSysKeySetPage.title'=>'新增数据字典SET',
	'editSysKeySetPage.title'=>'修改数据字典SET',
	'managerSysKeySetPage.title'=>'修改数据字典SET',
);

?>