<?php

class SysSflowAction extends SrAction{
 
	/*
	* http://127.0.0.1:82/sprcore_all/Demo/index.php/SysSflow/querySysSflow	*/
	public function querySysSflow($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('SysSflowService','querySysSflow', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('SysSflowView',__FUNCTION__, $spModel );
		return self::forward();
	}

	public function editSysSflowPage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('SysSflowService','getSysSflow', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('SysSflowView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editSysSflow($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('SysSflowService','editSysSflow', $spModel );
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editSysSflowPage','post',$spModel,$srModel);
	}
	public function deleteSysSflow($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('SysSflowService','deleteSysSflow', $spModel );
		$this->setIsOutHtml(false);
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('querySysSflow','post',$spModel,$srModel);
	}
	public function viewSysSflowPage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('SysSflowService','getSysSflow', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('SysSflowView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>