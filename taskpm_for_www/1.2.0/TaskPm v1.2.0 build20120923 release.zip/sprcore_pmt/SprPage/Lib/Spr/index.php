<?php
require_once dirname(__FILE__).'/../../../config.php';
define('SPR_INDEX_PATH',SPR_ROOT_SPATH.'SprPage/Lib/Spr/');
define('SPR_CONFIG_PATH',SPR_ROOT_SPATH.'');

if (get_magic_quotes_gpc()) {
    function undoMagicQuotes($array, $topLevel=true) {
        $newArray = array();
        foreach($array as $key => $value) {
            if (!$topLevel) {
                $key = stripslashes($key);
            }
            if (is_array($value)) {
                $newArray[$key] = undoMagicQuotes($value, false);
            }
            else {
                $newArray[$key] = stripslashes($value);
            }
        }
        return $newArray;
    }
    $_GET = undoMagicQuotes($_GET);
    $_POST = undoMagicQuotes($_POST);
    $_COOKIE = undoMagicQuotes($_COOKIE);
    $_REQUEST = undoMagicQuotes($_REQUEST);
}
//SrGantt
function import_extends($class_name){
	require_once SPR_INDEX_PATH.'core/extends/'.$class_name.'.php';
}

require(SPR_INDEX_PATH.'core/Sr.php');
require(SPR_INDEX_PATH.'core/SrAction.php');
require(SPR_INDEX_PATH.'core/SrService.php');
require(SPR_INDEX_PATH.'core/SrView.php');
require(SPR_INDEX_PATH.'core/SrBarView.php');
require(SPR_INDEX_PATH.'core/SrTabView.php');

require(SPR_INDEX_PATH.'core/mod/Page.class.php');
require(SPR_INDEX_PATH.'core/mod/TreeModel.class.php');
require(SPR_INDEX_PATH.'core/mod/SrUserSummary.php');
require(SPR_INDEX_PATH.'core/SrSecure.php');

require(SPR_INDEX_PATH.'core/extends/SrOpenFlashView.php');
require(SPR_INDEX_PATH.'core/extends/SrDict.php');
require(SPR_INDEX_PATH.'core/extends/SrUser.php');
require(SPR_INDEX_PATH.'core/extends/SrUup.php');
require(SPR_INDEX_PATH.'core/extends/SrSeq.php');
require(SPR_INDEX_PATH.'core/extends/SrSflow.php');
require(SPR_INDEX_PATH.'core/extends/SrLog.php');
require(SPR_INDEX_PATH.'core/extends/SrCas2.php');
require(SPR_INDEX_PATH.'core/extends/SrSflowService.php');
require(SPR_INDEX_PATH.'core/extends/SrViewPageHtml.php');
//require(SPR_INDEX_PATH.'core/extends/SrGantt.php');
require(SPR_INDEX_PATH.'core/extends/SrTree.php');
require(SPR_INDEX_PATH.'core/extends/SrRowVersion.php');
require(SPR_INDEX_PATH.'core/extends/SrAbstractTools.php');
require(SPR_INDEX_PATH.'core/extends/SrRac.php');
require(SPR_INDEX_PATH.'core/extends/SrThreadCache.php');
require(SPR_INDEX_PATH.'core/extends/SrNotify.php');
require(SPR_INDEX_PATH.'core/extends/SrWidget.php');
require(SPR_INDEX_PATH.'core/extends/SrImap.php');
//require(SPR_INDEX_PATH.'extends/optional/SrNotifyMail.php');

?>