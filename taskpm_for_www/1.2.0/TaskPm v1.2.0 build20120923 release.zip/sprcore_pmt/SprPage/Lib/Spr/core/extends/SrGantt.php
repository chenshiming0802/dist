<?php
/**
 * 向日葵甘特图帮助类
 */
class SrGantt extends SrService{
	public static function formatDate($str){
		if($str=='') return '';
		$d = Sr::sys_getDateFromDbString($str);
		return date('m/d/Y',$d);
	}
	/*
	 *
	 * 格式参照 http://www.51diaodu.cn/sfgantt/data/test.xml.aspx
	 * 例子：AppSfganttAction#queryTaskList
	 */
	 public static function generateXml($spModel=array()){
	 	$srModel = array();
		$tasks = Sr::sys_get($spModel["tasks"],array());
		$resources = Sr::sys_get($spModel["resources"],array());
		$assignments = Sr::sys_get($spModel["assignments"],array());

		$ret = "<?xml version='1.0' encoding='UTF-8'?>";

		$ret .= "<Project xmlns='http://schemas.microsoft.com/project'>";
		$ret .= "<Tasks>";

		$mm = array();
		$mm['uId'] = '0';
		$mm['iD'] = '0';
		$mm['name'] = '';
		$mm['createDate'] = date( "Y-m-d");
		$mm['outlineNumber'] ='0';
		$mm['start'] = date( "Y-m-d");
		$mm['finish'] = date( "Y-m-d");
		$mm['summary'] = '1';
		$mm['percentComplete'] = '';
		$mm['constraintType'] = '0';
		array_unshift ($tasks, $mm);

		foreach($tasks as $key=>$model){

//			if($model['summary']=='0' && (is_null($model['start']) || $model['start']=='' || is_null($model['finish']) || $model['finish']=='')){
//				continue;
//			}




			$model['percentComplete'] = str_replace("%","",$model['percentComplete']);

			$ret .= "<Task>";
			$ret .= self::addXmlNode('UID',$model['uId']);//
			$ret .= self::addXmlNode('ID',$model['id']);
			$ret .= self::addXmlNode('Name',$model['name']);

			if($model['createDate']!=''){
				$model['createDate'] = $model['createDate'].'T08:00:00';
				$ret .= self::addXmlNode('CreateDate',$model['createDate']);
			}
			$ret .= self::addXmlNode('OutlineNumber',$model['outlineNumber']);
			if($model['start']!=''){
				$model['start'] = $model['start'].'T08:00:00';
				$ret .= self::addXmlNode('Start',$model['start']);
			}
			if($model['finish']!=''){
				$model['finish'] = $model['finish'].'T17:00:00';
				$ret .= self::addXmlNode('Finish',$model['finish']);
			}
			$ret .= self::addXmlNode('Summary',$model['summary']);
			$ret .= self::addXmlNode('PercentComplete',$model['percentComplete']);
			$ret .= self::addXmlNode('ConstraintType',$model['constraintType']);
			$ret .= self::addXmlNode('HyperlinkAddress',$model['hyperlinkAddress']);
			foreach($model as $kk=>$vv){
				if(!in_array($kk,array('uId','name','name','createDate','outlineNumber','start','finish','summary','percentComplete','constraintType'))){
					$ret .= self::addXmlNode($kk,$vv);
				}
			}

			//$ret .= self::addXmlNode('manager_id','200022');
			$ret .= "</Task>";
		}
		$ret .= "</Tasks>";

		$ret .= "<Resources>";
		foreach($resources as $model){
			$ret .= "<Resource>";
			$ret .= self::addXmlNode('UID',$model['uId']);
			$ret .= self::addXmlNode('ID',$model['iD']);
			$ret .= "</Resource>";
		}
		$ret .= "</Resources>";

		$ret .= "<Assignments>";
		foreach($assignments as $model){
			$ret .= "<Assignment>";
			$ret .= self::addXmlNode('UID',$model['uId']);
			$ret .= self::addXmlNode('ID',$model['iD']);
			$ret .= self::addXmlNode('TaskUID',$model['taskUID']);
			$ret .= self::addXmlNode('ResourceUID',$model['resourceUID']);
			$ret .= self::addXmlNode('Units',$model['units']);
			$ret .= "</Assignment>";
		}
		$ret .= "</Assignments>";

		$ret .= "</Project>";
		//dump($ret);
		$srModel['data'] = $ret;

		return $srModel;
	}

	public static function addXmlNode($nodeName,$nodeValue){
		$nodeValue = str_replace("<","&lt;",$nodeValue);
		$nodeValue = str_replace(">","&gt;",$nodeValue);
		$nodeValue = str_replace("&","&amp;",$nodeValue);
		return "<{$nodeName}>{$nodeValue}</{$nodeName}>";
	}

}
?>