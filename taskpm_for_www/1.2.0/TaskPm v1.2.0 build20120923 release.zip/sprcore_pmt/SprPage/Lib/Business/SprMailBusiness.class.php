<?php
class SprMailBusiness extends SrService {
	//根据收件人接受邮件
	//如果有subject,则接收该邮件,如果无,则接受最新一条
	public function receiveMail($spModel){
		$srModel = array();
		$subject = $spModel['subject'];
		$from = $spModel['from'];
		$summary = SrUser::getUserSummary();
		$config = $summary->orgConfigs;

		//$obj= new SrImap('sprcore_server@163.com','abc123','sprcore_server@163.com','pop.163.com','pop3','110',false);//TODO

		$obj= new SrImap(
			$config['IMAP_RECEIVE_ADDRESS'],
			$config['IMAP_RECEIVE_PASSWORD'],
			$config['IMAP_RECEIVE_ADDRESS'],
			$config['IMAP_RECEIVE_SERVER'],
			$config['IMAP_RECEIVE_SERVER_TYPE'],
			$config['IMAP_RECEIVE_SERVER_PORT'],
			false);
		$obj->connect();
		$search = 'UNDELETED FROM "'.$from.'"';
		if($subject!=null && $subject!=''){
			$search .= ' SUBJECT "'.$subject.'"';
		}

		//echo $search;
		$some = imap_search($obj->marubox,$search , SE_UID);
		$model = array();
		if($some!==false){
			foreach($some as $index){
				$head=$obj->getHeaders($index);
				$model['subject'] = $obj->get_mime_header_decode($head['subject']);
				$model['content'] =  $obj->get_utf8_body($index);
				$model['from'] = $obj->get_mime_header_decode($head['from']);
				$model['from_name'] = $obj->get_mime_header_decode($head['from_name']);
				$model['to'] = $obj->get_mime_header_decode($head['to']);
				$model['to_name'] = $obj->get_mime_header_decode($head['to_name']);
				$model['toOth'] = $obj->get_mime_header_decode($head['toOth']);
				$model = self::insert2($model,'sys_mail_list');

				//保存附件
				$attaches = $obj->getAttachs($obj->marubox,$index);
				foreach($attaches as $detail){
					$mm = array();
					$mm['mail_list_id'] = $model['id'];
					$mm['original_document_name'] = $detail['original_document_name'];
					$mm['download_document_name'] = $detail['download_document_name'];
					$mm['path'] = $detail['path'];
					$mm['file_ext'] = $detail['file_ext'];
					$mm['file_size'] = $detail['file_size'];
					$mm = self::insert2($mm,'sys_mail_list_file');
				}
				imap_delete($obj->marubox,$index);

			}
		}
		imap_expunge($obj->marubox);
		$obj->close_mailbox();
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	//根据标题提取邮件信息
	public function getMailBySubject($spModel){
		$srModel = array();
		$subject = $spModel['subject'];
		$from = $spModel['from'];
		self::receiveMail($spModel);

		$sql = "select t.* from sys_mail_list t where t.from ='{0}'";
		$sql .= self::getCauseIfNotNull("t.subject like '%{0}%'",$subject);
		$sql .= " order by t.id desc";
		$model = self::getRowBySql($sql,array($from));
		if($model!==null){
			$sql = "select t.* from sys_mail_list_file t where t.mail_list_id='{0}'";
			$model['files'] = self::queryBySql($sql,array($model['id']));
		}
		$srModel['model'] = $model;

		self::addInfoResults($srModel,null);
		return $srModel;
	}




} //end class
?>