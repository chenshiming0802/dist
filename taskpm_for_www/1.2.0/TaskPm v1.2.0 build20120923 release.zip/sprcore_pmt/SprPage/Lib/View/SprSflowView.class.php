<?php

class SprSflowView extends SrView{
	public function editFlowStatus($spModel){
		$srModel = array();
		$dModel = $this->srModel['sys_sflow_d'];
		$title = $dModel['flow_d_name'];
		$this->title = Sr::sys_pl($title,array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>"/".SPR_ROOT_APATH."/SprPage/index.php/SprSflow/submitFlowStatus",
			"target"=>"_self",
			"onSubmit"=>"",
		);

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>$title,'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sflow_flow_d_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'sflow_flow_d_id',
			'control_value'=>"",
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel["sflow_flow_d_id"],
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sflow_business_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'sflow_business_id',
			'control_value'=>"",
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel["sflow_business_id"],
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sflow_business_num','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'sflow_business_num',
			'control_value'=>"",
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel["sflow_business_num"],
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sflow_return_url','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'sflow_return_url',
			'control_value'=>"",
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel["sflow_return_url"],
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sflow_from_status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'sflow_from_status',
			'control_value'=>"",
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel["sflow_from_status"],
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'need_sflow_from_status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'need_sflow_from_status',
			'control_value'=>"",
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel["need_sflow_from_status"],
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sflow_dst_status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'sflow_dst_status',
			'control_value'=>"",
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel["sflow_dst_status"],
		));

		L(include SPR_ROOT_SPATH.'\\'.$this->srModel['sys_sflow']['module_name'].'\Lang\zh-cn\common.php');//加载对应系统的文字内容
		$spModel2 = array();
		foreach($this->spModel as $k=>$v){
			$spModel2[$k]=$v;
		}

		$spModel2['view_refer'] = &$this;
		//T000510	       模块激活点击报错
		$input_add_method = $this->srModel['sys_sflow_d']['input_add_method'];
		if($input_add_method!=null&&$input_add_method!=''){
			Sr::sys_callSpMethod($this->srModel['sys_sflow']['flow_class'],$input_add_method,$spModel2);
		}


		if($dModel['user_content']!=null&&$dModel['user_content']!=''){
			$this->addItem(array(
				'div_id'=>'div_search_v','div_label'=>$dModel['user_content'],'item_line_type'=>'line','item_viewauth'=>'',
				'control_type'=>'TEXTAREA','control_name'=>'sflow_user_content',
				'control_value'=>"",
				'control_class'=>" ",'control_param'=>" ",'control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>"",
			));
		}


		$items = array('div_id'=>'div_search_v','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$status = $this->srModel['status'];
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'submitb',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>"",
				'value_input'=>'page.button.submit',
			);
		/*
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>"",
				'value_input'=>'page.button.close',
			);
		*/
		$this->addItems($items);

		$items = array('div_id'=>'div_search_v','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items[] = array(
				'control_type'=>'TEXTAREA','control_name'=>'sflow_user_content1',
				'control_value'=>"",
				'control_class'=>" ",'control_param'=>" ",'control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>"",
			);
		$items[] = array(
				'control_type'=>'TEXTAREA','control_name'=>'sflow_user_content',
				'control_value'=>"",
				'control_class'=>" ",'control_param'=>" ",'control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>"",
			);
		$this->addItems($items);

		self::addInfoResults($srModel,null);
		return $srModel;
	}

}

?>