<?php

class SysKeySetService extends SrService
{
 	public function querySysKeySet($spModel){
		$srModel = array();
		$sql = "select * from sys_key_set t where t.is_deleted='0' ";

		$sql .= self::getCauseIfNotNull("t.id like '%{0}%'",$spModel["query_id"]);
		$sql .= self::getCauseIfNotNull("t.code like '%{0}%'",$spModel["query_code"]);
		$sql .= self::getCauseIfNotNull("t.name like '%{0}%'",$spModel["query_name"]);
		$sql .= " order by id desc";
 		$srModel = self::queryPageBySql($sql);

		self::addInfoResults($srModel,null);
		return $srModel;
	}

 	public function getSysKeySet($spModel){
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$srModel = array();
		$srModel = self::queryById2($spModel["id"],"sys_key_set");
		if($srModel!=null){
			$srModel["details"] = self::queryBySql("select t.* from sys_key_value t where t.key_id={0} and t.is_deleted='0' order by seq asc",array($spModel["id"]));



		}

		if($detail_add_count_flag=="1"){
			$i = (int)$detail_add_count;
			while($i>0){
				$i--;
				$srModel["details"][] = null;
			}
		}		self::addInfoResults($srModel,null);
		return $srModel;
	}

	public function managerSysKeySet($spModel){

		//main id
		$id = $spModel["id"];

		//detail info
		$detail_id = $spModel["detail_id"];

		$detail_code = $spModel["detail_code"];
		$detail_name = $spModel["detail_name"];
		$detail_seq = $spModel["detail_seq"];
		$detail_id = $spModel["detail_id"];
		//del detail_id
		$detail_del_id = $spModel["detail_del_id"];
		$detail_add_id = explode(",",$spModel["detail_add_id"]);

		$srModel = array();
		if($id==null){
			$srModel = self::insert2($spModel,"sys_key_set");
			$id = $srModel["id"];
		}else{
			$srModel = self::update2($id,$spModel,"sys_key_set");
		}
		//add detail
		if($detail_id==null){
			$detail_id = array();
		}

		foreach($detail_id as $key=>$value){
			$dModel = array();
			$dModel["id"] = $detail_id[$key];

			$dModel["code"] = $detail_code[$key];
			$dModel["name"] = $detail_name[$key];
			$dModel["seq"] = $detail_seq[$key];
			$dModel["id"] = $detail_id[$key];
			$dModel["key_id"] = $id;

			if($value!=null && $value!=''){
				self::update2($dModel["id"],$dModel,"sys_key_value");
			}else{
				self::insert2($dModel,"sys_key_value");
			}
		}
		//delete detail
		if($detail_del_id!=null && $detail_del_id!=''){
			$model = array();
			$model["key_id"] = $id;
			$model["id"] = $detail_del_id;
			$model["is_deleted"] = "1";
			self::update2($model["id"],$model,"sys_key_value");
		}
		//add detail
		foreach($detail_add_id as $key=>$value){
			if($value==0 || $value==null){
				continue;
			}
			$dModel = array();
			$dModel["key_id"] = $id;
			$cnt = self::getCountBySql("select t.* from sys_key_value t where t.is_deleted='0' and t.key_id={0} ",
				array($id));
			if($cnt==0){
				self::insert2($dModel,"sys_key_value");
			}else{
				self::update2($dModel["id"],$dModel,"sys_key_value");
			}
		}
		if($status=='020'){
			self::addInfoResults($srModel,'message.success.submit',array($spModel["name"]));
		}else{
			self::addInfoResults($srModel,'message.success.update',array($spModel["name"]));
		}
		$srModel["sflow_method_business_id"] = $spModel["id"];//for sflow
		return $srModel;
	}
	public function editSysKeySet($spModel){
		$id = $spModel["id"];
		$srModel = array();
		if($id!=null&&$id!=''){
			$srModel = self::update2($id,$spModel,"sys_key_set");
		}else{
			$srModel = self::insert2($spModel,"sys_key_set");
		}

		self::addInfoResults($srModel,'message.success.update',array($srModel["name"]));
		return $srModel;
	}

	public function deleteSysKeySet($spModel){
		$srModel = array();
		$spModel["is_deleted"] = "1";
		$srModel = self::update2($spModel["id"],$spModel,"sys_key_set");
		self::addInfoResults($srModel,'message.success.delete',array($srModel["name"]));
		return $srModel;
	}
}//end class

?>