<?php
return array(
'WEB_MAX_OBJECT'=>array('uup_user'=>1000,'pmt_task'=>10000),
'PRIVATE_SN'=>'e3474caab0a8b909db676ff014aa6032',
);
?>
