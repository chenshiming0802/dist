<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='pmt_task'
//common.php:
$lanArray = array_merge($lanArray,include("DB.pmt_task.php"));
*/
return array(
'pmt_task'=>'任务信息',

'pmt_task.id'=>'ID',
'pmt_task.project_id'=>'项目',
'pmt_task.module_id'=>'子项目',
'pmt_task.code'=>'任务编号',
'pmt_task.parent_task_id'=>'父任务',
'pmt_task.name'=>'任务名称',
'pmt_task.proirity'=>'优先级',
'pmt_task.module_type_task_id'=>'任务类型',
'pmt_task.manager_id'=>'负责人',
'pmt_task.array_task_member'=>'人员',
'pmt_task.adv_begin_date'=>'预计开始',
'pmt_task.adv_end_date'=>'预计结束',
'pmt_task.adv_person_day'=>'预计人日',
//T000500	       去除任务的约束类型，约束时间修改为最后期限
//'pmt_task.constraint_type'=>'约束类型',
'pmt_task.constraint_time'=>'最后期限',
'pmt_task.content'=>'描述',
'pmt_task.url'=>'链接地址',
'pmt_task.ticket_type'=>'Ticket类型',
'pmt_task.status'=>'状态',
'pmt_task.no'=>'次序',
'pmt_task.type_ms_id'=>'里程碑',
'pmt_task.adv_progress'=>'计划进度',
'pmt_task.tsh_progress'=>'工时进度',
'pmt_task.act_progress'=>'实际进度',
'pmt_task.work_calc_type'=>'分解类型',//废弃
'pmt_task.module_follow_id'=>'后续处理类型',
'pmt_task.follow_task_id'=>'后续任务',
'pmt_task.business_person_name'=>'业务对口人',
);

?>