<?php
return array(
	"page.button.appadd"=>"新增",
);
?>