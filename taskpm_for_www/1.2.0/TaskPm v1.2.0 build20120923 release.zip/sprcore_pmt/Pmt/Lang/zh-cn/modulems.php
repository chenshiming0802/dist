<?php
return array(
	'queryModuleMs.title'=>'查询子项目(里程碑)',
	'saveModuleMsPage.title'=>'新增子项目(里程碑)',
	'editModuleMsPage.title'=>'修改子项目(里程碑)',
	'managerModuleMsPage.title'=>'修改子项目(里程碑)',
	'viewModuleMsPage.title'=>'查看子项目(里程碑)',
);

?>