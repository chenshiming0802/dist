<?php
return array(
	'queryTask.title'=>'查询任务信息',
	'saveTaskPage.title'=>'新增任务信息',
	'editTaskPage_010.title'=>'任务信息',
	'editTaskPage.title'=>'任务信息',
	'managerTaskPage.title'=>'维护任务信息',
	'viewTaskPage.title'=>'查看任务信息',

	'task.advtime.shortupbutton'=>'预计时间快捷选择',
	'buttom.fixtask.current.date'=>'当天',
	'buttom.fixtask.next.date'=>'明天',
	'buttom.fixtask.nextnext.date'=>'后天',
	'buttom.fixtask.current.week'=>'本周',
	'buttom.fixtask.next.week'=>'下周',
	'buttom.fixtask.current.month'=>'本月',
	'buttom.fixtask.next.month'=>'下月',
	'buttom.fixtask.next.week.1'=>'下周一',
	'buttom.fixtask.next.week.2'=>'下周二',
	'buttom.fixtask.next.week.3'=>'下周三',
	'buttom.fixtask.next.week.4'=>'下周四',
	'buttom.fixtask.next.week.5'=>'下周五',
	'buttom.task.getinfo'=>'获取任务信息',
	'label.task.source'=>'任务来源',

	"page.button.task.gantt"=>"任务甘特图维护",
);

?>