<?php
return array(
	'queryTask2Progress.title'=>'查询任务信息_时间进度',
	'saveTask2ProgressPage.title'=>'新增任务信息_时间进度',
	'editTask2ProgressPage.title'=>'修改任务信息_时间进度',
	'managerTask2ProgressPage.title'=>'修改任务信息_时间进度',
	'viewTask2ProgressPage.title'=>'查看任务信息_时间进度',
	
'pmt_task.table_id'=>'项目',
'pmt_task.table_name'=>'名称',
'pmt_task.adv_begin_date'=>'预计开始时间',
'pmt_task.adv_end_date'=>'预计结束时间',
'pmt_task.adv_work_day'=>'预计工期',
'pmt_task.adv_person_day'=>'预计人日',
'pmt_task.adv_progress'=>'计划进度',
'pmt_task.act_begin_date'=>'实际开始时间[废除]',
'pmt_task.act_end_date'=>'实际结束时间[废除]',
'pmt_task.act_work_day'=>'实际工期',
'pmt_task.act_person_day'=>'实际耗时',
'pmt_task.act_progress'=>'实际进度',
'pmt_task.tsh_begin_date'=>'工时开始时间',
'pmt_task.tsh_end_date'=>'工时结束时间',
'pmt_task.tsh_work_day'=>'工时工期',
'pmt_task.tsh_person_day'=>'实际工时',
'pmt_task.tsh_person_normal_day'=>'正常工时(H)',
'pmt_task.tsh_person_over_day'=>'加班工时(H)',
'pmt_task.tsh_progress'=>'实际工时进度',	
);

?>