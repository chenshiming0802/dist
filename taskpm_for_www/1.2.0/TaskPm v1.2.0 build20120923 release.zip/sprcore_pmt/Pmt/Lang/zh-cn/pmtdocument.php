<?php
return array(
	'queryDocument.title'=>'查询文档信息',
	'saveDocumentPage.title'=>'新增文档信息',
	'editDocumentPage.title'=>'修改文档信息',
	'managerDocumentPage.title'=>'修改文档信息',
	'viewDocumentPage.title'=>'查看文档信息',
);

?>