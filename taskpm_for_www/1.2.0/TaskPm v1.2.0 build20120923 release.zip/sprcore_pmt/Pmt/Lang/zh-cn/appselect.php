<?php
return array(
	'queryUupUser.title'=>'成员查询',
);

?>