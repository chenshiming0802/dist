<?php
return array(
	'queryTask2Depend.title'=>'查询任务信息_前置任务',
	'saveTask2DependPage.title'=>'新增任务信息_前置任务',
	'editTask2DependPage.title'=>'修改任务信息_前置任务',
	'managerTask2DependPage.title'=>'修改任务信息_前置任务',
	'viewTask2DependPage.title'=>'查看任务信息_前置任务',
);

?>