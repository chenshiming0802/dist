<?php
return array(
	'queryProject.title'=>'查询项目信息',
	'saveProjectPage.title'=>'新增项目信息',
	'editProjectPage.title'=>'修改项目信息',
	'managerProjectPage.title'=>'修改项目信息',
	'viewProjectPage.title'=>'查看项目信息',
);

?>