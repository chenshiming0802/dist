<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='pmt_task_member'
//common.php:
$lanArray = array_merge($lanArray,include("DB.pmt_task_member.php"));
*/
return array(
'pmt_task_member'=>'TaskMember',

'pmt_task_member.id'=>'ID',
'pmt_task_member.task_id'=>'项目',
'pmt_task_member.user_id'=>'成员',
'pmt_task_member.adv_begin_date'=>'预计开始时间',
'pmt_task_member.adv_end_date'=>'预计截至时间',
'pmt_task_member.user_rate'=>'使用率',);

?>