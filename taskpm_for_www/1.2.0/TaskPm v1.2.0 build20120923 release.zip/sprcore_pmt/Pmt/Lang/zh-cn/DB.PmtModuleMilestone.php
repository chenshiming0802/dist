<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='pmt_module_milestone'
//common.php:
$lanArray = array_merge($lanArray,include("DB.pmt_module_milestone.php"));
*/
return array(
'pmt_module_milestone'=>'子项目里程碑',

'pmt_module_milestone.id'=>'ID',
'pmt_module_milestone.module_id'=>'子项目',
'pmt_module_milestone.task_id'=>'里程碑事件',
'pmt_module_milestone.type_ms_id'=>'里程碑',
'pmt_module_milestone.adv_begin_date'=>'预计开始时间',
'pmt_module_milestone.adv_end_date'=>'预计结束时间',
'pmt_module_milestone.adv_person_day'=>'预计人日',
'pmt_module_milestone.progress'=>'进度',
'pmt_module_milestone.memo'=>'备注',
'pmt_module_milestone.no'=>' 次序',);

?>