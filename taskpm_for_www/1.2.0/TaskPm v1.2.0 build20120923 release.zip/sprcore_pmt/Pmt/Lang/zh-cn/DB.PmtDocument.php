<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='pmt_document'
//common.php:
$lanArray = array_merge($lanArray,include("DB.pmt_document.php"));
*/
return array(
'pmt_document'=>'文档信息',

'pmt_document.document_type'=>'文档类型',
'pmt_document.title'=>'标题',
'pmt_document.content'=>'描述',
'pmt_document.document_version'=>'文件版本',);

?>