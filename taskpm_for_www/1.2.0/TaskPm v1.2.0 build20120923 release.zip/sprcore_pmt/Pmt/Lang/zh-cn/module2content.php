<?php
return array(
	'queryModule2Content.title'=>'查询任务_内容',
	'saveModule2ContentPage.title'=>'新增任务_内容',
	'editModule2ContentPage.title'=>'修改任务_内容',
	'managerModule2ContentPage.title'=>'修改任务_内容',
	'viewModule2ContentPage.title'=>'查看任务_内容',
);

?>