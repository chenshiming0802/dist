<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='pmt_task_tsheet'
//common.php:
$lanArray = array_merge($lanArray,include("DB.pmt_task_tsheet.php"));
*/
return array(
'pmt_task_tsheet'=>'工时填报',

'pmt_task_tsheet.id'=>'ID',
'pmt_task_tsheet.project_id'=>'项目',
'pmt_task_tsheet.module_id'=>'子项目',
'pmt_task_tsheet.task_id'=>'任务',
'pmt_task_tsheet.occure_date'=>'发生时间',
'pmt_task_tsheet.hours'=>'正常工时(H)',
'pmt_task_tsheet.ext_hours'=>'加班工时(H)',
'pmt_task_tsheet.time_type'=>'[废弃]工作类型',
'pmt_task_tsheet.status'=>'状态',
'pmt_task_tsheet.memo'=>'备注',
'pmt_task_tsheet.belong_user_id'=>'所属人',);

?>