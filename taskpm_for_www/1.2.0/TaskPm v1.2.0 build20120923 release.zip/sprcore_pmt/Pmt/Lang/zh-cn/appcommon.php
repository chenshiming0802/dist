<?php
return array(
	'label.occure_date'=>'日期',
	'label.person_day'=>'人日',
	'label.person_day_type'=>'人日类型',
);

?>