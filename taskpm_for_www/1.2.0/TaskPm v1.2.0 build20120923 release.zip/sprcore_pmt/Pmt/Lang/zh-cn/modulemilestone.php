<?php
return array(
	'queryModuleMilestone.title'=>'查询子项目里程碑',
	'saveModuleMilestonePage.title'=>'新增子项目里程碑',
	'editModuleMilestonePage.title'=>'修改子项目里程碑',
	'managerModuleMilestonePage.title'=>'修改子项目里程碑',
	'viewModuleMilestonePage.title'=>'查看子项目里程碑',
);

?>