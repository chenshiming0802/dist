<?php
return array(
	"page.button.task.gantt.notice"=>"本系统使用的向日葵甘特图的免费版，可能会存在不稳定的情况出现。如有需要正式版的甘特图请联系sprcore_server@163.com",
);

?>