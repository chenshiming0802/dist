<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='pmt_progress'
//common.php:
$lanArray = array_merge($lanArray,include("DB.pmt_progress.php"));
*/
return array(
'pmt_progress'=>'进度_备用',

'pmt_progress.table_id'=>'项目',
'pmt_progress.table_name'=>'名称',
'pmt_progress.adv_begin_date'=>'预计开始',
'pmt_progress.adv_end_date'=>'预计结束',
'pmt_progress.adv_work_day'=>'预计工期',
'pmt_progress.adv_person_day'=>'预计人日',
'pmt_progress.adv_progress'=>'计划进度',
'pmt_progress.act_begin_date'=>'实际开始[废除]',
'pmt_progress.act_end_date'=>'实际结束[废除]',
'pmt_progress.act_work_day'=>'实际工期[废除]',
'pmt_progress.act_person_day'=>'实际耗时[废除]',
'pmt_progress.act_progress'=>'实际进度',
'pmt_progress.tsh_begin_date'=>'工时开始',
'pmt_progress.tsh_end_date'=>'工时结束',
'pmt_progress.tsh_work_day'=>'工时工期',
'pmt_progress.tsh_person_day'=>'实际工时',
'pmt_progress.tsh_person_normal_day'=>'上班工时(H)',
'pmt_progress.tsh_person_over_day'=>'加班工时(H)',
'pmt_progress.tsh_progress'=>'工时进度',);

?>