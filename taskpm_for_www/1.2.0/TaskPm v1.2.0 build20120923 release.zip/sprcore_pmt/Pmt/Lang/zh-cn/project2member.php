<?php
return array(
	'queryproject2Member.title'=>'查询项目信息_成员',
	'saveproject2MemberPage.title'=>'新增项目信息_成员',
	'editproject2MemberPage.title'=>'修改项目信息_成员',
	'managerproject2MemberPage.title'=>'修改项目信息_成员',
	'viewproject2MemberPage.title'=>'查看项目信息_成员',
);

?>