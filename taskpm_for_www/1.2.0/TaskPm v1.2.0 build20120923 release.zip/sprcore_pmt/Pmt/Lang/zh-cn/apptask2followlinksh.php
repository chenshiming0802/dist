<?php
return array(
	'viewTask2FollowLinkPage.title'=>'查看任务信息_上线任务清单',
	'managerTask2FollowLinkPage.title'=>'任务详情_上线任务维护'

);

?>