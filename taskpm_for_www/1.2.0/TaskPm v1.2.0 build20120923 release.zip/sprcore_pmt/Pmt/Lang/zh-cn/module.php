<?php
return array(
	'queryModule.title'=>'查询子项目',
	'saveModulePage.title'=>'新增子项目',
	'editModulePage.title'=>'修改子项目',
	'managerModulePage.title'=>'修改子项目',
	'viewModulePage.title'=>'查看子项目',
);

?>