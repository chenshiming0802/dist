<?php
return array(
	'tasklist.operate'=>'',
	'tasklist.content'=>'任务描述',
	'tasklist.enddate'=>'截止日期',
	'tasklist.end_date'=>'截止日期',
 
);

?>