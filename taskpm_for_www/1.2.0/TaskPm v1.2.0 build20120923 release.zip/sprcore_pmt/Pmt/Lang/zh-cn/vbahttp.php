<?php
return array(
	'message.info.upload.success'=>'文件上传成功!',
	'message.fail.upload.filename.notfound'=>'文件上传失败:服务器端文档不存在!!!',
	'message.fail.upload.filename.notcurrentversion'=>'文件上传失败:版本不是最新的!!!',
	'message.fail.upload.filename.wrong'=>'文件上传失败:文件名与服务器端不匹配{0}!!!',
	'message.fail.upload.filename.notfiletype'=>'文件上传失败:服务器文档不是文件类型!!!',
	'message.fail.upload.filename.sizeerror'=>'文件上传失败:服务器文档文件大小不匹配!!!',
	'message.fail.upload.filename.upload.exception'=>'文件上传失败:文件上传错误!!!',
);

?>