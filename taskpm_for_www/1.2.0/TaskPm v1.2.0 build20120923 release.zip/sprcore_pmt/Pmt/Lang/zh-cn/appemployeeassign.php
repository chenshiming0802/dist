<?php
return array(
	"page.button.appadd"=>"新增",
	"message.fail.insertemployeeassign.employeenotexits"=>"添加职员报错，原因可能是职员[{0}]不存在",
	"page.button.query_lack_employee"=>"查询空缺资源",
	"pmt_employee_assign.employee_count"=>"人数",
	"page.button.occupy"=>"全占",
	"pmt_employee_assign.occupy_month_info"=>'使用率',
	"viewEmployeeEmployeeAssign.title"=>'成员负荷',
);
?>