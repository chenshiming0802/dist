<?php
/*
//SELECT  CONCAT('\'',t.TABLE_NAME,'.',t.COLUMN_NAME,'\'=>','\'',t.COLUMN_COMMENT,'\',') FROM information_schema.COLUMNS t WHERE t.TABLE_SCHEMA = 'sprcore_all'  AND t.TABLE_NAME='pmt_employee'
//common.php:
$lanArray = array_merge($lanArray,include("DB.pmt_employee.php"));
*/
return array(
'pmt_employee'=>'公司职员',

'pmt_employee.id'=>'ID',
'pmt_employee.user_id'=>'登录帐号',
'pmt_employee.emp_no'=>'工号',
'pmt_employee.name'=>'姓名',
'pmt_employee.joblevel_id'=>'岗位级别',
'pmt_employee.depart_id'=>'所属部门',
'pmt_employee.company_id'=>'所属公司',
'pmt_employee.status'=>'入职状态',
'pmt_employee.memo'=>'备注',);

?>