<?php
class PmtTools extends SrAbstractTools {
	//模块是否可以修改
	public static function canEditModule($module_id) {
		$flag = self :: getValue_invokeBusiness("AppModuleBusiness", "isModuleManager", array (
			'module_id' => $module_id
		), 'Pmt', 'flag');
 		return $flag;
	}
	//模块是否可以创建
	public static function canAddModule($project_id){
		$model = self::queryById2($project_id,"pmt_project");
		if($model['manager_id']==SrUser::getUserId()||$model['config_user_id']==SrUser::getUserId()){
			return '1';
		}else{
			return '0';
		}

	}

	//任务是否可以修改
	public static function canEditTask($task_id) {

		$flag = self :: getValue_invokeBusiness("AppTaskBusiness", "isTaskManager", array (
			'task_id' => $task_id
		), 'Pmt', 'flag');

 		return $flag;
	}
	//任务是否可以创建
	public static function canAddTask($task_id){
		$flag = self :: getValue_invokeBusiness("AppTaskBusiness", "isTaskManager", array (
			'task_id' => $task_id
		), 'Pmt', 'flag');
 		return $flag;
	}
}
?>