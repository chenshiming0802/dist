<?php

class TaskTsheetService extends SrService
{

public function queryTaskTsheet($spModel){
		$srModel = array();

		$where = '';

		$where .= self::getCauseIfNotNull("t.id like '%{0}%'",$spModel["query_id"]);
		$where .= self::getCauseIfNotNull("t.module_id like '%{0}%'",$spModel["query_module_id"]);
		$where .= self::getCauseIfNotNull("t.task_id like '%{0}%'",$spModel["query_task_id"]);
		$where .= self::getCauseIfNotNull("t.occure_date like '%{0}%'",$spModel["query_occure_date"]);
		$where .= self::getCauseIfNotNull("t.hours like '%{0}%'",$spModel["query_hours"]);
		$where .= self::getCauseIfNotNull("t.ext_hours like '%{0}%'",$spModel["query_ext_hours"]);
		$where .= self::getCauseIfNotNull("t.time_type = '{0}'",$spModel["query_time_type"]);
		$where .= self::getCauseIfNotNull("t.status like '%{0}%'",$spModel["query_status"]);
		$where .= self::getCauseIfNotNull("t.memo like '%{0}%'",$spModel["query_memo"]);
		$where .= self::getCauseIfNotNull("t.belong_user_id like '%{0}%'",$spModel["query_belong_user_id"]);
		$where .= self::getCauseIfNotNull("t.belong_org_id = {0}",$spModel["query_belong_org_id"]);
		$where .= self::getCauseIfNotNull("t.belong_user_id = {0}",$spModel["query_belong_user_id"]);

		$where .= self::getCauseIfNotNull("t1.project_id = {0}",$spModel["query_project_id"]);
$sql = "select t.* ,t2.id project_id,t3.id module_id,t2.manager_id project_manager_id,t1.status task_status  from pmt_task_tsheet t ,pmt_task t1 ,pmt_project t2 ,pmt_module t3  where t.is_deleted='0' and t.task_id=t1.id and t1.project_id=t2.id and t1.module_id=t3.id {$where} order by t.occure_date DESC,t.belong_user_id asc ";

 		$srModel = self::queryPageBySql($sql);


		self::addInfoResults($srModel,null);
		return $srModel;
	}

 	public function getTaskTsheet($spModel){
		$id = $spModel["id"];
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$srModel = array();
		$srModel = self::queryById2($id,"pmt_task_tsheet");
		if($srModel!=null){



		}else{

		}

if($srModel['task_id']==null || $srModel['task_id']=='') $srModel['task_id'] = $spModel['task_id'];
$mm = self::queryById2($srModel['task_id'],'pmt_task');
$srModel['project_id'] = $mm['project_id'];
		$srModel['module_id'] = $mm['module_id'];
		self::addInfoResults($srModel,null);
		return $srModel;
	}




public function editTaskTsheet($spModel){
		$id = $spModel["id"];

		$srModel = array();
		if($id!=null&&$id!=''){

			$srModel = self::update2($id,$spModel,"pmt_task_tsheet");

		}else{

			$srModel = self::insert2($spModel,"pmt_task_tsheet");

			$spModel['id'] = $srModel['id'];

		}



		self::addInfoResults($srModel,'message.success.update',array($srModel["name"]));
		return $srModel;
	}


public function deleteTaskTsheet($spModel){
		$id = $spModel["id"];
		$srModel = array();
		$spModel["is_deleted"] = "1";

		$srModel = self::update2($id,$spModel,"pmt_task_tsheet");


		self::addInfoResults($srModel,'message.success.delete',array($srModel["name"]));
		return $srModel;
	}

}//end class



?>