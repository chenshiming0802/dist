<?php
class AppTaskFavoriteService extends SrService {
	//阅读
	public function doRead($spModel) {
		$srModel = array ();
		$task_id = $spModel['task_id'];

		$model = self :: queryById2($task_id, "pmt_task");
		if ($model == null) {
			self :: addInfoResults($srModel, null);
			return $srModel;
		}
		$user_id = SrUser :: getUserId();
		$sql = "select * from pmt_task_favorite t where t.task_id='{0}' and t.belong_user_id='{1}' /*w[t]*/";
		$cnt = self :: getCountBySql($sql, array (
			$task_id,
			$user_id
		));
		if ($cnt == 0) {
			$model = array ();
			$model['task_id'] = $task_id;
			self :: insert2($model, 'pmt_task_favorite');
		}
		self :: addInfoResults($srModel, null);
		return $srModel;
	}
	//未阅读
	public function unRead($spModel) {
		$srModel = array ();
		$task_id = $spModel['task_id'];

		$sql = "select * from pmt_task_favorite t where t.task_id='{0}' and t.belong_user_id='{1}' /*w[t]*/";
		$user_id = SrUser :: getUserId();
		$model = self :: getRowBySql($sql, array (
			$task_id,
			$user_id
		));
		if ($model != null) {
			$model['is_deleted'] = '1';
			self :: update2($model['id'], $model, 'pmt_task_favorite');
		}
		self :: addInfoResults($srModel, null);
		return $srModel;
	}
	//处理任务
	public function doProcess($spModel) {
		$srModel = array ();
		$task_id = $spModel['task_id'];

		$model = self :: queryById2($task_id, "pmt_task");
		if ($model == null) {
			self :: addInfoResults($srModel, null);
			return $srModel;
		}
		$user_id = SrUser :: getUserId();
		$today = Sr :: sys_date();

		$sql = "select * from pmt_task_tsheet t where t.task_id='{0}' and t.belong_user_id='{1}' and t.occure_date='{2}' /*w[t]*/";
		$cnt = self :: getCountBySql($sql, array (
			$task_id,
			$user_id,
			$today
		));
		if ($cnt == 0) {
			$model = array ();
			$model['task_id'] = $task_id;
			$model['occure_date'] = $today;
			$model['status'] = '010';
			self :: insert2($model, 'pmt_task_tsheet');
		}
		self :: addInfoResults($srModel, null);
		return $srModel;
	}
	public function indexMenu($spModel) {
		$srModel = array ();
		$sql = "SELECT DISTINCT t1.name,t1.id FROM pmt_project t1
					LEFT JOIN pmt_project_member t2 ON t1.id=t2.project_id /*w[t2]*/
				WHERE t1.status IN ('020','050')
				AND (t1.manager_id='{0}' or t1.config_user_id='{0}') /*w[t1]*/";
		$list = self::queryBySql($sql,array(SrUser::getUserId()));// OR t2.user_id='{0}'
		$srModel['project_list'] = $list;

		$sql = "SELECT DISTINCT t2.project_id ,t2.user_id,t3.name user_name
					FROM pmt_project t1,pmt_project_member t2,uup_user t3
				WHERE t1.id=t2.project_id and t2.user_id=t3.id and t1.status IN ('020','050')
				AND (t1.manager_id='{0}' or t1.config_user_id='{0}') /*w[t1,t2,t3]*/";
		$list = self::queryBySql($sql,array(SrUser::getUserId()));

		$srModel['project_member'] = $list;

		self :: addInfoResults($srModel, null);
		return $srModel;
	}
	public function indexTaskList($spModel) {
		$srModel = array ();
		$my_user_id = SrUser :: getUserId();
		$today = Sr :: sys_date();
		$where = "";
		//项目
		$where .= self :: getCauseIfNotNull("t1.project_id = '{0}'", $spModel["query_project_id"]);
		//负责人
		$where .= self :: getCauseIfNotNull("t1.manager_id={0} OR EXISTS (SELECT a1.* FROM pmt_task_member a1 WHERE a1.user_id={0} AND a1.task_id=t1.id /*w[a1]*/)",
			$spModel['query_user_id']);
		//状态:020 待处理,050:完成
		$where .= self :: getCauseIfNotNull("t1.status='{0}'", $spModel["query_task_status"]);
		//是否未读
		$where .= self :: getCauseIfNotNull("a1.id is null", $spModel["query_is_favorite"]);
		//是否今日处理
		$where .= self :: getCauseIfNotNull("a2.id is not null", $spModel["query_is_today_tsheet"]);
		//是否今日新增
		$where .= self :: getCauseIfNotNull("t1.create_time>'{$today} 00:00:00' AND  t1.create_time<'{$today} 59:59:59'",
			$spModel["query_is_today"]);
		//是否紧急任务
		$where .= self :: getCauseIfNotNull("t1.status='020' and t1.constraint_type='020' AND t1.constraint_time<='{$today}'", $spModel["query_is_today_emerg"]);
		//是否未指派:没有指派负责人,预计日期没有确认,状态是草稿状态的任务
		$where .= self :: getCauseIfNotNull("(t1.manager_id is null or t1.manager_id='0' or t3.adv_begin_date is null or t3.adv_end_date is null  or t1.status in ('010')) and t1.status in ('010','020')", $spModel["query_is_nomanager"]);
		//是否已指派
		$where .= self :: getCauseIfNotNull("t1.manager_id is not null and t1.manager_id<>'0' and t3.adv_begin_date is not null and t3.adv_end_date is not null", $spModel["query_is_hasmanager"]);

		if($spModel["query_key_type"]!=null && $spModel["query_key_type"]!='' && $spModel["query_key_value"]!=null && $spModel["query_key_value"]!=''){
			if(strlen($spModel["query_key_value"])<=2){
				self :: addFailResults($srModel, null);
				return $srModel;
			}
			switch($spModel["query_key_type"]){
				case 'task_code':
					$where .= self :: getCauseIfNotNull("t1.code like '%{0}%'", $spModel["query_key_value"]);
					break;
				case 'task_title':
					$where .= self :: getCauseIfNotNull("t1.name like '%{0}%'", $spModel["query_key_value"]);
					break;
				case 'task_content':
					$where .= self :: getCauseIfNotNull("t1.content like '%{0}%'", $spModel["query_key_value"]);
					break;
			}
		}

		// and t1.status in ('020','050')
		$sql = "select a1.id favorite_id,a2.id tsheet_id, t1.*,t1.id task_id ,t2.name module_name
						from pmt_task t1
								LEFT JOIN pmt_task_favorite a1 ON a1.task_id=t1.id and a1.belong_user_id={$my_user_id} /*w[a1]*/
								LEFT JOIN pmt_task_tsheet a2 ON a2.task_id=t1.id and a2.belong_user_id={$my_user_id} and a2.occure_date='{$today}' /*w[a2]*/
							,pmt_module t2 ,pmt_progress t3
						where t1.module_id=t2.id and t1.id=t3.table_id and t3.table_name='pmt_task' and  t1.spr_tree_type='020'  and t2.status='020' {$where} /*w[t1,t2]*/";

		if($spModel['SPR_SP_OPERATE']=='AJAX_COUNT'){
			$cnt = self :: getCountBySql($sql);
			$srModel['SPR_SR_AJAX_COUNT'] = $cnt;
			self :: addInfoResults($srModel, null);
			return $srModel;
		}
		$list = self :: queryBySql($sql);

		$list = self :: getValue_invokeBusiness("AppCommonBusiness", "progress_getRow2", array (
				'list' => $list,
				'table_name' => 'pmt_task'
			), '@','list');

		$list = self :: getValue_invokeBusiness("AppTaskBusiness", "getTaskInfo2", array (
				'list' => $list,
			), '@','list');

		foreach ($list as $k => $model) {
			$model['id'] = $model['task_id'];
			$model = self :: getValue_invokeBusiness("AppCommonBusiness", "task_calcProgress", $model, '@', 'spModel');
			$srModel['list'][] = $model;
		}
		$srModel['list'] = Sr :: sys_array2sort($srModel['list'], "star", SORT_DESC);

		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function indexTop($spModel) {
		$srModel = array ();
		$sql = "SELECT DISTINCT t1.name,t1.id FROM pmt_project t1
					LEFT JOIN pmt_project_member t2 ON t1.id=t2.project_id /*w[t2]*/
				WHERE t1.status IN ('020','050')
				AND (t1.manager_id='{0}' OR t2.user_id='{0}') /*w[t1]*/";
		$list = self::queryBySql($sql,array(SrUser::getUserId()));

		$srModel['project_list'] = $list;
		self :: addInfoResults($srModel, null);
		return $srModel;
	}


	public function indexFrame($spModel) {
		$srModel = array ();

		self :: addInfoResults($srModel, null);
		return $srModel;
	}
}
?>
