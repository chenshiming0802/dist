<?php
class AppEmployeeAssignService extends SrService{

//public function queryEmployeeAssign($spModel){
//		$srModel = array();
//
//		$where = '';
//
//		$where .= self::getCauseIfNotNull("t.id like '%{0}%'",$spModel["query_id"]);
//		$where .= self::getCauseIfNotNull("t.status like '%{0}%'",$spModel["query_status"]);
//		$where .= self::getCauseIfNotNull("t.employee_id = '{0}'",$spModel["query_employee_id"]);
//		$where .= self::getCauseIfNotNull("t.project_id = '{0}'",$spModel["query_project_id"]);
//		$where .= self::getCauseIfNotNull("t.joblevel_id = '{0}'",$spModel["query_joblevel_id"]);
//		$where .= self::getCauseIfNotNull("t.company_id = '{0}'",$spModel["query_company_id"]);
//		$where .= self::getCauseIfNotNull("t.memo like '%{0}%'",$spModel["query_memo"]);
//		$where .= self::getCauseIfNotNull("t.year like '%{0}%'",$spModel["query_year"]);
//		$where .= self::getCauseIfNotNull("t.m1 like '%{0}%'",$spModel["query_m1"]);
//		$where .= self::getCauseIfNotNull("t.m2 like '%{0}%'",$spModel["query_m2"]);
//		$where .= self::getCauseIfNotNull("t.m3 like '%{0}%'",$spModel["query_m3"]);
//		$where .= self::getCauseIfNotNull("t.m4 like '%{0}%'",$spModel["query_m4"]);
//		$where .= self::getCauseIfNotNull("t.m5 like '%{0}%'",$spModel["query_m5"]);
//		$where .= self::getCauseIfNotNull("t.m6 like '%{0}%'",$spModel["query_m6"]);
//		$where .= self::getCauseIfNotNull("t.m7 like '%{0}%'",$spModel["query_m7"]);
//		$where .= self::getCauseIfNotNull("t.m8 like '%{0}%'",$spModel["query_m8"]);
//		$where .= self::getCauseIfNotNull("t.m9 like '%{0}%'",$spModel["query_m9"]);
//		$where .= self::getCauseIfNotNull("t.m10 like '%{0}%'",$spModel["query_m10"]);
//		$where .= self::getCauseIfNotNull("t.m11 like '%{0}%'",$spModel["query_m11"]);
//		$where .= self::getCauseIfNotNull("t.m12 like '%{0}%'",$spModel["query_m12"]);
//		$where .= self::getCauseIfNotNull("t.belong_org_id = {0}",$spModel["query_belong_org_id"]);
//		$where .= self::getCauseIfNotNull("t.belong_user_id = {0}",$spModel["query_belong_user_id"]);
//
//
//		$sql = "select t.project_id,t.year,SUM(t.m1) m1,SUM(t.m2) m2,SUM(t.m3) m3,SUM(t.m4) m4,SUM(t.m5) m5,SUM(t.m6) m6,SUM(t.m7) m7,SUM(t.m8) m8,SUM(t.m9) m9,SUM(t.m10) m10,SUM(t.m11) m11,SUM(t.m12) m12
// from pmt_employee_assign t  where 1=1 /*w[t]*/ {$where} group by t.project_id,t.year  order by t.project_id desc";
//
//
// 		$srModel = self::queryPageBySql($sql);
//
//
//		self::addInfoResults($srModel,null);
//		return $srModel;
//	}

public function queryEmployeeAssign($spModel){
		$srModel = array();
		$where = '';

		$where .= self::getCauseIfNotNull("t.id like '%{0}%'",$spModel["query_id"]);
		$where .= self::getCauseIfNotNull("t.status like '%{0}%'",$spModel["query_status"]);
		$where .= self::getCauseIfNotNull("t.employee_id = '{0}'",$spModel["query_employee_id"]);
		$where .= self::getCauseIfNotNull("t.project_id = '{0}'",$spModel["query_project_id"]);
		$where .= self::getCauseIfNotNull("t.joblevel_id = '{0}'",$spModel["query_joblevel_id"]);
		$where .= self::getCauseIfNotNull("t.company_id = '{0}'",$spModel["query_company_id"]);
		$where .= self::getCauseIfNotNull("t.year like '%{0}%'",$spModel["query_year"]);
		$where .= self::getCauseIfNotNull("t.belong_org_id = {0}",$spModel["query_belong_org_id"]);
		$where .= self::getCauseIfNotNull("t.belong_user_id = {0}",$spModel["query_belong_user_id"]);

		$where .= self::getCauseIfNotNull("t.employee_id = '-1'",$spModel["query_employee_lack"]);

		$sql = "select t.* from pmt_employee_assign t  where 1=1 /*w[t]*/ {$where}  order by id desc";


 		$srModel = self::queryPageBySql($sql);

 /*add group info*/
 		$where2 = self::getCauseIfNotNull("t.year like '%{0}%'",$spModel["query_year"]);
 		$where2 = self::getCauseIfNotNull("t.status like '%{0}%'",$spModel["query_status"]);
 		$sql = "SELECT t.employee_id,
  SUM(t.m1)    m1,
  SUM(t.m2)    m2,
  SUM(t.m3)    m3,
  SUM(t.m4)    m4,
  SUM(t.m5)    m5,
  SUM(t.m6)    m6,
  SUM(t.m7)    m7,
  SUM(t.m8)    m8,
  SUM(t.m9)    m9,
  SUM(t.m10)    m10,
  SUM(t.m11)    m11,
  SUM(t.m12)    m12
FROM pmt_employee_assign t
WHERE t.employee_id IN({-1})  {$where2}
/*w[t]*/ GROUP BY t.employee_id";
 		$srModel['list'] = self::addListItemInfo(
 			$srModel['list'],
			"employee_id",
			"employee_id",
			"group_",
			$sql,
			array()
		);
/*add group info*/

		self::addInfoResults($srModel,null);
		return $srModel;
	}


 	public function getEmployeeAssign($spModel){
		$project_id = $spModel["project_id"];
		$year = $spModel["year"];

		$srModel = array();
		$sql = "SELECT t1.id employee_id,t1.emp_no,t1.name,t1.joblevel_id,t1.company_id,t1.status,t2.*
FROM  pmt_employee t1,pmt_employee_assign t2
WHERE t1.id=t2.employee_id
AND t2.status='020' /*w[t1,t2]*/ and t2.project_id='{0}' and t2.year='{1}'";
		$srModel['list'] = self::queryBySql($sql,array($project_id,$year));

/*add group info*/
 		$where2 = self::getCauseIfNotNull("t.year like '%{0}%'",$spModel["query_year"]);
 		$where2 = self::getCauseIfNotNull("t.status like '%{0}%'",$spModel["query_status"]);
 		$sql = "SELECT t.employee_id,
  SUM(t.m1)    m1,
  SUM(t.m2)    m2,
  SUM(t.m3)    m3,
  SUM(t.m4)    m4,
  SUM(t.m5)    m5,
  SUM(t.m6)    m6,
  SUM(t.m7)    m7,
  SUM(t.m8)    m8,
  SUM(t.m9)    m9,
  SUM(t.m10)    m10,
  SUM(t.m11)    m11,
  SUM(t.m12)    m12
FROM pmt_employee_assign t
WHERE t.employee_id IN({-1})  {$where2}
/*w[t]*/ GROUP BY t.employee_id";
 		$srModel['list'] = self::addListItemInfo(
 			$srModel['list'],
			"employee_id",
			"employee_id",
			"group_",
			$sql,
			array()
		);
/*add group info*/

		$srModel['project_id'] = $project_id;
		$srModel['year'] = $year;

		self::addInfoResults($srModel,null);
		return $srModel;
	}
	public function editEmployeeAssign($spModel){
//		$id = $spModel["id"];
		$project_id = $spModel["project_id"];
		$year = $spModel["year"];
		$detail_id = $spModel["detail_id"];
		$detail_del_id = $spModel["detail_del_id"];
		$detail_add_id = explode(",",$spModel["detail_add_id"]);

		$srModel = array();

		foreach($detail_id as $key=>$value){
			$dModel = array();
			$dModel["id"] = $detail_id[$key];

			$dModel["id"] = $detail_id[$key];
			$dModel["m1"] = $spModel['m1'][$key];
			$dModel["m2"] = $spModel['m2'][$key];
			$dModel["m3"] = $spModel['m3'][$key];
			$dModel["m4"] = $spModel['m4'][$key];
			$dModel["m5"] = $spModel['m5'][$key];
			$dModel["m6"] = $spModel['m6'][$key];
			$dModel["m7"] = $spModel['m7'][$key];
			$dModel["m8"] = $spModel['m8'][$key];
			$dModel["m9"] = $spModel['m9'][$key];
			$dModel["m10"] = $spModel['m10'][$key];
			$dModel["m11"] = $spModel['m11'][$key];
			$dModel["m12"] = $spModel['m12'][$key];
			$dModel["project_joblevel_id"] = $spModel['project_joblevel_id'][$key];
			$dModel["joblevel_id"] = $spModel['joblevel_id'][$key];
			$dModel["company_id"] = $spModel['company_id'][$key];
			if($value!=null && $value!=''&&$value!='-1'){
				self::update2($dModel["id"],$dModel,"pmt_employee_assign");
			}else{
				self::insert2($dModel,"pmt_employee_assign");
			}
		}
		//delete detail
		if($detail_del_id!=null && $detail_del_id!=''){
			$model = array();
			$model["id"] = $detail_del_id;
			$model["is_deleted"] = "1";
			self::update2($model["id"],$model,"pmt_employee_assign");
		}
		//add detail
		foreach($detail_add_id as $key=>$value){
			if($value==0 || $value==null){
				continue;
			}
			$dModel = array();
			$dModel["employee_id"] = $value;
			$dModel["project_id"] = $project_id;
			$dModel["year"] = $year;
			$employee = self::queryById2($dModel["employee_id"],"pmt_employee");
			if($employee==null){
				self::addFailResults($srModel,'message.fail.insertemployeeassign.employeenotexits',array($dModel["employee_id"]));
				return $srModel;
			}
			$dModel["joblevel_id"] = $employee['joblevel_id'];
			$dModel["company_id"] = $employee['company_id'];
			$dModel["status"] = '020';
			$cnt = self::getCountBySql("select t.* from pmt_employee_assign t where 1=1 /*w[t]*/ and t.employee_id={0} and t.project_id={1} and t.year='{2}'",
				array($value,$project_id,$year));
			if($cnt==0||$value=='-1'){
				self::insert2($dModel,"pmt_employee_assign");
			}else{
				self::update2($dModel["id"],$dModel,"pmt_employee_assign");
			}
		}
		self::addInfoResults($srModel,'message.success.update',array($srModel["name"]));
		return $srModel;
	}
}
?>
