<?php
class AppMessageReService extends SrService{	

}
?>
