<?php
 
class Task2FollowLinkService extends SrService
{
 
	
	

}//end class



?>