<?php

class ModuleService extends SrService
{

public function queryModule($spModel){
		$srModel = array();

		$where = '';

		$where .= self::getCauseIfNotNull("t.id like '%{0}%'",$spModel["query_id"]);
		$where .= self::getCauseIfNotNull("t.project_id like '%{0}%'",$spModel["query_project_id"]);
		$where .= self::getCauseIfNotNull("t.module_type_id = '{0}'",$spModel["query_module_type_id"]);
		$where .= self::getCauseIfNotNull("t.code like '%{0}%'",$spModel["query_code"]);
		$where .= self::getCauseIfNotNull("t.status like '%{0}%'",$spModel["query_status"]);
		$where .= self::getCauseIfNotNull("t.name like '%{0}%'",$spModel["query_name"]);
		$where .= self::getCauseIfNotNull("t.proirity = '{0}'",$spModel["query_proirity"]);
		$where .= self::getCauseIfNotNull("t.manager_id = '{0}'",$spModel["query_manager_id"]);
		$where .= self::getCauseIfNotNull("t.adv_begin_date like '%{0}%'",$spModel["query_adv_begin_date"]);
		$where .= self::getCauseIfNotNull("t.adv_end_date like '%{0}%'",$spModel["query_adv_end_date"]);
		$where .= self::getCauseIfNotNull("t.url like '%{0}%'",$spModel["query_url"]);
		$where .= self::getCauseIfNotNull("t.depend_module_id = '{0}'",$spModel["query_depend_module_id"]);
		$where .= self::getCauseIfNotNull("t.content like '%{0}%'",$spModel["query_content"]);
		$where .= self::getCauseIfNotNull("t.adv_progress like '%{0}%'",$spModel["query_adv_progress"]);
		$where .= self::getCauseIfNotNull("t.tsh_progress like '%{0}%'",$spModel["query_tsh_progress"]);
		$where .= self::getCauseIfNotNull("t.act_progress like '%{0}%'",$spModel["query_act_progress"]);
		$where .= self::getCauseIfNotNull("t.belong_org_id = {0}",$spModel["query_belong_org_id"]);
		$where .= self::getCauseIfNotNull("t.belong_user_id = {0}",$spModel["query_belong_user_id"]);

		$sql = "SELECT t.*,t1.adv_begin_date,t1.adv_end_date,t1.adv_work_day,t1.adv_person_day,t1.adv_progress,t1.act_begin_date,t1.act_end_date,t1.act_work_day,t1.act_person_day,t1.act_progress,t1.tsh_begin_date,t1.tsh_end_date,t1.tsh_work_day,t1.tsh_person_day,t1.tsh_person_normal_day,t1.tsh_person_over_day,t1.tsh_progress  FROM pmt_module t ,pmt_progress t1  WHERE t.is_deleted='0' AND t.id=t1.table_id AND t1.table_name='pmt_module' {$where} order by t.id desc";

 		$srModel = self::queryPageBySql($sql);

foreach($srModel['list'] as $k=>$model){
	$model = self::getValue_invokeBusiness("AppCommonBusiness","module_calcProgress",$model,'@','spModel');
	$srModel['list'][$k] = $model;
}
		self::addInfoResults($srModel,null);
		return $srModel;
	}

 	public function getModule($spModel){
		$id = $spModel["id"];
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$srModel = array();
		$srModel = self::queryById2($id,"pmt_module");
		if($srModel!=null){



		}else{

		}
$srModel2 = self::invokeBusiness("AppCommonBusiness","progress_getRow",array('table_id'=>$spModel["id"],'table_name'=>'pmt_module'),'@');
$srModel = Sr::sys_copyProperties($srModel,$srModel2);
		self::addInfoResults($srModel,null);
		return $srModel;
	}




public function editModule($spModel){
		$id = $spModel["id"];

		$srModel = array();
		if($id!=null&&$id!=''){

			$srModel = self::update2($id,$spModel,"pmt_module");

		}else{
		   $spModel['code'] = self::getValue_invokeBusiness("AppCommonBusiness","module_genNo",array(array()),'@','code');

			$srModel = self::insert2($spModel,"pmt_module");

			$spModel['id'] = $srModel['id'];



		}

		self::invokeBusiness("AppCommonBusiness","module_addMileStone",array("id"=>$srModel['id']));
self::invokeBusiness("AppCommonBusiness","progress_fillModule",$spModel);

		self::addInfoResults($srModel,'message.success.update',array($srModel["name"]));
		return $srModel;
	}


public function deleteModule($spModel){
		$id = $spModel["id"];
		$srModel = array();
		$spModel["is_deleted"] = "1";

		$srModel = self::update2($id,$spModel,"pmt_module");


		self::addInfoResults($srModel,'message.success.delete',array($srModel["name"]));
		return $srModel;
	}

}//end class



?>