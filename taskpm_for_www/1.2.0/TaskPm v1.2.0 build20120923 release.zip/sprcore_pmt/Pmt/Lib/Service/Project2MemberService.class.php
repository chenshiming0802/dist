<?php

class Project2MemberService extends SrService
{



 	public function getProject2Member($spModel){
		$id = $spModel["id"];
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$srModel = array();
		$srModel = self::queryById2($id,"pmt_project");
		if($srModel!=null){
			$srModel["details"] = self::queryBySql("select t.* from pmt_project_member t where t.project_id={0} /*w[t]*/",array($id));



		}else{

		}

		if($detail_add_count_flag=="1"){
			$i = (int)$detail_add_count;
			while($i>0){
				$i--;
				$srModel["details"][] = null;
			}
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}



	public function managerProject2Member($spModel){
		//main id
		$id = $spModel["id"];


		//detail info
		$detail_id = $spModel["detail_id"];

		$detail_id = $spModel["detail_id"];
		$detail_project_id = $spModel["detail_project_id"];
		$detail_user_id = $spModel["detail_user_id"];
		$detail_adv_begin_date = $spModel["detail_adv_begin_date"];
		$detail_adv_end_date = $spModel["detail_adv_end_date"];
		$detail_user_rate = $spModel["detail_user_rate"];
		//del detail_id
		$detail_del_id = $spModel["detail_del_id"];
		$detail_add_id = explode(",",$spModel["detail_add_id"]);

		$srModel = array();
		if($id==null){

			$srModel = self::insert2($spModel,"pmt_project");



			$id = $srModel["id"];
		}else{

			$srModel = self::update2($id,$spModel,"pmt_project");

		}
		//add detail
		foreach($detail_id as $key=>$value){
			$dModel = array();
			$dModel["id"] = $detail_id[$key];

			$dModel["id"] = $detail_id[$key];
			$dModel["project_id"] = $detail_project_id[$key];
			$dModel["user_id"] = $detail_user_id[$key];
			$dModel["adv_begin_date"] = $detail_adv_begin_date[$key];
			$dModel["adv_end_date"] = $detail_adv_end_date[$key];
			$dModel["user_rate"] = $detail_user_rate[$key];
			$dModel["project_id"] = $id;
			if($value!=null && $value!=''){
				self::update2($dModel["id"],$dModel,"pmt_project_member");
			}else{
				self::insert2($dModel,"pmt_project_member");
			}
		}
		//delete detail
		if($detail_del_id!=null && $detail_del_id!=''){
			$model = array();
			$model["project_id"] = $id;
			$model["id"] = $detail_del_id;
			$model["is_deleted"] = "1";
			self::update2($model["id"],$model,"pmt_project_member");
		}
		//add detail
		foreach($detail_add_id as $key=>$value){
			if($value==0 || $value==null){
				continue;
			}
			$dModel = array();
			$dModel["project_id"] = $id;
			$dModel["user_id"] = $value;
			$cnt = self::getCountBySql("select t.* from pmt_project_member t where 1=1 /*w[t]*/ and t.project_id={0} and t.user_id={1}",
				array($id,$value));
			if($cnt==0){
				self::insert2($dModel,"pmt_project_member");
			}else{
				self::update2($dModel["id"],$dModel,"pmt_project_member");
			}
		}


		self::addInfoResults($srModel,'message.success.update',array($spModel["name"]));
		$srModel["sflow_method_business_id"] = $id;//for sflow
		return $srModel;
	}






}//end class



?>