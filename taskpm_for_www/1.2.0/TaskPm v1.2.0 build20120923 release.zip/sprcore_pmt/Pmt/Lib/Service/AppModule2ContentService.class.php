<?php
class AppModule2ContentService extends SrService{	

}
?>
