<?php
class AppTaskService extends SrService {
	/*查找项目组成员的今日任务*/
	public function queryPersonTodayTask($spModel){
		$srModel = array();
		$query_user_id = $spModel['query_user_id'];
		$query_project_id = $spModel['query_project_id'];

		$where = "";
		$where .= self::getCauseIfNotNull("t1.project_id = '{0}'",$spModel["query_project_id"]);

 		$sql2 = self::getCauseIfNotNull("t1.manager_id={0} OR EXISTS (SELECT a1.* FROM pmt_task_member a1 WHERE a1.user_id={0} AND a1.task_id=t1.id /*w[a1]*/)",$query_user_id);
		$sql3 = " and t2.status='020' ";
		$sql = "select   t1.id,t1.name,t1.code,t1.status,t1.manager_id from pmt_task t1,pmt_module t2 where t1.module_id=t2.id and  t1.spr_tree_type='020' {$sql2} {$sql3} {$where} /*w[t1,t2]*/";
		$list = self::queryBySql($sql);

		foreach($list as $k=>$model){
			$srModel2 = self::invokeBusiness("AppCommonBusiness","progress_getRow",array('table_id'=>$model["id"],'table_name'=>'pmt_task'),'@');
			$model = Sr::sys_copyProperties($model,$srModel2);

			$srModel2 = self::invokeBusiness("AppTaskBusiness","getTaskInfo",array('id'=>$model['id'],'need_tsheet'=>'1'),'@');
			$model = Sr::sys_copyProperties($model,$srModel2);

			$model = self::getValue_invokeBusiness("AppCommonBusiness","task_calcProgress",$model,'@','spModel');
			$srModel['list'][] = $model;
		}

		$srModel['list'] = Sr::sys_array2sort($srModel['list'],"star",SORT_DESC);

		self :: addInfoResults($srModel, null);
		return $srModel;
	}


	public function queryTaskList($spModel) {
		$srModel = array ();
		$task_id = $spModel["id"];
		$where .= self::getCauseIfNotNull("t.id like '%{0}%'",$spModel["query_id"]);
		$where .= self::getCauseIfNotNull("t.project_id = '{0}'",$spModel["query_project_id"]);
		$where .= self::getCauseIfNotNull("t.module_id = '{0}'",$spModel["query_module_id"]);
		$where .= self::getCauseIfNotNull("t.code like '%{0}%'",$spModel["query_code"]);
		$where .= self::getCauseIfNotNull("t.parent_task_id like '%{0}%'",$spModel["query_parent_task_id"]);
		$where .= self::getCauseIfNotNull("t.name like '%{0}%'",$spModel["query_name"]);
		$where .= self::getCauseIfNotNull("t.proirity = '{0}'",$spModel["query_proirity"]);
		$where .= self::getCauseIfNotNull("t.module_type_task_id like '%{0}%'",$spModel["query_module_type_task_id"]);
		$where .= self::getCauseIfNotNull("t.manager_id = '{0}'",$spModel["query_manager_id"]);
		$where .= self::getCauseIfNotNull("EXISTS(SELECT a.* FROM pmt_task_member a WHERE 1=1 /*w[a]*/ and a.task_id = t.id AND a.user_id IN({0}))",$spModel["query_array_task_member"]);
		$where .= self::getCauseIfNotNull("t.adv_begin_date like '%{0}%'",$spModel["query_adv_begin_date"]);
		$where .= self::getCauseIfNotNull("t.adv_end_date like '%{0}%'",$spModel["query_adv_end_date"]);
		$where .= self::getCauseIfNotNull("t.adv_person_day like '%{0}%'",$spModel["query_adv_person_day"]);
		$where .= self::getCauseIfNotNull("t.constraint_type = '{0}'",$spModel["query_constraint_type"]);
		$where .= self::getCauseIfNotNull("t.constraint_time like '%{0}%'",$spModel["query_constraint_time"]);
		$where .= self::getCauseIfNotNull("t.content like '%{0}%'",$spModel["query_content"]);
		$where .= self::getCauseIfNotNull("t.url like '%{0}%'",$spModel["query_url"]);
		$where .= self::getCauseIfNotNull("t.ticket_type like '%{0}%'",$spModel["query_ticket_type"]);
		$where .= self::getCauseIfNotNull("t.status like '%{0}%'",$spModel["query_status"]);
		$where .= self::getCauseIfNotNull("t.no like '%{0}%'",$spModel["query_no"]);
		$where .= self::getCauseIfNotNull("t.type_ms_id like '%{0}%'",$spModel["query_type_ms_id"]);
		$where .= self::getCauseIfNotNull("t.adv_progress like '%{0}%'",$spModel["query_adv_progress"]);
		$where .= self::getCauseIfNotNull("t.tsh_progress like '%{0}%'",$spModel["query_tsh_progress"]);
		$where .= self::getCauseIfNotNull("t.act_progress like '%{0}%'",$spModel["query_act_progress"]);
		$where .= self::getCauseIfNotNull("t.work_calc_type = '{0}'",$spModel["query_work_calc_type"]);
		$where .= self::getCauseIfNotNull("t.module_follow_id like '%{0}%'",$spModel["query_module_follow_id"]);
		$where .= self::getCauseIfNotNull("t.belong_org_id = {0}",$spModel["query_belong_org_id"]);
		$where .= self::getCauseIfNotNull("t.belong_user_id = {0}",$spModel["query_belong_user_id"]);

		if($spModel['query_employee_id']!=null&&$spModel['query_employee_id']!=''){
			$employee = self::queryById2($spModel['query_employee_id'],"pmt_employee");
			if($employee!=null){
				$where .= self::getCauseIfNotNull("t.manager_id = '{0}' or EXISTS(SELECT a.* FROM pmt_task_member a WHERE 1=1 /*w[a]*/ and a.task_id = t.id AND a.user_id ={0})",$employee["user_id"]);
			}
		}
		//dump($where);
		$sql = "select t.* ,t2.id module_id, t2.name module_name,  t1. adv_begin_date,
  t1. adv_end_date,
  t1.adv_work_day,
  t1.adv_person_day,
  t1.adv_progress,
  t1.act_begin_date,
  t1.act_end_date,
  t1.act_work_day,
  t1.act_person_day,
  t1.act_progress,
  t1.tsh_begin_date,
  t1.tsh_end_date,
  t1.tsh_work_day,
  t1.tsh_person_day,
  t1.tsh_person_normal_day,
  t1.tsh_person_over_day,
  t1.tsh_progress from pmt_task t,pmt_progress t1,pmt_module t2 where  1=1 and t.module_id=t2.id AND t.id = t1.table_id
    AND t1.table_name = 'pmt_task'  {$where} /*w[t,t1,t2]*/ order by id desc";
 		$srModel = self::queryPageBySql($sql,array());
//		foreach($srModel['list'] as $k=>$model){
//			$srModel2 = self::queryBySql("select t.user_id from pmt_task_member t where t.task_id={0} /*w[t]*/",array($model["id"]));
//			$srModel['list'][$k]['array_task_member'] = Sr::sys_listToPostparam($srModel2,'user_id');
//		}
		foreach($srModel['list'] as $k=>$model){
			$model = self::getValue_invokeBusiness("AppCommonBusiness","task_calcProgress",$model,'@','spModel');
			$srModel['list'][$k] = $model;
		}

		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function queryDocuments($spModel) {
		$srModel = array ();
		$task_id = $spModel["id"];
		$where = '';


		$sql = "
SELECT t.*,t1.belong_user_id link_belong_user_id FROM pmt_document t,pmt_document_link t1
WHERE t.id=t1.document_id
AND t1.table_name='{0}' and t.status<>'000' and t.is_current_version='1'
AND t1.table_id = {1}
{$where} /*w[t,t1]*/
		";
		$srModel['list'] = self :: queryBySql($sql,array('pmt_task',$task_id));
		$srModel['list_count'] = count($srModel['list']);


		$sql = "
SELECT distinct t.*,t2.node_value task_id FROM pmt_document t,pmt_document_link t1,sys_help_tree_detail t2
WHERE t.id=t1.document_id
AND t1.table_name='{0}' and t.status<>'000' and t.is_current_version='1'
AND (t1.table_id = t2.node_value or t1.table_id=t2.parent_field_value) and t1.table_id<>{1}
and t2.help_tree_id=15 and (t2.node_value='{1}' or t2.parent_field_value='{1}')
{$where} /*w[t,t1,t2]*/
		";
		//$srModel['other_list'] = self :: queryBySql($sql,array('pmt_task',$task_id));
		//$srModel['other_list_count'] = count($srModel['other_list']);

		$flag = self::getValue_invokeBusiness("AppTaskBusiness","isTaskUpperManager",array('task_id'=>$task_id),'Pmt','flag');
		$srModel['is_task_upper_manager'] = $flag;



		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function indexTaskDetail($spModel) {
		$srModel = array ();
		$id = $spModel['id'];
		$model = self :: queryById2($id, "pmt_task");
		$srModel2 = self :: invokeBusiness("AppCommonBusiness", "progress_getRow", array (
			'table_id' => $model["id"],
			'table_name' => 'pmt_task'
		), '@');
		$model = Sr :: sys_copyProperties($model, $srModel2);

		$srModel2 = self :: invokeBusiness("AppTaskBusiness", "getTaskInfo", array (
			'id' => $model['id'],
			'need_tsheet' => '1'
		), '@');
		$model = Sr :: sys_copyProperties($model, $srModel2);

		$srModel2 = self :: invokeBusiness("AppTaskBusiness", "getTaskSrMessage", array (
			'id' => $model['id']
		), '@');
		$model = Sr :: sys_copyProperties($model, $srModel2);
		$srModel2 = self::queryBySql("select distinct t.user_id from pmt_task_member t where t.task_id={0} /*w[t]*/",array($model["id"]));
		foreach($srModel2 as $kk=>$item){
			$model['array_task_member_bar'] .= Sr::sys_dictTableById('uup_user',$item['user_id'],'name').' ';
		}

		$model = self :: getValue_invokeBusiness("AppCommonBusiness", "task_calcProgress", $model, '@', 'spModel');

		$flag = self::getValue_invokeBusiness("AppTaskBusiness","isTaskUpperManager",array('task_id'=>$id),'Pmt','flag');
		$model['is_task_upper_manager'] = $flag;
		$model['module'] = self :: queryById2($model['module_id'], "pmt_module");
		//dump($model['module']);
		$srModel['model'] = $model;
		self :: addInfoResults($srModel, null);
		return $srModel;
	}


	//提交留言
	public function doMessageSr($spModel) {
		$srModel = array();
		$task_id = $spModel['task_id'];
		$content = $spModel['content'];

		$model = array();
		$model['table_id'] = $task_id;
		$model['table_name'] = "pmt_task";
		$model['content'] = $content;
		self::insert2($model,'pmt_message_re');
		self :: addInfoResults($srModel, null);
		return $srModel;
	}
	//提交留言
	public function deleteMessageSr($spModel) {
		$srModel = array();
		$id = $spModel['id'];

 		$model = array();
 		$model["id"] = $id;
 		$model["is_deleted"] = "1";
		self::update2($id,$model,'pmt_message_re');
		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	//删除文档
	public function deleteDocument($spModel) {
		$srModel = array();
		$document_id = $spModel['document_id'];
		$task_id = $spModel['task_id'];
 		self::invokeBusiness("AppPmtDocumentBusiness","deleteDocument",array(
 			"document_id"=>$document_id,
 			"table_id"=>$task_id,
 			"table_name"=>"pmt_task"
 		));
		self :: addInfoResults($srModel, null);
		return $srModel;
	}
}
?>
