<?php

class ProjectService extends SrService
{

public function queryProject($spModel){
		$srModel = array();

		$where = '';

		$where .= self::getCauseIfNotNull("t.id like '%{0}%'",$spModel["query_id"]);
		$where .= self::getCauseIfNotNull("t.code like '%{0}%'",$spModel["query_code"]);
		$where .= self::getCauseIfNotNull("t.name like '%{0}%'",$spModel["query_name"]);
		$where .= self::getCauseIfNotNull("t.manager_id = '{0}'",$spModel["query_manager_id"]);
		$where .= self::getCauseIfNotNull("t.adv_begin_date like '%{0}%'",$spModel["query_adv_begin_date"]);
		$where .= self::getCauseIfNotNull("t.adv_end_date like '%{0}%'",$spModel["query_adv_end_date"]);
		$where .= self::getCauseIfNotNull("t.content like '%{0}%'",$spModel["query_content"]);
		$where .= self::getCauseIfNotNull("t.url like '%{0}%'",$spModel["query_url"]);
		$where .= self::getCauseIfNotNull("t.status like '%{0}%'",$spModel["query_status"]);
		$where .= self::getCauseIfNotNull("t.belong_org_id = {0}",$spModel["query_belong_org_id"]);
		$where .= self::getCauseIfNotNull("t.belong_user_id = {0}",$spModel["query_belong_user_id"]);


		$sql = "select t.* from pmt_project t  where 1=1 /*w[t]*/ {$where}  order by id desc";


 		$srModel = self::queryPageBySql($sql);


		self::addInfoResults($srModel,null);
		return $srModel;
	}

 	public function getProject($spModel){
		$id = $spModel["id"];
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$srModel = array();
		$srModel = self::queryById2($id,"pmt_project");
		if($srModel!=null){



		}else{

		}

		self::addInfoResults($srModel,null);
		return $srModel;
	}




public function editProject($spModel){

		$id = $spModel["id"];

		$srModel = array();
		if($id!=null&&$id!=''){

			$srModel = self::update2($id,$spModel,"pmt_project");

		}else{

			$srModel = self::insert2($spModel,"pmt_project");

			$spModel['id'] = $srModel['id'];

			//默认新增,是直接将当前创建人作为项目经理
//			$spModel2 = array();
//			$spModel2["dim_table_id"] = $srModel['id'];//project_id
//			$spModel2["assign_table_id"] = $srModel['create_user_id'];//user_id
//			self :: invokeBusiness("AppProjectBusiness", "rac_updateProjectMember", $spModel2, '@');
			//halt();
		}



		self::addInfoResults($srModel,'message.success.update',array($srModel["name"]));
		return $srModel;
	}


public function deleteProject($spModel){
		$id = $spModel["id"];
		$srModel = array();
		$spModel["is_deleted"] = "1";

		$srModel = self::update2($id,$spModel,"pmt_project");


		self::addInfoResults($srModel,'message.success.delete',array($srModel["name"]));
		return $srModel;
	}

}//end class



?>