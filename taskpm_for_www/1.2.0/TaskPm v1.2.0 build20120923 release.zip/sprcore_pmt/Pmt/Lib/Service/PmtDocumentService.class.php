<?php
 
class PmtDocumentService extends SrService
{
 
public function queryDocument($spModel){
		$srModel = array();

		$where = '';

		$where .= self::getCauseIfNotNull("t.belong_org_id = {0}",$spModel["query_belong_org_id"]);
		$where .= self::getCauseIfNotNull("t.belong_user_id = {0}",$spModel["query_belong_user_id"]);

 
		$sql = "select t.* from pmt_document t  where 1=1 /*w[t]*/ {$where}  order by id desc";
 

 		$srModel = self::queryPageBySql($sql);


		self::addInfoResults($srModel,null);
		return $srModel;
	}
	
 	public function getDocument($spModel){
		$id = $spModel["id"];
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$srModel = array();
		$srModel = self::queryById2($id,"pmt_document");
		if($srModel!=null){		



		}else{
	
		}

		self::addInfoResults($srModel,null);
		return $srModel;
	}




public function editDocument($spModel){
		$id = $spModel["id"];
		
		$srModel = array();
		if($id!=null&&$id!=''){
			
			$srModel = self::update2($id,$spModel,"pmt_document");		
			
		}else{
			
			$srModel = self::insert2($spModel,"pmt_document");	

			$spModel['id'] = $srModel['id'];
			
		}

		

		self::addInfoResults($srModel,'message.success.update',array($srModel["name"]));
		return $srModel;
	}	

	
public function deleteDocument($spModel){
		$id = $spModel["id"];
		$srModel = array();
		$spModel["is_deleted"] = "1";
		
		$srModel = self::update2($id,$spModel,"pmt_document");

		
		self::addInfoResults($srModel,'message.success.delete',array($srModel["name"]));
		return $srModel;
	}	

}//end class



?>