<?php

class ManagerSysToolTables2Service extends SrService
{
 	public function querySysToolTables2($spModel){
		$srModel = array();

		$sql = "select t.*   from sys_tool_table2 t   where t.is_deleted='0' ";

		$sql .= self::getCauseIfNotNull("t.id like '%{0}%'",$spModel["query_id"]);
		$sql .= self::getCauseIfNotNull("t.table_name like '%{0}%'",$spModel["query_table_name"]);
		$sql .= self::getCauseIfNotNull("t.table_desc like '%{0}%'",$spModel["query_table_desc"]);
		$sql .= self::getCauseIfNotNull("t.code_module like '%{0}%'",$spModel["query_code_module"]);
		$sql .= self::getCauseIfNotNull("t.code_module_method like '%{0}%'",$spModel["query_code_module_method"]);
		$sql .= self::getCauseIfNotNull("t.table_has_status = '{0}'",$spModel["query_table_has_status"]);
		$sql .= self::getCauseIfNotNull("t.table_status_field like '%{0}%'",$spModel["query_table_status_field"]);
		$sql .= self::getCauseIfNotNull("t.table_status_save like '%{0}%'",$spModel["query_table_status_save"]);
		$sql .= self::getCauseIfNotNull("t.table_status_submit like '%{0}%'",$spModel["query_table_status_submit"]);
		$sql .= self::getCauseIfNotNull("t.child_type = '{0}'",$spModel["query_child_type"]);
		$sql .= self::getCauseIfNotNull("t.child_type_value like '%{0}%'",$spModel["query_child_type_value"]);
		$sql .= self::getCauseIfNotNull("t.is_tree = '{0}'",$spModel["query_is_tree"]);
		$sql .= self::getCauseIfNotNull("t.tree_parent_field like '%{0}%'",$spModel["query_tree_parent_field"]);
		$sql .= self::getCauseIfNotNull("t.table_info like '%{0}%'",$spModel["query_table_info"]);
		$sql .= self::getCauseIfNotNull("t.before_query_method like '%{0}%'",$spModel["query_before_query_method"]);
		$sql .= self::getCauseIfNotNull("t.before_add_method like '%{0}%'",$spModel["query_before_add_method"]);
		$sql .= self::getCauseIfNotNull("t.before_update_method like '%{0}%'",$spModel["query_before_update_method"]);
		$sql .= self::getCauseIfNotNull("t.before_delete_method like '%{0}%'",$spModel["query_before_delete_method"]);
		$sql .= self::getCauseIfNotNull("t.before_get_method like '%{0}%'",$spModel["query_before_get_method"]);
		$sql .= self::getCauseIfNotNull("t.after_db_add_method like '%{0}%'",$spModel["query_after_db_add_method"]);
		$sql .= self::getCauseIfNotNull("t.after_db_update_method like '%{0}%'",$spModel["query_after_db_update_method"]);
		$sql .= self::getCauseIfNotNull("t.after_db_au_method like '%{0}%'",$spModel["query_after_db_au_method"]);
		$sql .= self::getCauseIfNotNull("t.after_db_delete_method like '%{0}%'",$spModel["query_after_db_delete_method"]);
		$sql .= self::getCauseIfNotNull("t.after_db_get_method like '%{0}%'",$spModel["query_after_db_get_method"]);
		$sql .= self::getCauseIfNotNull("t.before_db_add_method like '%{0}%'",$spModel["query_before_db_add_method"]);
		$sql .= self::getCauseIfNotNull("t.before_db_update_method like '%{0}%'",$spModel["query_before_db_update_method"]);
		$sql .= self::getCauseIfNotNull("t.before_db_au_method like '%{0}%'",$spModel["query_before_db_au_method"]);
		$sql .= self::getCauseIfNotNull("t.before_db_delete_method like '%{0}%'",$spModel["query_before_db_delete_method"]);
		$sql .= self::getCauseIfNotNull("t.before_db_get_method like '%{0}%'",$spModel["query_before_db_get_method"]);
		$sql .= self::getCauseIfNotNull("t.belong_org_id = {0}",$spModel["query_belong_org_id"]);
		$sql .= self::getCauseIfNotNull("t.belong_user_id = {0}",$spModel["query_belong_user_id"]);
		$sql .= " order by id desc";

 		$srModel = self::queryPageBySql($sql);

		self::addInfoResults($srModel,null);
		return $srModel;
	}

 	public function getSysToolTables2($spModel){
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$srModel = array();
		$srModel = self::queryById2($spModel["id"],"sys_tool_table2");
		if($srModel!=null){
			$srModel["details"] = self::queryBySql("select t.* from sys_tool_table_field2 t where t.table_id={0} and t.is_deleted='0'",array($spModel["id"]));



		}else{

		}

		if($detail_add_count_flag=="1"){
			$i = (int)$detail_add_count;
			while($i>0){
				$i--;
				$srModel["details"][] = null;
			}
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}

	public function managerSysToolTables2($spModel){
		//main id
		$id = $spModel["id"];


		//detail info
		$detail_id = $spModel["detail_id"];

		$detail_id = $spModel["detail_id"];
		$detail_table_id = $spModel["detail_table_id"];
		$detail_field_name = $spModel["detail_field_name"];
		$detail_field_desc = $spModel["detail_field_desc"];
		$detail_field_type = $spModel["detail_field_type"];
		$detail_field_type_value = $spModel["detail_field_type_value"];
		$detail_field_type_desc_value = $spModel["detail_field_type_desc_value"];
		$detail_field_class = $spModel["detail_field_class"];
		$detail_size_display = $spModel["detail_size_display"];
		$detail_size_max = $spModel["detail_size_max"];
		$detail_item_line_class = $spModel["detail_item_line_class"];
		$detail_item_control_class = $spModel["detail_item_control_class"];
		$detail_has_query_clause = $spModel["detail_has_query_clause"];
		$detail_has_query_result = $spModel["detail_has_query_result"];
		$detail_field_no = $spModel["detail_field_no"];
		$detail_item_control_param = $spModel["detail_item_control_param"];
		//del detail_id
		$detail_del_id = $spModel["detail_del_id"];
		$detail_add_id = explode(",",$spModel["detail_add_id"]);

		$srModel = array();
		if($id==null){

			$srModel = self::insert2($spModel,"sys_tool_table2");

			$id = $srModel["id"];
		}else{

			$srModel = self::update2($id,$spModel,"sys_tool_table2");

		}
		//add detail
		foreach($detail_id as $key=>$value){
			$dModel = array();
			$dModel["id"] = $detail_id[$key];

			$dModel["id"] = $detail_id[$key];
			$dModel["table_id"] = $detail_table_id[$key];
			$dModel["field_name"] = $detail_field_name[$key];
			$dModel["field_desc"] = $detail_field_desc[$key];
			$dModel["field_type"] = $detail_field_type[$key];
			$dModel["field_type_value"] = $detail_field_type_value[$key];
			$dModel["field_type_desc_value"] = $detail_field_type_desc_value[$key];
			$dModel["field_class"] = $detail_field_class[$key];
			$dModel["size_display"] = $detail_size_display[$key];
			$dModel["size_max"] = $detail_size_max[$key];
			$dModel["item_line_class"] = $detail_item_line_class[$key];
			$dModel["item_control_class"] = $detail_item_control_class[$key];
			$dModel["has_query_clause"] = $detail_has_query_clause[$key];
			$dModel["has_query_result"] = $detail_has_query_result[$key];
			$dModel["field_no"] = $detail_field_no[$key];
			$dModel["item_control_param"] = $detail_item_control_param[$key];
			$dModel["table_id"] = $id;
			if($value!=null && $value!=''){
				self::update2($dModel["id"],$dModel,"sys_tool_table_field2");
			}else{
				self::insert2($dModel,"sys_tool_table_field2");
			}
		}
		//delete detail
		if($detail_del_id!=null && $detail_del_id!=''){
			$model = array();
			$model["table_id"] = $id;
			$model["id"] = $detail_del_id;
			$model["is_deleted"] = "1";
			self::update2($model["id"],$model,"sys_tool_table_field2");
		}
		//add detail
		foreach($detail_add_id as $key=>$value){
			if($value==0 || $value==null){
				continue;
			}
			$dModel = array();
			$dModel["table_id"] = $id;
			$cnt = self::getCountBySql("select t.* from sys_tool_table_field2 t where t.is_deleted='0' and t.table_id={0} ",
				array($id));
			if($cnt==0){
				self::insert2($dModel,"sys_tool_table_field2");
			}else{
				self::update2($dModel["id"],$dModel,"sys_tool_table_field2");
			}
		}


		self::addInfoResults($srModel,'message.success.update',array($spModel["name"]));
		$srModel["sflow_method_business_id"] = $spModel["id"];//for sflow
		return $srModel;
	}
	public function editSysToolTables2($spModel){
		$id = $spModel["id"];

		$srModel = array();
		if($id!=null&&$id!=''){

			$srModel = self::update2($id,$spModel,"sys_tool_table2");

		}else{

			$srModel = self::insert2($spModel,"sys_tool_table2");

		}



		self::addInfoResults($srModel,'message.success.update',array($srModel["name"]));
		return $srModel;
	}

	public function deleteSysToolTables2($spModel){
		$srModel = array();
		$spModel["is_deleted"] = "1";

		$srModel = self::update2($spModel["id"],$spModel,"sys_tool_table2");

		self::addInfoResults($srModel,'message.success.delete',array($srModel["name"]));
		return $srModel;
	}
}//end class

?>