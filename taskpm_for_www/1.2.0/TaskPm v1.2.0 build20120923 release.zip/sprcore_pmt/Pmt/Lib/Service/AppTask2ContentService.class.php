<?php
class AppTask2ContentService extends SrService{	

}
?>
