<?php
 
class ModuleMilestoneService extends SrService
{
 	public function queryModuleMilestone($spModel){
		$srModel = array();
		$sql = "select * from pmt_module_milestone t where t.is_deleted='0' ";
		
		$sql .= self::getCauseIfNotNull("t.id like '%{0}%'",$spModel["query_id"]);		
		$sql .= self::getCauseIfNotNull("t.module_id like '%{0}%'",$spModel["query_module_id"]);		
		$sql .= self::getCauseIfNotNull("t.task_id = '{0}'",$spModel["query_task_id"]);		
		$sql .= self::getCauseIfNotNull("t.type_ms_id like '%{0}%'",$spModel["query_type_ms_id"]);		
		$sql .= self::getCauseIfNotNull("t.adv_begin_date like '%{0}%'",$spModel["query_adv_begin_date"]);		
		$sql .= self::getCauseIfNotNull("t.adv_end_date like '%{0}%'",$spModel["query_adv_end_date"]);		
		$sql .= self::getCauseIfNotNull("t.adv_person_day like '%{0}%'",$spModel["query_adv_person_day"]);		
		$sql .= self::getCauseIfNotNull("t.progress like '%{0}%'",$spModel["query_progress"]);		
		$sql .= self::getCauseIfNotNull("t.memo like '%{0}%'",$spModel["query_memo"]);		
		$sql .= self::getCauseIfNotNull("t.no like '%{0}%'",$spModel["query_no"]);
		$sql .= self::getCauseIfNotNull("t.belong_org_id = {0}",$spModel["query_belong_org_id"]);
		$sql .= self::getCauseIfNotNull("t.belong_user_id = {0}",$spModel["query_belong_user_id"]);
		$sql .= " order by id desc";
 		$srModel = self::queryPageBySql($sql);

		self::addInfoResults($srModel,null);
		return $srModel;
	}
	
 	public function getModuleMilestone($spModel){
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$srModel = array();
		$srModel = self::queryById2($spModel["id"],"pmt_module_milestone");
		if($srModel!=null){		



		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}

	public function editModuleMilestone($spModel){
		$id = $spModel["id"];
		$srModel = array();
		if($id!=null&&$id!=''){
			$srModel = self::update2($id,$spModel,"pmt_module_milestone");		
		}else{
			$srModel = self::insert2($spModel,"pmt_module_milestone");	
		}

		self::addInfoResults($srModel,'message.success.update',array($srModel["name"]));
		return $srModel;
	}
	
	public function deleteModuleMilestone($spModel){
		$srModel = array();
		$spModel["is_deleted"] = "1";
		$srModel = self::update2($spModel["id"],$spModel,"pmt_module_milestone");
		self::addInfoResults($srModel,'message.success.delete',array($srModel["name"]));
		return $srModel;
	}		
}//end class

?>