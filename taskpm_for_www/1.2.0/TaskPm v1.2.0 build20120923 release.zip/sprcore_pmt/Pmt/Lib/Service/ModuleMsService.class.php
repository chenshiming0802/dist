<?php

class ModuleMsService extends SrService
{
 	public function queryModuleMs($spModel){
		$srModel = array();
		$sql = "select * from pmt_module t where t.is_deleted='0' ";

		$sql .= self::getCauseIfNotNull("t.project_id like '%{0}%'",$spModel["query_project_id"]);
		$sql .= self::getCauseIfNotNull("t.module_type_id like '%{0}%'",$spModel["query_module_type_id"]);
		$sql .= self::getCauseIfNotNull("t.code like '%{0}%'",$spModel["query_code"]);
		$sql .= self::getCauseIfNotNull("t.name like '%{0}%'",$spModel["query_name"]);
		$sql .= self::getCauseIfNotNull("t.manager_id like '%{0}%'",$spModel["query_manager_id"]);
		$sql .= self::getCauseIfNotNull("t.adv_begin_date like '%{0}%'",$spModel["query_adv_begin_date"]);
		$sql .= self::getCauseIfNotNull("t.adv_end_date like '%{0}%'",$spModel["query_adv_end_date"]);
		$sql .= self::getCauseIfNotNull("t.content like '%{0}%'",$spModel["query_content"]);
		$sql .= self::getCauseIfNotNull("t.url like '%{0}%'",$spModel["query_url"]);
		$sql .= self::getCauseIfNotNull("t.status like '%{0}%'",$spModel["query_status"]);
		$sql .= self::getCauseIfNotNull("t.proirity like '%{0}%'",$spModel["query_proirity"]);
		$sql .= self::getCauseIfNotNull("t.depend_module_id like '%{0}%'",$spModel["query_depend_module_id"]);
		$sql .= self::getCauseIfNotNull("t.id like '%{0}%'",$spModel["query_id"]);
		$sql .= self::getCauseIfNotNull("t.belong_org_id = {0}",$spModel["query_belong_org_id"]);
		$sql .= self::getCauseIfNotNull("t.belong_user_id = {0}",$spModel["query_belong_user_id"]);
		$sql .= " order by id desc";
 		$srModel = self::queryPageBySql($sql);

		self::addInfoResults($srModel,null);
		return $srModel;
	}

 	public function getModuleMs($spModel){
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$srModel = array();
		$srModel = self::queryById2($spModel["id"],"pmt_module");
		if($srModel!=null){
			$srModel["details"] = self::queryBySql("select t.* from pmt_module_milestone t where t.module_id={0} and t.is_deleted='0'",array($spModel["id"]));



		}

		if($detail_add_count_flag=="1"){
			$i = (int)$detail_add_count;
			while($i>0){
				$i--;
				$srModel["details"][] = null;
			}
		}		self::addInfoResults($srModel,null);
		return $srModel;
	}

	public function managerModuleMs($spModel){
		//main id
		$id = $spModel["id"];

		//detail info
		$detail_id = $spModel["detail_id"];

		$detail_id = $spModel["detail_id"];
		$detail_module_id = $spModel["detail_module_id"];
		$detail_task_id = $spModel["detail_task_id"];
		$detail_type_ms_id = $spModel["detail_type_ms_id"];
		$detail_adv_begin_date = $spModel["detail_adv_begin_date"];
		$detail_adv_end_date = $spModel["detail_adv_end_date"];
		$detail_adv_person_day = $spModel["detail_adv_person_day"];
		$detail_progress = $spModel["detail_progress"];
		$detail_memo = $spModel["detail_memo"];
		$detail_no = $spModel["detail_no"];
		//del detail_id
		$detail_del_id = $spModel["detail_del_id"];
		$detail_add_id = explode(",",$spModel["detail_add_id"]);

		$srModel = array();
		if($id==null){

			$srModel = self::insert2($spModel,"pmt_module");
			$id = $srModel["id"];
		}else{
			$srModel = self::update2($id,$spModel,"pmt_module");
		}
		//add detail
		foreach($detail_id as $key=>$value){
			$dModel = array();
			$dModel["id"] = $detail_id[$key];

			$dModel["id"] = $detail_id[$key];
			$dModel["module_id"] = $detail_module_id[$key];
			$dModel["task_id"] = $detail_task_id[$key];
			$dModel["type_ms_id"] = $detail_type_ms_id[$key];
			$dModel["adv_begin_date"] = $detail_adv_begin_date[$key];
			$dModel["adv_end_date"] = $detail_adv_end_date[$key];
			$dModel["adv_person_day"] = $detail_adv_person_day[$key];
			$dModel["progress"] = $detail_progress[$key];
			$dModel["memo"] = $detail_memo[$key];
			$dModel["no"] = $detail_no[$key];
			$dModel["module_id"] = $id;
			if($value!=null && $value!=''){
				self::update2($dModel["id"],$dModel,"pmt_module_milestone");
			}else{
				self::insert2($dModel,"pmt_module_milestone");
			}
		}
		//delete detail
		if($detail_del_id!=null && $detail_del_id!=''){
			$model = array();
			$model["module_id"] = $id;
			$model["id"] = $detail_del_id;
			$model["is_deleted"] = "1";
			self::update2($model["id"],$model,"pmt_module_milestone");
		}
		//add detail
		foreach($detail_add_id as $key=>$value){
			if($value==0 || $value==null){
				continue;
			}
			$dModel = array();
			$dModel["module_id"] = $id;
			$cnt = self::getCountBySql("select t.* from pmt_module_milestone t where t.is_deleted='0' and t.module_id={0} ",
				array($id));
			if($cnt==0){
				self::insert2($dModel,"pmt_module_milestone");
			}else{
				self::update2($dModel["id"],$dModel,"pmt_module_milestone");
			}
		}

		if($status=='020'){
			self::addInfoResults($srModel,'message.success.submit',array($spModel["name"]));
		}else{
			self::addInfoResults($srModel,'message.success.update',array($spModel["name"]));
		}
		$srModel["sflow_method_business_id"] = $spModel["id"];//for sflow
		return $srModel;
	}
	public function editModuleMs($spModel){
		$id = $spModel["id"];
		$srModel = array();
		if($id!=null&&$id!=''){
			$srModel = self::update2($id,$spModel,"pmt_module");
		}else{
			$srModel = self::insert2($spModel,"pmt_module");
		}

		self::addInfoResults($srModel,'message.success.update',array($srModel["name"]));
		return $srModel;
	}

	public function deleteModuleMs($spModel){
		$srModel = array();
		$spModel["is_deleted"] = "1";
		$srModel = self::update2($spModel["id"],$spModel,"pmt_module");
		self::addInfoResults($srModel,'message.success.delete',array($srModel["name"]));
		return $srModel;
	}
}//end class

?>