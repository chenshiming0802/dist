<?php
class AppModuleService extends SrService{
	public function queryModuleMillstoneCycle($spModel){
		$query_project_id = $spModel['query_project_id'];
		$query_module_type_id = $spModel['query_module_type_id'];

		$srModel = array();
		$where = '';
		$where .= self::getCauseIfNotNull("t0.id={0}",$query_project_id);
		$where .= self::getCauseIfNotNull("t1.id={0}",$query_module_type_id);
		$where .= self::getCauseIfNotNull("t.status={0}",$spModel['query_status']);

		$sql = "SELECT DISTINCT concat(t.status,'@PMT04@DICT') _gridGroupSort_,
  t0.name               project_name, t0.id project_id,
  t.name               module_name, t.id module_id,
  t5.name              ms_name,
t4.adv_begin_date,
t4.act_begin_date,
t4.tsh_begin_date,
t4.adv_end_date,
t4.act_end_date,
t4.tsh_end_date,
t4.adv_work_day,
t4.act_work_day,
t4.tsh_work_day,
t4.adv_person_day,
t4.act_person_day,
t4.tsh_person_day,
t4.tsh_person_normal_day,
t4.tsh_person_over_day,
t4.adv_progress,
t4.act_progress,
t4.tsh_progress
FROM
  pmt_project t0,
  pmt_module t,
  pmt_module_type t1,
  pmt_task t2,
  pmt_progress t4,
  pmt_module_type_ms t5
WHERE 1=1
    AND t2.project_id = t0.id
    AND t.module_type_id = t1.id
    AND t.id = t2.module_id
    AND t2.id = t4.table_id
    AND t5.id=t2.type_ms_id
    AND t4.table_name = 'pmt_task' /*w[t0,t,t1,t2,t4,t5]*/  {$where} order by t.status asc";

 		$list = self::queryBySql($sql,array(),'name');

		foreach($list as $k=>$m){

			$m = self::getValue_invokeBusiness("AppCommonBusiness","task_calcProgress",$m,'@','spModel');
			//添加Module进度信息
			$sql = "select * from pmt_progress t where t.table_id={0} and t.table_name='pmt_module' and t.is_deleted='0'";
			$mp = self::getRowBySql($sql,array($m['module_id']));
			if($mp!=null)
				$mp = self::getValue_invokeBusiness("AppCommonBusiness","module_calcProgress",$mp,'@','spModel');
			foreach($mp as $kk=>$vv){
				$m["moduleinfo_".$kk] = $vv;
			}
			$list[$k] = $m;
		}

		$srModel['list'] = $list;
		$srModel['page'] = "";

		$sql = "select * from pmt_module_type_ms t where t.type_id={0} /*w[t]*/ order by no asc";

		//任务类型对应的里程碑
		$list = self::queryBySql($sql,array($query_module_type_id));
		$srModel['pmt_module_type_list'] = array();
		foreach($list as $k=>$m){
			$srModel['pmt_module_type_list'][$m['name']] = $m['name'];
		}


		self::addInfoResults($srModel,null);
		return $srModel;
	}

	public function viewModulePath($spModel){
		$srModel = array();
		$id = $spModel['module_id'];
		$sql = "select t.* from pmt_document_path t where t.table_id='{0}' and t.table_name='{1}' /*w[t]*/ order by no asc";
		$list = self::queryBySql($sql,array($id,'pmt_module'));
		foreach($list as $key=>$item){
			$item['document_count'] = self::getValue_invokeBusiness("AppDocumentBusiness","getDocumentsCount",array('table_id'=>$id,'table_name'=>'pmt_module','path_id'=>$item['id']),'@','count');
			$list[$key] = $item;
		}
		$srModel['list'] = $list;
		self::addInfoResults($srModel,null);
		return $srModel;
	}

}
?>
