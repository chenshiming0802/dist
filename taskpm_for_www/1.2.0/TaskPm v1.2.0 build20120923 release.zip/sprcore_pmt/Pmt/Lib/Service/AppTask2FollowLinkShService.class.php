<?php
class AppTask2FollowLinkShService extends SrService{



 	public function getTask2FollowLink($spModel){
		$id = $spModel["id"];
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$srModel = array();
		$srModel = self::queryById2($id,"pmt_task");
		if($srModel!=null){
			$srModel["details"] = self::queryBySql("select t.*,t2.id task_id,t2.module_id,t2.code,t2.name,t2.manager_id,t2.status,t2.content,t2.url from pmt_task_follow t,pmt_task t2 where t.task_id=t2.id and  t.follow_task_id={0} /*w[t,t2]*/",array($id));
			foreach($srModel['details'] as $k=>$model){
				$srModel2 = self::invokeBusiness("AppCommonBusiness","progress_getRow",array('table_id'=>$model["task_id"],'table_name'=>'pmt_task'),'@');
				$model = Sr::sys_copyProperties($model,$srModel2);
				$srModel['details'][$k] = $model;
			}

		}else{

		}

		if($detail_add_count_flag=="1"){
			$i = (int)$detail_add_count;
			while($i>0){
				$i--;
				$srModel["details"][] = null;
			}
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}



	public function managerTask2FollowLink($spModel){
		//main id
		$id = $spModel["id"];


		//detail info
		$detail_id = $spModel["detail_id"];

		$detail_task_id = $spModel["detail_task_id"];
		$detail_id = $spModel["detail_id"];
		//del detail_id
		$detail_del_id = $spModel["detail_del_id"];
		$detail_add_id = explode(",",$spModel["detail_add_id"]);

		$srModel = array();
		if($id==null){
			throw_exception(Sr::sys_l("message.exception.lack.param",array('ID')));
		}
		//delete detail
		if($detail_del_id!=null && $detail_del_id!=''){
			$model = array();
			$model["follow_task_id"] = 0;
			$model["id"] = $detail_del_id;
			self::update2($model["id"],$model,"pmt_task_follow");
		}
		//add detail
		foreach($detail_add_id as $key=>$value){
			if($value==0 || $value==null){
				continue;
			}
			$dmodel = self::getRowBySql("select t.* from pmt_task_follow t where 1=1 /*w[t]*/  and t.task_id={0}",
				array($value));

			if($dmodel==null){
				//没有需上线的任务（可能被临时取消了）
				throw_exception(Sr::sys_l("message.exception.task.nofollow",array($value)));
			}else if($dmodel['follow_task_id']!=null && $dmodel['follow_task_id']!='0'){
				//任务已经存在于某上线任务中
				throw_exception(Sr::sys_l("message.exception.task.alreadyfollow",array($value)));
			}else{
				$dmodel['follow_task_id'] = $id;
				self::update2($dmodel["id"],$dmodel,"pmt_task_follow");
			}
		}
		self::addInfoResults($srModel,'message.success.update',array($spModel["name"]));
		$srModel["sflow_method_business_id"] = $id;//for sflow
		return $srModel;
	}



}
?>
