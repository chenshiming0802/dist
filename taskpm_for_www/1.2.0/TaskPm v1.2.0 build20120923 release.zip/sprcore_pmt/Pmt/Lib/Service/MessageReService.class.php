<?php
 
class MessageReService extends SrService
{
 
public function queryMessageRe($spModel){
		$srModel = array();

		$where = '';

		$where .= self::getCauseIfNotNull("t.belong_org_id = {0}",$spModel["query_belong_org_id"]);
		$where .= self::getCauseIfNotNull("t.belong_user_id = {0}",$spModel["query_belong_user_id"]);

 
		$sql = "select t.* from pmt_message_re t  where 1=1 /*w[t]*/ {$where}  order by id desc";
 

 		$srModel = self::queryPageBySql($sql);


		self::addInfoResults($srModel,null);
		return $srModel;
	}
	
 	public function getMessageRe($spModel){
		$id = $spModel["id"];
 		$detail_add_count_flag = $spModel["detail_add_count_flag"];
 		$detail_add_count = $spModel["detail_add_count"];

		$srModel = array();
		$srModel = self::queryById2($id,"pmt_message_re");
		if($srModel!=null){		



		}else{
	
		}

		self::addInfoResults($srModel,null);
		return $srModel;
	}




public function editMessageRe($spModel){
		$id = $spModel["id"];
		
		$srModel = array();
		if($id!=null&&$id!=''){
			
			$srModel = self::update2($id,$spModel,"pmt_message_re");		
			
		}else{
			
			$srModel = self::insert2($spModel,"pmt_message_re");	

			$spModel['id'] = $srModel['id'];
			
		}

		

		self::addInfoResults($srModel,'message.success.update',array($srModel["name"]));
		return $srModel;
	}	

	
public function deleteMessageRe($spModel){
		$id = $spModel["id"];
		$srModel = array();
		$spModel["is_deleted"] = "1";
		
		$srModel = self::update2($id,$spModel,"pmt_message_re");

		
		self::addInfoResults($srModel,'message.success.delete',array($srModel["name"]));
		return $srModel;
	}	

}//end class



?>