<?php
class TaskTsheetSflow extends SrSflowService{
	//审核工时	
	public function confirmTsheet($spModel){
	
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		
		$mmDb = self::queryById2($id,"pmt_task_tsheet");
		
		self::invokeBusiness("AppCommonBusiness","taskProgress_updateParentTsheet",array("id"=>$mmDb['task_id']),"Pmt");
		//halt();
		self::addInfoResults($srModel,null);
		return $srModel;

	}
	function confirmTimeSheetHf($spModel){
		$srModel = array();
		$id = $spModel["sflow_business_id"];
		$sql = "SELECT t2.* FROM pmt_task_tsheet t0,pmt_task t1,pmt_project t2 
WHERE t0.task_id=t1.id and t1.project_id=t2.id
AND t0.id={0} /*w[t0,t1,t2]*/";
		
		$model = self::getRowBySql($sql,array($id));
		
		if($model["manager_id"]==SrUser::getUserId()){
			$srModel["hf"] = "1";
		}else{
			$srModel["hf"] = "0";
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}	
	//驳回工时
	function rejectTimeSheetHf($spModel){
		return self::confirmTimeSheetHf($spModel);
	}	
}
?>
