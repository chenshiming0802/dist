<?php
class TaskFavoriteSflow extends SrSflowService{	

}
?>
