<?php

class TaskTsheetAction extends SrAction{

/*
	* http://127.0.0.1:82/sprcore_all/Demo/index.php/TaskTsheet/queryTaskTsheet	*/
	public function queryTaskTsheet($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('AppCommonBarView','selectProject', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		
		$srModel = self::invokeService('TaskTsheetService','queryTaskTsheet', $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('TaskTsheetView',__FUNCTION__, $spModel );
		return self::forward();
	}



public function editTaskTsheetPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('TaskTsheetService','getTaskTsheet', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			self::setDefaultValue($spModel,"occure_date",Sr::sys_date(array())); 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		

$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('TaskTsheetView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editTaskTsheet($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('TaskTsheetService','editTaskTsheet', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editTaskTsheetPage','post',$spModel,$srModel);
	}


public function deleteTaskTsheet($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('TaskTsheetService','deleteTaskTsheet', $spModel );
		
		$this->setIsOutHtml(false);
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('viewTaskTsheetPage','post',$spModel,$srModel);
	}

	public function viewTaskTsheetPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('TaskTsheetService','getTaskTsheet', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
		
		$this->loadView('TaskTsheetView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>