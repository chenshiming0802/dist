<?php
import_extends("SrGantt");
class AppSfganttAction extends SrAction{


	public function queryTaskList($spModel=array()){
		$srModel = array();
 		$spModel=self::getSpModel($spModel);
		//dump($spModel);
		if($this->loadBarView('AppCommonBarView','selectModule', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}

		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		self::setDefaultValue($spModel,"query_status","020");
		self::setDefaultValue($spModel,"query_statuses",array('020'));
		//$this->loadTabView('AppCommonTabView','queryTaskStatus', $srModel);
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::forward();
	}


	public function queryTaskList_data($spModel=array()){
		header("Content-type: text/xml");
 		$spModel=self::getSpModel($spModel);



 		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		//self::setDefaultValue($spModel,"query_status","020");

		if($spModel["query_module_id"]!=null){
			$srModel = self::invokeService('TaskService','queryTask', $spModel );
		}else{
			$srModel['list'] = array();
		}




		$spModel2 = array();
		$spModel2['tasks'] = array();
		$spModel2['resources'] = array();
		$spModel2['assignments'] = array();
		//dump($srModel['list']);
		foreach($srModel['list'] as $key=>$model){
			$mm = array();
			$mm['uId'] = $model['id'];
			$mm['iD'] = $model['id'];
			$mm['name'] = $model['name'];
			$mm['createDate'] = $model['createTime'];
			$mm['outlineNumber'] =$model['_LEVEL_FULLSEQ_'];
			$mm['start'] = $model['adv_begin_date'];
			$mm['finish'] = $model['adv_end_date'];
			//$mm['summary'] = $model['_HAS_CHILDREN_']===true?'1':'0';
			$mm['summary'] = ($model['spr_tree_type']=='010')?'1':'0';
			$mm['percentComplete'] = strip_tags($model['act_progress']);
			$mm['constraintType'] = '0';
			$mm['hyperlinkAddress'] = Sr::sys_sl('__APP__/AppTask/indexTaskDetail?id='.$model['id']);

			$mm['manager_id'] = $model['manager_id'];
			$mm['module_type_task_id'] = $model['module_type_task_id'];
			$mm['task_status'] = $model['status'];
			$mm['task_adv_person_day'] = $model['adv_person_day'];

			$spModel2['tasks'][] = $mm;
		}



		$srModel2 = SrGantt::generateXml($spModel2);

		//$srModel['data'] = $srModel2['data'];
		echo $srModel2['data'];
	}

	public function queryTaskList_save($spModel=array()){
		header("Content-type: text/xml");
 		$spModel=self::getSpModel($spModel);
		Sr::info($spModel);
		$xml = $GLOBALS['HTTP_RAW_POST_DATA'];
		//$ret = "<Result errorCode=\"0\">[{'uid':'','id':'1196','action':'insert'}]</Result>";Sr::info($ret);echo $ret;return;
		//$ret = '<Result errorCode="0">[{\'uid\':\'1681\',\'id\':\'1681\',\'action\':\'update\'}]</Result>';Sr::info($ret);echo $ret;return;
		//$xml = '<Log><UpdateTasks><Task><UID>1196</UID><Name>abcd</Name></Task></UpdateTasks></Log>';
		$aa = simplexml_load_string($xml);//TODO 不能获取$aa
		Sr::info("Gantter-Xml:".$xml);
		$jsonArr = array();
		$tasks = array();

		if($aa->AddTasks!=null && $aa->AddTasks->Task!=null){
			foreach($aa->AddTasks->Task as $item){
				$tasks[] = $item;
			}
		}
		if($aa->UpdateTasks!=null && $aa->UpdateTasks->Task!=null){
			foreach($aa->UpdateTasks->Task as $item){
				$tasks[] = $item;
			}
		}


		foreach($tasks as $item){
			if($item->UID=='0'||$item->UID==''){// || !is_numeric($item['UID'])
				continue;
			}
			if(strpos($item->UID,'-')!==false){
				//insert
				$spModel2 = array();
				$srModel2['status'] = '010';
				$srModel2['project_id'] = $spModel['project_id'];
				$srModel2['module_id'] = $spModel['module_id'];
				$srModel2['name'] = $item->Name;
				$srModel2['adv_begin_date'] = $item->Start;
				$srModel2['adv_end_date'] = $item->Finish;
				$srModel2['parent_task_id'] = $spModel['parent_task_id'];
				//$srModel2['parent_task_id'] = $item->ParentUID;
				if($spModel['Summary']=='true'){
					$srModel2['spr_tree_type'] = '010';
				}else{
					$srModel2['spr_tree_type'] = '020';
				}
				$spModel2['adv_person_day'] = $item->task_adv_person_day;
				Sr::info($srModel2);
				$srModel2 = self::invokeService('TaskService','editTask', $srModel2 );
				$jsonArr[] = "{'uid':'{$item['UID']}','id':'{$srModel2['id']}','action':'insert'}";
			}else{
				//update
				$spModel2 = array();
				$spModel2['project_id'] = $spModel['project_id'];
				$spModel2['module_id'] = $spModel['module_id'];
				$spModel2['id'] = $item->UID;
				Sr::info($item->ParentUID);
				if($item->Start!=null&&$item->Start!=''){
					$spModel2['adv_begin_date'] = $item->Start;
				}
				if($item->Finish!=null&&$item->Finish!=''){
					$spModel2['adv_end_date'] = $item->Finish;
				}
				//$spModel2['parent_task_id'] = $spModel['parent_task_id'];
				//if($item->ParentUID!=null&&$item->ParentUID!=''){
				//	$srModel2['parent_task_id'] = $item->ParentUID;
				//}
				if($item->module_type_task_id!=null&&$item->module_type_task_id!=''){
					$spModel2['module_type_task_id'] = $item->module_type_task_id;
				}
				if($item->manager_id!=null&&$item->manager_id!=''){
					$spModel2['manager_id'] = $item->manager_id;
				}
				if($item->Name!=null&&$item->Name!=''){
					$spModel2['name'] = $item->Name;
				}
				$spModel2['adv_person_day'] = $item->task_adv_person_day;
				Sr::info($spModel2);
				$srModel2 = self::invokeService('TaskService','editTask', $spModel2 );
				$jsonArr[] = "{'uid':'{$item->UID}','id':'{$srModel2['id']}','action':'update'}";
			}
		}

		$json = "[".implode(',',$jsonArr)."]";
		$ret = "<Result errorCode=\"0\">".$json."</Result>";

		Sr::info($ret);
		echo $ret;
	}

	public function queryTaskList_submit($spModel=array()){
		header("Content-type: text/xml");
		$spModel=self::getSpModel($spModel);
		$taskids = $spModel['taskids'];
		$jsonArr = array();
		if($taskids!=null && $taskids!=''){
			foreach(explode(",",$taskids) as $key=>$id){
				if(strpos($id,'-')===false && $id!=''){
					//TODO 校验该ID是否为草稿状态(断言）
					$spModel2 = array();
					$srModel2['status'] = '020';
					$srModel2['id'] = $id;
					$srModel2 = self::invokeService('TaskService','editTask', $srModel2 );
					$jsonArr[] = "{'uid':'{$id}','id':'{$id}','action':'submit'}";
				}
			}
		}
		$json = "[".implode(',',$jsonArr)."]";
		$ret = "<Result errorCode=\"0\">".$json."</Result>";

		Sr::info($ret);
		echo $ret;

	}
	public function queryTaskList_delete($spModel=array()){
		header("Content-type: text/xml");
		$spModel=self::getSpModel($spModel);
		$taskids = $spModel['taskids'];
		$jsonArr = array();
		if($taskids!=null && $taskids!=''){
			foreach(explode(",",$taskids) as $key=>$id){
				if(strpos($id,'-')===false){
					//TODO 校验该ID是否为草稿状态(断言）
					$spModel2 = array();
					$srModel2['id'] = $id;
					$srModel2 = self::invokeService('TaskService','deleteTask', $srModel2 );
					$jsonArr[] = "{'uid':'{$id}','id':'{$id}','action':'delete'}";
				}
			}
		}
		$json = "[".implode(',',$jsonArr)."]";
		$ret = "<Result errorCode=\"0\">".$json."</Result>";

		Sr::info($ret);
		echo $ret;

	}

	public function queryTaskList_convertPage($spModel=array()){
		header("Content-type: text/xml");
		$spModel=self::getSpModel($spModel);
		$taskids = $spModel['taskids'];
		$jsonArr = array();
		if($taskids!=null && $taskids!=''){
			foreach(explode(",",$taskids) as $key=>$id){
				if(strpos($id,'-')===false && $id!=''){
					$spModel2 = array();
					$srModel2['sflow_business_id'] = $id;
					$srModel2 = self::invokeSflow('TaskSflow','convertPage', $srModel2 );
					$jsonArr[] = "{'uid':'{$id}','id':'{$id}','action':'convertPage'}";
				}
			}
		}
		$json = "[".implode(',',$jsonArr)."]";
		$ret = "<Result errorCode=\"0\">".$json."</Result>";

		Sr::info($ret);
		echo $ret;

	}

	public function queryTaskList_convertDirectory($spModel=array()){
		header("Content-type: text/xml");
		$spModel=self::getSpModel($spModel);
		$taskids = $spModel['taskids'];
		$jsonArr = array();
		if($taskids!=null && $taskids!=''){
			foreach(explode(",",$taskids) as $key=>$id){
				if(strpos($id,'-')===false && $id!=''){
					$spModel2 = array();
					$srModel2['sflow_business_id'] = $id;
					$srModel2 = self::invokeSflow('TaskSflow','convertDirectory', $srModel2 );
					$jsonArr[] = "{'uid':'{$id}','id':'{$id}','action':'convertDirectory'}";
				}
			}
		}
		$json = "[".implode(',',$jsonArr)."]";
		$ret = "<Result errorCode=\"0\">".$json."</Result>";

		Sr::info($ret);
		echo $ret;

	}

}

?>
