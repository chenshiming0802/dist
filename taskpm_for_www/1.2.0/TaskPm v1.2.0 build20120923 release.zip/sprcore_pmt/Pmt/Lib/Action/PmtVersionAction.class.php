<?php

class PmtVersionAction extends SrAction{

/*
	* http://127.0.0.1:82/sprcore_all/Demo/index.php/PmtVersion/queryPmtVersion	*/
	public function queryPmtVersion($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('AppCommonBarView','selectProject', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		$spModel["query_belong_user_id"]=SrUser::getUserId();
		$srModel = self::invokeService('PmtVersionService','queryPmtVersion', $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('PmtVersionView',__FUNCTION__, $spModel );
		return self::forward();
	}



public function editPmtVersionPage($spModel=array()){
		$spModel=self::getSpModel($spModel);
if($this->loadBarView('AppCommonBarView','selectProject', $spModel )===false){
	$this->set(__FUNCTION__,$spModel,array());
	return self::forward();
}
		$srModel = self::invokeService('PmtVersionService','getPmtVersion', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		

$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('PmtVersionView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editPmtVersion($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('PmtVersionService','editPmtVersion', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editPmtVersionPage','post',$spModel,$srModel);
	}




	public function viewPmtVersionPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('PmtVersionService','getPmtVersion', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
		
		$this->loadView('PmtVersionView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>