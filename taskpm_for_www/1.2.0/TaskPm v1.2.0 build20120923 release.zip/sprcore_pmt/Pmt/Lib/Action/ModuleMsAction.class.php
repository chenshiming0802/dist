<?php

class ModuleMsAction extends SrAction{
 
	/*
	* http://127.0.0.1:82/sprcore_all/Demo/index.php/ModuleMs/queryModuleMs	*/
	public function queryModuleMs($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		
		$srModel = self::invokeService('ModuleMsService','queryModuleMs', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('ModuleMsView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function managerModuleMsPage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('ModuleMsService','getModuleMs', $spModel );	
		if($srModel['id']==null||$srModel['id'=='']){
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('ModuleMsView',__FUNCTION__, $spModel );
		return self::forward();
	}	
	public function managerModuleMs($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('ModuleMsService','managerModuleMs', $spModel );
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('managerModuleMsPage','post',$spModel,$srModel);
	}
	public function editModuleMsPage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('ModuleMsService','getModuleMs', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('ModuleMsView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editModuleMs($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('ModuleMsService','editModuleMs', $spModel );
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editModuleMsPage','post',$spModel,$srModel);
	}
	public function deleteModuleMs($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('ModuleMsService','deleteModuleMs', $spModel );
		$this->setIsOutHtml(false);
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('queryModuleMs','post',$spModel,$srModel);
	}
	public function viewModuleMsPage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('ModuleMsService','getModuleMs', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('ModuleMsView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>