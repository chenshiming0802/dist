<?php
class AppModule2ContentAction extends SrAction{	

}
?>
