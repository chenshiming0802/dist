<?php

class Task2DependAction extends SrAction{



	public function managerTask2DependPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('Task2DependService','getTask2Depend', $spModel );	
		if($srModel['id']==null||$srModel['id'=='']){
			 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}
$this->loadTabView('AppCommonTabView','configTaskEdit', $srModel);
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('Task2DependView',__FUNCTION__, $spModel );
		return self::forward();
	}	
	public function managerTask2Depend($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('Task2DependService','managerTask2Depend', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('viewTask2DependPage','post',$spModel,$srModel);
	}

public function editTask2DependPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('Task2DependService','getTask2Depend', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		
$this->loadTabView('AppCommonTabView','configTaskEdit', $srModel);
$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('Task2DependView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editTask2Depend($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('Task2DependService','editTask2Depend', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('viewTask2DependPage','post',$spModel,$srModel);
	}




	public function viewTask2DependPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('Task2DependService','getTask2Depend', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
$this->loadTabView('AppCommonTabView','configTaskView', $srModel);		
		$this->loadView('Task2DependView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>