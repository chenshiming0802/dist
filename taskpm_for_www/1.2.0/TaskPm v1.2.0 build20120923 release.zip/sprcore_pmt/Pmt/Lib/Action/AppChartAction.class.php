<?php
class AppChartAction extends SrAction{	
	public function queryPersonDay($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('AppCommonBarView','selectProject', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}			
		$this->set(__FUNCTION__,$spModel,null);
		$this->loadView('AppChartView',__FUNCTION__, $spModel );
		return self::forward();			
	} 	
	public function queryPersonDayData($spModel=array()){
		$spModel=self::getSpModel($spModel);
//		$spModel['begin_occure_day'] =  '2011-11-01';	
//		$spModel['end_occure_day'] =  '2011-11-03';
		$srModel = self::invokeService('AppCommonService','queryPersonDayStatus', $spModel );		
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadOpenFlashChart('AppChartView',__FUNCTION__, $spModel );
//		return self::forward();			
	}	
}
?>
