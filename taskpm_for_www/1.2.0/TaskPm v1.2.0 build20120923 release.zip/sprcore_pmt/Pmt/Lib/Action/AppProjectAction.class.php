<?php
class AppProjectAction extends SrAction{	
	public function viewProjectIframePage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('ProjectService','getProject', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadTabView('AppCommonTabView','configProjectView', $srModel);		
		$this->loadView('AppProjectView',__FUNCTION__, $spModel );
		return self::forward();
	}
}
?>
