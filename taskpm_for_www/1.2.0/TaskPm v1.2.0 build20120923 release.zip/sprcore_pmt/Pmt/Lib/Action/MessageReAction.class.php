<?php

class MessageReAction extends SrAction{

/*
	* http://127.0.0.1:82/sprcore_all/Demo/index.php/MessageRe/queryMessageRe	*/
	public function queryMessageRe($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('','', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		
		$srModel = self::invokeService('MessageReService','queryMessageRe', $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('MessageReView',__FUNCTION__, $spModel );
		return self::forward();
	}



public function editMessageRePage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('MessageReService','getMessageRe', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		

$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('MessageReView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editMessageRe($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('MessageReService','editMessageRe', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editMessageRePage','post',$spModel,$srModel);
	}


public function deleteMessageRe($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('MessageReService','deleteMessageRe', $spModel );
		
		$this->setIsOutHtml(false);
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('viewMessageRePage','post',$spModel,$srModel);
	}

	public function viewMessageRePage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('MessageReService','getMessageRe', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
		
		$this->loadView('MessageReView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>