<?php

class ModuleMilestoneAction extends SrAction{
 
	/*
	* http://127.0.0.1:82/sprcore_all/Demo/index.php/ModuleMilestone/queryModuleMilestone	*/
	public function queryModuleMilestone($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		
		$srModel = self::invokeService('ModuleMilestoneService','queryModuleMilestone', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('ModuleMilestoneView',__FUNCTION__, $spModel );
		return self::forward();
	}

	public function editModuleMilestonePage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('ModuleMilestoneService','getModuleMilestone', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('ModuleMilestoneView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editModuleMilestone($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('ModuleMilestoneService','editModuleMilestone', $spModel );
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editModuleMilestonePage','post',$spModel,$srModel);
	}
	public function deleteModuleMilestone($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('ModuleMilestoneService','deleteModuleMilestone', $spModel );
		$this->setIsOutHtml(false);
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('queryModuleMilestone','post',$spModel,$srModel);
	}
	public function viewModuleMilestonePage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('ModuleMilestoneService','getModuleMilestone', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('ModuleMilestoneView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>