<?php

class TaskAction extends SrAction{

/*
	* http://127.0.0.1:82/sprcore_all/Demo/index.php/Task/queryTask	*/
	public function queryTask($spModel=array()){
 		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('AppCommonBarView','selectModule', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		self::setDefaultValue($spModel,"query_status","020");
		$srModel = self::invokeService('TaskService','queryTask', $spModel );
		$this->loadTabView('AppCommonTabView','queryTaskStatus', $srModel);
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('TaskView',__FUNCTION__, $spModel );
		$ret = self::forward();

		return $ret;
	}



public function editTaskPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('TaskService','getTask', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			$srModel['project_id']=Session::get('pmt_current_project_id');
			$srModel['module_id']=Session::get('pmt_current_module_id');
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}
		$this->loadTabView('AppCommonTabView','configTaskEdit', $srModel);
		$this->set(__FUNCTION__,$spModel,$srModel);
		if($srModel['spr_tree_type']=='010'){
			$this->loadView('TaskView','editTaskPage_010', $spModel );
		}else{
			$this->loadView('TaskView',__FUNCTION__, $spModel );
		}
		return self::forward();
	}
	public function editTask($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('TaskService','editTask', $spModel );

		$spModel['id'] = $srModel['id'];


		return self::redirectMethod('viewTaskPage','post',$spModel,$srModel);
	}


public function deleteTask($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('TaskService','deleteTask', $spModel );

		$this->setIsOutHtml(false);
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('viewTaskPage','post',$spModel,$srModel);
	}

	public function viewTaskPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('TaskService','getTask', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
$this->loadTabView('AppCommonTabView','configTaskView', $srModel);
		$this->loadView('TaskView',__FUNCTION__, $spModel );
		return self::forward();
	}
	//T000506	       任务添加从其他系统读取任务详情功能
	public function getTaskSourceInfo($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('TaskService','getTaskSourceInfo', $spModel );
		//echo $srModel['content'];
		Sr::info($srModel);
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::sprAjaxReturn();
	}
	//T000386	       支持邮件模块任务项目绑定
	public function getTaskSourceFromMail($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('TaskService','getTaskSourceFromMail', $spModel );
		//echo $srModel['content'];
		Sr::info($srModel);
		$this->set(__FUNCTION__,$spModel,$srModel);
		return self::sprAjaxReturn();
	}
}

?>