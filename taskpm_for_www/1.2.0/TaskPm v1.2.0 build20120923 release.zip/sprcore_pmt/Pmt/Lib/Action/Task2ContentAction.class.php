<?php

class Task2ContentAction extends SrAction{





public function editTask2ContentPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('Task2ContentService','getTask2Content', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		
$this->loadTabView('AppCommonTabView','configTaskEdit', $srModel);
$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('Task2ContentView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editTask2Content($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('Task2ContentService','editTask2Content', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('viewTask2ContentPage','post',$spModel,$srModel);
	}




	public function viewTask2ContentPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('Task2ContentService','getTask2Content', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
$this->loadTabView('AppCommonTabView','configTaskView', $srModel);		
		$this->loadView('Task2ContentView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>