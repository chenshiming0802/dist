<?php

class PmtDocumentAction extends SrAction{

/*
	* http://127.0.0.1:82/sprcore_all/Demo/index.php/PmtDocument/queryDocument	*/
	public function queryDocument($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('','', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		
		$srModel = self::invokeService('PmtDocumentService','queryDocument', $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('PmtDocumentView',__FUNCTION__, $spModel );
		return self::forward();
	}



public function editDocumentPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('PmtDocumentService','getDocument', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		

$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('PmtDocumentView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editDocument($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('PmtDocumentService','editDocument', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editDocumentPage','post',$spModel,$srModel);
	}


public function deleteDocument($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('DocumentService','deleteDocument', $spModel );
		
		$this->setIsOutHtml(false);
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('viewDocumentPage','post',$spModel,$srModel);
	}

	public function viewDocumentPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('PmtDocumentService','getDocument', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
		
		$this->loadView('PmtDocumentView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>