<?php

class Module2ContentAction extends SrAction{





public function editModule2ContentPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('Module2ContentService','getModule2Content', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		
$this->loadTabView('AppCommonTabView','configModuleEdit', $srModel);
$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('Module2ContentView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editModule2Content($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('Module2ContentService','editModule2Content', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editModule2ContentPage','post',$spModel,$srModel);
	}




	public function viewModule2ContentPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('Module2ContentService','getModule2Content', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
$this->loadTabView('AppCommonTabView','configModuleView', $srModel);		
		$this->loadView('Module2ContentView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>