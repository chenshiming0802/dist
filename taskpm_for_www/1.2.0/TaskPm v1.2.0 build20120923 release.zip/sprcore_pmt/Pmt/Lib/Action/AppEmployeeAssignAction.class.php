<?php
class AppEmployeeAssignAction extends SrAction{	
	public function queryEmployeeAssign($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('','', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		
		$srModel = self::invokeService('AppEmployeeAssignService','queryEmployeeAssign', $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppEmployeeAssignView',__FUNCTION__, $spModel );
		return self::forward();
	}	
	
	public function editEmployeeAssignPage($spModel=array()){
		$spModel=self::getSpModel($spModel);
		self::setDefaultValue($spModel,"year",date('Y'));
		$srModel = self::invokeService('AppEmployeeAssignService','getEmployeeAssign', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		

$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('AppEmployeeAssignView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editEmployeeAssign($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('AppEmployeeAssignService','editEmployeeAssign', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editEmployeeAssignPage','post',$spModel,$srModel,'0');
	}
	
	public function viewProjectEmployeeAssign($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('','', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		$spModel["query_project_id"] = $spModel['id'];
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		
		$srModel = self::invokeService('AppEmployeeAssignService','queryEmployeeAssign', $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadTabView('AppCommonTabView','configProjectView', $spModel);	
		$this->loadView('AppEmployeeAssignView',__FUNCTION__, $spModel );
		return self::forward();
	}	

	
	public function viewEmployeeEmployeeAssign($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('','', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		$spModel["query_employee_id"] = $spModel['id'];
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		
		$srModel = self::invokeService('AppEmployeeAssignService','queryEmployeeAssign', $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadTabView('AppCommonTabView','configEmployeeView', $spModel);	
		$this->loadView('AppEmployeeAssignView',__FUNCTION__, $spModel );
		return self::forward();
	}		
}
?>
