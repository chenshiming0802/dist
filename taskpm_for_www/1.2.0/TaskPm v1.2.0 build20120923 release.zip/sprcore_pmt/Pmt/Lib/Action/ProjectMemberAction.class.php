<?php

class ProjectMemberAction extends SrAction{

/*
	* http://127.0.0.1:82/sprcore_all/Demo/index.php/ProjectMember/queryProjectMember	*/
	public function queryProjectMember($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('','', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		$spModel["query_belong_org_id"]=SrUser::getOrgId();
		
		$srModel = self::invokeService('ProjectMemberService','queryProjectMember', $spModel );

		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('ProjectMemberView',__FUNCTION__, $spModel );
		return self::forward();
	}



public function editProjectMemberPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('ProjectMemberService','getProjectMember', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		

$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('ProjectMemberView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editProjectMember($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('ProjectMemberService','editProjectMember', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editProjectMemberPage','post',$spModel,$srModel);
	}


public function deleteProjectMember($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('ProjectMemberService','deleteProjectMember', $spModel );
		
		$this->setIsOutHtml(false);
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('viewProjectMemberPage','post',$spModel,$srModel);
	}

	public function viewProjectMemberPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('ProjectMemberService','getProjectMember', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
		
		$this->loadView('ProjectMemberView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>