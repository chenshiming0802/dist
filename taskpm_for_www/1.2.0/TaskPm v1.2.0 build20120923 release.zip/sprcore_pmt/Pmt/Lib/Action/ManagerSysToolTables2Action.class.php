<?php

class ManagerSysToolTables2Action extends SrAction{
 
	/*
	* http://127.0.0.1:82/sprcore_all/Demo/index.php/ManagerSysToolTables2/querySysToolTables2	*/
	public function querySysToolTables2($spModel=array()){
		$spModel=self::getSpModel($spModel);
		if($this->loadBarView('','', $spModel )===false){
			$this->set(__FUNCTION__,$spModel,array());
			return self::forward();
		}
		
		
		$srModel = self::invokeService('ManagerSysToolTables2Service','querySysToolTables2', $spModel );
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('ManagerSysToolTables2View',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function managerSysToolTables2Page($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('ManagerSysToolTables2Service','getSysToolTables2', $spModel );	
		if($srModel['id']==null||$srModel['id'=='']){
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('ManagerSysToolTables2View',__FUNCTION__, $spModel );
		return self::forward();
	}	
	public function managerSysToolTables2($spModel=array()){
		$spModel=self::getSpModel($spModel);

				$srModel = self::invokeService('ManagerSysToolTables2Service','managerSysToolTables2', $spModel );
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('managerSysToolTables2Page','post',$spModel,$srModel);
	}
	public function editSysToolTables2Page($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('ManagerSysToolTables2Service','getSysToolTables2', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('ManagerSysToolTables2View',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editSysToolTables2($spModel=array()){
		$spModel=self::getSpModel($spModel);

				$srModel = self::invokeService('ManagerSysToolTables2Service','editSysToolTables2', $spModel );
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editSysToolTables2Page','post',$spModel,$srModel);
	}
	public function deleteSysToolTables2($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('SysToolTables2Service','deleteSysToolTables2', $spModel );
		$this->setIsOutHtml(false);
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('viewSysToolTables2','post',$spModel,$srModel);
	}
	public function viewSysToolTables2Page($spModel=array()){
		$spModel=self::getSpModel($spModel);
		$srModel = self::invokeService('ManagerSysToolTables2Service','getSysToolTables2', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('ManagerSysToolTables2View',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>