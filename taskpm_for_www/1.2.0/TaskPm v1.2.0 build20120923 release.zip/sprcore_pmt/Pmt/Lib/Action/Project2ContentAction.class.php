<?php

class Project2ContentAction extends SrAction{





public function editProject2ContentPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('Project2ContentService','getProject2Content', $spModel );
		if($srModel['id']==null||$srModel['id'=='']){
			 
			$srModel = self::fillSrModelBySpModel($srModel,$spModel);
		}		
$this->loadTabView('AppCommonTabView','configProjectEdit', $srModel);
$this->set(__FUNCTION__,$spModel,$srModel);
		$this->loadView('Project2ContentView',__FUNCTION__, $spModel );
		return self::forward();
	}
	public function editProject2Content($spModel=array()){
		$spModel=self::getSpModel($spModel);
		
		$srModel = self::invokeService('Project2ContentService','editProject2Content', $spModel );
		
		$spModel['id'] = $srModel['id'];
		return self::redirectMethod('editProject2ContentPage','post',$spModel,$srModel);
	}




	public function viewProject2ContentPage($spModel=array()){
		$spModel=self::getSpModel($spModel);

		$srModel = self::invokeService('Project2ContentService','getProject2Content', $spModel );	
		$this->set(__FUNCTION__,$spModel,$srModel);
$this->loadTabView('AppCommonTabView','configProjectView', $srModel);		
		$this->loadView('Project2ContentView',__FUNCTION__, $spModel );
		return self::forward();
	}			  
}

?>