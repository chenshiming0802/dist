<?php
class AppChartView extends SrView{	
	public function queryPersonDay($spModel){
		$id = $this->srModel['id'];
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/queryPersonDay",
			"target"=>"_self",
			"onSubmit"=>"",
		);	
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));	
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'label.begin_time','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'begin_occure_day',
			'control_value'=>'',
			'control_class'=>"required",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['begin_occure_day'],
			'INFO'=>"",
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'label.end_time','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'end_occure_day',
			'control_value'=>'',
			'control_class'=>"required",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['end_occure_day'],
			'INFO'=>"",
		));	
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(		
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$this->addItems($items);			
 
		$begin_occure_day = $this->spModel['begin_occure_day'];
		$end_occure_day = $this->spModel['end_occure_day'];
		$query_project_id = $this->spModel['query_project_id'];
		$this->addOpenFlashChart(array(
			'div_id'=>'div_search','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'chart',
			'data_url'=>__URL__."/queryPersonDayData/begin_occure_day/{$begin_occure_day}/end_occure_day/{$end_occure_day}/query_project_id/{$query_project_id}",
			//'data_url'=>'/open-flash-chart/data.json',
			'chart_width'=>800,
			'chart_height'=>400,
			));	
		//dump($ret2['list']);		
		
		self::addInfoResults($srModel,null);
		return $srModel;	;		
	}	
}
?>
