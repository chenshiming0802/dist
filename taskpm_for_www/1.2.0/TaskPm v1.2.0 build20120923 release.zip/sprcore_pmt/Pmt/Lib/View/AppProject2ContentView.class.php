<?php
class AppProject2ContentView extends SrView{	

}
?>
