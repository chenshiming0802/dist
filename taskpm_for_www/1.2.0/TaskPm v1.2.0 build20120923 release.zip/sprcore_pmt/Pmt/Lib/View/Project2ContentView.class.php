<?php

class Project2ContentView extends SrView{
	private $tv_project_level;

	public function __construct(){
		$this->tv_project_level = "1;;PMT10";

	}






public function editProject2ContentPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/editProject2Content",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.manager_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'manager_id',
			'control_value'=>$this->tv_manager_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["manager_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.adv_begin_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'adv_begin_date',
			'control_value'=>$this->tv_adv_begin_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_begin_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.adv_end_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'adv_end_date',
			'control_value'=>$this->tv_adv_end_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_end_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'status',
			'control_value'=>$this->tv_status,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["status"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'code',
			'control_value'=>$this->tv_code,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.customer_name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'customer_name',
			'control_value'=>$this->tv_customer_name,
			'control_class'=>" ",'control_param'=>"  size='40'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["customer_name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.project_level','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'project_level',
			'control_value'=>$this->tv_project_level,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["project_level"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.content','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'RICKEDIT','control_name'=>'content',
			'control_value'=>$this->tv_content,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["content"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.url','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'url',
			'control_value'=>$this->tv_url,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  size='100'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["url"],
		));



		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
					$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);


if($id==null || $id==''){


}else{


}


		self::addInfoResults($srModel,null);
		return $srModel;
	}
	public function viewProject2ContentPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewProject2ContentPage",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.manager_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'manager_id',
			'control_value'=>$this->tv_manager_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["manager_id"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.adv_begin_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'adv_begin_date',
			'control_value'=>$this->tv_adv_begin_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_begin_date"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.adv_end_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'adv_end_date',
			'control_value'=>$this->tv_adv_end_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_end_date"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'status',
			'control_value'=>$this->tv_status,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["status"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'code',
			'control_value'=>$this->tv_code,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.customer_name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'customer_name',
			'control_value'=>$this->tv_customer_name,
			'control_class'=>" ",'control_param'=>"  size='40'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["customer_name"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.project_level','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'project_level',
			'control_value'=>$this->tv_project_level,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["project_level"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.content','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'RICKEDIT','control_name'=>'content',
			'control_value'=>$this->tv_content,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["content"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_project.url','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'url',
			'control_value'=>$this->tv_url,
			'control_class'=>" ",'control_param'=>"ROWS=2 COLS=150  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["url"],
			'INFO'=>"",
		));



//		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
//		$srModel_sflow = SrSflow::page_displayButton(array(
//			"sflow_is_add_form"=>"0",
//			"sflow_current_form"=>"ff",
//			"sflow_code"=>"pmt_project",
//			"sflow_business_id"=>$this->srModel["id"],
//			"sflow_business_num"=>$this->srModel["code"],
//			"sflow_from_status"=>$this->srModel[""],
//			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
//			"sflow_return_url"=>__SELF__,
//			"sflow_request_params"=>array(
//			"id"=>$spModel["id"],
//			"pageType"=>$spModel["pageType"],
//			),
//		));
//		$this->hidden_html = $srModel_sflow["divHtml"];
//		$items["items_line"] = $srModel_sflow["buttonArrays"];
///*
//		$items["items_line"][] =array(
//				'control_type'=>'BUTTON','control_name'=>'update',
//				'control_value'=>__URL__."/editProject2ContentPage?id={$id}",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.update',
//			);
//
//		$items["items_line"][] =array(
//				'control_type'=>'BUTTON','control_name'=>'delete',
//				'control_value'=>__URL__."/deleteTask?id={$id}",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.delete',
//			);
//
//Sflow(flow_name,button_name,page_submit_type,page_submit_js):
//修改项目信息_内容	page.button.update	030	__APP__/Project2Content/editProject2ContentPage?id={1}
//新增子项目信息_内容	page.button.addchild	030	__APP__/Project2Content/editProject2ContentPage?={1}
//删除项目信息_内容	page.button.delete	030	__APP__/Project2Content/deleteProject2Content?id={1}
//*/
//
//		$items["items_line"][] = array(
//				'control_type'=>'BUTTON','control_name'=>'close',
//				'control_value'=>"",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.close',
//			);
//		$this->addItems($items);




		self::addInfoResults($srModel,null);
		return $srModel;
	}
}

?>