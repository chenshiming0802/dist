<?php

class Task2DependView extends SrView{
	private $tv_depend_task_id;
	private $tv_depend_type;

	public function __construct(){
		$this->tv_depend_task_id = "1;;;pmt_task;name;SELECT t.id _valueCode_,t.name _valueName_,t.id _childCode_,t.parent_task_id _parentCode_,t.id _childSortNo_ FROM pmt_task t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()." and t.module_id=".Session::get("pmt_current_module_id")."";
		$this->tv_depend_type = "1;;PMT11";

	}




	public function managerTask2DependPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.'.title',array('displayDiv'=>'false'));
		$this->form = array(
			'name'=>'ff',
			'method'=>'post',
			'action'=>__URL__."/managerTask2Depend",
			'target'=>'_self',
			'onSubmit'=>'',
		);
		//$this->srModel['id']?'1':'0'
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.'.title','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>'',
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'code',
			'control_value'=>$this->tv_code,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));


		//DETAIL BUTTON
		$items = array('div_id'=>'div_search_v','div_label'=>'pmt_task_depend','item_line_type'=>'line','item_viewauth'=>'',);
		$items["items_line"] = array();


		$items["items_line"][] = array(
				'control_type'=>'TEXT','control_name'=>'detail_add_count',
				'control_value'=>"",
				'control_class'=>"",'control_param'=>'size="2"','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'adddetail1',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.add.detail',
			);

		$this->addItems($items);
		//GRID
		$buttons = array();
		$buttons[] =array(
						'control_type'=>'BUTTON','control_name'=>'deletedetail',
						'control_value'=>"id",
						'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'page.button.delete',
					);
		$this->addGrid(array(
			'div_id'=>'div_search','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'grid_list'=>$this->srModel['details'],'grid_page'=>$this->srModel['details_page'],
			'grid_param'=>array(

				'pmt_task_depend.id'=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_id[]',
						'control_value'=>$this->tv_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'id',
					),
				'pmt_task_depend.task_id'=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_task_id[]',
						'control_value'=>$this->tv_task_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'task_id',
					),
				'pmt_task_depend.depend_task_id'=>array(
						'control_type'=>'SELECT_SQL','control_name'=>'detail_depend_task_id[]',
						'control_value'=>$this->tv_depend_task_id,
						'control_class'=>"required",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'depend_task_id',
					),
				'pmt_task_depend.depend_type'=>array(
						'control_type'=>'SELECT_DICT','control_name'=>'detail_depend_type[]',
						'control_value'=>$this->tv_depend_type,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'depend_type',
					),
				'pmt_task_depend.delay_day'=>array(
						'control_type'=>'TEXT','control_name'=>'detail_delay_day[]',
						'control_value'=>$this->tv_delay_day,
						'control_class'=>"required validate-numbe max-value-100",'control_param'=>"  size='3'  ",'control_readonly'=>'0','control_viewauth'=>'',
						'value_input'=>'delay_day',
					),
				"operate"=>$buttons,
			),
		));

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
					$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);


if($id==null || $id==''){


}else{


}



		self::addInfoResults($srModel,null);
		return $srModel;
	}


public function editTask2DependPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/editTask2Depend",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'code',
			'control_value'=>$this->tv_code,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));



		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
					$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);


if($id==null || $id==''){


}else{


}


		self::addInfoResults($srModel,null);
		return $srModel;
	}
	public function viewTask2DependPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewTask2DependPage",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'code',
			'control_value'=>$this->tv_code,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_task.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));


		//GRID
		$this->addGrid(array(
			'div_id'=>'div_search','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'grid_list'=>$this->srModel['details'],'grid_page'=>$this->srModel['details_page'],
			'grid_param'=>array(

				"pmt_task_depend.id"=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_id[]',
						'control_value'=>$this->tv_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'id',
					),
				"pmt_task_depend.task_id"=>array(
						'control_type'=>'HIDDEN','control_name'=>'detail_task_id[]',
						'control_value'=>$this->tv_task_id,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'task_id',
					),
				"pmt_task_depend.depend_task_id"=>array(
						'control_type'=>'SELECT_SQL','control_name'=>'detail_depend_task_id[]',
						'control_value'=>$this->tv_depend_task_id,
						'control_class'=>"required",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'depend_task_id',
					),
				"pmt_task_depend.depend_type"=>array(
						'control_type'=>'SELECT_DICT','control_name'=>'detail_depend_type[]',
						'control_value'=>$this->tv_depend_type,
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'depend_type',
					),
				"pmt_task_depend.delay_day"=>array(
						'control_type'=>'TEXT','control_name'=>'detail_delay_day[]',
						'control_value'=>$this->tv_delay_day,
						'control_class'=>"required validate-numbe max-value-100",'control_param'=>"  size='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'delay_day',
					),			),
		));

//		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
//		$srModel_sflow = SrSflow::page_displayButton(array(
//			"sflow_is_add_form"=>"0",
//			"sflow_current_form"=>"ff",
//			"sflow_code"=>"pmt_task",
//			"sflow_business_id"=>$this->srModel["id"],
//			"sflow_business_num"=>$this->srModel["code"],
//			"sflow_from_status"=>$this->srModel[""],
//			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
//			"sflow_return_url"=>__SELF__,
//			"sflow_request_params"=>array(
//			"id"=>$spModel["id"],
//			"pageType"=>$spModel["pageType"],
//			),
//		));
//		echo $srModel_sflow["divHtml"];
//		$items["items_line"] = $srModel_sflow["buttonArrays"];
///*
//		$items["items_line"][] =array(
//				'control_type'=>'BUTTON','control_name'=>'update',
//				'control_value'=>__URL__."/editTask2DependPage?id={$id}",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.update',
//			);
//
//
//		$items["items_line"][] =array(
//				'control_type'=>'BUTTON','control_name'=>'update2',
//				'control_value'=>__URL__."/managerTask2DependPage?id={$id}",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.update',
//			);
//
//				$items["items_line"][] =array(
//				'control_type'=>'BUTTON','control_name'=>'delete',
//				'control_value'=>__URL__."/deleteTask?id={$id}",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.delete',
//			);
//
//Sflow(flow_name,button_name,page_submit_type,page_submit_js):
//修改任务信息_前置任务	page.button.update	030	__APP__/Task2Depend/editTask2DependPage?id={1}
//新增子任务信息_前置任务	page.button.addchild	030	__APP__/Task2Depend/editTask2DependPage?={1}
//删除任务信息_前置任务	page.button.delete	030	__APP__/Task2Depend/deleteTask2Depend?id={1}
//*/
//
//		$items["items_line"][] = array(
//				'control_type'=>'BUTTON','control_name'=>'close',
//				'control_value'=>"",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.close',
//			);
//		$this->addItems($items);




		self::addInfoResults($srModel,null);
		return $srModel;
	}
}

?>