<?php
class AppEmployeeAssignView extends SrView{	
	private $tv_status; 
	private $tv_employee_id; 
	private $tv_project_id; 
	private $tv_project_joblevel_id; 
	private $tv_joblevel_id; 
	private $tv_company_id; 

	public function __construct(){
		$this->tv_status = "1;;PMT15"; 
		$this->tv_employee_id = "1;;;pmt_employee;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_employee t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId().""; 
		$this->tv_project_id = "1;;;pmt_project;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_project t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId().""; 
		$this->tv_joblevel_id = "1;;;pmt_joblevel;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_joblevel t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()." "; 
		$this->tv_company_id = "1;;;pmt_company;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_company t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()." "; 
		$this->tv_project_joblevel_id = "1;;;pmt_joblevel;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_project_joblevel t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()." "; 
	
	}
public function queryEmployeeAssign($spModel){
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);
		
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee_assign.employee_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_employee_id',
			'control_value'=>$this->tv_employee_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_employee_id'],
			'INFO'=>"TYPE=open&URL=__APP__/Employee/viewEmployeePage?id=[employee_id]",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee_assign.project_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_project_id'],
			'INFO'=>"TYPE=open&URL=__APP__/Project/viewProjectPage%3Fid=[project_id]",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee_assign.project_joblevel_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_project_joblevel_id',
			'control_value'=>$this->tv_project_joblevel_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_project_joblevel_id'],
			'INFO'=>"",
		));		
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee_assign.joblevel_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_joblevel_id',
			'control_value'=>$this->tv_joblevel_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_joblevel_id'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee_assign.company_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_company_id',
			'control_value'=>$this->tv_company_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_company_id'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee_assign.year','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_year',
			'control_value'=>$this->tv_year,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_year'],
			'INFO'=>"",
		));
	 
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(		
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$items["items_line"][] = array(		
				'control_type'=>'BUTTON','control_name'=>'query_lack_employee',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query_lack_employee',
			);
	
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'appadd',
				'control_value'=>__URL__."/managerEmployeeAssignPage",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.appadd',
			);


		$this->addItems($items);	

		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'view',
				'control_value'=>__URL__."/editEmployeeAssignPage?project_id=[project_id]&year=[year]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.view',
			);

		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_info'=>'{has_e_label_checkeck:1,has_group_select:1,group_select_option:pmt_employee_assign.employee_id/pmt_employee_assign.project_id,group_select_key:pmt_employee_assign.project_id}',
			'grid_param'=>array(		
					'pmt_employee_assign.employee_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'employee_id[]',
					'control_value'=>$this->tv_employee_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'employee_id',
					'INFO'=>"TYPE=open&URL=__APP__/Employee/viewEmployeePage?id=[employee_id]",
					'div_label'=>'',
				),			
					'pmt_employee_assign.project_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'project_id',
					'control_value'=>$this->tv_project_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'project_id',
					'INFO'=>"TYPE=open&URL=__APP__/Project/viewProjectPage%3Fid=[project_id]",
					'div_label'=>'',
				),
					'pmt_employee_assign.project_joblevel_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'project_joblevel_id',
					'control_value'=>$this->tv_project_joblevel_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'project_joblevel_id',
					'INFO'=>"",
					'div_label'=>'',
				),								
					'pmt_employee_assign.joblevel_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'joblevel_id',
					'control_value'=>$this->tv_joblevel_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'joblevel_id',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.company_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'company_id',
					'control_value'=>$this->tv_company_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'company_id',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.year'=>array(
					'control_type'=>'TEXT','control_name'=>'year',
					'control_value'=>$this->tv_year,
					'control_class'=>"validate-numbe max-value-3000",'control_param'=>"  size='4'  maxlength='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'year',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m1'=>array(
					'control_type'=>'TEXT','control_name'=>'m1',
					'control_value'=>$this->tv_m1,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m1',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'//*m[group_m1]*/',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m2'=>array(
					'control_type'=>'TEXT','control_name'=>'m2',
					'control_value'=>$this->tv_m2,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m2',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m2]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m3'=>array(
					'control_type'=>'TEXT','control_name'=>'m3',
					'control_value'=>$this->tv_m3,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m3',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m3]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m4'=>array(
					'control_type'=>'TEXT','control_name'=>'m4',
					'control_value'=>$this->tv_m4,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m4',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m4]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m5'=>array(
					'control_type'=>'TEXT','control_name'=>'m5',
					'control_value'=>$this->tv_m5,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m5',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m5]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m6'=>array(
					'control_type'=>'TEXT','control_name'=>'m6',
					'control_value'=>$this->tv_m6,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m6',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m6]*/',						
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m7'=>array(
					'control_type'=>'TEXT','control_name'=>'m7',
					'control_value'=>$this->tv_m7,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m7',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m7]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m8'=>array(
					'control_type'=>'TEXT','control_name'=>'m8',
					'control_value'=>$this->tv_m8,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m8',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m8]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m9'=>array(
					'control_type'=>'TEXT','control_name'=>'m9',
					'control_value'=>$this->tv_m9,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m9',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m9]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m10'=>array(
					'control_type'=>'TEXT','control_name'=>'m10',
					'control_value'=>$this->tv_m10,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m10',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m10]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m11'=>array(
					'control_type'=>'TEXT','control_name'=>'m11',
					'control_value'=>$this->tv_m11,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m11',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m11]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m12'=>array(
					'control_type'=>'TEXT','control_name'=>'m12',
					'control_value'=>$this->tv_m12,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m12',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m12]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
	
				'operate'=>$buttons,
			),			
		));
		

		

		self::addInfoResults($srModel,null);
		return $srModel;
	}
	
public function editEmployeeAssignPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/editEmployeeAssign",
			"target"=>"_self",
			"onSubmit"=>"",
		);	
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));		

			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.project_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>"required",'control_param'=>" onChange='changePage()' ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel['project_id'],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.year','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'year',
			'control_value'=>"1;;PMT16",
			'control_class'=>"required",'control_param'=>" onChange='changePage()' ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["year"],
		));
		$e1 = 0;//存在的资源数
		$e2 = 0;//空缺的资源数
		foreach($this->srModel['list'] as $key=>$mm){
			$eid = (int)$mm["employee_id"];
			if($eid=='-1'){
				$e2++;
			}else{
				$e1++;
			}
		}
		$tt = $e1;
		if($e2>0){
			$tt .= " 缺 $e2";
		}
		
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee_assign.employee_count','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'employee_count',
			'control_value'=>"",
			'control_class'=>"required",'control_param'=>" onChange='changePage()' ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$tt,
		));		
		$tt = Sr::sys_getArrayBarByList($this->srModel["list"],'employee_id',"|");
 
		$items = array('div_id'=>'div_search_v','div_label'=>'pmt_project_member','item_line_type'=>'line','item_viewauth'=>'',);
		$items["items_line"] = array();	
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'adddetail2',
				'control_value'=>__APP__."/AppSelect/queryEmployeeAssignInfo?isMulti=1&callbackMethod=selectDetailCallBack&no_in_ids={$tt}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'添加职员',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'adddetail3',
				'control_value'=>__APP__."/AppSelect/queryEmployeeAssignInfo?isMulti=1&callbackMethod=selectDetailCallBack&no_in_ids={$tt}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'添加缺口成员',
			);			
		$this->addItems($items);			


		foreach($this->srModel['list'] as $k=>$model){
			if($model['employee_id']!='-1'){
				$this->srModel['list'][$k]["has_occupy_button"] = '1';
			}else{
				$this->srModel['list'][$k]["has_occupy_button"] = '0';
			}
		}			


		$buttons = array();
		$buttons[] =array(
						'control_type'=>'BUTTON','control_name'=>'occupy',
						'control_value'=>"id",
						'control_class'=>'','control_param'=>'','control_readonly'=>'','control_viewauth'=>'has_occupy_button',
						'value_input'=>'page.button.occupy',
					);							
		$buttons[] =array(
						'control_type'=>'BUTTON','control_name'=>'deletedetail',
						'control_value'=>"id",
						'control_class'=>'','control_param'=>'','control_readonly'=>'','control_viewauth'=>'',
						'value_input'=>'page.button.delete',
					);

 		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param_hidden'=>array(),
			'grid_info'=>'{has_tr_data:1,has_e_label_checkeck:1}',
			'grid_param'=>array(
					'pmt_employee_assign.id'=>array(
					'control_type'=>'HIDDEN','control_name'=>'detail_id[]',
					'control_value'=>$this->tv_emp_no,
					'control_class'=>"required max-length-20",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'id',
					'INFO'=>"",
					'div_label'=>'',
				),	
					'pmt_employee.id'=>array(
					'control_type'=>'HIDDEN','control_name'=>'detail_employee_id[]',
					'control_value'=>$this->tv_emp_no,
					'control_class'=>"required max-length-20",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'employee_id',
					'INFO'=>"",
					'div_label'=>'',
				),								
					'pmt_employee.emp_no'=>array(
					'control_type'=>'TEXT','control_name'=>'emp_no[]',
					'control_value'=>$this->tv_emp_no,
					'control_class'=>"required max-length-20",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'emp_no',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee.name'=>array(
					'control_type'=>'TEXT','control_name'=>'name',
					'control_value'=>$this->tv_name,
					'control_class'=>"required  max-length-20",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'name',
					'INFO'=>"",
					'div_label'=>'',
				),	
					'pmt_employee_assign.project_joblevel_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'project_joblevel_id[]',
					'control_value'=>$this->tv_project_joblevel_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'project_joblevel_id',
					'INFO'=>"",
					'div_label'=>'',
				),							
					'pmt_employee.joblevel_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'joblevel_id[]',
					'control_value'=>$this->tv_joblevel_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'joblevel_id',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee.company_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'company_id[]',
					'control_value'=>$this->tv_company_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'company_id',
					'INFO'=>"",
					'div_label'=>'',
				),		
					'pmt_employee_assign.m1'=>array(
					'control_type'=>'TEXT','control_name'=>'m1[]',
					'control_value'=>$this->tv_m1,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'m1',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m1]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m2'=>array(
					'control_type'=>'TEXT','control_name'=>'m2[]',
					'control_value'=>$this->tv_m2,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'m2',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m2]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m3'=>array(
					'control_type'=>'TEXT','control_name'=>'m3[]',
					'control_value'=>$this->tv_m3,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'m3',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m3]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m4'=>array(
					'control_type'=>'TEXT','control_name'=>'m4[]',
					'control_value'=>$this->tv_m4,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'m4',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m4]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m5'=>array(
					'control_type'=>'TEXT','control_name'=>'m5[]',
					'control_value'=>$this->tv_m5,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'m5',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m5]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m6'=>array(
					'control_type'=>'TEXT','control_name'=>'m6[]',
					'control_value'=>$this->tv_m6,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'m6',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m6]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m7'=>array(
					'control_type'=>'TEXT','control_name'=>'m7[]',
					'control_value'=>$this->tv_m7,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'m7',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m7]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m8'=>array(
					'control_type'=>'TEXT','control_name'=>'m8[]',
					'control_value'=>$this->tv_m8,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'m8',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m8]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m9'=>array(
					'control_type'=>'TEXT','control_name'=>'m9[]',
					'control_value'=>$this->tv_m9,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'m9',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m9]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m10'=>array(
					'control_type'=>'TEXT','control_name'=>'m10[]',
					'control_value'=>$this->tv_m10,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'m10',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m10]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m11'=>array(
					'control_type'=>'TEXT','control_name'=>'m11[]',
					'control_value'=>$this->tv_m11,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'m11',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m11]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m12'=>array(
					'control_type'=>'TEXT','control_name'=>'m12[]',
					'control_value'=>$this->tv_m12,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'m12',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m12]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),	
				'operate'=>$buttons,																	
			),	
			'grid_label_param'=>array(
				"label.select"=>array(
					'control_type'=>'CHECKBOX','control_name'=>'ids',
					'control_value'=>'',
					'control_class'=>'','control_param'=>"onClick=\"a_checkAll(this,'id[]')\"",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'',
				),
			),
		));
		
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$status = $this->srModel['status'];
//		$items["items_line"][] = array(			
//				'control_type'=>'BUTTON','control_name'=>'save',
//				'control_value'=>"",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
//				'control_viewauth'=>($status==null||$status=='010')?'0':'1',
//				'value_input'=>'page.button.save',
//			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'submitb',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>($status==null||$status=='010')?'0':'1',
				'value_input'=>'page.button.submit',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>($status==null||$status=='010')?'1':'0',
				'value_input'=>'page.button.update',
			);
					$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);										
		$this->addItems($items);				


if($id==null || $id==''){
		

}else{
		

}

		
		self::addInfoResults($srModel,null);
		return $srModel;		
	}	
	
	
public function viewProjectEmployeeAssign($spModel){
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);
		
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
	 
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);

		$this->addItems($items);	

 

		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_info'=>'{has_e_label_checkeck:1}',
			'grid_param'=>array(		
					'pmt_employee_assign.employee_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'employee_id[]',
					'control_value'=>$this->tv_employee_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'employee_id',
					'INFO'=>"TYPE=open&URL=__APP__/Employee/viewEmployeePage?id=[employee_id]",
					'div_label'=>'',
				),			
//					'pmt_employee_assign.project_id'=>array(
//					'control_type'=>'SELECT_SQL','control_name'=>'project_id',
//					'control_value'=>$this->tv_project_id,
//					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//					'value_input'=>'project_id',
//					'INFO'=>"TYPE=open&URL=__APP__/Project/viewProjectPage%3Fid=[project_id]",
//					'div_label'=>'',
//				),
					'pmt_employee_assign.project_joblevel_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'project_joblevel_id',
					'control_value'=>$this->tv_project_joblevel_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'project_joblevel_id',
					'INFO'=>"",
					'div_label'=>'',
				),								
					'pmt_employee_assign.joblevel_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'joblevel_id',
					'control_value'=>$this->tv_joblevel_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'joblevel_id',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.company_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'company_id',
					'control_value'=>$this->tv_company_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'company_id',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.year'=>array(
					'control_type'=>'TEXT','control_name'=>'year',
					'control_value'=>$this->tv_year,
					'control_class'=>"validate-numbe max-value-3000",'control_param'=>"  size='4'  maxlength='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'year',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m1'=>array(
					'control_type'=>'TEXT','control_name'=>'m1',
					'control_value'=>$this->tv_m1,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m1',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'//*m[group_m1]*/',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m2'=>array(
					'control_type'=>'TEXT','control_name'=>'m2',
					'control_value'=>$this->tv_m2,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m2',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m2]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m3'=>array(
					'control_type'=>'TEXT','control_name'=>'m3',
					'control_value'=>$this->tv_m3,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m3',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m3]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m4'=>array(
					'control_type'=>'TEXT','control_name'=>'m4',
					'control_value'=>$this->tv_m4,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m4',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m4]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m5'=>array(
					'control_type'=>'TEXT','control_name'=>'m5',
					'control_value'=>$this->tv_m5,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m5',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m5]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m6'=>array(
					'control_type'=>'TEXT','control_name'=>'m6',
					'control_value'=>$this->tv_m6,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m6',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m6]*/',						
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m7'=>array(
					'control_type'=>'TEXT','control_name'=>'m7',
					'control_value'=>$this->tv_m7,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m7',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m7]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m8'=>array(
					'control_type'=>'TEXT','control_name'=>'m8',
					'control_value'=>$this->tv_m8,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m8',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m8]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m9'=>array(
					'control_type'=>'TEXT','control_name'=>'m9',
					'control_value'=>$this->tv_m9,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m9',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m9]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m10'=>array(
					'control_type'=>'TEXT','control_name'=>'m10',
					'control_value'=>$this->tv_m10,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m10',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m10]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m11'=>array(
					'control_type'=>'TEXT','control_name'=>'m11',
					'control_value'=>$this->tv_m11,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m11',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m11]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m12'=>array(
					'control_type'=>'TEXT','control_name'=>'m12',
					'control_value'=>$this->tv_m12,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m12',
					'value_input_b_label'=>'',
					'value_input_e_label'=>'/ /*m[group_m12]*/',					
					'INFO'=>"",
					'div_label'=>'',
				),			
	
//				'operate'=>$buttons,
			),			
		));
		

		

		self::addInfoResults($srModel,null);
		return $srModel;
	}	
	
	public function viewEmployeeEmployeeAssign($spModel){
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);
		
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));

	 	$tt = "1月(".Sr::array_sum_key($this->srModel['list'],"m1").")&nbsp;";
	 	$tt .= "2月(".Sr::array_sum_key($this->srModel['list'],"m2").")&nbsp;";
	 	$tt .= "3月(".Sr::array_sum_key($this->srModel['list'],"m3").")&nbsp;";
	 	$tt .= "4月(".Sr::array_sum_key($this->srModel['list'],"m4").")&nbsp;";
	 	
	 	$tt .= "5月(".Sr::array_sum_key($this->srModel['list'],"m5").")&nbsp;";
	 	$tt .= "6月(".Sr::array_sum_key($this->srModel['list'],"m6").")&nbsp;";
	 	$tt .= "7月(".Sr::array_sum_key($this->srModel['list'],"m7").")&nbsp;";
	 	$tt .= "8月(".Sr::array_sum_key($this->srModel['list'],"m8").")&nbsp;";
	 	
	 	$tt .= "9月(".Sr::array_sum_key($this->srModel['list'],"m9").")&nbsp;";
	 	$tt .= "10月(".Sr::array_sum_key($this->srModel['list'],"m10").")&nbsp;";
	 	$tt .= "11月(".Sr::array_sum_key($this->srModel['list'],"m11").")&nbsp;";
	 	$tt .= "12月(".Sr::array_sum_key($this->srModel['list'],"m12").")&nbsp;";
  	
	 
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee_assign.occupy_month_info','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'occupy_month_info',
			'control_value'=>"",
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'','control_viewauth'=>'',
			'value_input'=>$tt,
			'INFO'=>"",
		));	
		
		$this->addItems($items);	

 

		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_info'=>'{has_e_label_checkeck:0}',
			'grid_param'=>array(		
//					'pmt_employee_assign.employee_id'=>array(
//					'control_type'=>'SELECT_SQL','control_name'=>'employee_id[]',
//					'control_value'=>$this->tv_employee_id,
//					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//					'value_input'=>'employee_id',
//					'INFO'=>"TYPE=open&URL=__APP__/Employee/viewEmployeePage?id=[employee_id]",
//					'div_label'=>'',
//				),			
					'pmt_employee_assign.project_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'project_id',
					'control_value'=>$this->tv_project_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'project_id',
					'INFO'=>"TYPE=open&URL=__APP__/Project/viewProjectPage%3Fid=[project_id]",
					'div_label'=>'',
				),
					'pmt_employee_assign.project_joblevel_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'project_joblevel_id',
					'control_value'=>$this->tv_project_joblevel_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'project_joblevel_id',
					'INFO'=>"",
					'div_label'=>'',
				),								
					'pmt_employee_assign.joblevel_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'joblevel_id',
					'control_value'=>$this->tv_joblevel_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'joblevel_id',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.company_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'company_id',
					'control_value'=>$this->tv_company_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'company_id',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.year'=>array(
					'control_type'=>'TEXT','control_name'=>'year',
					'control_value'=>$this->tv_year,
					'control_class'=>"validate-numbe max-value-3000",'control_param'=>"  size='4'  maxlength='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'year',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m1'=>array(
					'control_type'=>'TEXT','control_name'=>'m1',
					'control_value'=>$this->tv_m1,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m1',
					'value_input_b_label'=>'',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m2'=>array(
					'control_type'=>'TEXT','control_name'=>'m2',
					'control_value'=>$this->tv_m2,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m2',
					'value_input_b_label'=>'',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m3'=>array(
					'control_type'=>'TEXT','control_name'=>'m3',
					'control_value'=>$this->tv_m3,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m3',
					'value_input_b_label'=>'',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m4'=>array(
					'control_type'=>'TEXT','control_name'=>'m4',
					'control_value'=>$this->tv_m4,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m4',
					'value_input_b_label'=>'',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m5'=>array(
					'control_type'=>'TEXT','control_name'=>'m5',
					'control_value'=>$this->tv_m5,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m5',
					'value_input_b_label'=>'',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m6'=>array(
					'control_type'=>'TEXT','control_name'=>'m6',
					'control_value'=>$this->tv_m6,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m6',
					'value_input_b_label'=>'',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m7'=>array(
					'control_type'=>'TEXT','control_name'=>'m7',
					'control_value'=>$this->tv_m7,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m7',
					'value_input_b_label'=>'',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m8'=>array(
					'control_type'=>'TEXT','control_name'=>'m8',
					'control_value'=>$this->tv_m8,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m8',
					'value_input_b_label'=>'',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m9'=>array(
					'control_type'=>'TEXT','control_name'=>'m9',
					'control_value'=>$this->tv_m9,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m9',
					'value_input_b_label'=>'',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m10'=>array(
					'control_type'=>'TEXT','control_name'=>'m10',
					'control_value'=>$this->tv_m10,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m10',
					'value_input_b_label'=>'',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m11'=>array(
					'control_type'=>'TEXT','control_name'=>'m11',
					'control_value'=>$this->tv_m11,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m11',
					'value_input_b_label'=>'',
					'INFO'=>"",
					'div_label'=>'',
				),			
					'pmt_employee_assign.m12'=>array(
					'control_type'=>'TEXT','control_name'=>'m12',
					'control_value'=>$this->tv_m12,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  style='width:26px;' maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'m12',
					'value_input_b_label'=>'',
					'INFO'=>"",
					'div_label'=>'',
				),			
	
//				'operate'=>$buttons,
			),			
		));
		

		

		self::addInfoResults($srModel,null);
		return $srModel;
	}		
}
?>
