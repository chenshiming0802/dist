<?php
class AppTaskFavoriteView extends SrView{
public function indexTaskList($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);
		if($this->srModel['list']!=null){
			foreach($this->srModel['list'] as $k=>&$vo){
				$vo['content'] = strip_tags($vo['content']);

				$vo['operate'] = "<a href='#' name='bread_unread'>未读</a><a href='#' name='bread_read'>已读</a>
					<BR>
					<a href='#' name='bread_unprocess'>未处理</a><span name='bread_process'>处理中</span>
					<BR>";

				$tt = '';
				if($vo['constraint_type']!=null){
					$tt .= '<div class="item_constraint_time">'.SrDict::getValueName('PMT08',$vo['constraint_type']).':'.$vo['constraint_time'].'</div>';
				}
				//dump($vo['task_id'].'/'.$vo['star']);
				if($vo['module_follow_id']!=null && $vo['module_follow_id']!=''){

					$tt3 = Sr::sys_dictTableById('pmt_module_type_follow',$vo['module_follow_id'],'name');
					$tt2 = Sr::sys_dictTableById('pmt_task',$vo['follow_task_id'],'name');
					$tt2 = "&nbsp;<a target='_blank' href='".Sr::sys_sl(__APP__."/Task/viewTaskPage?id=".$vo['follow_task_id'])."'>".$tt2."</a>";
					$tt .= '<div class="item_constraint_time">需'.$tt3.$tt2."</div>";
				}


				$vo['content2'] = "<div class='item_group'>".Sr::sys_dictTableById('pmt_module',$vo['module_id'],'name')."</div>
					<div class='item_line'>".$vo['name']."</div>{$tt}
					<div class='item_desc'>".substr($vo['content'],0,400)."</div>";

				$vo['end_date'] = $vo['adv_end_date'];
				$manager = SrUup::getUserById($vo['manager_id']);
				$vo['enddate'] = "<b><a target='_blank' href='".Sr::sys_sl(__APP__."/Task/viewTaskPage?id=".$vo['id'])."'>".$vo['code']."</a></b><BR>
						<b>".$manager['name']."</b><BR>
					".$vo['adv_end_date']."<BR>预计：".$vo['adv_progress']."<BR>
					".SrViewPageHtml::pareseItemValue2(array('control_type'=>'STAR','control_name'=>'ss[]','value_input'=>$vo['star'],'control_readonly'=>'1'),array(0),'0');		//.$vo['emerg_weight']

			}
		}


		if($this->spModel['SPR_GRID_GROUP_KEY']=='tasklist.end_date'){
			$this->srModel['list'] = Sr::sys_array2sort($this->srModel['list'],'emerg_weight',SORT_ASC);//
			$this->srModel['list'] = Sr::sys_array2sort($this->srModel['list'],'end_date',SORT_ASC);//
		}
		if($this->spModel['SPR_GRID_GROUP_KEY']=='pmt_task.constraint_time'){
			$this->srModel['list'] = Sr::sys_array2sort($this->srModel['list'],'emerg_weight',SORT_ASC);//
			$this->srModel['list'] = Sr::sys_array2sort($this->srModel['list'],'constraint_time',SORT_ASC);//
		}

		$this->addGrid(array(
			'div_id'=>'div_results_user','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			"grid_info"=>"{has_tr_data:1,has_group_select:1,group_select_option:pmt_module.name/tasklist.end_date/pmt_task.constraint_time}",
			'grid_param'=>array(
				'tasklist.operate'=>array(
					'control_type'=>'LABEL','control_name'=>'',
					'control_value'=>'',
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
					'value_input'=>'operate',
					'div_label'=>'',
				),
				'tasklist.content'=>array(
					'control_type'=>'LABEL','control_name'=>'',
					'control_value'=>'',
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
					'value_input'=>'content2',
					'div_label'=>'',
				),
				'tasklist.enddate'=>array(
					'control_type'=>'LABEL','control_name'=>'',
					'control_value'=>'',
					'control_class'=>"",'control_param'=>"    ",'control_readonly'=>'','control_viewauth'=>'',
					'value_input'=>'enddate',
					'div_label'=>'',
				),
				'pmt_module.name'=>array(
					'control_type'=>'LABEL','control_name'=>'',
					'control_value'=>'',
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
					'value_input'=>'module_name',
					'div_label'=>'',
				),
				'tasklist.end_date'=>array(
					'control_type'=>'LABEL','control_name'=>'',
					'control_value'=>'',
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
					'value_input'=>'end_date',
					'div_label'=>'',
				),
				'pmt_task.constraint_time'=>array(
					'control_type'=>'LABEL','control_name'=>'',
					'control_value'=>'',
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'','control_viewauth'=>'',
					'value_input'=>'constraint_time',
					'div_label'=>'',
				),
			),
		));




		self::addInfoResults($srModel,null);
		return $srModel;
	}
}
?>
