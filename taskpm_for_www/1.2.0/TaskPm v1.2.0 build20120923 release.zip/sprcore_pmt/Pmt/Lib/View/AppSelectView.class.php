<?php

class AppSelectView extends SrView{
	private $tv_project_id;
	private $tv_module_id;
	private $tv_parent_task_id;
	private $tv_proirity;
	private $tv_module_type_task_id;
	private $tv_manager_id;
	private $tv_array_task_member;
	private $tv_constraint_type;
	private $tv_ticket_type;
	private $tv_status;
	private $tv_type_ms_id;
	private $tv_work_calc_type;
	private $tv_module_follow_id;
	private $tv_user_id;
	private $tv_joblevel_id;
	private $tv_depart_id;
	private $tv_company_id;
	private $tv_employee_status;

	public function __construct(){
		$this->tv_project_id = "1;;;pmt_project;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_project t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";
		$this->tv_module_id = "1;;;pmt_module;name;SELECT t.id _valueCode_,t.name _valueName_,t.project_id _parentCode_ FROM pmt_module t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId().";project_id";
		$this->tv_parent_task_id = "1;;;pmt_task;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_task t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";
		$this->tv_proirity = "1;;PMT06";
		$this->tv_module_type_task_id = "1;;;pmt_module_type_task;name;SELECT t3.id  _valueCode_,t3.name  _valueName_,t1.id _parentObjectCode_ FROM pmt_module t1,pmt_module_type t2,pmt_module_type_task t3 WHERE t1.is_deleted = '0' AND t2.is_deleted = '0' AND t3.is_deleted='0' AND t1.module_type_id=t2.id  AND t2.id=t3.type_id order by t3.no asc;module_id";
		$this->tv_manager_id = "1;;;uup_user;name;SELECT t.id _valueCode_,t.name _valueName_ FROM uup_user t WHERE is_deleted='0' and org_id=".SrUser::getOrgId()."";
		$this->tv_array_task_member = "1;;;uup_user;name;SELECT t.id _valueCode_,t.name _valueName_ FROM uup_user t WHERE is_deleted='0' and org_id=".SrUser::getOrgId()." ";
		$this->tv_constraint_type = "1;;PMT08";
		$this->tv_ticket_type = "1;;PMT02";
		$this->tv_status = "1;;PMT04";
		$this->tv_type_ms_id = "1;;;pmt_module_type_ms;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_module_type_ms t WHERE is_deleted='0'";
		$this->tv_work_calc_type = "1;;PMT12";
		$this->tv_user_id = "1;;;uup_user;name;SELECT t.id _valueCode_,t.name _valueName_ FROM uup_user t WHERE is_deleted='0' and org_id=".SrUser::getOrgId()."";
		$this->tv_joblevel_id = "1;;;pmt_joblevel;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_joblevel t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";
		$this->tv_depart_id = "1;;;pmt_depart;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_depart t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";
		$this->tv_company_id = "1;;;pmt_company;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_company t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()." ";
		$this->tv_employee_status = "1;;PMT14";

	}
	public function queryUnFollowTask($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__."title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_task_tsheet.project_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_project_id'],
			'INFO'=>"TYPE=open&URL=__APP__/Project/viewProjectPage%3Fid=[project_id]",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_task_tsheet.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'query_status',
			'control_value'=>$this->tv_status,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_status'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_task.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_code',
			'control_value'=>$this->tv_code,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_code'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_task.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_name',
			'control_value'=>$this->tv_name,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_name'],
			'INFO'=>"",
		));

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'confirm',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.confirm',
			);
		$this->addItems($items);



 		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param_hidden'=>array(),
			'grid_param'=>array(
				"label.select"=>array(
					'control_type'=>$this->spModel['isMulti']=='0'?'RADIO':'CHECKBOX','control_name'=>'id[]',
					'control_value'=>'[id]',
					'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'',
				),
				'pmt_module.name'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'code',
					'control_value'=>$this->tv_module_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'module_id',
					'INFO'=>"TYPE=open&URL=__APP__/Module/viewModulePage?id=[module_id]",
					'div_label'=>'',
				),
				'pmt_task.code'=>array(
					'control_type'=>'LABEL','control_name'=>'code',
					'control_value'=>$this->tv_code,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'code',
					'INFO'=>"TYPE=open&URL=__APP__/Task/viewTaskPage?id=[id]",
					'div_label'=>'',
				),
					'pmt_task.name'=>array(
					'control_type'=>'TEXT','control_name'=>'name',
					'control_value'=>$this->tv_name,
					'control_class'=>"required",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'name',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.manager_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'manager_id',
					'control_value'=>$this->tv_manager_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'manager_id',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.status'=>array(
					'control_type'=>'LABEL_DICT','control_name'=>'status',
					'control_value'=>$this->tv_status,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'status',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.adv_begin_date'=>array(
					'control_type'=>'INPUT_DATE','control_name'=>'adv_begin_date',
					'control_value'=>$this->tv_adv_end_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_begin_date',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task.adv_end_date'=>array(
					'control_type'=>'TEXT','control_name'=>'adv_end_date',
					'control_value'=>$this->tv_adv_person_day,
					'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_end_date',
					'INFO'=>"",
					'div_label'=>'',
				),
				'pmt_task.adv_person_day'=>array(
					'control_type'=>'TEXT','control_name'=>'adv_person_day',
					'control_value'=>$this->tv_adv_person_day,
					'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_person_day',
					'INFO'=>"",
					'div_label'=>'',
				),
			),
			'grid_label_param'=>$this->spModel['isMulti']=='0'?null:array(
				"label.select"=>array(
					'control_type'=>'CHECKBOX','control_name'=>'ids',
					'control_value'=>'',
					'control_class'=>'','control_param'=>"onClick=\"a_checkAll(this,'id[]')\"",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'',
				),
			),
		));


		self::addInfoResults($srModel,null);
		return $srModel;
	}

	public function queryEmployeeAssignInfo($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__."title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee.emp_no','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_emp_no',
			'control_value'=>$this->tv_emp_no,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_emp_no'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_name',
			'control_value'=>$this->tv_name,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_name'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee.joblevel_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_joblevel_id',
			'control_value'=>$this->tv_joblevel_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_joblevel_id'],
			'INFO'=>"",
		));
		/*
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee.company_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_company_id',
			'control_value'=>$this->tv_company_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_company_id'],
			'INFO'=>"",
		));
		*/
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'query_status',
			'control_value'=>$this->tv_employee_status,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_status'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'label.month','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'CHECKBOX_DICT','control_name'=>'query_month[]',
			'control_value'=>"1;;SYS11",
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_month'],
			'INFO'=>"",
		));


		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'confirm',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.confirm',
			);
		$this->addItems($items);

 		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param_hidden'=>array(),
			'grid_param'=>array(
				"label.select"=>array(
					'control_type'=>$this->spModel['isMulti']=='0'?'RADIO':'CHECKBOX','control_name'=>'id[]',
					'control_value'=>'[employee_id]',
					'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'',
				),
					'pmt_employee.emp_no'=>array(
					'control_type'=>'TEXT','control_name'=>'emp_no',
					'control_value'=>$this->tv_emp_no,
					'control_class'=>"required max-length-20",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'emp_no',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee.name'=>array(
					'control_type'=>'TEXT','control_name'=>'name',
					'control_value'=>$this->tv_name,
					'control_class'=>"required  max-length-20",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'name',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee.joblevel_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'joblevel_id',
					'control_value'=>$this->tv_joblevel_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'joblevel_id',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee.company_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'company_id',
					'control_value'=>$this->tv_company_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'company_id',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee_assign.m1'=>array(
					'control_type'=>'TEXT','control_name'=>'m1',
					'value_input_e_label'=>$this->tv_m1,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input_e_label'=>'m1',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee_assign.m2'=>array(
					'control_type'=>'TEXT','control_name'=>'m2',
					'control_value'=>$this->tv_m2,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input_e_label'=>'m2',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee_assign.m3'=>array(
					'control_type'=>'TEXT','control_name'=>'m3',
					'control_value'=>$this->tv_m3,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input_e_label'=>'m3',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee_assign.m4'=>array(
					'control_type'=>'TEXT','control_name'=>'m4',
					'control_value'=>$this->tv_m4,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input_e_label'=>'m4',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee_assign.m5'=>array(
					'control_type'=>'TEXT','control_name'=>'m5',
					'control_value'=>$this->tv_m5,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input_e_label'=>'m5',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee_assign.m6'=>array(
					'control_type'=>'TEXT','control_name'=>'m6',
					'control_value'=>$this->tv_m6,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input_e_label'=>'m6',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee_assign.m7'=>array(
					'control_type'=>'TEXT','control_name'=>'m7',
					'control_value'=>$this->tv_m7,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input_e_label'=>'m7',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee_assign.m8'=>array(
					'control_type'=>'TEXT','control_name'=>'m8',
					'control_value'=>$this->tv_m8,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input_e_label'=>'m8',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee_assign.m9'=>array(
					'control_type'=>'TEXT','control_name'=>'m9',
					'control_value'=>$this->tv_m9,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input_e_label'=>'m9',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee_assign.m10'=>array(
					'control_type'=>'TEXT','control_name'=>'m10',
					'control_value'=>$this->tv_m10,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input_e_label'=>'m10',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee_assign.m11'=>array(
					'control_type'=>'TEXT','control_name'=>'m11',
					'control_value'=>$this->tv_m11,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input_e_label'=>'m11',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee_assign.m12'=>array(
					'control_type'=>'TEXT','control_name'=>'m12',
					'control_value'=>$this->tv_m12,
					'control_class'=>"validate-numbe max-value-100",'control_param'=>"  size='3'  maxlength='3'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input_e_label'=>'m12',
					'INFO'=>"",
					'div_label'=>'',
				),
			),
			'grid_label_param'=>$this->spModel['isMulti']=='0'?null:array(
				"label.select"=>array(
					'control_type'=>'CHECKBOX','control_name'=>'ids',
					'control_value'=>'',
					'control_class'=>'','control_param'=>"onClick=\"a_checkAll(this,'id[]')\"",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'',
				),
			),
		));


		self::addInfoResults($srModel,null);
		return $srModel;
	}


	public function queryUupUser($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__."title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'uup_user.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_code',
			'control_value'=>$this->tv_emp_no,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_code'],
			'INFO'=>"",
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'uup_user.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_name',
			'control_value'=>$this->tv_emp_no,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_name'],
			'INFO'=>"",
		));


		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'confirm',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.confirm',
			);
		$this->addItems($items);

 		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param_hidden'=>array(),
			'grid_param'=>array(
				"label.select"=>array(
					'control_type'=>$this->spModel['isMulti']=='0'?'RADIO':'CHECKBOX','control_name'=>'id[]',
					'control_value'=>'[id]',
					'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'',
				),
					'uup_user.code'=>array(
					'control_type'=>'TEXT','control_name'=>'emp_no',
					'control_value'=>$this->tv_emp_no,
					'control_class'=>"required max-length-20",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'code',
					'INFO'=>"",
					'div_label'=>'',
				),
					'uup_user.name'=>array(
					'control_type'=>'TEXT','control_name'=>'name',
					'control_value'=>$this->tv_name,
					'control_class'=>"required  max-length-20",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'name',
					'INFO'=>"",
					'div_label'=>'',
				),
			),
			'grid_label_param'=>$this->spModel['isMulti']=='0'?null:array(
				"label.select"=>array(
					'control_type'=>'CHECKBOX','control_name'=>'ids',
					'control_value'=>'',
					'control_class'=>'','control_param'=>"onClick=\"a_checkAll(this,'id[]')\"",'control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'',
				),
			),
		));


		self::addInfoResults($srModel,null);
		return $srModel;
	}
}
?>