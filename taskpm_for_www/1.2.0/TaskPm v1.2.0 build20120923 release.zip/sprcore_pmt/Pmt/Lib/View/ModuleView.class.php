<?php

class ModuleView extends SrView{
	private $tv_project_id;
	private $tv_module_type_id;
	private $tv_status;
	private $tv_proirity;
	private $tv_manager_id;
//	private $tv_depend_module_id;

	public function __construct(){
		$this->tv_project_id = "1;;;pmt_project;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_project t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";
		$this->tv_module_type_id = "1;;;pmt_module_type;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_module_type t WHERE is_deleted='0' ";
		$this->tv_status = "1;;PMT03";
		$this->tv_proirity = "1;;PMT06";
		$this->tv_manager_id = "1;;;uup_user;name;SELECT distinct t.id _valueCode_,t.name _valueName_ FROM uup_user t,pmt_project_member t2 WHERE t2.user_id=t.id and org_id=".SrUser::getOrgId()." /*w[t,t2]*/";
//		$this->tv_depend_module_id = "1;;;pmt_module;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_module t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";

	}

public function queryModule($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.module_type_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_module_type_id',
			'control_value'=>$this->tv_module_type_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_module_type_id'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_code',
			'control_value'=>$this->tv_code,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_code'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'query_status',
			'control_value'=>$this->tv_status,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_status'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_name',
			'control_value'=>$this->tv_name,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_name'],
			'INFO'=>"",
		));

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);

		if(PmtTools::canAddModule($this->spModel['query_project_id'])=='1'){
			$items["items_line"][] = array(
					'control_type'=>'BUTTON','control_name'=>'insert',
					'control_value'=>__URL__."/editModulePage",
					'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'page.button.insert',
				);
		}


		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'cycle',
				'control_value'=>__URL__."/managerModulePage",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.cycle',
			);


		$this->addItems($items);

		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'view',
				'control_value'=>__URL__."/viewModulePage?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.view',
			);

		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
				/*
				'pmt_module.module_type_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'module_type_id',
					'control_value'=>$this->tv_module_type_id,
					'control_class'=>"required",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'module_type_id',
					'INFO'=>"",
					'div_label'=>'',
				),
				*/
					'pmt_module.code'=>array(
					'control_type'=>'LABEL_PHP','control_name'=>'code',
					'control_value'=>$this->tv_code,
					'control_class'=>"",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'code',
					'INFO'=>"TYPE=open&URL=__APP__/Module/viewModulePage?id=[id]",
					'div_label'=>'',
				),
					'pmt_module.status'=>array(
					'control_type'=>'LABEL_DICT','control_name'=>'status',
					'control_value'=>$this->tv_status,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'status',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_module.name'=>array(
					'control_type'=>'TEXT','control_name'=>'name',
					'control_value'=>$this->tv_name,
					'control_class'=>"required",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'name',
					'INFO'=>"",
					'div_label'=>'',
				),
				/*
					'pmt_module.proirity'=>array(
					'control_type'=>'SELECT_DICT','control_name'=>'proirity',
					'control_value'=>$this->tv_proirity,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'proirity',
					'INFO'=>"",
					'div_label'=>'',
				),
				*/
					'pmt_module.manager_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'manager_id',
					'control_value'=>$this->tv_manager_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'manager_id',
					'INFO'=>"TYPE=open&URL=__APP__/Employee/viewEmployeePage?user_id=[manager_id]",
					'div_label'=>'',
				),
					'pmt_module.adv_begin_date'=>array(
					'control_type'=>'TEXT','control_name'=>'adv_begin_date',
					'control_value'=>$this->tv_adv_begin_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_begin_date',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_module.adv_end_date'=>array(
					'control_type'=>'TEXT','control_name'=>'adv_end_date',
					'control_value'=>$this->tv_adv_end_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_end_date',
					'INFO'=>"",
					'div_label'=>'',
				),
//					'pmt_module.depend_module_id'=>array(
//					'control_type'=>'SELECT_SQL','control_name'=>'depend_module_id',
//					'control_value'=>$this->tv_depend_module_id,
//					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//					'value_input'=>'depend_module_id',
//					'INFO'=>"",
//					'div_label'=>'',
//				),
					'pmt_module.adv_person_day'=>array(
					'control_type'=>'LABEL','control_name'=>'adv_person_day',
					'control_value'=>$this->tv_adv_person_day,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_person_day',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_module.adv_progress'=>array(
					'control_type'=>'LABEL','control_name'=>'adv_progress',
					'control_value'=>$this->tv_adv_progress,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_progress',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_module.tsh_progress'=>array(
					'control_type'=>'LABEL','control_name'=>'tsh_progress',
					'control_value'=>$this->tv_tsh_progress,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'tsh_progress',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_module.act_progress'=>array(
					'control_type'=>'LABEL','control_name'=>'act_progress',
					'control_value'=>$this->tv_act_progress,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'act_progress',
					'INFO'=>"",
					'div_label'=>'',
				),

				'operate'=>$buttons,
			),
		));




		self::addInfoResults($srModel,null);
		return $srModel;
	}




public function editModulePage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/editModule",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));

			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.project_id','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL_SQL','control_name'=>'project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["project_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_PHP','control_name'=>'code',
			'control_value'=>$this->tv_code,
			'control_class'=>" ",'control_param'=>"  size='20'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_DICT','control_name'=>'status',
			'control_value'=>$this->tv_status,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["status"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.module_type_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'module_type_id',
			'control_value'=>$this->tv_module_type_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["module_type_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.name','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>"required ",'control_param'=>"  size='100'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.proirity','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'proirity',
			'control_value'=>$this->tv_proirity,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["proirity"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.manager_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'manager_id',
			'control_value'=>$this->tv_manager_id." and t2.project_id=".$this->srModel["project_id"],
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["manager_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.url','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'url',
			'control_value'=>$this->tv_url,
			'control_class'=>" ",'control_param'=>"  size='100'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["url"],
		));
//			$this->addItem(array(
//			'div_id'=>'div_search_v','div_label'=>'pmt_module.depend_module_id','item_line_type'=>'','item_viewauth'=>'',
//			'control_type'=>'SELECT_SQL','control_name'=>'depend_module_id',
//			'control_value'=>$this->tv_depend_module_id,
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
//			'value_input'=>$this->srModel["depend_module_id"],
//		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.content','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'RICKEDIT','control_name'=>'content',
			'control_value'=>$this->tv_content,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["content"],
		));



		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$status = $this->srModel['status'];
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'save',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>($status==null||$status=='010')?'0':'1',
				'value_input'=>'page.button.save',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'submitb',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>($status==null||$status=='010')?'0':'1',
				'value_input'=>'page.button.submit',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>($status==null||$status=='010')?'1':'0',
				'value_input'=>'page.button.update',
			);
					$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);


if($id==null || $id==''){


}else{


}


		self::addInfoResults($srModel,null);
		return $srModel;
	}
	public function viewModulePage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewModulePage",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.project_id','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL_SQL','control_name'=>'project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["project_id"],
			'INFO'=>"TYPE=open&URL=__APP__/Project/viewProjectPage%3Fid=[project_id] ",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.code','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_PHP','control_name'=>'code',
			'control_value'=>$this->tv_code,
			'control_class'=>" ",'control_param'=>"  size='20'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["code"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_DICT','control_name'=>'status',
			'control_value'=>$this->tv_status,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["status"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.module_type_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'module_type_id',
			'control_value'=>$this->tv_module_type_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["module_type_id"],
			'INFO'=>"",
		));

			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.name','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>"required ",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.proirity','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'proirity',
			'control_value'=>$this->tv_proirity,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["proirity"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.manager_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'manager_id',
			'control_value'=>$this->tv_manager_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["manager_id"],
			'INFO'=>"TYPE=open&URL=__APP__/Employee/viewEmployeePage?user_id=".$this->srModel["manager_id"]."",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.url','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'url',
			'control_value'=>$this->tv_url,
			'control_class'=>" ",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["url"],
			'INFO'=>"",
		));
//			$this->addItem(array(
//			'div_id'=>'div_search_v','div_label'=>'pmt_module.depend_module_id','item_line_type'=>'','item_viewauth'=>'',
//			'control_type'=>'SELECT_SQL','control_name'=>'depend_module_id',
//			'control_value'=>$this->tv_depend_module_id,
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//			'value_input'=>$this->srModel["depend_module_id"],
//			'INFO'=>"",
//		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.content','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'RICKEDIT','control_name'=>'content',
			'control_value'=>$this->tv_content,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["content"],
			'INFO'=>"",
		));


//
//		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
//		$srModel_sflow = SrSflow::page_displayButton(array(
//			"sflow_is_add_form"=>"0",
//			"sflow_current_form"=>"ff",
//			"sflow_code"=>"pmt_module",
//			"sflow_business_id"=>$this->srModel["id"],
//			"sflow_business_num"=>$this->srModel["code"],
//			"sflow_from_status"=>$this->srModel["status"],
//			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
//			"sflow_return_url"=>__SELF__,
//			"sflow_request_params"=>array(
//			"id"=>$spModel["id"],
//			"pageType"=>$spModel["pageType"],
//			),
//		));
//		$this->hidden_html = $srModel_sflow["divHtml"];
//		$items["items_line"] = $srModel_sflow["buttonArrays"];
///*
//		$items["items_line"][] =array(
//				'control_type'=>'BUTTON','control_name'=>'update',
//				'control_value'=>__URL__."/editModulePage?id={$id}",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.update',
//			);
//
//		$items["items_line"][] =array(
//				'control_type'=>'BUTTON','control_name'=>'delete',
//				'control_value'=>__URL__."/deleteTask?id={$id}",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.delete',
//			);
//
//Sflow(flow_name,button_name,page_submit_type,page_submit_js):
//修改模块	page.button.update	030	__APP__/Module/editModulePage?id={1}
//新增子模块	page.button.addchild	030	__APP__/Module/editModulePage?={1}
//删除模块	page.button.delete	030	__APP__/Module/deleteModule?id={1}
//*/
//
//		$items["items_line"][] = array(
//				'control_type'=>'BUTTON','control_name'=>'close',
//				'control_value'=>"",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.close',
//			);
//		$this->addItems($items);




		self::addInfoResults($srModel,null);
		return $srModel;
	}
}

?>