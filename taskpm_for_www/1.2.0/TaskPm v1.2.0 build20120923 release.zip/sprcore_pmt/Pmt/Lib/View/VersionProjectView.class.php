<?php

class VersionProjectView extends SrView{
	private $tv_project_id;
	private $tv_belong_user_id;

	public function __construct(){
		$this->tv_project_id = "1;;;pmt_project;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_project t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";
		$this->tv_belong_user_id = "1;;;uup_user;name;SELECT t.id _valueCode_,t.name _valueName_ FROM uup_user t WHERE is_deleted='0'";

	}

public function queryVersionProject($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_version_project.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_name',
			'control_value'=>$this->tv_name,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_name'],
		));

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		if(PmtTools::canAddModule($this->spModel['query_project_id'])=='1'){
			$items["items_line"][] = array(
					'control_type'=>'BUTTON','control_name'=>'insert',
					'control_value'=>__URL__."/editVersionProjectPage",
					'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
					'value_input'=>'page.button.insert',
				);
		}


		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'compareModule',
				'control_value'=>__URL__."/managerVersionProjectPage",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.compareModule',
			);

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'compareTask',
				'control_value'=>__URL__."/managerVersionProjectPage",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.compareTask',
			);


		$this->addItems($items);

		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'view',
				'control_value'=>__URL__."/viewVersionProjectPage?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.view',
			);

		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
				'pmt_version_project.name'=>array(
					'control_type'=>'TEXT','control_name'=>'name',
					'control_value'=>$this->tv_name,
					'control_class'=>"required",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'name',
					'div_label'=>'',
				),
					'pmt_version_project.create_time'=>array(
					'control_type'=>'LABEL','control_name'=>'create_time',
					'control_value'=>$this->tv_create_time,
					'control_class'=>"required",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'create_time',
					'div_label'=>'',
				),
					'pmt_version_project.belong_user_id'=>array(
					'control_type'=>'LABEL_SQL','control_name'=>'belong_user_id',
					'control_value'=>$this->tv_belong_user_id,
					'control_class'=>"required",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'belong_user_id',
					'div_label'=>'',
				),

				'operate'=>$buttons,
			),
		));




		self::addInfoResults($srModel,null);
		return $srModel;
	}


public function editVersionProjectBasePage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/editVersionProjectBase",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>'',
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.project_id','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["project_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.name','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>"required ",'control_param'=>"  size='100'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.memo','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'memo',
			'control_value'=>$this->tv_memo,
			'control_class'=>" ",'control_param'=>"ROWS=10 COLS=100  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["memo"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.create_time','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'create_time',
			'control_value'=>$this->tv_create_time,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["create_time"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.belong_user_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_SQL','control_name'=>'belong_user_id',
			'control_value'=>$this->tv_belong_user_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["belong_user_id"],
		));



		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
					$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);


if($id==null || $id==''){


}else{


}


		self::addInfoResults($srModel,null);
		return $srModel;
	}
	public function viewVersionProjectPageBase($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewVersionProjectPage",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.project_id','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL_SQL','control_name'=>'project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["project_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.name','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>"required ",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.memo','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'memo',
			'control_value'=>$this->tv_memo,
			'control_class'=>" ",'control_param'=>"ROWS=10 COLS=100  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["memo"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.create_time','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'create_time',
			'control_value'=>$this->tv_create_time,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["create_time"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.belong_user_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_SQL','control_name'=>'belong_user_id',
			'control_value'=>$this->tv_belong_user_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["belong_user_id"],
		));






		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);




		self::addInfoResults($srModel,null);
		return $srModel;
	}


public function editVersionProjectPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/editVersionProject",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.project_id','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["project_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.name','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>"required ",'control_param'=>"  size='100'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.memo','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'memo',
			'control_value'=>$this->tv_memo,
			'control_class'=>" ",'control_param'=>"ROWS=10 COLS=100  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["memo"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.create_time','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'create_time',
			'control_value'=>$this->tv_create_time,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["create_time"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.belong_user_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_SQL','control_name'=>'belong_user_id',
			'control_value'=>$this->tv_belong_user_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["belong_user_id"],
		));



		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
					$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);


if($id==null || $id==''){


}else{


}


		self::addInfoResults($srModel,null);
		return $srModel;
	}
	public function viewVersionProjectPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewVersionProjectPage",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.project_id','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL_SQL','control_name'=>'project_id',
			'control_value'=>$this->tv_project_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["project_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.name','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>"required ",'control_param'=>"  size='100'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.memo','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'memo',
			'control_value'=>$this->tv_memo,
			'control_class'=>" ",'control_param'=>"ROWS=10 COLS=100  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["memo"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.create_time','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'create_time',
			'control_value'=>$this->tv_create_time,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["create_time"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_version_project.belong_user_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_SQL','control_name'=>'belong_user_id',
			'control_value'=>$this->tv_belong_user_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["belong_user_id"],
		));



		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$srModel_sflow = SrSflow::page_displayButton(array(
			"sflow_is_add_form"=>"0",
			"sflow_current_form"=>"ff",
			"sflow_code"=>"pmt_version_project",
			"sflow_business_id"=>$this->srModel["id"],
			"sflow_business_num"=>$this->srModel["code"],
			"sflow_from_status"=>$this->srModel[""],
			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
			"sflow_return_url"=>__SELF__,
			"sflow_request_params"=>array(
			"id"=>$spModel["id"],
			"pageType"=>$spModel["pageType"],
			),
		));
		$this->hidden_html = $srModel_sflow["divHtml"];
		$items["items_line"] = $srModel_sflow["buttonArrays"];
/*
		$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>__URL__."/editVersionProjectPage?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);

		$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'delete',
				'control_value'=>__URL__."/deleteTask?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.delete',
			);

Sflow(flow_name,button_name,page_submit_type,page_submit_js):
修改项目基线	page.button.update	030	__APP__/VersionProject/editVersionProjectPage?id={1}
新增子项目基线	page.button.addchild	030	__APP__/VersionProject/editVersionProjectPage?={1}
删除项目基线	page.button.delete	030	__APP__/VersionProject/deleteVersionProject?id={1}
*/
		$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>__URL__."/editVersionProjectBasePage?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);




		self::addInfoResults($srModel,null);
		return $srModel;
	}
}

?>