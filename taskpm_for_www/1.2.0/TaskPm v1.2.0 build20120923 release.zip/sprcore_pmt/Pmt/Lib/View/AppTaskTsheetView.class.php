<?php
class AppTaskTsheetView extends SrView{
	private $tv_project_id;
	private $tv_module_id;
	private $tv_task_id;
	private $tv_time_type;
	private $tv_status;
	private $tv_belong_user_id;

	public function __construct(){
		$this->tv_project_id = "1;;;pmt_project;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_project t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";
		$this->tv_module_id = "1;;;pmt_module;name;SELECT t.id _valueCode_,t.name _valueName_,t.project_id _parentObjectCode_ FROM pmt_module t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId().";project_id";
		$this->tv_task_id = "1;;;pmt_task;name;SELECT t.id _valueCode_,t.name _valueName_,t.id _childCode_,t.parent_task_id _parentCode_,t.id _childSortNo_,t.module_id _parentObjectCode_,(CASE WHEN t.spr_tree_type='020' OR t.work_calc_type='020'  THEN '0' ELSE '1' END)  _isOptGroup_ FROM pmt_task t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId().";module_id";
		$this->tv_time_type = "1;;PMT07";
		$this->tv_status = "1;;PMT09";
		$this->tv_belong_user_id = "1;;;uup_user;name;SELECT t.id _valueCode_,t.name _valueName_ FROM uup_user t WHERE is_deleted='0' and org_id=".SrUser::getOrgId()."";

	}

	public function queryUserShTimes($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/queryUserShTimes",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
		//GRID
		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['details'],'grid_page'=>$this->srModel['details_page'],
			'grid_param'=>array(
				"pmt_task_tsheet.belong_user_id"=>array(
						'control_type'=>'LABEL_SQL','control_name'=>'belong_user_id[]',
						'control_value'=>"1;;;uup_user;name",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'belong_user_id',
					),
				"pmt_task_tsheet.tsheet_occure_date"=>array(
						'control_type'=>'LABEL','control_name'=>'tsheet_occure_date[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsheet_occure_date',
					),
				"pmt_task_tsheet.tsheet_hours_020"=>array(
						'control_type'=>'LABEL','control_name'=>'tsheet_hours_020[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsheet_hours_020',
						'div_label'=>'pmt_task_tsheet.tsheet_hours_020',
					),
//				"pmt_task_tsheet.tsheet_hours_030"=>array(
//						'control_type'=>'LABEL','control_name'=>'tsheet_hours_030[]',
//						'control_value'=>"",
//						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//						'value_input'=>'tsheet_hours_030',
//						'div_label'=>'pmt_task_tsheet.tsheet_hours_030',
//					),
				"pmt_task_tsheet.tsheet_hours_100"=>array(
						'control_type'=>'LABEL','control_name'=>'tsheet_hours_100[]',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'tsheet_hours_100',
						'div_label'=>'pmt_task_tsheet.tsheet_hours_100',
					),
				),
		));


 		$this->gridConvertXToY('div_results','grid',array(
			'x_dims'=>array('belong_user_id[]'),
			'y_dim'=>'tsheet_occure_date[]',
			'y_dim_value'=>$this->srModel['timeDims'],
			'is_display'=>'1',
		));


		self::addInfoResults($srModel,null);
		return $srModel;	;
	}

	public function getSheetInfoFromProjectModuleTask($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewProject2MemberPage",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));

		//GRID
		$this->addGrid(array(
			'div_id'=>'div_search','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'grid_list'=>$this->srModel['details'],'grid_page'=>$this->srModel['details_page'],
			'grid_param'=>array(
				"uup_user.name"=>array(
						'control_type'=>'LABEL','control_name'=>'user_name',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'user_name',
					),
				"pmt_project.name"=>array(
						'control_type'=>'LABEL_SQL','control_name'=>'detail_id',
						'control_value'=>"1;;;pmt_project;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_project t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'project_id',
					),
				"pmt_module.name"=>array(
						'control_type'=>'LABEL_SQL','control_name'=>'detail_id',
						'control_value'=>"1;;;pmt_module;name;SELECT t.id _valueCode_,t.name _valueName_,t.project_id _parentCode_ FROM pmt_module t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId().";project_id",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'module_id',
					),
				"pmt_task.name"=>array(
						'control_type'=>'LABEL_SQL','control_name'=>'detail_id',
						'control_value'=>"1;;;pmt_task;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_task t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'task_id',
					),
//				"pmt_task_tsheet.time_type"=>array(
//						'control_type'=>'LABEL_DICT','control_name'=>'detail_id[]',
//						'control_value'=>"1;;PMT07",
//						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//						'value_input'=>'time_type',
//					),
				"pmt_task_tsheet.occure_date"=>array(
						'control_type'=>'LABEL','control_name'=>'detail_id',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'occure_date',
					),
				"pmt_task_tsheet.hours"=>array(
						'control_type'=>'LABEL','control_name'=>'detail_id',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'hours',
					),
				"pmt_task_tsheet.ext_hours"=>array(
						'control_type'=>'LABEL','control_name'=>'detail_id',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'ext_hours',
					),
				),
		));


		self::addInfoResults($srModel,null);
		return $srModel;
	}


	public function exportBaosightSheet($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/exportBaosightSheet",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'label.begin_time','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'begin_occure_day',
			'control_value'=>'',
			'control_class'=>"required",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['begin_occure_day'],
			'INFO'=>"",
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'label.end_time','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'end_occure_day',
			'control_value'=>'',
			'control_class'=>"required",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['end_occure_day'],
			'INFO'=>"",
		));
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$this->addItems($items);
		//GRID
		$this->addGrid(array(
			'div_id'=>'div_search','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['details_page'],
			'grid_param'=>array(
				"baosight.1"=>array(
						'control_type'=>'LABEL','control_name'=>'',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'baosight.1',
					),
				"baosight.2"=>array(
						'control_type'=>'LABEL','control_name'=>'',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'baosight.2',
					),
				"baosight.3"=>array(
						'control_type'=>'LABEL','control_name'=>'',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'baosight.3',
					),
				"baosight.4"=>array(
						'control_type'=>'LABEL','control_name'=>'',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'baosight.4',
					),
				"baosight.5"=>array(
						'control_type'=>'LABEL','control_name'=>'',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'baosight.5',
					),
				"baosight.6"=>array(
						'control_type'=>'LABEL','control_name'=>'',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'baosight.6',
					),
				"baosight.7"=>array(
						'control_type'=>'LABEL','control_name'=>'',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'baosight.7',
					),
				"baosight.8"=>array(
						'control_type'=>'LABEL','control_name'=>'',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'baosight.8',
					),
				"baosight.9"=>array(
						'control_type'=>'LABEL','control_name'=>'',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'baosight.9',
					),
				"baosight.10"=>array(
						'control_type'=>'LABEL','control_name'=>'',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'baosight.10',
					),
				"baosight.11"=>array(
						'control_type'=>'LABEL','control_name'=>'',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'baosight.11',
					),
				"baosight.12"=>array(
						'control_type'=>'LABEL','control_name'=>'',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'baosight.12',
					),
				"baosight.13"=>array(
						'control_type'=>'LABEL','control_name'=>'',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'baosight.13',
					),
				"baosight.14"=>array(
						'control_type'=>'LABEL','control_name'=>'',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'baosight.14',
					),
				"baosight.15"=>array(
						'control_type'=>'LABEL','control_name'=>'',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'baosight.15',
					),
				"baosight.16"=>array(
						'control_type'=>'LABEL','control_name'=>'',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'baosight.16',
					),
				"baosight.17"=>array(
						'control_type'=>'LABEL','control_name'=>'',
						'control_value'=>"",
						'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
						'value_input'=>'baosight.17',
					),



				),
		));


		self::addInfoResults($srModel,null);
		return $srModel;
	}

	public function fillQucikTsheetPage($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_task_tsheet.occure_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'query_occure_date',
			'control_value'=>$this->tv_occure_date,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_occure_date'],
			'INFO'=>"",
		));


		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'save',
				'control_value'=>__URL__."/fillQucikTsheet",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.save',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'submit2',
				'control_value'=>__URL__."/fillQucikTsheet",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.submit',
			);




		$this->addItems($items);

		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'delete',
				'control_value'=>__URL__."/deleteQucikTsheet?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'can_deleted',
				'value_input'=>'page.button.delete',
			);
		$list = &$this->srModel['list'];
		foreach($list as $k=>$item){
			if($item['status']=='010' ||$item['status']=='020' ||$item['status']=='030' || $item['status']==null){
				$list[$k]['readonly'] = '0';
				$list[$k]['can_deleted'] = '1';
			}else{
				$list[$k]['readonly'] = '1';
				$list[$k]['can_deleted'] = '0';
			}
		}


		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$list,'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
				'pmt_task_tsheet.id'=>array(
					'control_type'=>'HIDDEN','control_name'=>'id[]',
					'control_value'=>'',
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'id',
					'INFO'=>"TYPE=open&URL=__APP__/Project/viewProjectPage%3Fid=[project_id]",
					'div_label'=>'',
				),
				'pmt_task_tsheet.project_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'project_id[]',
					'control_value'=>$this->tv_project_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'project_id',
					'INFO'=>"TYPE=open&URL=__APP__/Project/viewProjectPage%3Fid=[project_id]",
					'div_label'=>'',
				),
					'pmt_task_tsheet.module_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'module_id[]',
					'control_value'=>$this->tv_module_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'module_id',
					'INFO'=>"TYPE=open&URL=__APP__/Module/viewModulePage?id=[module_id]",
					'div_label'=>'',
				),
					'pmt_task_tsheet.task_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'task_id[]',
					'control_value'=>$this->tv_task_id,
					'control_class'=>"required",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'task_id',
					'INFO'=>"TYPE=open&URL=__APP__/Task/viewTaskPage?id=[task_id]",
					'div_label'=>'',
				),
					'pmt_task_tsheet.occure_date'=>array(
					'control_type'=>'LABEL','control_name'=>'occure_date[]',
					'control_value'=>$this->tv_occure_date,
					'control_class'=>"required",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'occure_date',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task_tsheet.status'=>array(
					'control_type'=>'LABEL_DICT','control_name'=>'status[]',
					'control_value'=>$this->tv_status,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'status',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task_tsheet.hours'=>array(
					'control_type'=>'TEXT','control_name'=>'hours[]',
					'control_value'=>$this->tv_hours,
					'control_class'=>"required validate-number max-value-24",'control_param'=>"  size='4'  ",'control_readonly'=>'readonly','control_viewauth'=>'',
					'value_input'=>'hours',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_task_tsheet.ext_hours'=>array(
					'control_type'=>'TEXT','control_name'=>'ext_hours[]',
					'control_value'=>$this->tv_ext_hours,
					'control_class'=>"validate-number max-value-24",'control_param'=>"  size='4'  ",'control_readonly'=>'readonly','control_viewauth'=>'',
					'value_input'=>'ext_hours',
					'INFO'=>"",
					'div_label'=>'',
				),

//					'pmt_task_tsheet.belong_user_id'=>array(
//					'control_type'=>'LABEL_SQL','control_name'=>'belong_user_id',
//					'control_value'=>$this->tv_belong_user_id,
//					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//					'value_input'=>'belong_user_id',
//					'INFO'=>"",
//					'div_label'=>'',
//				),

				'operate'=>$buttons,
			),
		));




		self::addInfoResults($srModel,null);
		return $srModel;
	}
}
?>
