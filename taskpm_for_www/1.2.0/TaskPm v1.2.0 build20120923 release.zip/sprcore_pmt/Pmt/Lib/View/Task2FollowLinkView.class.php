<?php

class Task2FollowLinkView extends SrView{
	
}
 
?>