<?php

class PmtVersionView extends SrView{

	public function __construct(){
	
	}

public function queryPmtVersion($spModel){
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);
		
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'sys_version.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_name',
			'control_value'=>$this->tv_name,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_name'],
		));
	 
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(		
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'insert',
				'control_value'=>__URL__."/editPmtVersionPage",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.insert',
			);	



		$this->addItems($items);	

		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'view',
				'control_value'=>__URL__."/viewPmtVersionPage?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.view',
			);

		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
				'sys_version.name'=>array(
					'control_type'=>'TEXT','control_name'=>'name',
					'control_value'=>$this->tv_name,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'name',
					'div_label'=>'',
				),			
					'sys_version.create_time'=>array(
					'control_type'=>'LABEL','control_name'=>'create_time',
					'control_value'=>$this->tv_create_time,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'create_time',
					'div_label'=>'',
				),			
	
				'operate'=>$buttons,
			),			
		));
		

		

		self::addInfoResults($srModel,null);
		return $srModel;
	}




public function editPmtVersionPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/editPmtVersion",
			"target"=>"_self",
			"onSubmit"=>"",
		);	
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));		
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_version.table_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'table_id',
			'control_value'=>$this->tv_table_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_version.name','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_version.memo','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'memo',
			'control_value'=>$this->tv_memo,
			'control_class'=>" ",'control_param'=>"ROWS=10 COLS=100  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["memo"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_version.create_time','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'create_time',
			'control_value'=>$this->tv_create_time,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["create_time"],
		));
	 
 
		
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
					$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);										
		$this->addItems($items);				


if($id==null || $id==''){
		

}else{
		

}

		
		self::addInfoResults($srModel,null);
		return $srModel;		
	}
	public function viewPmtVersionPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewPmtVersionPage",
			"target"=>"_self",
			"onSubmit"=>"",
		);	
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));	
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_version.table_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'table_id',
			'control_value'=>$this->tv_table_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["table_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_version.name','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_version.memo','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'memo',
			'control_value'=>$this->tv_memo,
			'control_class'=>" ",'control_param'=>"ROWS=10 COLS=100  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["memo"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'sys_version.create_time','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'create_time',
			'control_value'=>$this->tv_create_time,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["create_time"],
		));
	
		

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$srModel_sflow = SrSflow::page_displayButton(array(
			"sflow_is_add_form"=>"0",
			"sflow_current_form"=>"ff",
			"sflow_code"=>"sys_version",
			"sflow_business_id"=>$this->srModel["id"],
			"sflow_business_num"=>$this->srModel["code"],
			"sflow_from_status"=>$this->srModel[""],
			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
			"sflow_return_url"=>__SELF__,
			"sflow_request_params"=>array(
			"id"=>$spModel["id"],
			"pageType"=>$spModel["pageType"],
			),
		));		
		echo $srModel_sflow["divHtml"];	
		$items["items_line"] = $srModel_sflow["buttonArrays"];
/*
		$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>__URL__."/editPmtVersionPage?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
	
		$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'delete',
				'control_value'=>__URL__."/deleteTask?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.delete',
			);	

Sflow(flow_name,button_name,page_submit_type,page_submit_js):
修改基线版本	page.button.update	030	__APP__/PmtVersion/editPmtVersionPage?id={1}
新增子基线版本	page.button.addchild	030	__APP__/PmtVersion/editPmtVersionPage?={1}
删除基线版本	page.button.delete	030	__APP__/PmtVersion/deletePmtVersion?id={1}
*/

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);										
		$this->addItems($items);		
 		
 

		
		self::addInfoResults($srModel,null);
		return $srModel;		
	}	
}
 
?>