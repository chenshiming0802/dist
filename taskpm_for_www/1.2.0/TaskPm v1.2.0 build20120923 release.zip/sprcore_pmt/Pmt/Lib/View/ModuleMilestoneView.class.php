<?php

class ModuleMilestoneView extends SrView{
	private $tv_task_id; 
	private $tv_type_ms_id; 

	public function __construct(){
		$this->tv_task_id = "1;;;pmt_task;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_task t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId().""; 
		$this->tv_type_ms_id = "1;;;pmt_module_type_ms;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_module_type_ms t WHERE is_deleted='0'"; 
	
	}

	public function queryModuleMilestone($spModel){
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);
		
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module_milestone.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'query_id',
			'control_value'=>$this->tv_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_id'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module_milestone.module_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'query_module_id',
			'control_value'=>$this->tv_module_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_module_id'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module_milestone.task_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_task_id',
			'control_value'=>$this->tv_task_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_task_id'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module_milestone.type_ms_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_type_ms_id',
			'control_value'=>$this->tv_type_ms_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_type_ms_id'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module_milestone.adv_begin_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'query_adv_begin_date',
			'control_value'=>$this->tv_adv_begin_date,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_adv_begin_date'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module_milestone.adv_end_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'query_adv_end_date',
			'control_value'=>$this->tv_adv_end_date,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_adv_end_date'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module_milestone.adv_person_day','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_adv_person_day',
			'control_value'=>$this->tv_adv_person_day,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_adv_person_day'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module_milestone.progress','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_progress',
			'control_value'=>$this->tv_progress,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_progress'],
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_module_milestone.memo','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_memo',
			'control_value'=>$this->tv_memo,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_memo'],
		));
	 
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(		
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'insert',
				'control_value'=>__URL__."/editModuleMilestonePage",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.insert',
			);	

		$this->addItems($items);	

		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'view',
				'control_value'=>__URL__."/viewModuleMilestonePage?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.view',
			);

		$buttons[] =array(
				'control_type'=>'BUTTON','control_name'=>'delete',
				'control_value'=>__URL__."/deleteModuleMilestone[id]",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.delete',
			);
		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
				'pmt_module_milestone.id'=>array(
					'control_type'=>'HIDDEN','control_name'=>'id',
					'control_value'=>$this->tv_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'id',
				),			
					'pmt_module_milestone.module_id'=>array(
					'control_type'=>'HIDDEN','control_name'=>'module_id',
					'control_value'=>$this->tv_module_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'module_id',
				),			
					'pmt_module_milestone.task_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'task_id',
					'control_value'=>$this->tv_task_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'task_id',
				),			
					'pmt_module_milestone.type_ms_id'=>array(
					'control_type'=>'LABEL_SQL','control_name'=>'type_ms_id',
					'control_value'=>$this->tv_type_ms_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'type_ms_id',
				),			
					'pmt_module_milestone.adv_begin_date'=>array(
					'control_type'=>'INPUT_DATE','control_name'=>'adv_begin_date',
					'control_value'=>$this->tv_adv_begin_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_begin_date',
				),			
					'pmt_module_milestone.adv_end_date'=>array(
					'control_type'=>'INPUT_DATE','control_name'=>'adv_end_date',
					'control_value'=>$this->tv_adv_end_date,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_end_date',
				),			
					'pmt_module_milestone.adv_person_day'=>array(
					'control_type'=>'TEXT','control_name'=>'adv_person_day',
					'control_value'=>$this->tv_adv_person_day,
					'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'adv_person_day',
				),			
					'pmt_module_milestone.progress'=>array(
					'control_type'=>'TEXT','control_name'=>'progress',
					'control_value'=>$this->tv_progress,
					'control_class'=>"",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'progress',
				),			
					'pmt_module_milestone.memo'=>array(
					'control_type'=>'TEXT','control_name'=>'memo',
					'control_value'=>$this->tv_memo,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'memo',
				),			
	
				'operate'=>$buttons,
			),			
		));

		

		self::addInfoResults($srModel,null);
		return $srModel;
	}
	

	public function editModuleMilestonePage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/editModuleMilestone",
			"target"=>"_self",
			"onSubmit"=>"",
		);	
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));		
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.module_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'module_id',
			'control_value'=>$this->tv_module_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["module_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.task_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'task_id',
			'control_value'=>$this->tv_task_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["task_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.type_ms_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_SQL','control_name'=>'type_ms_id',
			'control_value'=>$this->tv_type_ms_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["type_ms_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.adv_begin_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'adv_begin_date',
			'control_value'=>$this->tv_adv_begin_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_begin_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.adv_end_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'adv_end_date',
			'control_value'=>$this->tv_adv_end_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_end_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.adv_person_day','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'adv_person_day',
			'control_value'=>$this->tv_adv_person_day,
			'control_class'=>" ",'control_param'=>"  size='4'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_person_day"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.progress','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'progress',
			'control_value'=>$this->tv_progress,
			'control_class'=>" ",'control_param'=>"  size='4'  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["progress"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.memo','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'memo',
			'control_value'=>$this->tv_memo,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["memo"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.no','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'no',
			'control_value'=>$this->tv_no,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["no"],
		));
	 
 
		
		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();


		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'submitb',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.submit',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);										
		$this->addItems($items);																		
		
		self::addInfoResults($srModel,null);
		return $srModel;		
	}


	public function viewModuleMilestonePage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();
		
		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewModuleMilestonePage",
			"target"=>"_self",
			"onSubmit"=>"",
		);	
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));	
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.module_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'module_id',
			'control_value'=>$this->tv_module_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["module_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.task_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'task_id',
			'control_value'=>$this->tv_task_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["task_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.type_ms_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL_SQL','control_name'=>'type_ms_id',
			'control_value'=>$this->tv_type_ms_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["type_ms_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.adv_begin_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'adv_begin_date',
			'control_value'=>$this->tv_adv_begin_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_begin_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.adv_end_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'INPUT_DATE','control_name'=>'adv_end_date',
			'control_value'=>$this->tv_adv_end_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_end_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.adv_person_day','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'adv_person_day',
			'control_value'=>$this->tv_adv_person_day,
			'control_class'=>" ",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_person_day"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.progress','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'progress',
			'control_value'=>$this->tv_progress,
			'control_class'=>" ",'control_param'=>"  size='4'  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["progress"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.memo','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'memo',
			'control_value'=>$this->tv_memo,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["memo"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module_milestone.no','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'no',
			'control_value'=>$this->tv_no,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["no"],
		));
	
		

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$srModel_sflow = SrSflow::page_displayButton(array(
			"sflow_is_add_form"=>"0",
			"sflow_current_form"=>"ff",
			"sflow_code"=>"pmt_module_milestone",
			"sflow_business_id"=>$srModel["id"],
			"sflow_business_num"=>$srModel["code"],
			"sflow_from_status"=>$srModel[""],
			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
			"sflow_return_url"=>__SELF__,
			"sflow_request_params"=>array(
			"id"=>$spModel["id"],
			"pageType"=>$spModel["pageType"],
			),
		));		
		echo $srModel_sflow["divHtml"];	
		$items["items_line"] = $srModel_sflow["buttonArrays"];
		$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>__URL__."/editModuleMilestonePage?id=",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);

			
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);										
		$this->addItems($items);		

		
		self::addInfoResults($srModel,null);
		return $srModel;		
	}	
}
 
?>