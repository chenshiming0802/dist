<?php

class EmployeeView extends SrView{
	private $tv_user_id;
	private $tv_joblevel_id;
	private $tv_depart_id;
	private $tv_company_id;
	private $tv_status;

	public function __construct(){
		$this->tv_user_id = "1;;;uup_user;code;SELECT t.id _valueCode_,t.name _valueName_ FROM uup_user t WHERE is_deleted='0' and org_id=".SrUser::getOrgId()."";
		$this->tv_joblevel_id = "1;;;pmt_joblevel;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_joblevel t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";
		$this->tv_depart_id = "1;;;pmt_depart;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_depart t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()."";
		$this->tv_company_id = "1;;;pmt_company;name;SELECT t.id _valueCode_,t.name _valueName_ FROM pmt_company t WHERE is_deleted='0' and belong_org_id=".SrUser::getOrgId()." ";
		$this->tv_status = "1;;PMT14";

	}

public function queryEmployee($spModel){
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->download = array("download"=>"0","method"=>"post");
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__SELF__,
			"target"=>"_self",
			"onSubmit"=>"",
		);

		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee.emp_no','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_emp_no',
			'control_value'=>$this->tv_emp_no,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_emp_no'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'query_name',
			'control_value'=>$this->tv_name,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_name'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee.joblevel_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_joblevel_id',
			'control_value'=>$this->tv_joblevel_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_joblevel_id'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee.company_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'query_company_id',
			'control_value'=>$this->tv_company_id,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_company_id'],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search','div_label'=>'pmt_employee.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'query_status',
			'control_value'=>$this->tv_status,
			'control_class'=>"",'control_param'=>"",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->spModel['query_status'],
			'INFO'=>"",
		));

		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'query',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.query',
			);
		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'insert',
				'control_value'=>__URL__."/editEmployeePage",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.insert',
			);



		$this->addItems($items);

		$buttons = array();
		$buttons[] = array(
				'control_type'=>'BUTTON','control_name'=>'view',
				'control_value'=>__URL__."/viewEmployeePage?id=[id]",//URL,GRID,REQUEST,SESSION
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.view',
			);

		$this->addGrid(array(
			'div_id'=>'div_results','div_label'=>'','item_line_type'=>'line','item_viewauth'=>'',
			'control_name'=>'grid',
			'grid_list'=>$this->srModel['list'],'grid_page'=>$this->srModel['page'],
			'grid_param'=>array(
				'pmt_employee.id'=>array(
					'control_type'=>'HIDDEN','control_name'=>'id',
					'control_value'=>$this->tv_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'id',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee.emp_no'=>array(
					'control_type'=>'TEXT','control_name'=>'emp_no',
					'control_value'=>$this->tv_emp_no,
					'control_class'=>"required max-length-20",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'emp_no',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee.name'=>array(
					'control_type'=>'TEXT','control_name'=>'name',
					'control_value'=>$this->tv_name,
					'control_class'=>"required  max-length-20",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'name',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee.joblevel_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'joblevel_id',
					'control_value'=>$this->tv_joblevel_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'joblevel_id',
					'INFO'=>"",
					'div_label'=>'',
				),
					'pmt_employee.company_id'=>array(
					'control_type'=>'SELECT_SQL','control_name'=>'company_id',
					'control_value'=>$this->tv_company_id,
					'control_class'=>"",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'company_id',
					'INFO'=>"",
					'div_label'=>'',
				),

					'pmt_employee.status'=>array(
					'control_type'=>'SELECT_DICT','control_name'=>'status',
					'control_value'=>$this->tv_status,
					'control_class'=>"required",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
					'value_input'=>'status',
					'INFO'=>"",
					'div_label'=>'',
				),

				'operate'=>$buttons,
			),
		));




		self::addInfoResults($srModel,null);
		return $srModel;
	}




public function editEmployeePage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/editEmployee",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee.user_id','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'user_id',
			'control_value'=>$this->tv_user_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["user_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee.emp_no','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'emp_no',
			'control_value'=>$this->tv_emp_no,
			'control_class'=>"required max-length-20 ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["emp_no"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>"required  max-length-20 ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee.joblevel_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'joblevel_id',
			'control_value'=>$this->tv_joblevel_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["joblevel_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee.company_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'company_id',
			'control_value'=>$this->tv_company_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["company_id"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'status',
			'control_value'=>$this->tv_status,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["status"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee.memo','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'memo',
			'control_value'=>$this->tv_memo,
			'control_class'=>" ",'control_param'=>"ROWS=10 COLS=100  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["memo"],
		));



		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

//		$items["items_line"][] = array(
//				'control_type'=>'BUTTON','control_name'=>'update',
//				'control_value'=>"",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
//				'control_viewauth'=>'',
//				'value_input'=>'page.button.update',
//			);
					$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);


if($id==null || $id==''){


}else{


}


		self::addInfoResults($srModel,null);
		return $srModel;
	}
	public function viewEmployeePage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewEmployeePage",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee.id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'HIDDEN','control_name'=>'id',
			'control_value'=>$this->tv_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["id"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee.user_id','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'user_id',
			'control_value'=>$this->tv_user_id,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["user_id"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee.emp_no','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'emp_no',
			'control_value'=>$this->tv_emp_no,
			'control_class'=>"required max-length-20 ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["emp_no"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee.name','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'TEXT','control_name'=>'name',
			'control_value'=>$this->tv_name,
			'control_class'=>"required  max-length-20 ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["name"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee.joblevel_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'joblevel_id',
			'control_value'=>$this->tv_joblevel_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["joblevel_id"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee.company_id','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_SQL','control_name'=>'company_id',
			'control_value'=>$this->tv_company_id,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["company_id"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee.status','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'SELECT_DICT','control_name'=>'status',
			'control_value'=>$this->tv_status,
			'control_class'=>"required ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["status"],
			'INFO'=>"",
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_employee.memo','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'TEXTAREA','control_name'=>'memo',
			'control_value'=>$this->tv_memo,
			'control_class'=>" ",'control_param'=>"ROWS=10 COLS=100  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["memo"],
			'INFO'=>"",
		));



		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$srModel_sflow = SrSflow::page_displayButton(array(
			"sflow_is_add_form"=>"0",
			"sflow_current_form"=>"ff",
			"sflow_code"=>"pmt_employee",
			"sflow_business_id"=>$this->srModel["id"],
			"sflow_business_num"=>$this->srModel["code"],
			"sflow_from_status"=>$this->srModel[""],
			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
			"sflow_return_url"=>__SELF__,
			"sflow_request_params"=>array(
			"id"=>$spModel["id"],
			"pageType"=>$spModel["pageType"],
			),
		));
		$this->hidden_html = $srModel_sflow["divHtml"];
		$items["items_line"] = $srModel_sflow["buttonArrays"];

//		$items["items_line"][] =array(
//				'control_type'=>'BUTTON','control_name'=>'update',
//				'control_value'=>__URL__."/editEmployeePage?id={$id}",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.update',
//			);
/*

		$items["items_line"][] =array(
				'control_type'=>'BUTTON','control_name'=>'delete',
				'control_value'=>__URL__."/deleteTask?id={$id}",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.delete',
			);

Sflow(flow_name,button_name,page_submit_type,page_submit_js):
修改公司职员	page.button.update	030	__APP__/Employee/editEmployeePage?id={1}
新增子公司职员	page.button.addchild	030	__APP__/Employee/editEmployeePage?={1}
删除公司职员	page.button.delete	030	__APP__/Employee/deleteEmployee?id={1}
*/

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);




		self::addInfoResults($srModel,null);
		return $srModel;
	}
}

?>