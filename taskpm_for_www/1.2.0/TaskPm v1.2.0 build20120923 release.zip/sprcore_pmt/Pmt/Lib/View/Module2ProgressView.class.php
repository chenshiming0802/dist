<?php

class Module2ProgressView extends SrView{

	public function __construct(){

	}






public function editModule2ProgressPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/editModule2Progress",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>'',
		));
		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.adv_begin_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'adv_begin_date',
			'control_value'=>$this->tv_adv_begin_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_begin_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.adv_end_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'adv_end_date',
			'control_value'=>$this->tv_adv_end_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_end_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.adv_work_day','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'adv_work_day',
			'control_value'=>$this->tv_adv_work_day,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_work_day"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.adv_person_day','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'adv_person_day',
			'control_value'=>$this->tv_adv_person_day,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_person_day"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.adv_progress','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'adv_progress',
			'control_value'=>$this->tv_adv_progress,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_progress"],
		));
//			$this->addItem(array(
//			'div_id'=>'div_search_v','div_label'=>'pmt_module.act_begin_date','item_line_type'=>'','item_viewauth'=>'',
//			'control_type'=>'LABEL','control_name'=>'act_begin_date',
//			'control_value'=>$this->tv_act_begin_date,
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
//			'value_input'=>$this->srModel["act_begin_date"],
//		));
//			$this->addItem(array(
//			'div_id'=>'div_search_v','div_label'=>'pmt_module.act_end_date','item_line_type'=>'','item_viewauth'=>'',
//			'control_type'=>'LABEL','control_name'=>'act_end_date',
//			'control_value'=>$this->tv_act_end_date,
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
//			'value_input'=>$this->srModel["act_end_date"],
//		));
//			$this->addItem(array(
//			'div_id'=>'div_search_v','div_label'=>'pmt_module.act_work_day','item_line_type'=>'','item_viewauth'=>'',
//			'control_type'=>'LABEL','control_name'=>'act_work_day',
//			'control_value'=>$this->tv_act_work_day,
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
//			'value_input'=>$this->srModel["act_work_day"],
//		));
//			$this->addItem(array(
//			'div_id'=>'div_search_v','div_label'=>'pmt_module.act_person_day','item_line_type'=>'','item_viewauth'=>'',
//			'control_type'=>'LABEL','control_name'=>'act_person_day',
//			'control_value'=>$this->tv_act_person_day,
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
//			'value_input'=>$this->srModel["act_person_day"],
//		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.tsh_begin_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'tsh_begin_date',
			'control_value'=>$this->tv_tsh_begin_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["tsh_begin_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.tsh_end_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'tsh_end_date',
			'control_value'=>$this->tv_tsh_end_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["tsh_end_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.tsh_work_day','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'tsh_work_day',
			'control_value'=>$this->tv_tsh_work_day,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["tsh_work_day"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.tsh_person_day','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'tsh_person_day',
			'control_value'=>$this->tv_tsh_person_day,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["tsh_person_day"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.tsh_person_normal_day','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'tsh_person_normal_day',
			'control_value'=>$this->tv_tsh_person_normal_day,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["tsh_person_normal_day"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.tsh_person_over_day','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'tsh_person_over_day',
			'control_value'=>$this->tv_tsh_person_over_day,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["tsh_person_over_day"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.tsh_progress','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'tsh_progress',
			'control_value'=>$this->tv_tsh_progress,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'0','control_viewauth'=>'',
			'value_input'=>$this->srModel["tsh_progress"],
		));



		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
		$items["items_line"] = array();

		$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'update',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0',
				'control_viewauth'=>'',
				'value_input'=>'page.button.update',
			);
					$items["items_line"][] = array(
				'control_type'=>'BUTTON','control_name'=>'close',
				'control_value'=>"",
				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
				'value_input'=>'page.button.close',
			);
		$this->addItems($items);


if($id==null || $id==''){


}else{


}


		self::addInfoResults($srModel,null);
		return $srModel;
	}
	public function viewModule2ProgressPage($spModel){
		$id = $this->srModel['id'];
		$srModel = array();

		$this->title = Sr::sys_pl(__FUNCTION__.".title",array("displayDiv"=>"false"));
		$this->form = array(
			"name"=>"ff",
			"method"=>"post",
			"action"=>__URL__."/viewModule2ProgressPage",
			"target"=>"_self",
			"onSubmit"=>"",
		);
		//$this->srModel['id']?"1":"0"
		$this->addItem(array(
			'div_id'=>'div_title','div_label'=>__FUNCTION__.".title",'item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'',
			'control_value'=>"",
			'control_class'=>'','control_param'=>'','control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>'',
		));
 		$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.adv_begin_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'adv_begin_date',
			'control_value'=>$this->tv_adv_begin_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_begin_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.adv_end_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'adv_end_date',
			'control_value'=>$this->tv_adv_end_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_end_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.adv_work_day','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'adv_work_day',
			'control_value'=>$this->tv_adv_work_day,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_work_day"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.adv_person_day','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'adv_person_day',
			'control_value'=>$this->tv_adv_person_day,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_person_day"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.adv_progress','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'adv_progress',
			'control_value'=>$this->tv_adv_progress,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["adv_progress"],
		));
//			$this->addItem(array(
//			'div_id'=>'div_search_v','div_label'=>'pmt_module.act_begin_date','item_line_type'=>'','item_viewauth'=>'',
//			'control_type'=>'LABEL','control_name'=>'act_begin_date',
//			'control_value'=>$this->tv_act_begin_date,
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//			'value_input'=>$this->srModel["act_begin_date"],
//		));
//			$this->addItem(array(
//			'div_id'=>'div_search_v','div_label'=>'pmt_module.act_end_date','item_line_type'=>'','item_viewauth'=>'',
//			'control_type'=>'LABEL','control_name'=>'act_end_date',
//			'control_value'=>$this->tv_act_end_date,
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//			'value_input'=>$this->srModel["act_end_date"],
//		));
//			$this->addItem(array(
//			'div_id'=>'div_search_v','div_label'=>'pmt_module.act_work_day','item_line_type'=>'','item_viewauth'=>'',
//			'control_type'=>'LABEL','control_name'=>'act_work_day',
//			'control_value'=>$this->tv_act_work_day,
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//			'value_input'=>$this->srModel["act_work_day"],
//		));
//			$this->addItem(array(
//			'div_id'=>'div_search_v','div_label'=>'pmt_module.act_person_day','item_line_type'=>'','item_viewauth'=>'',
//			'control_type'=>'LABEL','control_name'=>'act_person_day',
//			'control_value'=>$this->tv_act_person_day,
//			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
//			'value_input'=>$this->srModel["act_person_day"],
//		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.tsh_begin_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'tsh_begin_date',
			'control_value'=>$this->tv_tsh_begin_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["tsh_begin_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.tsh_end_date','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'tsh_end_date',
			'control_value'=>$this->tv_tsh_end_date,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["tsh_end_date"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.tsh_work_day','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'tsh_work_day',
			'control_value'=>$this->tv_tsh_work_day,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["tsh_work_day"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.tsh_person_day','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'tsh_person_day',
			'control_value'=>$this->tv_tsh_person_day,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["tsh_person_day"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.tsh_person_normal_day','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'tsh_person_normal_day',
			'control_value'=>$this->tv_tsh_person_normal_day,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["tsh_person_normal_day"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.tsh_person_over_day','item_line_type'=>'','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'tsh_person_over_day',
			'control_value'=>$this->tv_tsh_person_over_day,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["tsh_person_over_day"],
		));
			$this->addItem(array(
			'div_id'=>'div_search_v','div_label'=>'pmt_module.tsh_progress','item_line_type'=>'line','item_viewauth'=>'',
			'control_type'=>'LABEL','control_name'=>'tsh_progress',
			'control_value'=>$this->tv_tsh_progress,
			'control_class'=>" ",'control_param'=>"  ",'control_readonly'=>'1','control_viewauth'=>'',
			'value_input'=>$this->srModel["tsh_progress"],
		));



//		$items = array('div_id'=>'div_search','div_label'=>'','item_line_type'=>'button','item_viewauth'=>'',);
//		$srModel_sflow = SrSflow::page_displayButton(array(
//			"sflow_is_add_form"=>"0",
//			"sflow_current_form"=>"ff",
//			"sflow_code"=>"pmt_module",
//			"sflow_business_id"=>$this->srModel["id"],
//			"sflow_business_num"=>$this->srModel["code"],
//			"sflow_from_status"=>$this->srModel[""],
//			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
//			"sflow_return_url"=>__SELF__,
//			"sflow_request_params"=>array(
//			"id"=>$spModel["id"],
//			"pageType"=>$spModel["pageType"],
//			),
//		));
//		echo $srModel_sflow["divHtml"];
//		$items["items_line"] = $srModel_sflow["buttonArrays"];
///*
//		$items["items_line"][] =array(
//				'control_type'=>'BUTTON','control_name'=>'update',
//				'control_value'=>__URL__."/editModule2ProgressPage?id={$id}",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.update',
//			);
//
//		$items["items_line"][] =array(
//				'control_type'=>'BUTTON','control_name'=>'delete',
//				'control_value'=>__URL__."/deleteTask?id={$id}",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.delete',
//			);
//
//Sflow(flow_name,button_name,page_submit_type,page_submit_js):
//修改模块_时间进度	page.button.update	030	__APP__/Module2Progress/editModule2ProgressPage?id={1}
//新增子模块_时间进度	page.button.addchild	030	__APP__/Module2Progress/editModule2ProgressPage?={1}
//删除模块_时间进度	page.button.delete	030	__APP__/Module2Progress/deleteModule2Progress?id={1}
//*/
//
//		$items["items_line"][] = array(
//				'control_type'=>'BUTTON','control_name'=>'close',
//				'control_value'=>"",
//				'control_class'=>'','control_param'=>'','control_readonly'=>'0','control_viewauth'=>'',
//				'value_input'=>'page.button.close',
//			);
//		$this->addItems($items);




		self::addInfoResults($srModel,null);
		return $srModel;
	}
}

?>