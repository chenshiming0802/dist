<?php
class AppCommonTabView extends SrTabView{
	public static function configWelcome($spModel){

		$id = $spModel['id'];
		$srModel = array();
		$srModel['TAB'] = array();
		$srModel['TAB']['LIST'] = array();
		$srModel['TAB']['LIST'][__FUNCTION__.'010'] = array(
			'name'=>'基本信息',
			'url'=>__APP__.'/Index/welcome',
			'default_no'=>'010',
			'except_add_get_keys'=>array('project_id'),
			//'rac_privilege'=>array(array('PMT#B#0002','1',$id)) ,
		);
		$sql = "select t.* from pmt_project t where (t.manager_id='{0}' or t.config_user_id='{0}') /*w[t]*/ and t.status='020'";
		if(SrUser::isVisitor()===true){
			$pss = 'select a.project_id from pmt_project_member a where a.user_id={0}';
			$sql = "select t.* from pmt_project t where 1=1 /*w[t]*/ and t.status='020' and t.id in (".$pss.")";
		}

		$list = self::queryBySql($sql,array(SrUser::getUserId()));

		foreach($list as &$model){
			$srModel['TAB']['LIST'][__FUNCTION__.'020_'.$model['id']] = array(
				'name'=>$model['name'],
				'url'=>__APP__.'/Index/welcomeProject?project_id='.$model['id'],
				'default_no'=>'020',
				'except_add_get_keys'=>array('project_id'),
				//'rac_privilege'=>array(array('PMT#B#0002','1',$id)) ,
			);
		}

		self::addInfoResults($srModel,null);
		return $srModel;
	}


	//项目的配置
	public static function configProjectEdit($spModel){
//		SrUser::p();

		$id = $spModel['id'];
		$srModel = array();
		$srModel['TAB'] = array();
		$srModel['TAB']['LIST'] = array();
		$srModel['TAB']['LIST'][__FUNCTION__.'010'] = array(
			'name'=>'基本信息',
			'url'=>__APP__.'/Project/editProjectPage?id='.$id,
			'default_no'=>'010',
			'rac_privilege'=>array(array('PMT#B#0002','1',$id)) ,
		);
		if($id!=null&&$id!=''){
			$srModel['TAB']['LIST'][__FUNCTION__.'020'] = array(
				'name'=>'详情',
				'url'=>__APP__.'/Project2Content/editProject2ContentPage?id='.$id,
				'default_no'=>'020',
				'rac_privilege'=>array(array('PMT#B#0002','1',$id)) ,
			);
//			$srModel['TAB']['LIST'][__FUNCTION__.'030'] = array(
//				'name'=>'成员',
//				'url'=>__APP__.'/Project2Member/managerProject2MemberPage?id='.$id,
//				'default_no'=>'020',
//				'rac_privilege'=>array(array('PMT#B#0002','1',$id)) ,
//			);
			$uu = SrRac::url_editAssignUserByDim(array('dim_table_id'=>$id,'dim_code'=>'PMT_PROJECT_ROLE'));
			$srModel['TAB']['LIST'][__FUNCTION__.'040'] = array(
				'name'=>'成员',
				'url'=>__APP__.'/Project/editProjectPage?id='.$id.'&SPR_TAB_VIEW_TYPE=IFRAME&SPR_TAB_VIEW_TYPE_VALUE1='.urlencode($uu),
				'default_no'=>'040',
				'rac_privilege'=>array(array('PMT#B#0002','1',$id),array('PMT#B#0003','1',$id)) ,
			);
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	//项目的配置
	public static function configProjectView($spModel){
		$id = $spModel['id'];
		$project = self::queryById2($id,'pmt_project');
		$srModel = array();
		$srModel['TAB'] = array();
		$srModel['TAB']['LIST'] = array();
		$srModel['TAB']['LIST'][__FUNCTION__.'010'] = array(
			'name'=>'基本信息',
			'url'=>__APP__.'/Project/viewProjectPage?id='.$id,
			'default_no'=>'010',
		);
		$srModel['TAB']['LIST'][__FUNCTION__.'020'] = array(
			'name'=>'详情',
			'url'=>__APP__.'/Project2Content/viewProject2ContentPage?id='.$id,
			'default_no'=>'020',
		);
//		$srModel['TAB']['LIST'][__FUNCTION__.'025'] = array(
//			'name'=>'成员',
//			'url'=>__APP__.'/Project2Member/viewProject2MemberPage?id='.$id,
//			'default_no'=>'020',
//		);
		$uu = SrRac::url_viewAssignUserByDim(array('dim_table_id'=>$id,'dim_code'=>'PMT_PROJECT_ROLE'));
		$srModel['TAB']['LIST'][__FUNCTION__.'030'] = array(
			'name'=>'成员',
			'url'=>__APP__.'/Project/viewProjectPage?id='.$id.'&SPR_TAB_VIEW_TYPE=IFRAME&SPR_TAB_VIEW_TYPE_VALUE1='.urlencode($uu),
			'default_no'=>'030',
			//'rac_privilege'=>array(array('PMT01dd03','1',$id)) ,
		);
//		$srModel['TAB']['LIST'][__FUNCTION__.'040'] = array(
//			'name'=>'成员(计划)',
//			'url'=>__APP__.'/AppEmployeeAssign/viewProjectEmployeeAssign?id='.$id,
//			'default_no'=>'040',
//		);
		$uu = __APP__.'/Module/queryModule?query_project_id='.$id;
		$srModel['TAB']['LIST'][__FUNCTION__.'050'] = array(
			'name'=>'模块清单',
			'url'=>__APP__.'/Project/viewProjectPage?id='.$id.'&SPR_TAB_VIEW_TYPE=IFRAME&SPR_TAB_VIEW_TYPE_VALUE1='.urlencode($uu),
			'default_no'=>'050',
		);

		$srModel['TAB']['BUTTONS'] = array();
		$srModel_sflow = SrSflow::page_displayButton(array(
			"sflow_is_add_form"=>"0",
			"sflow_current_form"=>"ff",
			"sflow_code"=>"pmt_project",
			"sflow_business_id"=>$id,
			"sflow_business_num"=>$project["code"],
			"sflow_from_status"=>$project["status"],
			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
			"sflow_return_url"=>__SELF__,
			"sflow_request_params"=>array(
			"id"=>$id,
			"pageType"=>$spModel["pageType"],
			),
		));
		$srModel['TAB']['BUTTONS'] = $srModel_sflow["buttonArrays"];
		$srModel['TAB']['HTML'] = $srModel_sflow["divHtml"];

		self::addInfoResults($srModel,null);
		return $srModel;
	}
	//任务查询
	public static function queryTaskStatus($spModel){
		$srModel = array();
		$srModel['TAB'] = array();
		$srModel['TAB']['LIST'] = array();
		$srModel['TAB']['LIST'][__FUNCTION__.'010'] = array(
			'name'=>'全部任务',
			'url'=>__APP__.'/Task/queryTask?query_status=',
			'except_add_get_keys'=>array('query_status'),
			'default_no'=>'010',
		);
		$srModel['TAB']['LIST'][__FUNCTION__.'020'] = array(
			'name'=>'草稿任务',
			'url'=>__APP__.'/Task/queryTask?query_status=010',
			'except_add_get_keys'=>array('query_status'),
			'default_no'=>'020',
		);
		$srModel['TAB']['LIST'][__FUNCTION__.'030'] = array(
			'name'=>'正在处理任务',
			'url'=>__APP__.'/Task/queryTask?query_status=020',
			'except_add_get_keys'=>array('query_status'),
			'default_no'=>'030',
		);
		$srModel['TAB']['LIST'][__FUNCTION__.'040'] = array(
			'name'=>'完成任务',
			'url'=>__APP__.'/Task/queryTask?query_status=050',
			'except_add_get_keys'=>array('query_status'),
			'default_no'=>'040',
		);
		$srModel['TAB']['LIST'][__FUNCTION__.'050'] = array(
			'name'=>'关闭任务',
			'url'=>__APP__.'/Task/queryTask?query_status=100',
			'except_add_get_keys'=>array('query_status'),
			'default_no'=>'050',
		);
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	//模块的配置
	public static function configModuleEdit($spModel){
		$id = $spModel['id'];
		$srModel = array();
		$srModel['TAB'] = array();
		$srModel['TAB']['LIST'] = array();
		$srModel['TAB']['LIST'][__FUNCTION__.'010'] = array(
			'name'=>'基本信息',
			'url'=>__APP__.'/Module/editModulePage?id='.$id,
			'default_no'=>'010',
		);
		if($id!=null&&$id!=''){
			$srModel['TAB']['LIST'][__FUNCTION__.'020'] = array(
				'name'=>'模块内容',
				'url'=>__APP__.'/Module2Content/editModule2ContentPage?id='.$id,
				'default_no'=>'020',
			);
		}
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	//模块的配置
	public static function configModuleView($spModel){
		$id = $spModel['id'];
		$module = self::queryById2($id,'pmt_module');
		$srModel = array();
		$srModel['TAB'] = array();
		$srModel['TAB']['LIST'] = array();
		$srModel['TAB']['LIST'][__FUNCTION__.'010'] = array(
			'name'=>'基本信息',
			'url'=>__APP__.'/Module/viewModulePage?id='.$id,
			'default_no'=>'010',
		);
		$srModel['TAB']['LIST'][__FUNCTION__.'020'] = array(
			'name'=>'模块内容',
			'url'=>__APP__.'/Module2Content/viewModule2ContentPage?id='.$id,
			'default_no'=>'020',
		);
//		$uu = __APP__.'/AppModule/viewModulePath?module_id='.$id;
//		$srModel['TAB']['LIST'][__FUNCTION__.'030'] = array(
//			'name'=>'文档详情[废除]',
//			'url'=>__APP__.'/Module/viewModulePage?id='.$id.'&SPR_TAB_VIEW_TYPE=2IFRAME&SPR_TAB_VIEW_TYPE_VALUE1='.urlencode($uu),
//			'default_no'=>'030',
//		);
		$srModel['TAB']['LIST'][__FUNCTION__.'040'] = array(
			'name'=>'时间进度',
			'url'=>__APP__.'/Module2Progress/viewModule2ProgressPage?id='.$id,
			'default_no'=>'040',
		);

		$uu = __APP__.'/AppTaskTsheet/getSheetInfoFromProjectModuleTask?status=100&module_id='.$id;
		$srModel['TAB']['LIST'][__FUNCTION__.'050'] = array(
			'name'=>'工时详情',
			'url'=>__APP__.'/Module/viewModulePage?id='.$id.'&SPR_TAB_VIEW_TYPE=IFRAME&SPR_TAB_VIEW_TYPE_VALUE1='.urlencode($uu),
			'default_no'=>'050',
		);
		$model = self::queryById2($id,'pmt_module');
		$uu = __APP__.'/Task/queryTask?query_status=020&query_project_id='.$model['project_id'].'&query_module_id='.$id;
		$srModel['TAB']['LIST'][__FUNCTION__.'060'] = array(
			'name'=>'任务清单',
			'url'=>__APP__.'/Module/viewModulePage?id='.$id.'&SPR_TAB_VIEW_TYPE=IFRAME&SPR_TAB_VIEW_TYPE_VALUE1='.urlencode($uu),
			'default_no'=>'060',
		);
		$srModel['TAB']['BUTTONS'] = array();
		$srModel_sflow = SrSflow::page_displayButton(array(
			"sflow_is_add_form"=>"0",
			"sflow_current_form"=>"ff",
			"sflow_code"=>"pmt_module",
			"sflow_business_id"=>$id,
			"sflow_business_num"=>$module["code"],
			"sflow_from_status"=>$module["status"],
			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
			"sflow_return_url"=>__SELF__,
			"sflow_request_params"=>array(
			"id"=>$id,
			"pageType"=>$spModel["pageType"],
			),
		));
		$srModel['TAB']['BUTTONS'] = $srModel_sflow["buttonArrays"];
		$srModel['TAB']['HTML'] = $srModel_sflow["divHtml"];

		self::addInfoResults($srModel,null);
		return $srModel;
	}

	//任务的配置
	public static function configTaskEdit($spModel){
		$id = $spModel['id'];
		$task = self::queryById2($id,'pmt_task');
		$srModel = array();
		$srModel['TAB'] = array();
		$srModel['TAB']['LIST'] = array();
		$srModel['TAB']['LIST'][__FUNCTION__.'010'] = array(
			'name'=>'基本信息',
			'url'=>__APP__.'/Task/editTaskPage?id='.$id,
			'default_no'=>'010',
		);
		if($id!=null&&$id!=''){

			$srModel2 = self::invokeService('AppTaskService','queryDocuments', array('id'=>$id) );
			//$tt = "(".$srModel2['list_count']."+".$srModel2['other_list_count'].")";
			$tt = "(".$srModel2['list_count'].")";

//			$srModel['TAB']['LIST'][__FUNCTION__.'020'] = array(
//				'name'=>'任务内容',
//				'url'=>__APP__.'/Task2Content/editTask2ContentPage?id='.$id,
//				'default_no'=>'020',
//			);
			$sql = "select t.* from pmt_module_type_follow t,pmt_module_type_follow_dst t1 where t.id=t1.follow_id and t1.module_task_type_id='{0}' /*w[t,t1]*/";
			$list = self::queryBySql($sql,array($task['module_type_task_id']));
			foreach($list as $kk=>$item){
				$srModel['TAB']['LIST'][__FUNCTION__.'030'] = array(
					'name'=>'上线任务清单',
					'url'=>__APP__.'/'.$item['implement_class'].'/managerTask2FollowLinkPage?id='.$id,
					'default_no'=>'030',
				);
			}
			$srModel['TAB']['LIST'][__FUNCTION__.'040'] = array(
				'name'=>'任务文档清单'.$tt.'',
				'url'=>__APP__.'/AppTask/queryDocuments?action=edit&id='.$id,
				'default_no'=>'040',
			);
//			$cnt = self::getValue_invokeBusiness("AppDocumentBusiness","getDocumentsCount",array('table_id'=>$task['module_id'],'table_name'=>'pmt_module'),'@','count');
//			$uu = __APP__.'/AppModule/viewModulePath?module_id='.$task['module_id'];
//			$srModel['TAB']['LIST'][__FUNCTION__.'050'] = array(
//				'name'=>'项目文档详情('.$cnt.')',
//				'url'=>__APP__.'/Task/editTaskPage?id='.$id.'&SPR_TAB_VIEW_TYPE=2IFRAME&SPR_TAB_VIEW_TYPE_VALUE1='.urlencode($uu),
//				'default_no'=>'050',
//			);
			$srModel['TAB']['LIST'][__FUNCTION__.'060'] = array(
				'name'=>'前置任务',
				'url'=>__APP__.'/Task2Depend/managerTask2DependPage?id='.$id,
				'default_no'=>'060',
			);
		}
//		dump($_SERVER);
//		$ufull=$_SERVER['HTTP_REFERER'];
//		$upre=$_SERVER['HTTP_ORIGIN'];
//		if(substr($ufull,0,strlen($upre))==$upre){
//			$ufull = substr($ufull,strlen($upre));
//		}
//
//		dump($ufull);halt();
		self::addInfoResults($srModel,null);
		return $srModel;
	}
	//任务的配置
	public static function configTaskView($spModel){
		$id = $spModel['id'];

		$srModel = self::invokeService('AppTaskService','queryDocuments', array('id'=>$id) );
		//$tt = "(".$srModel['list_count']."+".$srModel['other_list_count'].")";
		$tt = "(".$srModel['list_count'].")";
		$task = self::queryById2($id,'pmt_task');

		$srModel = array();
		$srModel['TAB'] = array();
		$srModel['TAB']['LIST'] = array();
		$srModel['TAB']['LIST'][__FUNCTION__.'010'] = array(
			'name'=>'汇总',
			'url'=>__APP__.'/AppTask/indexTaskDetail?id='.$id,
			'default_no'=>'010',
		);
		$srModel['TAB']['LIST'][__FUNCTION__.'020'] = array(
			'name'=>'基本信息',
			'url'=>__APP__.'/Task/viewTaskPage?id='.$id,
			'default_no'=>'020',
		);
		$srModel['TAB']['LIST'][__FUNCTION__.'030'] = array(
			'name'=>'内容',
			'url'=>__APP__.'/Task2Content/viewTask2ContentPage?id='.$id,
			'default_no'=>'030',
		);
			$sql = "select t.* from pmt_module_type_follow t,pmt_module_type_follow_dst t1 where t.id=t1.follow_id and t1.module_task_type_id='{0}' /*w[t,t1]*/";
			$list = self::queryBySql($sql,array($task['module_type_task_id']));
			foreach($list as $kk=>$item){
				$srModel['TAB']['LIST'][__FUNCTION__.'040'] = array(
					'name'=>'上线任务清单',
					'url'=>__APP__.'/'.$item['implement_class'].'/viewTask2FollowLinkPage?id='.$id,
					'default_no'=>'040',
				);
				$srModel['TAB']['LIST'][__FUNCTION__.'041'] = array(
					'name'=>'清单WIKI版',
					'url'=>__APP__.'/'.$item['implement_class'].'/viewWikiPage?id='.$id,
					'default_no'=>'040',
				);
			}
		$srModel['TAB']['LIST'][__FUNCTION__.'050'] = array(
			'name'=>'任务文档'.$tt,
			'url'=>__APP__.'/AppTask/queryDocuments?id='.$id,
			'default_no'=>'050',
		);
//		$cnt = self::getValue_invokeBusiness("AppDocumentBusiness","getDocumentsCount",array('table_id'=>$task['module_id'],'table_name'=>'pmt_module'),'@','count');
//		$uu = __APP__.'/AppModule/viewModulePath?module_id='.$task['module_id'];
//		$srModel['TAB']['LIST'][__FUNCTION__.'060'] = array(
//			'name'=>'项目文档('.$cnt.')',
//			'url'=>__APP__.'/Task/viewTaskPage?id='.$id.'&SPR_TAB_VIEW_TYPE=2IFRAME&SPR_TAB_VIEW_TYPE_VALUE1='.urlencode($uu),
//			'default_no'=>'060',
//		);
		$srModel['TAB']['LIST'][__FUNCTION__.'070'] = array(
			'name'=>'前置任务',
			'url'=>__APP__.'/Task2Depend/viewTask2DependPage?id='.$id,
			'default_no'=>'070',
		);
		$srModel['TAB']['LIST'][__FUNCTION__.'080'] = array(
			'name'=>'进度',
			'url'=>__APP__.'/Task2Progress/viewTask2ProgressPage?id='.$id,
			'default_no'=>'080',
		);
		$uu = __APP__.'/AppTaskTsheet/getSheetInfoFromProjectModuleTask?status=100&task_id='.$id;
		$srModel['TAB']['LIST'][__FUNCTION__.'090'] = array(
			'name'=>'工时',
			'url'=>__APP__.'/Task/viewTaskPage?id='.$id.'&SPR_TAB_VIEW_TYPE=IFRAME&SPR_TAB_VIEW_TYPE_VALUE1='.urlencode($uu),
			'default_no'=>'090',
		);
		$srModel['TAB']['BUTTONS'] = array();
		$srModel_sflow = SrSflow::page_displayButton(array(
			"sflow_is_add_form"=>"0",
			"sflow_current_form"=>"ff",
			"sflow_code"=>"pmt_task",
			"sflow_business_id"=>$id,
			"sflow_business_num"=>$task["code"],
			"sflow_from_status"=>$task["status"],
			"sflow_business_type"=>$spModel["pageType"],//$spModel["pageType"],
			"sflow_return_url"=>__SELF__,
			"sflow_request_params"=>array(
			"id"=>$id,
			"pageType"=>$spModel["pageType"],
			),
		));
		$srModel['TAB']['BUTTONS'] = $srModel_sflow["buttonArrays"];
		$srModel['TAB']['HTML'] = $srModel_sflow["divHtml"];


		self::addInfoResults($srModel,null);
		return $srModel;
	}

	//我的任务(列出所有项目下的所有帐号)
	public static function queryUserTask($spModel){
		$query_project_id = $spModel["query_project_id"];

		$sql = "SELECT distinct t2.id user_id,t2.name user_name
				FROM pmt_project_member t1, uup_user t2
				WHERE 1=1 /*w[t1]*/
				AND t1.user_id=t2.id and t1.project_id = {0}";
		$project_user = self :: queryBySql($sql,array($query_project_id));



		$srModel = array();
		$srModel['TAB'] = array();
		$srModel['TAB']['LIST'] = array();
		$srModel2 = self::invokeService('AppCommonService','queryUserTask', array('task_list_type'=>'5','action_count'=>'1','query_project_id'=>$query_project_id) );
		$srModel['TAB']['LIST'][__FUNCTION__.'010'] = array(
			'name'=>'未指派任务('.$srModel2['list_count'].')',
			'url'=>__URL__.'/queryUserTask?query_user_id=&task_list_type=5',
			'default_no'=>'010',
		);
		$srModel['TAB']['LIST'][__FUNCTION__.'020'] = array(
			'name'=>'新增任务',
			'url'=>__URL__.'/queryUserTask?query_user_id=&task_list_type=2',
			'default_no'=>'020',
		);
		$srModel['TAB']['LIST'][__FUNCTION__.'030'] = array(
			'name'=>'完成任务',
			'url'=>__URL__.'/queryUserTask?query_user_id=&task_list_type=3',
			'default_no'=>'030',
		);
		$srModel['TAB']['LIST'][__FUNCTION__.'040'] = array(
			'name'=>'关闭任务',
			'url'=>__URL__.'/queryUserTask?query_user_id=&task_list_type=4',
			'default_no'=>'040',
		);
		$srModel['TAB']['LIST'][__FUNCTION__.'050'] = array(
			'name'=>'我的任务',
			'url'=>__URL__.'/queryUserTask',
			'default_no'=>'050',
		);
		$srModel['TAB']['LIST'][__FUNCTION__.'060'] = array(
			'name'=>'所有待处理',
			'url'=>__URL__.'/queryUserTask?query_user_id=',
			'default_no'=>'060',
		);
		foreach($project_user as $k=>$m){
			$srModel['TAB']['LIST'][__FUNCTION__.'070'."_".$k] = array(
				'name'=>$m['user_name'],
				'url'=>__URL__.'/queryUserTask?query_user_id='.$m['user_id'],
				'default_no'=>'070',
			);
		}
		$srModel['TAB']['LIST'][__FUNCTION__.'080'] = array(
			'name'=>'我的任务收藏夹(新)',
			'url'=>__APP__.'/AppTaskFavorite/indexFrame',
			'default'=>'0',
			'default_no'=>'080',
		);
		self::addInfoResults($srModel,null);
		return $srModel;
	}

	//职员配置
	public static function configEmployeeView($spModel){
		$id = $spModel['id'];
		$srModel = array();
		$srModel['TAB'] = array();
		$srModel['TAB']['LIST'] = array();
		$srModel['TAB']['LIST'][__FUNCTION__.'010'] = array(
			'name'=>'基本',
			'url'=>__APP__.'/Employee/viewEmployeePage?id='.$id,
			'default_no'=>'010',
		);
		/*
		$srModel['TAB']['LIST'][__FUNCTION__.'020'] = array(
			'name'=>'项目分配',
			'url'=>__APP__.'/AppEmployeeAssign/viewEmployeeEmployeeAssign?id='.$id,
			'default_no'=>'020',
		);
		$srModel['TAB']['LIST'][__FUNCTION__.'030'] = array(
			'name'=>'任务分配',
			'url'=>__APP__.'/AppTask/viewEmployeeTask?id='.$id,
			'default_no'=>'030',
		);
		*/
		self::addInfoResults($srModel,null);
		return $srModel;
	}
}
?>
