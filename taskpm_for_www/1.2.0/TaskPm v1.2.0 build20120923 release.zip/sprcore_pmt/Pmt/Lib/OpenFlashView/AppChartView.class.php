<?php
class AppChartView extends SrOpenFlashView{	
	public function queryPersonDayData($spModel){
		$srModel = array();
		$list = $this->srModel['details'];
		$y_legend['text'] = 'Task Person';//+
		$lables['labels'] = $this->srModel['days'];//+
		$elements = array();
		$min = 0;
		$max = 0;
		
		//新增加任务
		$line = array();
		$line['text'] = '新增任务工时';
		$line['colour'] = '#0000ff';
		$line['values'] = array();
		foreach($lables['labels'] as $kk=>$vv){
			$pot = 0;
			foreach($list as $key=>$model){
				if($model['person_day_type']=='begin') {
					if($model['occure_date']==$vv){
						$pot = $model['person_day'];
					}					
				}
			}
			$line['values'][] = $pot;
			$line['values_n'][] = '{"value":'.$pot.',"on-click":"http://www.baidu.com","tip":"'.self::tip($line['text'],$vv,$pot).'"}';
		}
		$elements[] = $line;//+
		//结束任务
		$line = array();
		$line['text'] = '结束任务工时';
		$line['colour'] = '#00ff00';
		$line['values'] = array();
		$line['values_n'] = array();
		foreach($lables['labels'] as $kk=>$vv){
			$pot = 0;
			foreach($list as $key=>$model){
				if($model['person_day_type']=='end') {
					if($model['occure_date']==$vv){
						$pot = $model['person_day'];
					}					
				}
			}
			$line['values'][] = $pot;
			$line['values_n'][] = '{"value":'.$pot.',"tip":"'.self::tip($line['text'],$vv,$pot).'"}';//,"colour":"#FF0000"
		}
		$elements[] = $line;//+
		//计划待处理任务
		$line = array();
		$line['text'] = '计划处理任务工时';
		$line['colour'] = '#000000';
		$line['values'] = array();
		foreach($lables['labels'] as $kk=>$vv){
			$pot = 0;
			foreach($list as $key=>$model){
				if($model['person_day_type']=='todo') {
					if($model['occure_date']==$vv){
						$pot = $model['person_day'];
					}					
				}
			}
			$line['values'][] = $pot;
			$line['values_n'][] = '{"value":'.$pot.',"tip":"'.self::tip($line['text'],$vv,$pot).'"}';
		}
		$elements[] = $line;//+		
		//过期任务
		$line = array();
		$line['text'] = '过期任务工时';
		$line['colour'] = '#ff0000';
		$line['values'] = array();
		foreach($lables['labels'] as $kk=>$vv){
			$pot = 0;
			foreach($list as $key=>$model){
				if($model['person_day_type']=='expired') {
					if($model['occure_date']==$vv){
						$pot = $model['person_day'];
					}					
				}
			}
			$line['type'] = 'area';
			$line['fill'] = '#ff0000';
			$line['values'][] = $pot;
			$line['values_n'][] = '{"value":'.$pot.',"tip":"'.self::tip($line['text'],$vv,$pot).'"}';
		}
		$elements[] = $line;//+	
		
 		$srModel['DATA'] = self::drawLine(array(
 			'y_legend'=>$y_legend,
 			'elements'=>$elements,
 			'lables'=>$lables,
 		));
		self::addInfoResults($srModel,null);
		return $srModel;	
	}	
}
?>
