<?php
class AppVersionProjectBusiness extends SrService{	
	public static function addVersion($spModel){
		$id = $spModel['id'];
		$project_id = $spModel['project_id'];
		$srModel = array ();	

		
 
		$sql = "select t.*,t1.status table_status from pmt_progress t,pmt_project t1 where t.table_id=t1.id and t.table_name='{0}' and t1.id = '{1}' /*w[t,t1]*/";
		$list = self::queryBySql($sql,array('pmt_project',$project_id));
		SrRowVersion::insertRow(array(
			'list'=>$list,
			'spr_version_id'=>$id,
			'spr_version_table'=>'pmt_progress_version',
		));
	
		$sql = "select t.*,t1.status table_status from pmt_progress t,pmt_module t1 where t.table_id=t1.id and t.table_name='{0}' and t1.project_id = '{1}' /*w[t,t1]*/";
		$list = self::queryBySql($sql,array('pmt_module',$project_id));
		SrRowVersion::insertRow(array(
			'list'=>$list,
			'spr_version_id'=>$id,
			'spr_version_table'=>'pmt_progress_version',
		));	
		$sql = "select t.*,t1.status table_status from pmt_progress t,pmt_task t1 where t.table_id=t1.id and t.table_name='{0}' and t1.project_id = '{1}' /*w[t,t1]*/";
		$list = self::queryBySql($sql,array('pmt_task',$project_id));
		SrRowVersion::insertRow(array(
			'list'=>$list,
			'spr_version_id'=>$id,
			'spr_version_table'=>'pmt_progress_version',
		));				
	 	
		
		self :: addInfoResults($srModel, null);	
		return $srModel;		
	}
}
?>
