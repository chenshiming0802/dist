<?php
class AppTaskBusiness extends SrService{
	/*
	 * 发送邮件
	 * 通知任务成员\任务服务人\模块负责人\项目经理\项目配置成员
	 */
	function sendTaskMail($spModel){
		$task_id = $spModel['task_id'];
		$sql = "select * from pmt_task_member t where t.task_id='{0}' /*w[t]*/";
		$list = self::queryBySql($sql,array($task_id));
		$us = array();
		foreach($list as $m){
			$us[] = $m['user_id'];
		}
		$task = self::queryById2($task_id,'pmt_task');
		$module = self::queryById2($task['module_id'],'pmt_module');
		$project = self::queryById2($task['project_id'],'pmt_project');

		$us[] = $module['manager_id'];
		$us[] = $project['manager_id'];
		$us[] = $project['config_user_id'];
		$us = array_unique($us);
		$title = '['.$task['code'].']'.$module['name'].':'.$task['name'];
		$create_user = SrUup::getUserById($task['create_user_id']);
		$manager = SrUup::getUserById($task['manager_id']);
		$url = Sr::getRootUrl()."Pmt/index.php/Task/viewTaskPage?id=".$task_id;
		$url = SrSecure::addEvKey($url);
		$content = '';
		$content .= "".$title."<BR>";
		$content .= "<B>项目</B>：".$project['name'].'<BR>';
		$content .= "<B>负责人</B>：".$manager['name'].' '.$manager['mobile'].' '.$manager['mail']."<BR>";
		$content .= "<B>任务创建人</B>：".$create_user['name'].' '.$create_user['mobile'].' '.$create_user['mail']."<BR>";
		$content .= "<B>任务地址</B>：<a href='{$url}' target='_blank'>{$url}</a><BR>";
		$content2 = $task['content'];
		if($content2!=null&&$content2!=''){
			$content .= "<B>邮件内容</B>：<BR>{$content2}<BR>";
		}
		$url2 = $task['url'];
		if($url2!=null&&$url2!=''){
			$content .= "<B>任务详情页面</B>：<a href='{$url2}' target='_blank'>{$url2}</a><BR>";
		}

		$content .= '<HR>注意:对任务有疑问请直接联系任务创建人!';
		//dump($spModel);halt();

		//dump($us);halt();
		foreach($us as $user_id){
			if($user_id==null||$user_id==''||$user_id=='0'){
				continue;
			}
			SrNotify::notifyUser(array(
				'target_user_id'=>$user_id,
				'notify_type'=>'010',
				'subject'=>$title,
				'content'=>$content,
				'dup_notify'=>'0',
				'table_name'=>'pmt_task',
				'table_code'=>$task_id,
			));
		}
		$srModel = array();
		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	//获取任务的留言信息
	function getTaskSrMessage($spModel){
		$id = $spModel["id"];
		$sql = "select * from pmt_message_re t where t.table_id='{0}' and t.table_name='{1}' /*w[t]*/ order by t.id asc";
		$list = self::queryBySql($sql,array($id,"pmt_task"));
		$srModel = array();
		$srModel['message_sr_list'] = $list;

		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	function getTaskInfo($spModel){
		$id = $spModel["id"];
		$to_day = Sr::sys_date();

		$need_tsheet = $spModel["need_tsheet"];//1表示查询工时信息

		$srModel = array();
		$sql = "select * from pmt_task_follow t where t.task_id='{0}' /*w[t]*/ order by id asc";
		$model = self::getRowBySql($sql,array($id));
		if($model!=null){
			$srModel['module_follow_id'] = $model['module_follow_id'];
			$srModel['follow_task_id'] = $model['follow_task_id'];
		}
		if($need_tsheet=='1'){
			$sql = "select distinct t.* from pmt_task_tsheet t where t.occure_date='{0}' and t.task_id={1} /*w[t]*/";
			$srModel['array_tsheet'] = self::queryBySql($sql,array($to_day,$id));
			$tt = array();
			foreach($srModel['array_tsheet'] as $key=>$item){
				if(!in_array($item['belong_user_id'],$tt)){
					$tt[] = $item['belong_user_id'];
					if($item['belong_user_id']==SrUser::getUserId()){
						//自己也参与处理
						$srModel['tsheet_my_deail'] = '1';
					}
					$srModel['array_tsheet_member_bar'] .= Sr::sys_dictTableById('uup_user',$item['belong_user_id'],'name').' ';

				}
			}
		}


		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	public function getTaskInfo2($spModel) {
		$list = $spModel['list'];
		$sql = "SELECT t.task_id,t.module_follow_id,t.follow_task_id
			 FROM pmt_task_follow t
			 WHERE t.task_id IN({-1})  {$where2} /*w[t]*/
			 ";

		$srModel['list'] = self::addListItemInfo(
			 $list,
			 "task_id",
			 "task_id",
			 "",
			 $sql,
			 array()
		);

		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	function fillTaskInfo($spModel){
		$module_follow_id = $spModel['module_follow_id'];
		$follow_task_id = $spModel['follow_task_id'];
		$id = $spModel["id"];
		$srModel = array();

		$found = false;
		$sql = "select * from pmt_task_follow t where t.task_id='{0}'/*w[t]*/";
		$list = self::queryBySql($sql,array($id));
		$foundModel = null;
		//只有一条类型可以保留,其他都需要删除
		foreach($list as $k=>$model){
			if($model['module_follow_id']==$module_follow_id){
				$found = true;
				$foundModel = $model;
			}else{
				$model['is_deleted'] = '1';
				self::update2($model['id'],$model,'pmt_task_follow');
			}
		}
		//有后续处理类型
		if($module_follow_id!=null && $module_follow_id!=''){
			//如果没有找到,则新增
			if($found===false){
				$model = array();
				$model['task_id'] = $id;
				$model['module_follow_id'] = $module_follow_id;
				$model['follow_task_id'] = $follow_task_id;
				self::insert2($model,'pmt_task_follow');
			}else{
				$foundModel['follow_task_id'] = $follow_task_id;
				self::update2($foundModel['id'],$foundModel,'pmt_task_follow');
			}
		}
		self :: addInfoResults($srModel, null);
		return $srModel;
	}

	//是否是Task的管理者(项目经理/模块负责人/任务负责人)
	//$flag = self::getValue_invokeBusiness("AppTaskBusiness","isTaskManager",array('task_id'=>$id),'Pmt','flag');
	function isTaskManager($spModel){
		$task_id = $spModel['task_id'];
		$srModel = array();

		$user_id = SrUser::getUserId();
		$task = self::queryById2($task_id,"pmt_task");
		$module = self::queryById2($task['module_id'],"pmt_module");
		$project = self::queryById2($task['project_id'],"pmt_project");

		if($project['manager_id']==$user_id ||$project['config_user_id']==$user_id|| $module['manager_id']==$user_id || $task['manager_id']==$user_id){
			$srModel['flag'] = '1';
		}else{
			$srModel['flag'] = '0';
		}
		self :: addInfoResults($srModel, null);
		return $srModel;
	}
	//是否是Task的商机管理者(项目经理/模块负责人)
	function isTaskUpperManager($spModel){
		$task_id = $spModel['task_id'];
		$srModel = array();

		$user_id = SrUser::getUserId();

		$task = self::queryById2($task_id,"pmt_task");
		$module = self::queryById2($task['module_id'],"pmt_module");
		$project = self::queryById2($task['project_id'],"pmt_project");
		if($project['manager_id']==$user_id ||$project['config_user_id']==$user_id || $module['manager_id']==$user_id){
			$srModel['flag'] = '1';
		}else{
			$srModel['flag'] = '0';
		}
		self :: addInfoResults($srModel, null);
		return $srModel;
	}
}
?>
