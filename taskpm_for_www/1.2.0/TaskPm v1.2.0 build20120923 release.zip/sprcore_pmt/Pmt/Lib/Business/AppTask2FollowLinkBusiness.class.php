<?php
class AppTask2FollowLinkBusiness extends SrService{	

}
?>
