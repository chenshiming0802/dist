<?php
class AppPmtDocumentBusiness extends SrService{	
	//删除文档
	public function deleteDocument($spModel) {	

		$srModel = array();
		$document_id = $spModel['document_id'];
		$table_id = $spModel['table_id'];
		$table_name = $spModel['table_name'];
 		$sql = "select * from pmt_document_link t where t.document_id='{0}' and t.table_id='{1}' and t.table_name='{2}' /*w[t]*/";
 		$model = self::getRowBySql($sql,array(
 				$document_id,$table_id,$table_name
 			));
		if($model!=null){
	 		$model["is_deleted"] = "1";
			self::update2($model['id'],$model,'pmt_document_link'); 			
 		}else{
 			throw_exception(Sr::sys_l("message.exception.dbmodel.not.found",array("Document",$document_id)));
 		}
		self :: addInfoResults($srModel, null);
		return $srModel;
	}	
}
?>
