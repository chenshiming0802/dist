<?php
class AppModuleBusiness extends SrService{	
	// 
	function isModuleManager($spModel){
		$module_id = $spModel['module_id'];
		$srModel = array();
		
		$user_id = SrUser::getUserId();	
		$module = self::queryById2($module_id,"pmt_module");
		$project = self::queryById2($module['project_id'],"pmt_project");		
		if($project['manager_id']==$user_id || $module['manager_id']==$user_id){
			$srModel['flag'] = '1';
		}else{
			$srModel['flag'] = '0';
		}	
		self :: addInfoResults($srModel, null);	
		return $srModel;				
	}	
	// 
	function isModuleUpperManager($spModel){
		$module_id = $spModel['module_id'];
		$srModel = array();
		
		$user_id = SrUser::getUserId();
		
		$module = self::queryById2($module_id,"pmt_module");
		$project = self::queryById2($module['project_id'],"pmt_project");		
		
		if($project['manager_id']==$user_id){
			$srModel['flag'] = '1';
		}else{
			$srModel['flag'] = '0';
		}	
		self :: addInfoResults($srModel, null);	
		return $srModel;				
	}	
}
?>
