<?php
class AppProject2ContentBusiness extends SrService{	

}
?>
