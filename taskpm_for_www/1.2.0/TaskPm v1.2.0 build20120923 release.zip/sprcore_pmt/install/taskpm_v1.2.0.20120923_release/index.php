<?php

    require_once("settings.inc");    
	
	/*
    if (file_exists($config_file_path)) {        
		header("location: ".$application_start_file);
        exit;
	}
	*/
	assertInstall($application_name,$config_file_path,$application_start_file);
        
    ob_start();
    phpinfo(-1);
    $phpinfo = array('phpinfo' => array());
    if(preg_match_all('#(?:<h2>(?:<a name=".*?">)?(.*?)(?:</a>)?</h2>)|(?:<tr(?: class=".*?")?><t[hd](?: class=".*?")?>(.*?)\s*</t[hd]>(?:<t[hd](?: class=".*?")?>(.*?)\s*</t[hd]>(?:<t[hd](?: class=".*?")?>(.*?)\s*</t[hd]>)?)?</tr>)#s', ob_get_clean(), $matches, PREG_SET_ORDER))
    foreach($matches as $match){
        if(strlen($match[1]))
            $phpinfo[$match[1]] = array();
        elseif(isset($match[3]))
            $phpinfo[end(array_keys($phpinfo))][$match[2]] = isset($match[4]) ? array($match[3], $match[4]) : $match[3];
        else
            $phpinfo[end(array_keys($phpinfo))][] = $match[2];
    }

    
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>Installation Guide</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="img/styles.css">
</head>
<style>
.ok{color:green;font-size:13px;}
.fail{color:red;font-weight:bold;font-size:13px;}
.warn{color:#cccc33;font-weight:bold;font-size:13px;}
</style>
<BODY text=#000000 vLink=#2971c1 aLink=#2971c1 link=#2971c1 bgColor=#ffffff>
    
<TABLE align="center" width="70%" cellSpacing=0 cellPadding=2 border=0>
<TBODY>
<TR>
    <TD class=text vAlign=top>
        <H2><?=$application_name.'('.$version.')';?> 安装步骤 1/3</H2>
        <TABLE width="100%" cellSpacing=0 cellPadding=0 border=0>
        <TBODY>
        <TR>
            <TD>
                <TABLE width="100%" cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                <TR>
                    <TD></TD>
                    <TD align=middle>
                        <TABLE width="100%" cellSpacing=0 cellPadding=0 border=0>
                        <TBODY>
                        <TR>
                            <TD class=text align=left>
								<b>系统要求:</b>
                            </TD>
                        </TR>
                        <tr>
                            <TD class=text align=left>
                                <UL>                            
                                    <LI>PHP version : 5.3或以上版本</li>
                                    <LI>Apache : 2.0或以上版本</li>
                                    <LI>MySql : 5.0或以上版本</li>
								</UL>
							</TD>
                        </TR>
						</TBODY>
                        </TABLE>
						<BR>

                        <TABLE width="100%" cellSpacing=0 cellPadding=0 border=0>
                        <TBODY>
                        <TR>
                            <TD class=text align=left>
								<b>当前服务器相关信息</b>
                            </TD>
                        </TR>
                        <tr>
                            <TD class=text align=left>
                                <UL>
									<LI>System: <?=$phpinfo['phpinfo']['System'];?></li>                                    
                                    <LI>PHP version: <?=$phpinfo['phpinfo']['PHP Version'];?></li>
                                    <LI>Server API: <?=$phpinfo['phpinfo']['Server API'];?></li>
                                    <LI>Safe Mode: <?=$phpinfo['PHP Core']['safe_mode'][0];?></li>
								</UL>
							</TD>
                        </TR>
						</TBODY>
                        </TABLE>
						<br />

						
                        <TABLE width="100%" cellSpacing=0 cellPadding=0 border=0>
                        <TBODY>
                        <TR>
                            <TD class=text align=left>
								<b>安装环境检查</b>
                            </TD>
                        </TR>
                        <tr>
                            <TD class=text align=left>
                                <UL>
									<?php $canInstall = checkInstallInfo();?>                                   
								</UL>
							</TD>
                        </TR>
						</TBODY>
                        </TABLE>

                        <table width="100%" border="0" cellspacing="0" cellpadding="2" class="main_text">
                        <tr>
                            <td colspan=2 align='left'>
								<?php if($canInstall===true){?>
                                <input type="button" class="form_button" value="开始安装" name="submit" title="Click to start installation" onclick="document.location.href='install.php'">
								<?php }else{?>
								不能安装
								<?php }?>
                            </td>
                        </table>

					</TD>
                    <TD></TD>
                </TR>
                </TBODY>
                </TABLE>

            </TD>
        </TR>
        </TBODY>
        </TABLE>

        <? include_once("footer.php"); ?>        
    </TD>
</TR>
</TBODY>
</TABLE>
                  
</body>
</html>

