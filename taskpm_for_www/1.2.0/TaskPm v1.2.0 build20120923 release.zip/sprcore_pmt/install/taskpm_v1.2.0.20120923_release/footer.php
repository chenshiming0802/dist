<TABLE cellSpacing=0 cellPadding=0 width=200 border=0>
<TBODY>
<tr><td height=20></td></tr>
<TR>
    <TD bgColor=#d6d6d6><IMG height=1 alt="" src="img/free.gif" width=1 border=0></TD>
</TR>
<TR><TD height=7></TD></TR>
</TBODY>
</TABLE>

  <SPAN style="COLOR: #bb5500"><a href='http://www.sprcore.com'>www.sprcore.com</a>&nbsp;&nbsp;来自Sprcore小组
<? if($license_agreement_page != ""){ ?>
    <A href="<?=$license_agreement_page;?>" target=_blank>License</A>
<? } ?>
