<?php

    require_once("settings.inc");    
    
	assertInstall($application_name,$config_file_path,$application_start_file);

       
?>	


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>Installation Guide</title>
	<script type="text/javascript" src="../../Webdocs/Spr1.1/js/jquery-1.7.1.min.js"></script>
	<script type="text/javascript" src="../../Webdocs/Spr1.1/js/function_addition.js"></script>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="img/styles.css">
</head>
<script type="text/javascript">
<!--
	$(function(){  
		
		$('#send_mail_config_163').bind('click',function(){
			$('#div_send_mail_config').css('display','none');
			$('#div_receive_mail_config').css('display','none');
			$('#div_send_mail_config_163').css('display','block');
			var address = $("#mail_type_163_address").val();
			var password = $("#mail_type_163_password").val();
			$("input[name='_MAIL_SEND_ADDRESS_']").val(address);
			$("input[name='_MAIL_SEND_ADDRESS_']").val(address);
			$("input[name='_MAIL_SMTP_SERVER_']").val('smtp.163.com');
			$("input[name='_MAIL_SMTP_PORT_']").val('25');
			$("input[name='_MAIL_LOGIN_NAME_']").val(address);
			$("input[name='_MAIL_LOGIN_PSD_']").val(password);

			$("input[name='_IMAP_RECEIVE_SERVER_TYPE_']").val('pop3');
			$("input[name='_IMAP_RECEIVE_SERVER_PORT_']").val('110');
			$("input[name='_IMAP_RECEIVE_ADDRESS_']").val(address);
			$("input[name='_IMAP_RECEIVE_PASSWORD_']").val(password);
			$("input[name='_IMAP_RECEIVE_SERVER_']").val('pop.163.com');
		});
		$('#mail_type_163_address,#mail_type_163_password').bind('change',function(){
			$('#send_mail_config_163').attr('checked','true');
			$('#send_mail_config_163').click();
		});
		$('#send_mail_config_other').bind('click',function(){
			$('#div_send_mail_config').css('display','block');
			$('#div_receive_mail_config').css('display','block');
			$('#div_send_mail_config_163').css('display','none');

			$("input[name='_MAIL_SEND_ADDRESS_']").val('');
			$("input[name='_MAIL_SMTP_SERVER_']").val('');
			$("input[name='_MAIL_SMTP_PORT_']").val('25');
			$("input[name='_MAIL_LOGIN_NAME_']").val('');
			$("input[name='_MAIL_LOGIN_PSD_']").val('');

			$("input[name='_IMAP_RECEIVE_SERVER_TYPE_']").val('pop3');
			$("input[name='_IMAP_RECEIVE_SERVER_PORT_']").val('110');
			$("input[name='_IMAP_RECEIVE_ADDRESS_']").val('');
			$("input[name='_IMAP_RECEIVE_PASSWORD_']").val('');
			$("input[name='_IMAP_RECEIVE_SERVER_']").val('');
		});

		//默认是选择163邮箱
		$('#send_mail_config_163').attr('checked','true');
		$('#send_mail_config_163').click();
	});
 
//-->
</script>

<BODY text=#000000 vLink=#2971c1 aLink=#2971c1 link=#2971c1 bgColor=#ffffff>
<form method="post" action="install2.php" name='ff' id='idff'>
    
<TABLE align="center" width="70%" cellSpacing=0 cellPadding=2 border=0>
<TBODY>
<TR>
    <TD class=text vAlign=top>
        <H2><?=$application_name.'('.$version.')';?> 安装步骤 2/3</H2>
        <TABLE width="100%" cellSpacing=0 cellPadding=0 border=0>
        <TBODY>
        <TR>
            <TD>
                <TABLE width="100%" cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                <TR>
                    <TD></TD>
                    <TD align=middle>
                        <TABLE width="100%" cellSpacing=0 cellPadding=0 border=0>
                        <TBODY>
                        <TR>
                            <TD class=text align=left>
								<b>Step 1. 数据库配置</b>
                            </td>
                        </tr>
                        </tbody>
                        </table>
                        <br />
                        
                        <input type="hidden" name="submit2" value="step2" />
                        <table class=text width="100%" border="0" cellspacing="0" cellpadding="2" class="main_text">
                        <tr>
                            <tr>
                                <td width='100px'>&nbsp;数据库地址</td>
                                <td>
                                    <input type="text" class="form_text" name="database_host" value='localhost' size="30">
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;数据库表空间</td>
                                <td>
                                    <input type="text" class="form_text" name="database_name" size="30" value="<?= $database_name ?>">
									(数据库中表空间需要存在，为避免乱码表空间建议是utf8编码)<BR>
									创建表空间命令: CREATE DATABASE 表空间名 CHARACTER SET utf8 COLLATE utf8_unicode_ci;
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;数据库帐号</td>
                                <td>
                                    <input type="text" class="form_text" name="database_username" size="30" value="<?= $database_username ?>">
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;数据库密码</td>
                                <td>
                                    <input type="text" class="form_text" name="database_password" size="30" value="<?= $database_password ?>">
                                </td>
                            </tr>
							<tr>
                                <td>&nbsp;导入Demo数据</td>
                                <td>
                                    <input type="checkbox" name="import_demo_data" value='1' checked>
                                </td>
                            </tr>
                            <tr>
                                <td colspan=2>&nbsp;</td>
                            </tr>

                        
                        </table>
						<br />						

					</TD>
                    <TD></TD>
                </TR>

                <TR>
                    <TD></TD>
                    <TD align=middle>
                        <TABLE width="100%" cellSpacing=0 cellPadding=0 border=0>
                        <TBODY>
                        <TR>
                            <TD class=text align=left>
								<b>Step 2. 系统配置</b>
                            </td>
                        </tr>
                        </tbody>
                        </table>
                        <br />
                        
                        <table class=text width="100%" border="0" cellspacing="0" cellpadding="2" class="main_text">
                        <tr>
                            <tr>
                                <td width='100px'>&nbsp;系统名</td>
                                <td>
                                    <input type="text" class="form_text" name="spr_app_tnane" value='' size="30">
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;附件保存地址</td>
                                <td>
                                    <input type="text" class="form_text" name="file_base_root" size="100" value="<?= $database_name ?>">
									<BR>附件保存地址,最后以斜杠结尾，填写格式如： d:\www\
                                </td>
                            </tr>                    
                        </table>
                                                
						<br />						

					</TD>
                    <TD></TD>
                  </TR>
                 <TR>
                    <TD></TD>
                    <TD align=middle>
                        <TABLE width="100%" cellSpacing=0 cellPadding=0 border=0>
                        <TBODY>
                        <TR>
                            <TD class=text align=left>
								<b>Step3.发送邮件和接受邮件邮箱地址配置</b>
                            </td>
                        </tr>
                        </tbody>
                        </table>
                        <br />
                        
                        <table class=text width="100%" border="0" cellspacing="0" cellpadding="2" class="main_text">
                        <tr>
							<tr>
                               <td>
                                    <input type="radio" name="mail_type" id='send_mail_config_163' value='163'>163邮箱&nbsp;&nbsp;<B>[推荐]</B>&nbsp;&nbsp;
									<span id='div_send_mail_config_163'>
									账号:<input type="text" class="form_text" id="mail_type_163_address" value='@163.com' size="50">
									密码:<input type="password" class="form_text" id="mail_type_163_password" value='' size="10">
									<a href='http://mail.163.com/' target='_blank'>没有账号</a>
									</span>
                                </td>
							</tr>
							<tr>
                                <td>
                                    <input type="radio" name="mail_type"  id='send_mail_config_other' value='other'>其他邮箱&nbsp;&nbsp;
                                </td>
                            </tr>   						
                        </table>
                                                
						<br />						

					</TD>
                    <TD></TD>
                  </TR>
                 <TR>
                    <TD></TD>
                    <TD align=middle id='div_send_mail_config'>
                        <TABLE width="100%" cellSpacing=0 cellPadding=0 border=0>
                        <TBODY>
                        <TR>
                            <TD class=text align=left>
								<b>3.1邮箱发送地址配置</b>
                            </td>
                        </tr>
                        </tbody>
                        </table>
                        <br />
                        
                        <table class=text width="100%" border="0" cellspacing="0" cellpadding="2" class="main_text">
                        <tr>
                            <tr>
                                <td width='100px'>&nbsp;邮箱发送地址</td>
                                <td>
                                    <input type="text" class="form_text" name="_MAIL_SEND_ADDRESS_" value='' size="30">如：sprcore_server@163.com
                                </td>
                            </tr>   
                            <tr>
                                <td width='100px'>&nbsp;SMTP服务器</td>
                                <td>
                                    <input type="text" class="form_text" name="_MAIL_SMTP_SERVER_" value='' size="30">如：smtp.163.com
                                </td>
                            </tr>							
                           <tr>
                                <td width='100px'>&nbsp;SMTP服务器端口</td>
                                <td>
                                    <input type="text" class="form_text" name="_MAIL_SMTP_PORT_" value='' size="30">
                                </td>
                            </tr>							
                           <tr>
                                <td width='100px'>&nbsp;邮箱帐号</td>
                                <td>
                                    <input type="text" class="form_text" name="_MAIL_LOGIN_NAME_" value='' size="30">如：sprcore_server@163.com
                                </td>
                            </tr>							
                           <tr>
                                <td width='100px'>&nbsp;邮箱密码</td>
                                <td>
                                    <input type="text" class="form_text" name="_MAIL_LOGIN_PSD_" value='' size="30">
                                </td>
                            </tr>							
                        </table>
                                                
						<br />						

					</TD>
                    <TD></TD>
                  </TR>

                <TR>
                    <TD></TD>
                    <TD align=middle  id='div_receive_mail_config'>
                        <TABLE width="100%" cellSpacing=0 cellPadding=0 border=0>
                        <TBODY>
                        <TR>
                            <TD class=text align=left>
								<b>3.2邮箱发送接收配置</b>
                            </td>
                        </tr>
                        </tbody>
                        </table>
                        <br />
                        
                        <table class=text width="100%" border="0" cellspacing="0" cellpadding="2" class="main_text">
                        <tr>
                            <tr>
                                <td width='100px'>&nbsp;接收邮箱账号</td>
                                <td>
                                    <input type="text" class="form_text" name="_IMAP_RECEIVE_ADDRESS_" value='' size="30">如：sprcore_server@163.com
                                </td>
                            </tr>                
                            <tr>
                                <td width='100px'>&nbsp;接收邮箱密码</td>
                                <td>
                                    <input type="text" class="form_text" name="_IMAP_RECEIVE_PASSWORD_" value='' size="30">
                                </td>
                            </tr>                
                            <tr>
                                <td width='100px'>&nbsp;接收邮箱服务器</td>
                                <td>
                                    <input type="text" class="form_text" name="_IMAP_RECEIVE_SERVER_" value='' size="30">如：pop.163.com
                                </td>
                            </tr>                
                             <tr>
                                <td width='100px'>&nbsp;邮件接收类型</td>
                                <td>
                                    <input type="text" class="form_text" name="_IMAP_RECEIVE_SERVER_TYPE_" value='' size="30">
                                </td>
                            </tr>                
                             <tr>
                                <td width='100px'>&nbsp;端口</td>
                                <td>
                                    <input type="text" class="form_text" name="_IMAP_RECEIVE_SERVER_PORT_" value='' size="30">
                                </td>
                            </tr>                               
                        </table>
                                                
						<br />						

					</TD>
                    <TD></TD>
                  </TR>

				<tr>
					<td colspan=2 align='left'>
		<input type="button" class="form_button" name="btn_cancel" value="  返 回  " onclick="document.location.href='index.php'">
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="button" onClick='o_window_submit(document.ff)' class="form_button" id="btn_submit" value="  下一步  "  >
					</td>
				</tr>
                </TBODY>
                </TABLE>

			
			
			</TD>
        </TR>
        </TBODY>
        </TABLE>
                
        <? include_once("footer.php"); ?>        
    </TD>
</TR>
</TBODY>
</TABLE>
</form>           
</body>
</html>
