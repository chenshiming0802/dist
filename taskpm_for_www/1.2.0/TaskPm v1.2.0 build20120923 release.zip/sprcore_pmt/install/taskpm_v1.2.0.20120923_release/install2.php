<?php

    require_once("settings.inc");    
    
	assertInstall($application_name,$config_file_path,$application_start_file);

    
	$completed = false;
	$error_mg  = array();	
	
	if ($_POST['submit2'] == "step2") {

		$database_host		= isset($_POST['database_host'])?$_POST['database_host']:"";
		$database_name		= isset($_POST['database_name'])?$_POST['database_name']:"";
		$database_username	= isset($_POST['database_username'])?$_POST['database_username']:"";
		$database_password	= isset($_POST['database_password'])?$_POST['database_password']:"";
		$import_demo_data	= isset($_POST['import_demo_data'])?$_POST['import_demo_data']:"0";

		$spr_app_tnane	= isset($_POST['spr_app_tnane'])?$_POST['spr_app_tnane']:"";
		$file_base_root	= isset($_POST['file_base_root'])?$_POST['file_base_root']:"";

		$_MAIL_SEND_ADDRESS_	= isset($_POST['_MAIL_SEND_ADDRESS_'])?$_POST['_MAIL_SEND_ADDRESS_']:"";
		$_MAIL_SMTP_SERVER_	= isset($_POST['_MAIL_SMTP_SERVER_'])?$_POST['_MAIL_SMTP_SERVER_']:"";
		$_MAIL_SMTP_PORT_	= isset($_POST['_MAIL_SMTP_PORT_'])?$_POST['_MAIL_SMTP_PORT_']:"";
		$_MAIL_LOGIN_NAME_	= isset($_POST['_MAIL_LOGIN_NAME_'])?$_POST['_MAIL_LOGIN_NAME_']:"";
		$_MAIL_LOGIN_PSD_	= isset($_POST['_MAIL_LOGIN_PSD_'])?$_POST['_MAIL_LOGIN_PSD_']:"";

		$_IMAP_RECEIVE_SERVER_TYPE_	= isset($_POST['_IMAP_RECEIVE_SERVER_TYPE_'])?$_POST['_IMAP_RECEIVE_SERVER_TYPE_']:"";
		$_IMAP_RECEIVE_SERVER_PORT_	= isset($_POST['_IMAP_RECEIVE_SERVER_PORT_'])?$_POST['_IMAP_RECEIVE_SERVER_PORT_']:"";
		$_IMAP_RECEIVE_ADDRESS_	= isset($_POST['_IMAP_RECEIVE_ADDRESS_'])?$_POST['_IMAP_RECEIVE_ADDRESS_']:"";
		$_IMAP_RECEIVE_PASSWORD_	= isset($_POST['_IMAP_RECEIVE_PASSWORD_'])?$_POST['_IMAP_RECEIVE_PASSWORD_']:"";
		$_IMAP_RECEIVE_SERVER_	= isset($_POST['_IMAP_RECEIVE_SERVER_'])?$_POST['_IMAP_RECEIVE_SERVER_']:"";
		
		if (empty($database_host)){
			$error_mg[] = "数据库地址不能为空，请重新填写！";	
		}
		
		if (empty($database_name)){
			$error_mg[] = "数据库表空间不能为空，请重新填写！";	
		}
		
		if (empty($database_username)){
			$error_mg[] = "数据库帐号不能为空，请重新填写！";	
		}
		
		if (empty($database_password)){
			$error_mg[] = "数据库密码不能为空，请重新填写！";	
		}

		if (empty($spr_app_tnane)){
			$error_mg[] = "系统名不能为空，请重新填写！";	
		}
		if (empty($file_base_root)){
			$error_mg[] = "附件保存地址不能为空，请重新填写！";	
		}
		
		if(empty($error_mg)){
		
			$config_file = file_get_contents($config_file_default);
			$config_file = str_replace("_DB_HOST_", $database_host, $config_file);
			$config_file = str_replace("_DB_NAME_", $database_name, $config_file);
			$config_file = str_replace("_DB_USER_", $database_username, $config_file);
			$config_file = str_replace("_DB_PASSWORD_", $database_password, $config_file);

			$config_file = str_replace("_SPR_APP_TNANE_", $spr_app_tnane, $config_file);
			$config_file = str_replace("_FILE_BASE_ROOT_", $file_base_root, $config_file);

			$config_file = str_replace("_MAIL_SEND_ADDRESS_", $_MAIL_SEND_ADDRESS_, $config_file);
			$config_file = str_replace("_MAIL_SMTP_SERVER_", $_MAIL_SMTP_SERVER_, $config_file);
			$config_file = str_replace("_MAIL_SMTP_PORT_", $_MAIL_SMTP_PORT_, $config_file);
			$config_file = str_replace("_MAIL_LOGIN_NAME_", $_MAIL_LOGIN_NAME_, $config_file);
			$config_file = str_replace("_MAIL_LOGIN_PSD_", $_MAIL_LOGIN_PSD_, $config_file);

			$config_file = str_replace("_IMAP_RECEIVE_SERVER_TYPE_", $_IMAP_RECEIVE_SERVER_TYPE_, $config_file);
			$config_file = str_replace("_IMAP_RECEIVE_SERVER_PORT_", $_IMAP_RECEIVE_SERVER_PORT_, $config_file);
			$config_file = str_replace("_IMAP_RECEIVE_ADDRESS_", $_IMAP_RECEIVE_ADDRESS_, $config_file);
			$config_file = str_replace("_IMAP_RECEIVE_PASSWORD_", $_IMAP_RECEIVE_PASSWORD_, $config_file);
			$config_file = str_replace("_IMAP_RECEIVE_SERVER_", $_IMAP_RECEIVE_SERVER_, $config_file);
			
			
			$link = @mysql_connect($database_host, $database_username, $database_password);
			if($link){					
				if (@mysql_select_db($database_name)) {                        
					if(false == ($db_error = apphp_db_install($database_name, $sql_dump))){
						$error_mg[] = "导入文件读取失败，请检查文件是否存在：".$sql_dump."!.";                            
					}else{
						// additional operations, like setting up admin passwords etc.
						// ...
						if($import_demo_data=='1'){
							apphp_db_install($database_name, $sql_demo_dump);
						}
						$completed = true;                            
					}
				} else {
					$error_mg[] = "数据库连接失败，请检查数据库表空间是否存在.</span><br/>";
				}
			} else {
				$error_mg[] = "数据库连接失败，可能是数据库没有启动或者是帐号密码错误</span><br/>";
			}		
		}
		
		if(empty($error_mg)){
			$f = @fopen($config_file_path, "w+");
			if (@fwrite($f, $config_file) > 0){
			} else {				
				$error_mg[] = "不能读取配置文件 ".$config_file_directory.$config_file_name;				
			}
			@fclose($f);	
		}
	}
        
?>	


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>Installation Guide</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="img/styles.css">
</head>


<BODY text=#000000 vLink=#2971c1 aLink=#2971c1 link=#2971c1 bgColor=#ffffff>
    
<TABLE align="center" width="70%" cellSpacing=0 cellPadding=2 border=0>
<TBODY>
<TR>
    <TD class=text vAlign=top>
        <H2><?=$application_name.'('.$version.')';?> 安装步骤 3/3</H2>
        <TABLE width="100%" cellSpacing=0 cellPadding=0 border=0>
        <TBODY>
        <TR>
            <TD>
                <TABLE width="100%" cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                <TR>
                    <TD></TD>
                    <TD align=middle>
                        <TABLE width="100%" cellSpacing=0 cellPadding=0 border=0>
                        <TBODY>
						<? if(!$completed){
							
							foreach($error_mg as $msg){
								echo "<tr><td class=text align=left><span style='color:#bb5500;'>&#8226; ".$msg."</span></td></tr>";
							}
						?>
							<tr><td>&nbsp;</td></tr>
							<tr>
								<td class=text align=left>	
									<input type="button" class="form_button" value="  返 回  " name="submit" onclick="javascript: history.go(-1);">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
									<input type="button" class="form_button" value="  重 试  " name="submit" onclick="javascript: location.reload();">
								</td>
							</tr>
							
						<? } else {?>
							<tr><td>&nbsp;</td></tr>
							<TR>
								<TD class=text align=left>
									<b>Step 2. 安装已经完成</b>
								</td>
							</tr>
							<tr><td>&nbsp;</td></tr>	
							<tr>
								<TD class=text align=left>
									系统配置文件已经生成： <?=$config_file_path;?> .
									<br />
									系统初始帐号:<?=$sys_default_user;?>
									<br />
									系统初始密码:<?=$sys_default_password;?>
									<br />
									<span style='color:#bb5500;'>
										<b>!!! 处于安全原因, 请删除 /install 目录.</b>
									</span>
									<br /><br />
									<? if($application_start_file != ""){ ?><A href="<?=$application_start_file;?>">点击进入系统</A><? } ?>
								</td>
							</tr>
							<iframe src='../../clear.php' width='0' height='0'></iframe>
						
						<? } ?>
                        </tbody>
                        </table>
                        <br />                        

					</TD>
                    <TD></TD>
                </TR>
                </TBODY>
                </TABLE>
            </TD>
        </TR>
        </TBODY>
        </TABLE>
				
		<? include_once("footer.php"); ?>        
    </TD>
</TR>
</TBODY>
</TABLE>
                  
</body>
</html>





<? 
  function apphp_db_install($database, $sql_file) {
    global $link;
	mysql_query("SET NAMES 'UTF8'" ,$link);
	$sql_data = file_get_contents($sql_file);
	$ss = explode("\n",$sql_data);
	foreach($ss as $line){
		mysql_query($line,$link);
		//echo $line."<BR>";
	};	
	return true;
  }
	 

  function apphp_db_install2($database, $sql_file) {
    $db_error = false;

    if (!@apphp_db_select_db($database)) {
      if (@apphp_db_query('create database ' . $database)) {
        apphp_db_select_db($database);
      } else {
        $db_error = mysql_error();
        return false;		
      }
    }

    if (!$db_error) {
      if (file_exists($sql_file)) {
        $fd = fopen($sql_file, 'rb');
        $restore_query = fread($fd, filesize($sql_file));
         fclose($fd);
      } else {
          $db_error = '导入数据库文件不存在: ' . $sql_file;
          return false;
      }
		
      $sql_array = array();
      $sql_length = strlen($restore_query);
      $pos = strpos($restore_query, ';');
      for ($i=$pos; $i<$sql_length; $i++) {
        if ($restore_query[0] == '#') {
          $restore_query = ltrim(substr($restore_query, strpos($restore_query, "\n")));
          $sql_length = strlen($restore_query);
          $i = strpos($restore_query, ';')-1;
          continue;
        }
        if ($restore_query[($i+1)] == "\n") {
          for ($j=($i+2); $j<$sql_length; $j++) {
            if (trim($restore_query[$j]) != '') {
              $next = substr($restore_query, $j, 6);
              if ($next[0] == '#') {
                // find out where the break position is so we can remove this line (#comment line)
                for ($k=$j; $k<$sql_length; $k++) {
                  if ($restore_query[$k] == "\n") break;
                }
                $query = substr($restore_query, 0, $i+1);
                $restore_query = substr($restore_query, $k);
                // join the query before the comment appeared, with the rest of the dump
                $restore_query = $query . $restore_query;
                $sql_length = strlen($restore_query);
                $i = strpos($restore_query, ';')-1;
                continue 2;
              }
              break;
            }
          }
          if ($next == '') { // get the last insert query
            $next = 'insert';
          }
          if ( (eregi('create', $next)) || (eregi('insert', $next)) || (eregi('drop t', $next)) ) {
            $next = '';
            $sql_array[] = substr($restore_query, 0, $i);
            $restore_query = ltrim(substr($restore_query, $i+1));
            $sql_length = strlen($restore_query);
            $i = strpos($restore_query, ';')-1;
          }
        }
      }

      for ($i=0; $i<sizeof($sql_array); $i++) {
		apphp_db_query($sql_array[$i]);
      }
      return true;
    } else {
      return false;
    }
  }

  function apphp_db_select_db($database) {
    return mysql_select_db($database);
  }

  function apphp_db_query($query) {
    global $link;
    $res=mysql_query($query, $link);
    return $res;
  }

?>