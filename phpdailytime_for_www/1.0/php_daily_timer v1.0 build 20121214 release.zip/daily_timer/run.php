<?php
require 'function.php';
daily_timer_process();
?>